package com.ihr.oea.comparator.quest

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.count

import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import com.ihr.oea.util.ComparatorUtil

class QuestAddMapWorklist {

  val log = Logger.getLogger(getClass.getName)
  def generateQuestAddMapWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {
      log.info("Running data comparator for ADD Map worklist for quest releaseId : " + releaseID)
      log.info("loading add codes for quest releaseId : " + releaseID)

      val mongoDAO = new MongoDAO
      log.info("Finding  distinct taxonomies in release data for quest releaseId : " + releaseID)
      val addWorkListData = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.WORKLIST_ITEMS)
        .filter(col(SparkSQLConstants.RELEASE_ID) === releaseID && col(SparkSQLConstants.WORKLIST_TYPE) === GlobalConstants.ADD_CODES)

      // Find the distinct taxonomies in the release from the MongoDB
      val util = new ComparatorUtil
      val questutil = new QuestCompareUtil
      var taxonomyStack = util.findDistinctTaxonomy(addWorkListData)
      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING

      while (taxonomyStack.nonEmpty) {
        val taxonomyName = taxonomyStack.pop
        try {
          val workListID = questutil.getWorklistID(addWorkListData, taxonomyName)
          val sourceAddCodesDF = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.WORKLIST_ITEMS)
            .filter(col(SparkSQLConstants.WORKLIST_ID) === workListID)

          log.info("generating add direct map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
          // ADD Direct Map codes
          worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_DIRECT_MAP
          val addDirectCodes = questutil.generateQuestMapData(taxonomyName, sourceAddCodesDF, GlobalConstants.ADD_CODES, spark, oesConfiguration, releaseID)
            .select(
              SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.TYPE,
              SparkSQLConstants.PREFERRED_TERM,
              SparkSQLConstants.LOINC_CODE,
              SparkSQLConstants.CPT_CODE,
              SparkSQLConstants.EFFECTIVE_TIME,
              SparkSQLConstants.IHR_MAP,
              SparkSQLConstants.MATCH_TYPE,
              SparkSQLConstants.MATCH_VALUE,
              SparkSQLConstants.SUPER_CLASS_STATUS)
            .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
            .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
            .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
            .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_DIRECT_MAP))
            .dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)
            .cache()
          //writing add data into mongo
          log.info("saving  add direct map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
          mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addDirectCodes)
          log.info("saved successfully add direct map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID+addDirectCodes.count())
          // ADD Unmatched Map codes
          log.info("generating add Unmatched map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
          worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_UNMATCHED
          val addUnmachedCodes = sourceAddCodesDF.join(addDirectCodes, addDirectCodes(SparkSQLConstants.CONCEPT_ID) === sourceAddCodesDF(SparkSQLConstants.CONCEPT_ID),
            SparkSQLConstants.ANTI_LEFT_JOIN).select(
              SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.TYPE,
              SparkSQLConstants.PREFERRED_TERM,
              SparkSQLConstants.LOINC_CODE,
              SparkSQLConstants.CPT_CODE,
              SparkSQLConstants.EFFECTIVE_TIME)
            .withColumn(SparkSQLConstants.IHR_MAP, lit(GlobalConstants.DEFAULT_NO_MAP))
            .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.MANUALLY_PROCESSED))
            .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
            .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
            .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_UNMATCHED))
          //writing add data into mongo
          log.info("saving  add Unmatched map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
          mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addUnmachedCodes)
          log.info("saved successfully add Unmatched map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
          count += 1
        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator taxonomy " + taxonomyName + " for Add Map Worklist for quest releaseId : " + releaseID)
            log.error(e.printStackTrace())
        }
      }
      log.info("Completed data comparator for Add Map Worklists for quest releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for Add Map Worklists for quest releaseId : " + releaseID)
        log.error(e.printStackTrace())
      //throw e
    }
  }
}