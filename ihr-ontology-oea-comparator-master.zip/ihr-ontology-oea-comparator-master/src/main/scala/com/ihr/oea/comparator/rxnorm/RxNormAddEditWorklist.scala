package com.ihr.oea.comparator.rxnorm

import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.Stack
import scala.collection.mutable.WrappedArray
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.udf
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import com.ihr.oea.util.ComparatorUtil
import java.util.ArrayList
import org.apache.spark.sql.types.ArrayType
import org.apache.spark.sql.Column


class RxNormAddEditWorklist {
  val log = Logger.getLogger(getClass.getName)


  def buildReleaseConceptsSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.RELEASE_ID, StringType, true),
        StructField(SparkSQLConstants.RXCUI, StringType, true),
        StructField(SparkSQLConstants.SYNONYM, ArrayType(StringType), true),
        StructField(SparkSQLConstants.SAB, StringType, true),
        StructField(SparkSQLConstants.TTY, StringType, true),
        StructField(SparkSQLConstants.SUPPRESS, StringType, true),
        StructField(SparkSQLConstants.NDCCODE, StringType, true),
        StructField(SparkSQLConstants.UNIICODE, StringType, true),
        StructField(SparkSQLConstants.EFFECTIVETIME, StringType, true),
        StructField(SparkSQLConstants.STR, StringType, true)))
    schema
  }
  


  def generateRxNormAddEditWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {
      log.info("Running data comparator for ADD worklist for rxnorm releaseId : " + releaseID)
      log.info("loading release concepts from db for rxnorm releaseId : " + releaseID)
      val mongoDAO = new MongoDAO
      val releaseConcepts = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE, oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.RELEASE_CONCEPTS)
        .schema(buildReleaseConceptsSchema())
        .load().filter(col(SparkSQLConstants.RELEASE_ID) === releaseID )

     
      log.info("generating the source path for Rxnorm releaseId : " + releaseID)
      var sourceAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SOURCE_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
      if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE))
        sourceAnnotationBasePath = sourceAnnotationBasePath.substring(5)

      
      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING

        try {
          var srcAnnotationFileName = GlobalConstants.rxnormSourceAnnotationMap
          if (null != srcAnnotationFileName) {
            log.info("Loading source annotation data for RxNorm releaseId : " + releaseID)
            var sourceData = spark.read
              .format(GlobalConstants.CSV_FORMAT)
              .option(GlobalConstants.HEADER, true)
              .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
              .load(sourceAnnotationBasePath + srcAnnotationFileName)


              



            val releaseData = releaseConcepts
            
            // ADD codes
            log.info("generating add code work list data for rxnorm releaseId : " + releaseID)
            
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_CODES
            
            val addCodes = releaseData.join(sourceData, sourceData(SparkSQLConstants.IDENTIFIER) === releaseData(SparkSQLConstants.RXCUI), SparkSQLConstants.ANTI_LEFT_JOIN)
            
            var addCodesWorklist = addCodes.select(SparkSQLConstants.RXCUI,SparkSQLConstants.STR,
                SparkSQLConstants.UNIICODE,SparkSQLConstants.EFFECTIVETIME)
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.CONCEPT_ID, col(SparkSQLConstants.RXCUI))
              .withColumn(SparkSQLConstants.TAXONOMYFSN, lit(GlobalConstants.RXNORMFSN))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_CODES))
              
            //writing add data into mongo
            log.info("saving  add code work list data for rxnorm releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addCodesWorklist.distinct())
            log.info("saved successfully add code work list data for rxnorm releaseId : " + releaseID)
           
          } else {
            log.info("No SrcAnnotation mapping is found")
          }
        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator for ADD/EDIT worklist for rxnorm releaseId : " + releaseID)
             log.error(e.printStackTrace())
        }
      
      log.info("Completed data comparator for ADD/EDIT Worklist for rxnorm releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for ADD/EDIT worklist for rxnorm releaseId : " + releaseID)
         log.error(e.printStackTrace())
      //throw e
    }
  }

}
