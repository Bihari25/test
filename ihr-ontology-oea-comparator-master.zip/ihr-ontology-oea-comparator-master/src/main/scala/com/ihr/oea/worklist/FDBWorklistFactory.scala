package com.ihr.oea.worklist

import org.apache.spark.sql.SparkSession

import com.ihr.oea.common.OESConfiguration
import org.apache.log4j.Logger
import com.ihr.oea.comparator.fdb.FDBAddEditWorklist
import com.ihr.oea.comparator.fdb.FdbAddMapWorklist
import com.ihr.oea.comparator.fdb.FdbEditMapWorklist

class FDBWorklistFactory {
  val log = Logger.getLogger(getClass.getName)

  @throws(classOf[Exception])
  def generateFDBWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseId: String) {
    log.info("Running  data comparator for fdb releaseId : " + releaseId)

    val addEditWorklist = new FDBAddEditWorklist
    addEditWorklist.generateFDBAddEditWorklist(spark, oesConfiguration, releaseId)
    
    val fdbAddMapWorklist =new FdbAddMapWorklist
    fdbAddMapWorklist.generateFdbAddMapWorklist(spark, oesConfiguration, releaseId);
    
     val editMapWorklist = new FdbEditMapWorklist
    editMapWorklist.generateFdbEditMapWorklist(spark, oesConfiguration, releaseId)
    
    val workBenchData = new WorkBenchData
    workBenchData.generateWorkBenchData(spark, oesConfiguration, releaseId);

    log.info("Completed  data comparator for fdb releaseId : " + releaseId)
  }
}