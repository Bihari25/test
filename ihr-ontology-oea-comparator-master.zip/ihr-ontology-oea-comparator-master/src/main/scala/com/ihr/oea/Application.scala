package com.ihr.oea
import org.apache.spark.sql.SparkSession
import com.ihr.oea.common.GlobalContext
import com.ihr.oea.common.OESConfiguration
import org.apache.log4j.Logger
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.worklist.SnomedWorklistFactory
import com.ihr.oea.worklist.LoincWorklistFactory
import com.ihr.oea.worklist.QuestWorklistFactory
import com.ihr.oea.worklist.LabCorpWorklistFactory
import com.ihr.oea.worklist.FDBWorklistFactory
import com.ihr.oea.worklist.RxnormWorklistFactory

object Application{
  val log = Logger.getLogger(getClass.getName)
  def main(args: Array[String]) {
    if (args.length != 2) {
      log.info("Invalid arguments to data comparator from spark launcher.please check...")
      System.exit(1)
    } else {
      try {
        val codeSetType = args(0).trim()
        val releaseId = args(1).trim()
        log.info("Starting OES Compartor Spark Application for releaseId : " + releaseId)
        val oesConfiguration = new OESConfiguration
        oesConfiguration.readConfigFile()

        val globalContext = new GlobalContext
        val spark: SparkSession = globalContext.createSparkSession(oesConfiguration)

        if (codeSetType.equalsIgnoreCase(GlobalConstants.SNOMED)) {
          val snomedFactory = new SnomedWorklistFactory
          snomedFactory.generateSnomedWorklist(spark, oesConfiguration, releaseId);
        } else if (codeSetType.equalsIgnoreCase(GlobalConstants.LOINC)) {
          val loincFactory = new LoincWorklistFactory
          loincFactory.generateLoincWorklist(spark, oesConfiguration, releaseId);
        } else if (codeSetType.equalsIgnoreCase(GlobalConstants.QUEST)) {
          val questFactory = new QuestWorklistFactory
          questFactory.generateQuestWorklist(spark, oesConfiguration, releaseId);
        }  else if (codeSetType.equalsIgnoreCase(GlobalConstants.LABCORP)) {
          val labFactory = new LabCorpWorklistFactory
          labFactory.generateLabCorpWorklist(spark, oesConfiguration, releaseId);
        } else if (codeSetType.equalsIgnoreCase(GlobalConstants.FDB)) {
          val fdbFactory = new FDBWorklistFactory
          fdbFactory.generateFDBWorklist(spark, oesConfiguration, releaseId);
        }else if (codeSetType.equalsIgnoreCase(GlobalConstants.RXNORM)) {
          val rxnormFactory = new RxnormWorklistFactory
          rxnormFactory.generateRxNormWorklist(spark, oesConfiguration, releaseId);
        }
        spark.stop()
        log.info("Completed OES Compartor Spark Application for releaseId : " + releaseId)
      } catch {
        case e: Exception => log.error(s"Exception while processing data comparator : " + e.getMessage)
      }
    }
  }
}