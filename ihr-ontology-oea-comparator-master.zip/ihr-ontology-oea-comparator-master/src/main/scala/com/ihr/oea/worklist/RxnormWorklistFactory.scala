package com.ihr.oea.worklist

import org.apache.spark.sql.SparkSession

import com.ihr.oea.common.OESConfiguration
import org.apache.log4j.Logger
import com.ihr.oea.comparator.rxnorm.RxNormAddEditWorklist


class RxnormWorklistFactory {
  val log = Logger.getLogger(getClass.getName)

  @throws(classOf[Exception])
  def generateRxNormWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseId: String) {
    log.info("Running  data comparator for Rxnorm releaseId : " + releaseId)

    val addEditWorklist = new RxNormAddEditWorklist
    addEditWorklist.generateRxNormAddEditWorklist(spark, oesConfiguration, releaseId)

    val workBenchData = new WorkBenchData
    workBenchData.generateWorkBenchData(spark, oesConfiguration, releaseId);

    log.info("Completed  data comparator for rxnorm releaseId : " + releaseId)
  }
}