package com.ihr.oea.worklist

import org.apache.spark.sql.SparkSession

import com.ihr.oea.common.OESConfiguration
import org.apache.log4j.Logger
import com.ihr.oea.comparator.labcorp.LabCorpAddEditWorklist
import com.ihr.oea.comparator.labcorp.LabCorpAddMapWorklist
import com.ihr.oea.comparator.labcorp.LabCorpEditMapWorklist


class LabCorpWorklistFactory {
  val log = Logger.getLogger(getClass.getName)

  @throws(classOf[Exception])
  def generateLabCorpWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseId: String) {
    log.info("Running  data comparator for labcorp releaseId : " + releaseId)

    val addEditWorklist = new LabCorpAddEditWorklist
    addEditWorklist.generateLabCorpAddEditWorklist(spark, oesConfiguration, releaseId)
    
    val addMapWorklist = new LabCorpAddMapWorklist
    addMapWorklist.generateLabCorpAddMapWorklist(spark, oesConfiguration, releaseId)

    val editMapWorklist = new LabCorpEditMapWorklist
    editMapWorklist.generateLabCorpEditMapWorklist(spark, oesConfiguration, releaseId)
    
    val workBenchData = new WorkBenchData
    workBenchData.generateWorkBenchData(spark, oesConfiguration, releaseId);

    log.info("Completed  data comparator for lacorp releaseId : " + releaseId)
  }
}