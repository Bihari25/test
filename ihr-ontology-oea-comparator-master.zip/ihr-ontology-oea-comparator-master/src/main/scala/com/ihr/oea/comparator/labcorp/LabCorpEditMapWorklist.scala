package com.ihr.oea.comparator.labcorp

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.ArrayList
import org.apache.spark.sql.functions.{ concat, lit }
import scala.collection.mutable.Stack
import scala.util.control.Breaks

import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.split
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.when

import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import org.apache.log4j.Logger
import com.ihr.oea.util.ComparatorUtil

class LabCorpEditMapWorklist {
  val log = Logger.getLogger(getClass.getName)
  def generateLabCorpEditMapWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {

      log.info("Running data comparator for Edit Map worklist for LabCorp releaseId : " + releaseID)
      log.info("loading edit codes from db for LabCorp releaseId : " + releaseID)
      val labCorputil = new LabCorpEditMapCompareUtil
      val mongoDAO = new MongoDAO
      log.info("Finding  distinct taxonomies in release data for LabCorp releaseId : " + releaseID)

      val editWorkListData = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.WORKLIST_ITEMS)
        .filter(col(SparkSQLConstants.RELEASE_ID) === releaseID && col(SparkSQLConstants.WORKLIST_TYPE) === GlobalConstants.EDIT_CODES)

      // Find the distinct taxonomies in the release from the MongoDB
      val util = new ComparatorUtil
      var taxonomyStack = util.findDistinctTaxonomy(editWorkListData)

      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING
      while (taxonomyStack.nonEmpty) {
        val taxonomyName = taxonomyStack.pop
        try {
          log.info("Loading the IHR annoataion mapping for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)

          val workListID = labCorputil.getWorklistID(editWorkListData, taxonomyName)

          val sourceEditCodesDF = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.WORKLIST_ITEMS)
            .filter(col(SparkSQLConstants.WORKLIST_ID) === workListID)
            .withColumn(SparkSQLConstants.PREFERRED_TERM, col(SparkSQLConstants.REL_PREFERRED_TERM))
            .withColumn(SparkSQLConstants.TYPE, col(SparkSQLConstants.REL_TYPE))
            .withColumn(SparkSQLConstants.LOINC_CODE, col(SparkSQLConstants.REL_LOINC_CODE))
             .withColumn(SparkSQLConstants.CHANGECODE_FLAG, col(SparkSQLConstants.CHANGECODE_FLAG))
              .withColumnRenamed(SparkSQLConstants.SUPERCLASS_LABEL, GlobalConstants.EXITING_MAP).cache()

          log.info("generating edit direct map worklist data for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)

          val editDirectMapCodes = labCorputil.generateLabCorpMapData(taxonomyName, sourceEditCodesDF, GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID, count,mongoDAO)

          log.info("saved successfully add Unmatched map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
          count += 1

        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator for taxonomy : " + taxonomyName + " for Edit Map Worklist for LabCorp releaseId : " + releaseID)
            log.error(e.printStackTrace())
        }
      }
      log.info("Completed data comparator for Edit Map Worklist for LabCorp releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for Edit Map Worklist for LabCorp releaseId : " + releaseID)
        log.error(e.printStackTrace())
      //throw e
    }
  }
}