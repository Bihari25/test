package com.ihr.oea.worklist

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.comparator.snomed.SnomedAddEditWorklist
import com.ihr.oea.comparator.snomed.SnomedAddMapWorklist
import com.ihr.oea.comparator.snomed.SnomedEditMapWorklist

class SnomedWorklistFactory{
  val log = Logger.getLogger(getClass.getName)

  @throws(classOf[Exception])
  def generateSnomedWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseId: String) {
    log.info("Running data comparator for snomed releaseId : " + releaseId)

    val addEditWorklist = new SnomedAddEditWorklist
    addEditWorklist.generateSnomedAddEditWorklist(spark, oesConfiguration, releaseId)

    val addMapWorklist = new SnomedAddMapWorklist
    addMapWorklist.generateSnomedAddMapWorklist(spark, oesConfiguration, releaseId)

    val editMapWorklist = new SnomedEditMapWorklist
    editMapWorklist.generateSnomedEditMapWorklist(spark, oesConfiguration, releaseId)

    val workBenchData = new WorkBenchData
    workBenchData.generateWorkBenchData(spark, oesConfiguration, releaseId);

    log.info("Completed data comparator for snomed releaseId : " + releaseId)
  }
}