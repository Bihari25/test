package com.ihr.oea.comparator.loinc

import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.Stack

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.functions._

import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import com.ihr.oea.util.ComparatorUtil

class LoincAddEditWorklist {
  val log = Logger.getLogger(getClass.getName)

  def buildReleaseConceptsSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.RELEASE_ID, StringType, true),
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.FSN, StringType, true),
        StructField(SparkSQLConstants.PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.SHORTNAME, StringType, true),
        StructField(SparkSQLConstants.LANGUAGE_CODE, StringType, true),
        StructField(SparkSQLConstants.VERSIONFIRSTRELEASED, StringType, true),
        StructField(SparkSQLConstants.VERSIONLASTCHANGED, StringType, true),
        StructField(SparkSQLConstants.CLASS_NAME, StringType, true),
        StructField(SparkSQLConstants.ORDER_OBS, StringType, true),
        StructField(SparkSQLConstants.STATUS, StringType, true),
        StructField(SparkSQLConstants.CHNG_TYPE, StringType, true),
        StructField(SparkSQLConstants.REL_PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.EFFECTIVE_TIME, StringType, true),
        StructField(SparkSQLConstants.REVISED_DATE, StringType, true),
        StructField(SparkSQLConstants.RETIRED_DATE, StringType, true)))
    schema
  }
  def generateLoincAddEditWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {
      log.info("Running data comparator for ADD/EDIT worklist for loinc releaseId : " + releaseID)

      log.info("loading release concepts from db for loinc releaseId : " + releaseID)
      val loincConcepts = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE, oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.RELEASE_CONCEPTS)
        .schema(buildReleaseConceptsSchema())
        .load().filter(col(SparkSQLConstants.RELEASE_ID) === releaseID)
      val mongoDAO = new MongoDAO
      log.info("Finding  distinct taxonomies in release data for loinc releaseId : " + releaseID)
      val util = new ComparatorUtil
      var taxonomyStack = util.findDistinctTaxonomy(loincConcepts)

      def deleteFlagChk = udf((shortName: String, shortNameEn: String) => {
        if ((null == shortName || shortName.equals(GlobalConstants.EMPTY_STRING) || shortName.isEmpty()) && shortNameEn != null && !shortNameEn.equals(shortName)) {
          1
        } else {
          0
        }
      })
		  

      val same_string = udf { (t1: String, t2: String) =>
        if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0 &&
          t1.trim().toLowerCase() == t2.trim().toLowerCase()) { 1 }
        else if (t1 == null && t2 != null && t2.length() >= 0) { 0 }
        else if (t1 == null && t2 == null) { 1 }
        else { 0 }
      }

      log.info("generating the source annotation path for lonic releaseId : " + releaseID)
      var sourceAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SOURCE_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
      if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE))
        sourceAnnotationBasePath = sourceAnnotationBasePath.substring(5)
      
      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING
      while (taxonomyStack.nonEmpty) {
        val taxonomyName = taxonomyStack.pop
        try {
          var taxonomyOntologyFileName = GlobalConstants.loincSourceAnnotationMap.apply(taxonomyName)
          if (null != taxonomyOntologyFileName) {
            log.info("Loading the source annoataion data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            var sourceData = spark.read
              .format(GlobalConstants.CSV_FORMAT)
              .option(GlobalConstants.HEADER, true)
              .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
              .load(sourceAnnotationBasePath + taxonomyOntologyFileName)
              .withColumnRenamed(SparkSQLConstants.STATUS, SparkSQLConstants.LOINC_SRC_STATUS)
              .withColumnRenamed(SparkSQLConstants.REVISED_DATE, SparkSQLConstants.ANNOTATION_REVISED_DATE)
              .withColumnRenamed(SparkSQLConstants.RETIRED_DATE, SparkSQLConstants.ANNOTATION_RETIRED_DATE)

            val releaseData = loincConcepts.filter(col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
             sourceData = sourceData.select(GlobalConstants.STAR).withColumn(SparkSQLConstants.LABEL_PT,split(col(SparkSQLConstants.LABEL), GlobalConstants.ESCAPE_UNDERSCORE).getItem(2))

            // ADD codes
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_CODES
            val addCodesData = releaseData.join(sourceData, sourceData(SparkSQLConstants.IDENTIFIER) === releaseData(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
            log.info("generating add code work list data for taxonomy : " + taxonomyName + " for loinc releaseId : " + releaseID)

            val addCodesWorklistData = addCodesData
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.FSN,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.EFFECTIVE_TIME,
                SparkSQLConstants.LANGUAGE_CODE,
                SparkSQLConstants.VERSIONFIRSTRELEASED,
                SparkSQLConstants.SHORTNAME,
                SparkSQLConstants.CLASS_NAME,
                SparkSQLConstants.ORDER_OBS,
                SparkSQLConstants.STATUS)
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_CODES))
            //writing add data into mongo
            log.info("saving  add code work list data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addCodesWorklistData)
            log.info("saved successfully add code work list data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            
            
            // EDIT codes
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_CODES
            val editCodesData = releaseData.join(sourceData, releaseData(SparkSQLConstants.CONCEPT_ID) === sourceData(SparkSQLConstants.IDENTIFIER))
              .where(same_string(releaseData(SparkSQLConstants.SHORTNAME), sourceData(SparkSQLConstants.SHORT_PREFERRED_TERM_EN)) === 0 ||
                same_string(releaseData(SparkSQLConstants.PREFERRED_TERM), sourceData(SparkSQLConstants.LABEL_PT)) === 0 ||
                same_string(releaseData(SparkSQLConstants.STATUS), sourceData(SparkSQLConstants.LOINC_SRC_STATUS)) === 0 )
              .withColumn(SparkSQLConstants.EDITCODE_FLAG, when(deleteFlagChk(releaseData(SparkSQLConstants.SHORTNAME),sourceData(SparkSQLConstants.SHORT_PREFERRED_TERM_EN)) === 1,
                 array(lit(SparkSQLConstants.SHORTNAME))).otherwise(null))
              .withColumn(SparkSQLConstants.REL_PREFERRED_TERM, releaseData(SparkSQLConstants.PREFERRED_TERM))
              .withColumn(SparkSQLConstants.SHORTNAME, when(
                same_string(releaseData(SparkSQLConstants.SHORTNAME), sourceData(SparkSQLConstants.SHORT_PREFERRED_TERM_EN)) === 0,
                releaseData(SparkSQLConstants.SHORTNAME)).otherwise(null))
              .withColumn(SparkSQLConstants.STATUS, when(
                same_string(releaseData(SparkSQLConstants.STATUS), sourceData(SparkSQLConstants.LOINC_SRC_STATUS)) === 0,
                releaseData(SparkSQLConstants.STATUS)).otherwise(null))
              .withColumn(SparkSQLConstants.PREFERRED_TERM, when(
                same_string(releaseData(SparkSQLConstants.PREFERRED_TERM), sourceData(SparkSQLConstants.LABEL_PT)) === 0,
                releaseData(SparkSQLConstants.PREFERRED_TERM)).otherwise(null))
               .withColumn(SparkSQLConstants.CHANGECODE_FLAG, when(col(SparkSQLConstants.PREFERRED_TERM).isNotNull,GlobalConstants.TRUE).otherwise(GlobalConstants.FALSE))
   
           
               
            val columnNames = editCodesData.columns.toArray
            val requiredColumns = ArrayBuffer[String](
              SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.PREFERRED_TERM,
              SparkSQLConstants.SHORTNAME,
              SparkSQLConstants.LANGUAGE_CODE,
              SparkSQLConstants.VERSIONLASTCHANGED,
              SparkSQLConstants.CHNG_TYPE,
              SparkSQLConstants.STATUS,
              SparkSQLConstants.REL_PREFERRED_TERM,
              SparkSQLConstants.EFFECTIVE_TIME,
              SparkSQLConstants.REVISED_DATE,
              SparkSQLConstants.RETIRED_DATE,
              SparkSQLConstants.CHANGECODE_FLAG,
              SparkSQLConstants.EDITCODE_FLAG)

            val selectedColumns = requiredColumns.intersect(columnNames)
            val colNames = selectedColumns.map(name => col(name))

            log.info("generating edit code work list data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            var editCodesWorklistData = editCodesData.select(colNames: _*)
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_CODES))
            log.info("saving edit code work list data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            //writing edit data into mongo
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editCodesWorklistData)
            log.info("saved edit code work list data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            count += 1
          } else {
            log.info("No Source ontology file found for taxonomy : " + taxonomyName)
          }
        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator for taxonomy " + taxonomyName + " for ADD/EDIT worklist for loinc releaseId : " + releaseID)
            log.error(e.printStackTrace())
        }
      }
      log.info("Completed data comparator for ADD/EDIT worklist for loinc releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for ADD/EDIT worklist for loinc releaseId : " + releaseID)
        log.error(e.printStackTrace())
      //	throw e
    }
  }
}