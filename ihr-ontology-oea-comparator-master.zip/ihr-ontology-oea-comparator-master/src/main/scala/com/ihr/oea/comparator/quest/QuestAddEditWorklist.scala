package com.ihr.oea.comparator.quest

import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.Stack
import scala.collection.mutable.WrappedArray
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.udf
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import com.ihr.oea.util.ComparatorUtil
import java.util.ArrayList


class QuestAddEditWorklist {
  val log = Logger.getLogger(getClass.getName)

  def buildReleaseConceptsSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.RELEASE_ID, StringType, true),
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.TYPE, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.CPT_CODE, StringType, true),
        StructField(SparkSQLConstants.LOINC_CODE, StringType, true),
        StructField(SparkSQLConstants.PROCESS_STATUS, StringType, true),
        StructField(SparkSQLConstants.REL_PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.REL_CPT_CODE, StringType, true),
        StructField(SparkSQLConstants.REL_LOINC_CODE, StringType, true),
        StructField(SparkSQLConstants.REL_TYPE, StringType, true),
        StructField(SparkSQLConstants.EFFECTIVE_TIME, StringType, true)))
    schema
  }

  def generateQuestAddEditWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {
      log.info("Running data comparator for ADD worklist for quest releaseId : " + releaseID)
      log.info("loading release concepts from db for quest releaseId : " + releaseID)
      val mongoDAO = new MongoDAO
      val questConcepts = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE, oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.RELEASE_CONCEPTS)
        .schema(buildReleaseConceptsSchema())
        .load().filter(col(SparkSQLConstants.RELEASE_ID) === releaseID && col(SparkSQLConstants.PROCESS_STATUS) === GlobalConstants.PROCESSED)
      val catalogDF = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.CATALOG).filter(col(SparkSQLConstants.RELEASE_ID) === releaseID)
      val  revisedDate = catalogDF.select(GlobalConstants.RELEASE_DATE).first().getString(0)
      log.info("revisedDate::"+ revisedDate)      
      log.info("Finding  distinct taxonomies in release data for quest releaseId : " + releaseID)
      val util = new ComparatorUtil
      var taxonomyStack = util.findDistinctTaxonomy(questConcepts)
       val same_string = udf { (t1: String, t2: String) =>
        if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0 &&
          t1.trim().toLowerCase() == t2.trim().toLowerCase()) { 1 }
        else if (t1 == null && t2 != null && t2.length() >= 0) { 0 }
        else if (t1 == null && t2 == null) { 1 }
        else { 0 }
      }
      
     val same_array = udf { (t1: WrappedArray[String], t2: WrappedArray[String]) =>
        if (t1 != null && t2 != null && t1.length == t2.length &&
          (t1.map(_.trim().toLowerCase()).intersect(t2.map(_.trim().toLowerCase())).length == t2.length)) { 1 }  
        else if (t1 == null && t2 == null) { 1 }
        else if ((t1 == null && t2 != null) || (t2 == null && t1 != null)) { 0 }
        else { 0 }
      }
      
     def normalizeCodes = udf((cptLoincCode: String) => { 
         if(null==cptLoincCode || cptLoincCode.equals(GlobalConstants.EMPTY_STRING) || cptLoincCode.isEmpty()){
					null
    		}
    		else if(cptLoincCode.startsWith(GlobalConstants.PIPE)){
				cptLoincCode.substring(1).split(GlobalConstants.PIPE)
    		} else{
    		   cptLoincCode.split(GlobalConstants.PIPE)
    		   Array(cptLoincCode)
    		}
		  })
		  
	 def deleteFlagChk = udf((t1: String, t2: String) => {
         if ((null == t1 || t1.equals(GlobalConstants.EMPTY_STRING) || t1.isEmpty()) && t2 != null && !t2.equals(t1)) {
				1
			} else {
				0
			}
		  })
	 def addValue = udf((array: Seq[String],t1: String)=> array ++ Array(t1))
		  
      log.info("generating the source annotation path for lonic releaseId : " + releaseID)
      log.info("generating the source annotation path for quest cptLoincCode : " + normalizeCodes +":::::cptCode:::")
     
      var sourceAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SOURCE_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
      if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE))
        sourceAnnotationBasePath = sourceAnnotationBasePath.substring(5)
      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING
      while (taxonomyStack.nonEmpty) {
        val taxonomyName = taxonomyStack.pop
        try {
          var taxonomyOntologyFileName = GlobalConstants.questSourceAnnotationMap.apply(taxonomyName)
          if (null != taxonomyOntologyFileName) {
            log.info("Loading the source annoataion data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
            val sourceData = spark.read
              .format(GlobalConstants.CSV_FORMAT)
              .option(GlobalConstants.HEADER, true)
              .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
              .load(sourceAnnotationBasePath + taxonomyOntologyFileName)

            val releaseData = questConcepts.filter(col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
            // ADD codes
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_CODES
            val addCodesData = releaseData.join(sourceData, lower(sourceData(SparkSQLConstants.IDENTIFIER)) === lower(releaseData(SparkSQLConstants.CONCEPT_ID)), SparkSQLConstants.ANTI_LEFT_JOIN)
            log.info("generating add code work list data for taxonomy : " + taxonomyName + " for quest releaseId : " + releaseID)
            val addCodesWorklistData = addCodesData
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE,
                SparkSQLConstants.CPT_CODE,
                SparkSQLConstants.EFFECTIVE_TIME)
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_CODES))

            //writing add data into mongo
            log.info("saving  add code work list data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addCodesWorklistData)
            log.info("saved successfully add code work list data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
            
              // EDIT codes
           var srcWithCptdata = sourceData.select(GlobalConstants.STAR)
           if(taxonomyName == GlobalConstants.OBSERVATION){
                srcWithCptdata = sourceData.withColumn(SparkSQLConstants.CPT,lit(GlobalConstants.EMPTY_STRING))
           }
           val relData = releaseData.select(GlobalConstants.STAR).withColumnRenamed(SparkSQLConstants.TYPE,SparkSQLConstants.RELEASE_TYPE)
             worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_CODES
            val editCodesData = relData.join(srcWithCptdata, relData(SparkSQLConstants.CONCEPT_ID) === srcWithCptdata(SparkSQLConstants.IDENTIFIER))
                .where(same_string(relData(SparkSQLConstants.PREFERRED_TERM), srcWithCptdata(SparkSQLConstants.PREFERRED_TERM_EN)) === 0 ||              
                 same_array(normalizeCodes(relData((SparkSQLConstants.CPT_CODE))), normalizeCodes(srcWithCptdata(SparkSQLConstants.CPT))) === 0  ||
                  same_array(normalizeCodes(relData((SparkSQLConstants.LOINC_CODE))), normalizeCodes(srcWithCptdata(SparkSQLConstants.LOINC_ID))) === 0 ||
                   same_string(relData(SparkSQLConstants.RELEASE_TYPE), srcWithCptdata(SparkSQLConstants.TYPE)) === 0 
                )
				.withColumn(SparkSQLConstants.EDITCODE_FLAG, when(deleteFlagChk(relData(SparkSQLConstants.LOINC_CODE),srcWithCptdata(SparkSQLConstants.LOINC_ID)) === 1,
                array(lit(SparkSQLConstants.LOINC_CODE))).otherwise(typedLit(Array.empty[(Double)])))
				 .withColumn(SparkSQLConstants.EDITCODE_FLAG, when(deleteFlagChk(relData(SparkSQLConstants.CPT_CODE),srcWithCptdata(SparkSQLConstants.CPT)) === 1,
                addValue(col(SparkSQLConstants.EDITCODE_FLAG),lit(SparkSQLConstants.CPT_CODE))).otherwise(col(SparkSQLConstants.EDITCODE_FLAG)))
                .withColumn(SparkSQLConstants.REL_PREFERRED_TERM, relData(SparkSQLConstants.PREFERRED_TERM)) 
                .withColumn(SparkSQLConstants.REL_CPT_CODE, relData(SparkSQLConstants.CPT_CODE)) 
                .withColumn(SparkSQLConstants.REL_LOINC_CODE, relData(SparkSQLConstants.LOINC_CODE))
                .withColumn(SparkSQLConstants.REL_TYPE, relData(SparkSQLConstants.RELEASE_TYPE))
                .withColumn(SparkSQLConstants.PREFERRED_TERM, when(same_string(relData(SparkSQLConstants.PREFERRED_TERM), srcWithCptdata(SparkSQLConstants.PREFERRED_TERM_EN)) === 0,
                relData(SparkSQLConstants.PREFERRED_TERM)).otherwise(null))
                .withColumn(SparkSQLConstants.CPT_CODE, when( same_array(normalizeCodes(relData(SparkSQLConstants.CPT_CODE)), normalizeCodes(srcWithCptdata(SparkSQLConstants.CPT))) === 0,
                relData(SparkSQLConstants.CPT_CODE)).otherwise(null))
                 .withColumn(SparkSQLConstants.LOINC_CODE, when( same_array(normalizeCodes(relData(SparkSQLConstants.LOINC_CODE)), normalizeCodes(srcWithCptdata(SparkSQLConstants.LOINC_ID))) === 0,
                relData(SparkSQLConstants.LOINC_CODE)).otherwise(null))
                 .withColumn(SparkSQLConstants.TYPE, when( same_string(relData(SparkSQLConstants.RELEASE_TYPE), srcWithCptdata(SparkSQLConstants.TYPE)) === 0,
                relData(SparkSQLConstants.RELEASE_TYPE)).otherwise(null))
                 .withColumn(SparkSQLConstants.CHANGECODE_FLAG, when(col(SparkSQLConstants.PREFERRED_TERM).isNotNull,GlobalConstants.TRUE).otherwise(GlobalConstants.FALSE))
                
               
            val columnNames = editCodesData.columns.toArray
            val requiredColumns = ArrayBuffer[String](
              SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.PREFERRED_TERM,             
              SparkSQLConstants.LOINC_CODE,
              SparkSQLConstants.TYPE,
              SparkSQLConstants.REL_PREFERRED_TERM,
              SparkSQLConstants.REL_LOINC_CODE,
              SparkSQLConstants.REL_TYPE,
              SparkSQLConstants.EDITCODE_FLAG,
              SparkSQLConstants.CHANGECODE_FLAG
               )
              
               if(taxonomyName == GlobalConstants.PROCEDURE){
                 requiredColumns.append(SparkSQLConstants.CPT_CODE)
                 requiredColumns.append(SparkSQLConstants.REL_CPT_CODE)
               }

            val selectedColumns = requiredColumns.intersect(columnNames)
            val colNames = selectedColumns.map(name => col(name))
            log.info("generating edit code work list data for taxonomy " + taxonomyName + " for QUEST releaseId : " + releaseID  + "colNames"+ colNames)
            var editCodesWorklistData = editCodesData.select(colNames: _*)
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.LANGUAGE_CODE, lit(GlobalConstants.EN))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_CODES))
              .withColumn(SparkSQLConstants.REVISED_DATE, lit(revisedDate))
           log.info("saving edit code work list data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            //writing edit data into mongo
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editCodesWorklistData.distinct())
            log.info("saved edit code work list data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            count += 1
          } else {
            log.info("No Source ontology file found for taxonomy : " + taxonomyName)
          }
        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator for taxonomy " + taxonomyName + " for ADD worklist for quest releaseId : " + releaseID)
            log.error(e.printStackTrace())
        }
      }
      log.info("Completed data comparator for ADD worklist for quest releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for ADD worklist for quest releaseId : " + releaseID)
        log.error(e.printStackTrace())
      //	throw e
    }
  }
}
