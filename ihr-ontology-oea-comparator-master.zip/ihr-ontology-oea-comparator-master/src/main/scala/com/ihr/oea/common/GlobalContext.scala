package com.ihr.oea.common

import org.apache.spark.sql.SparkSession
import org.apache.log4j.Logger

class GlobalContext {
  val log = Logger.getLogger(getClass.getName)
  def createSparkSession(oesConfiguration: OESConfiguration): SparkSession = {
    try {
      val spark = SparkSession.builder()
        .master("local")
        .config("spark.mongodb.output.uri", oesConfiguration.MONGO_URL + oesConfiguration.DATABASE_NAME)
        .config("spark.mongodb.input.uri", oesConfiguration.MONGO_URL + oesConfiguration.DATABASE_NAME)
        .getOrCreate()
       spark.conf.set("spark.sql.broadcastTimeout",  36000)
       //   spark.conf.set("spark.mongodb.keep_alive_ms", 10800000)
       // spark.conf.set("spark.sql.noCursorTimeout", true)
        
      spark
    } catch {
      case e: Exception =>
        log.error(s"Exception while creating spark session \n " + e.printStackTrace())
        throw e
    }
  }
}
