package com.ihr.oea.common

import java.util.Properties
import org.apache.log4j.Logger

class OESConfiguration {
  val log = Logger.getLogger(getClass.getName)

  var PROFILE = GlobalConstants.EMPTY_STRING
  var MONGO_URL = GlobalConstants.EMPTY_STRING
  var DATABASE_NAME = GlobalConstants.EMPTY_STRING
  var BASE_PATH = GlobalConstants.EMPTY_STRING
  var SOURCE_ANNOTATION_PATH = GlobalConstants.EMPTY_STRING
  var IHR_ANNOTATION_PATH = GlobalConstants.EMPTY_STRING
  var SUPERCLASS_DUMP_PATH = GlobalConstants.EMPTY_STRING

  def readConfigFile() {
    try {
      val instream = this.getClass.getClassLoader.getResourceAsStream(GlobalConstants.APPLICATION_CONF_FILE)
      val prop = new Properties
      prop.load(instream)
      PROFILE = prop.getProperty(GlobalConstants.PROFILE_PROPERTY).trim()
      MONGO_URL = prop.getProperty(GlobalConstants.MONGO_URL_PROPERTY).trim()
      DATABASE_NAME = prop.getProperty(GlobalConstants.DATABASE_NAME_PROPERTY).trim()
      BASE_PATH = prop.getProperty(GlobalConstants.BASE_PATH_PROPERTY).trim()
      SOURCE_ANNOTATION_PATH = prop.getProperty(GlobalConstants.SOURCE_ANNOTATION_PATH_PROPERTY).trim()
      IHR_ANNOTATION_PATH = prop.getProperty(GlobalConstants.IHR_ANNOTATION_PATH_PROPERTY).trim()
      SUPERCLASS_DUMP_PATH = prop.getProperty(GlobalConstants.SUPERCLASS_DUMP_PATH_PROPERTY).trim()
    } catch {
      case e: Exception =>
        log.error(s"Exception while reading configuration file \n " + e.printStackTrace())
        throw e
    }
  }
}

