package com.ihr.oea.common

import scala.collection.mutable.HashMap


object GlobalConstants {
  val PROFILE_PROPERTY = "oea.profile"
  val MONGO_URL_PROPERTY = "oea.mongo.url"
  val DATABASE_NAME_PROPERTY = "oea.mongo.database"
  val BASE_PATH_PROPERTY = "oea.base.path"
  val SOURCE_ANNOTATION_PATH_PROPERTY = "source.annotation.path"
  val IHR_ANNOTATION_PATH_PROPERTY = "ihr.annotation.path"
  val SUPERCLASS_DUMP_PATH_PROPERTY = "superclass.dump.path"

  val APPLICATION_CONF_FILE = "application.conf"

  val RELEASE_CONCEPTS = "releaseConcepts"
  val WORKLIST_ITEMS = "worklistItems"
  val WORKBENCH_COLLECTION = "releaseWorkbench"
  val OES_MONGO_DATABASE_NAME = "OES"
  val SPARK_DEFAULT_MONGO_DATASOURCE = "com.mongodb.spark.sql.DefaultSource"
  val TIME_FORMAT = "yyyy-MM-dd HH:mm:ss"

  val ADD_CODES = "Add Codes"
  val EDIT_CODES = "Edit Codes"
  val ADD_DIRECT_MAP = "Add - Direct Map"
  val ADD_UNMATCHED = "Add - Unmatched"
  val EDIT_BETTER_MATCHED = "Edit Map - Better Match"
  val EDIT_UNMATCHED_DIRECT_MAP = "Edit Unmapped – Direct Map"
  val EDIT_UNMATCHED = "Edit Unmapped - NoMap found"
  val EDIT_MATCHED = "Edit Maps"
  val LEFT = "left"
  val FULL_OUTER = "fullouter"
  val EDIT_NO_MAPFOUND = "Edit Map - NoMap found"
  val CLASS_ID = "MappedClassID"
  val WORKLIST_ADD_CODES = "ADD_CODES"
  val WORKLIST_EDIT_CODES = "EDIT_CODES"
  val WORKLIST_ADD_DIRECT_MAP = "ADD_DIRECT_MAP"
  val WORKLIST_ADD_UNMATCHED = "ADD_UNMATCHED"
  val WORKLIST_EDIT_BETTER_MATCHED = "EDIT_BETTER_MATCHED"
  val WORKLIST_EDIT_UNMATCHED_DIRECT_MAP = "EDIT_UNMATCHED_DIRECT_MAP"
  val WORKLIST_EDIT_UNMATCHED = "EDIT_UNMATCHED"
  val WORKLIST_EDIT_NO_MAPFOUND = "EDIT_NO_MAPFOUND"

  val PT_PT = "preferredTerm --> preferredTerm@en"
  val PT_LABEL = "preferredTerm --> label"
  val PT_ALIAS = "preferredTerm --> aliasTerm@en"

  val FSN_PT = "fsn --> preferredTerm@en"
  val FSN_LABEL = "fsn --> label"
  val FSN_ALIAS = "fsn --> aliasTerm@en"

  val SYN_PT = "synonym --> preferredTerm@en"
  val SYN_LABEL = "synonym --> label"
  val SYN_ALIAS = "synonym --> aliasTerm@en"

  val CODE_PT = "CODE NAME - > preferredTerm@en (IHR Dump)"
  val CODE_LABEL = "CODE NAME - > label (IHR Dump)"
  val CODE_ALIAS = "CODE NAME - > aliasTerm@en (IHR Dump)"
  val CODE_SC = "CODE NAME -> label (QST SC Dump)"
  
  val LOINC_NUMBER = "LOINC_NUMBER"
  val CPT = "CPT"
  val REVIEW_PENDING = "Review Pending"
  val MANUALLY_PROCESSED = "Manually Processed"
  val INPROGRESS = "In Progress"
  val COMPLETED = "Completed"
  val PENDING = "Pending"

  val LOCAL_PROFILE = "local"

  val DEFAULT_USER = "Wendy"
  val CSV_FORMAT = "csv"
  val JSON_FORMAT = "json"
  val TAB = "\t"
  val HEADER = "header"
  val DELIMITER = "delimiter"
  val COLLECTION = "collection"
  val DATABASE = "database"
  val OVERWRITE_MODE = "overwrite"
  val APPENED_MODE = "append"
  val FORWARD_SLASH = "/"
  val SQUARE_BRACKET = "["
  val CURLY_BRACKET = "{"
  val ROUND_BRACKET = "("
  val MONGO = "mongo"
  val EMPTY_STRING = ""
  val W = "_W_"
  val UNDER_SCORE = "_"
  val PIPE = "|"
  val QUOTE_PIPE = '|'
  val COMMA = ","
  val TILDA = "~"
  val SQUARE_PIPE = "[|]"
  val ESCAPE_UNDERSCORE = "\\_"
  val DEFAULT_NO_MAP = "No Map"

  val SOURCE_ONTOLOGY = "source"
  val IHR_ONTOLOGY = "ihr"
  val MORPHOLOGY_ONT = "MorphologyOntology"
  val BODYSTRUCTURE_ONT = "BodyStructureOntology"
  val PROCEDURE_ONT = "ProcedureOntology"
  val CONDITION_ONT = "ConditionOntology"

  val BODY_STRUCTURE_PATTERN = "%(body structure)%"
  val CELL_STRUCTURE_PATTERN = "%(cell structure)%"
  val CELL_PATTERN = "%(cell)%"
  val MORPHOLOGIC_PATTERN = "%(morphologic abnormality)%"
  val SITUATION_PATTERN = "situation"

  val NULL_STRING = "null"
  val PROCESSED = "Processed"
  val TRUE = "true"
  val FALSE = "false"
  val SNOMED = "snomed"
  val LOINC = "loinc"
  val QUEST = "quest"
  val CATALOG = "catalog"
  val RELEASE_DATE = "releaseDate"
  val STAR = "*"
  val PROCEDURE = "Procedure"
  val ORDER = "Order"
  val OBSERVATION = "Observation"

  val QUEST_AP = "AP"
  val QUEST_FILE_NAME = "QuestProcedureOntology"
  val SRC_EXISTING_MAP  = "srcExistingIHRMap"
  val LABCORP = "LabCorp"
  val FDB = "FDB"
  val DELETED =  "Deleted"
  val T = "T"
  val LABCORP_SC = "CODE NAME -> label (LCA SC Dump)"
  val SINGLE_QUOTE = "'"
  val HCPCSCPTOntologyFile = "HCPCSCPTOntology.txt"
  val TAXONOMY = "taxonomy"
  val PT = "PT"
  val IHRMAP = "ihr_Map"
  val LOINCODE = "loinc_code"
  val IHR_TYPE = "ihrType"
  val IHR_MATCHTYPE =  "ihrMatchType"
  val VALUE = "value"
  val STATUS ="status"
  val EXITING_MAP = "existingMap"
  val CHANGE_FLAG = "changeFlag"
  val FDBMN =  "FDBMN"
  val FDBRD = "FDBRD"
  val FDDC = "FDDC"
  val SPACE = " "
  val BRACKET_SQUARE = "\\["
  val SPACE_BRACKET = " \\["
  
  val fdbSourceAnnotationMap = "FirstDataBankDrugOntology.txt"
  val PRODUCT_MEDICATION_ONT = "ProductMedicationOntology.txt"
  val PRODUCT_DEVICE_ONT = "ProductDeviceOntology.txt"
  
  val MEDISPAN_PRODUCT = "MedispanProductOntology.txt"
  val NDC_ONT =      "NDCOntology.txt"
  val RXN_ONT =     "RXNormOntology.txt"
  val MULTUM_SRC_VOCB =     "MultumSourceVocabulary.txt"
  val SNOMED_PHARMA =     "SnomedPharmaceuticalOntology.txt"
  val PT_DEV_IHR_DUMP = "CODE NAME - > preferredTerm@en (DEV IHR Dump)"
  val LABEL_DEV_IHR_DUMP = "CODE NAME - > label (DEV IHR Dump)"
  val ALIAS_DEV_IHR_DUMP = "CODE NAME - > aliasTerm@en (DEV IHR Dump)"
  
  val PT_MED_IHR_DUMP = "CODE NAME - > preferredTerm@en (MED IHR Dump)"
  val LABELMED_IHR_DUMP = "CODE NAME - > label (MED IHR Dump)"
  val ALIAS_MED_IHR_DUMP = "CODE NAME - > aliasTerm@en (MED IHR Dump)"
  
  val MSPD_SC_DUMP = "CODE NAME -> label(MSPD SC Dump)"
  val NDC_SC_DUMP = "CODE NAME -> label(NDC SC Dump)"
  val RX_SC_DUMP = "CODE NAME -> label(Rx SC Dump)"
  val MULTUM_SC_DUMP = "CODE NAME -> label(Multum SC Dump)"
  val SNORX_SC_DUMP =  "CODE NAME -> label(SNORx SC Dump)"
  val FDB_SC_DUMP =  "GEN_MED_ID -> CLASSID(FDB SC Dump)"
  val EXTERNAL = "External"  
  val external = "external"  
  val TOPICAL = "Topical"
  val topical = "topical"
  val SV ="SV"
  val SPACE_ROUND_BRACKET = " \\("
  val EN ="en"
  val SPARK_CONFIG ="sparkConfig"
  val PREPOSITIONS = "prepositions"
  val CONJUNCTIONS ="conjunctions"
  val REMOVE_TERMS ="removeterms"
  val REG_PATTERN = "[ ]+"
  val SC_LABEL =  "SCLabel"
  
  val LONG_COMMON_PT = "LONG_COMMON_NAME- > preferredTerm@en"
  val LONG_COMMON_LABEL = "LONG_COMMON_NAME- > label"
  val LONG_COMMON_ALIAS = "LONG_COMMON_NAME- > aliasTerm@en"
  val FSN_SRC= "fsnsrc"
  val SYS_SRC = "synsrc"
  val PREFERRED_TERM_SRC = "PreferredTermsrc"
  val PTEN ="PT-EN"
  val IHR_label = "IHR_label"
  val IHR_alias_en = "IHR_alias@en"
  val LabelEN = "Label-EN"
  val IHR_preferredTerm_en = "IHR_preferredTerm@en"
  val TEMP_PT ="temp_pt"
  val TEMP_LABEL = "temp_label"
  val TEMPPT = "tempPT"
  val TEMPFSN = "tempFSN"
  val TEMPSYN ="tempSYN"
   val ESCAPE_PIPE = "\\|"
   
  
  val fdbTaxonomyIds: HashMap[String, String] = HashMap(
    "FDBMN" -> "QLR3109",
    "FDBRD" -> "QLR3107",
    "FDDC"  -> "QLR1082")
  
  val questSourceAnnotationMap: HashMap[String, String] = HashMap(
    "Observation" -> "QuestObservationOntology.txt",
    "Procedure" -> "QuestProcedureOntology.txt")

  val questIHRAnnotationMap: HashMap[String, String] = HashMap(
    "Observation" -> "ObservationOntology.txt",
    "Procedure" -> "ProcedureOntology.txt") 
    
    val questLoincSuperClassMap: HashMap[String, String] = HashMap(
    "Observation" -> "LOINCObservationOntology.txt",
    "Procedure" -> "LOINCProcedureOntology.txt"
    ) 

  val loincSourceAnnotationMap: HashMap[String, String] = HashMap(
    "Observation" -> "LOINCObservationOntology.txt",
    "Order" -> "LOINCProcedureOntology.txt")

  val loincIHRAnnotationMap: HashMap[String, String] = HashMap(
    "Observation" -> "ObservationOntology.txt",
    "Order" -> "ProcedureOntology.txt")
    
    
  val labCorpSourceAnnotationMap: HashMap[String, String] = HashMap(
    "Observation" -> "LCAObservationOntology.txt",
    "Procedure" -> "LCAProcedureOntology.txt")  
    
    
  val fdbIHRAnnotationMap: List[String] =  List(
      "ProductDeviceOntology.txt",
      "ProductMedicationOntology.txt"
     )  
     
    val fdbSuperClassMap: List[String] =  List(
        "MedispanProductOntology.txt",
        "NDCOntology.txt",
        "RXNormOntology.txt",
        "MultumSourceVocabulary.txt",
        "SnomedPharmaceuticalOntology.txt"
     )   
     
    
  val snomedSourceAnnotationMap: HashMap[String, String] = HashMap(
    "Special concept (special concept)" -> null,
    "Linkage concept (linkage concept)" -> "SnomedLinkageConceptOntology.txt",
    "Organism (organism)" -> "SnomedOrganismOntology.txt",
    "Specimen (specimen)" -> "SnomedSpecimenOntology.txt",
    "Substance (substance)" -> "SnomedSubstanceOntology.txt",
    "Procedure (procedure)" -> "SnomedProcedureOntology.txt",
    "Physical force (physical force)" -> "SnomedPhysicalForceOntology.txt",
    "Observable entity (observable entity)" -> "SnomedObservableEntityOntology.txt",
    "Clinical finding (finding)" -> "SnomedClinicalFindingOntology.txt",
    "Body structure (body structure)" -> "SnomedBodyStructureOntology.txt",
    "Situation with explicit context (situation)" -> "SnomedSituationWithExplicitContextOntology.txt",
    "Event (event)" -> "SnomedEventOntology.txt",
    "Record artifact (record artifact)" -> "SnomedRecordArtifactOntology.txt",
    "Social context (social concept)" -> "SnomedSocialContextOntology.txt",
    "Staging and scales (staging scale)" -> "SnomedStagingAndScalesOntology.txt",
    "Pharmaceutical / biologic product (product)" -> "SnomedPharmaceuticalOntology.txt",
    "Environment or geographical location (environment / location)" -> "SnomedEnvironmentOrGeographicalLocationOntology.txt",
    "Physical object (physical object)" -> "SnomedPhysicalObjectOntology.txt",
    "Qualifier value (qualifier value)" -> "SnomedQualifierValueOntology.txt")

  val snomedIHRAnnotationMap: HashMap[String, String] = HashMap(
    "Physical force (physical force)" -> null,
    "Special concept (special concept)" -> null,
    "Staging and scales (staging scale)" -> null,
    "Record artifact (record artifact)" -> null,
    "Linkage concept (linkage concept)" -> null,
    "Organism (organism)" -> "OrganismOntology.txt",
    "Specimen (specimen)" -> "SpecimenOntology.txt",
    "Substance (substance)" -> "SubstanceOntology.txt",
    "Procedure (procedure)" -> "ProcedureOntology.txt",
    "Observable entity (observable entity)" -> "ObservationOntology.txt",
    "Clinical finding (finding)" -> "ConditionOntology.txt",
    "Body structure (body structure)" -> "BodyStructureOntology.txt,MorphologyOntology.txt",
    "Situation with explicit context (situation)" -> "ConditionOntology.txt,ProcedureOntology.txt",
    "Event (event)" -> "CircumstanceOntology.txt",
    "Social context (social concept)" -> "SocialAspectOntology.txt",
    "Pharmaceutical / biologic product (product)" -> "ProductMedicationOntology.txt",
    "Environment or geographical location (environment / location)" -> "LocationOntology.txt",
    "Physical object (physical object)" -> "PhysicalObjectOntology.txt",
    "Qualifier value (qualifier value)" -> "QualifierOntology.txt")
    
    
    val rxnormSourceAnnotationMap = "RXNormOntology.txt"
    val RXNORM="rxnorm"
    val RXNORMFSN="RxNorm"
}



