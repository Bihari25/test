package com.ihr.oea.comparator.fdb

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.count
import org.apache.spark.sql.functions.concat_ws
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import com.ihr.oea.util.ComparatorUtil
import org.apache.spark.sql.types.StringType

class FdbAddMapWorklist {

 def buildAddCodesSchema(): StructType = {
    val schema = StructType(
      Array(
         StructField(SparkSQLConstants.RELEASE_ID, StringType, true),  
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.TYPE, StringType, true),
        StructField(SparkSQLConstants.STATUS, StringType, true),
        StructField(SparkSQLConstants.GEN_MED_ID, StringType, true),       
        StructField(SparkSQLConstants.WORKLIST_TYPE, StringType, true),
        StructField(SparkSQLConstants.WORKLIST_ID, StringType, true)))
    schema
  }

  val log = Logger.getLogger(getClass.getName)
  def generateFdbAddMapWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {
      log.info("Running data comparator for ADD Map worklist for Fdb releaseId : " + releaseID)
      log.info("loading add codes for Fdb releaseId : " + releaseID)

      val mongoDAO = new MongoDAO
      log.info("Finding  distinct taxonomies in release data for Fdb releaseId : " + releaseID)      
           
     
       val addWorkListData = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.WORKLIST_ITEMS)
        .filter(col(SparkSQLConstants.RELEASE_ID) === releaseID && col(SparkSQLConstants.WORKLIST_TYPE) === GlobalConstants.ADD_CODES)

      // Find the distinct taxonomies in the release from the MongoDB
      val util = new ComparatorUtil
      val fdbCorputil = new FdbCompareUtil
      var taxonomyStack = util.findDistinctTaxonomy(addWorkListData)
      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING

      while (taxonomyStack.nonEmpty) {
        val taxonomyName = taxonomyStack.pop
        try {
          val workListID = fdbCorputil.getWorklistID(addWorkListData, taxonomyName)
          
       var sourceAddCodesDF =   spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE,  oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.WORKLIST_ITEMS)
        .schema(buildAddCodesSchema()).load()
            .filter(col(SparkSQLConstants.WORKLIST_ID) === workListID)
            
        sourceAddCodesDF = sourceAddCodesDF.select(GlobalConstants.STAR)
                               .withColumn(SparkSQLConstants.PREFERRED_TERM_EN, col(SparkSQLConstants.PREFERRED_TERM))
                               .withColumn(SparkSQLConstants.CHANGECODE_FLAG, lit(GlobalConstants.EMPTY_STRING))
        
        var sourceCodesExt =   sourceAddCodesDF.select(GlobalConstants.STAR)
                               .withColumn(SparkSQLConstants.PREFERRED_TERM_EN, fdbCorputil.replaceString(col(SparkSQLConstants.PREFERRED_TERM)))
                             
         sourceCodesExt =   sourceCodesExt
                               .filter(col(SparkSQLConstants.PREFERRED_TERM_EN).isNotNull)
                               
        var sourceCodes = sourceAddCodesDF.union(sourceCodesExt)
        
          log.info("generating add direct map worklist data for taxonomy " + taxonomyName + " for Fdb releaseId : " + releaseID)
         
          // ADD Direct Map codes
          worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_DIRECT_MAP
          val addIhrDirectCodes = fdbCorputil.generateFdbIhrMapData(taxonomyName, sourceCodes, GlobalConstants.ADD_CODES, spark, oesConfiguration, releaseID)
          
          var addDirectCodes = fdbCorputil.generateFdbSCMapData(taxonomyName, addIhrDirectCodes, sourceCodes,GlobalConstants.ADD_CODES, spark, oesConfiguration, releaseID)
         
          addDirectCodes = addDirectCodes.union(addIhrDirectCodes).dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)
          addDirectCodes =   addDirectCodes.select(
              SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.TYPE,
              SparkSQLConstants.PREFERRED_TERM,
              SparkSQLConstants.STATUS,
              SparkSQLConstants.GEN_MED_ID,
              SparkSQLConstants.IHR_MAP,
              SparkSQLConstants.MATCH_TYPE,
              SparkSQLConstants.MATCH_VALUE,
              SparkSQLConstants.MSP_DDID,SparkSQLConstants.MSP_PNID,SparkSQLConstants.MSP_RPID,
              SparkSQLConstants.SUPER_CLASS_STATUS)
            .withColumnRenamed(SparkSQLConstants.MSP_DDID, SparkSQLConstants.mspDdId)
            .withColumnRenamed(SparkSQLConstants.MSP_PNID, SparkSQLConstants.mspPnId)
            .withColumnRenamed(SparkSQLConstants.MSP_RPID, SparkSQLConstants.mspRpId)
            .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
            .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
            .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
            .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_DIRECT_MAP))
            .cache()
             
          //writing add data into mongo
          log.info("saving  add direct map worklist data for taxonomy " + taxonomyName + " for Fdb releaseId : " + releaseID)
          mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addDirectCodes)
          log.info("saved successfully add direct map worklist data for taxonomy " + taxonomyName + " for Fdb releaseId : " + releaseID)

          // ADD Unmatched Map codes
          log.info("generating add Unmatched map worklist data for taxonomy " + taxonomyName + " for Fdb releaseId : " + releaseID)
          worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_UNMATCHED
          val addUnmachedCodes = sourceAddCodesDF.join(addDirectCodes, addDirectCodes(SparkSQLConstants.CONCEPT_ID) ===  sourceAddCodesDF(SparkSQLConstants.CONCEPT_ID),SparkSQLConstants.ANTI_LEFT_JOIN
            ).select(
              SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.TYPE,
              SparkSQLConstants.PREFERRED_TERM,
              SparkSQLConstants.STATUS,
              SparkSQLConstants.GEN_MED_ID)
            .withColumn(SparkSQLConstants.IHR_MAP, lit(GlobalConstants.DEFAULT_NO_MAP))
            .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.MANUALLY_PROCESSED))
            .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
            .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
            .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_UNMATCHED))
            
          //writing add data into mongo
          log.info("saving  add Unmatched map worklist data for taxonomy " + taxonomyName + " for Fdb releaseId : " + releaseID)
          mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addUnmachedCodes)
          log.info("saved successfully add Unmatched map worklist data for taxonomy " + taxonomyName + " for Fdb releaseId : " + releaseID)
          count += 1
        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator taxonomy " + taxonomyName + " for Add Map Worklist for Fdb releaseId : " + releaseID+e.printStackTrace())
            log.error(e.printStackTrace())
        }
      }
      log.info("Completed data comparator for Add Map Worklists for Fdb releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for Add Map Worklists for Fdb releaseId : " + releaseID)
        log.error(e.printStackTrace())
      //throw e
    }
  }
}