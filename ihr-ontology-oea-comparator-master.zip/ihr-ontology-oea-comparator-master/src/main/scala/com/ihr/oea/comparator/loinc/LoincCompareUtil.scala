package com.ihr.oea.comparator.loinc

import scala.collection.mutable.WrappedArray
import scala.util.control.Breaks
import org.apache.spark.sql.functions.concat_ws
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.max
import org.apache.spark.sql.functions.split
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.when

import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import com.ihr.oea.util.ComparatorUtil
import org.apache.spark.sql.functions.lit


@throws(classOf[Exception])
object LoincCompareUtil {
  val log = Logger.getLogger(getClass.getName)
  def generateLoincIHRMapData(taxonomyName: String, sourceCodes: DataFrame, codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
    val mongoDAO = new MongoDAO
     val util = new ComparatorUtil
    log.info("generating the IHR annotation path for lonic releaseId : " + releaseID)
    var ihrAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.IHR_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      ihrAnnotationBasePath = ihrAnnotationBasePath.substring(5)
    }
    var ihrOntologyFile = GlobalConstants.loincIHRAnnotationMap.apply(taxonomyName)
    var addDirectMapCodesData = sourceCodes
    if (null != ihrOntologyFile) {
      log.info("Loading IHR annotation data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
      val fullIHROntologyData = spark.read
        .format(GlobalConstants.CSV_FORMAT)
        .option(GlobalConstants.HEADER, true)
        .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
        .load(ihrAnnotationBasePath + ihrOntologyFile)
        .withColumn(SparkSQLConstants.ALIAS_TERM_EN, split(col(SparkSQLConstants.ALIAS_TERM_EN), GlobalConstants.SQUARE_PIPE))
        .withColumnRenamed(SparkSQLConstants.REVISED_DATE, SparkSQLConstants.ANNOTATION_REVISED_DATE)
        .withColumnRenamed(SparkSQLConstants.RETIRED_DATE, SparkSQLConstants.ANNOTATION_RETIRED_DATE)

      var ihrOntologyData = fullIHROntologyData.select(
        SparkSQLConstants.CLASS_ID,
        SparkSQLConstants.LABEL1,
        SparkSQLConstants.PREFERRED_TERM_EN,
        SparkSQLConstants.ALIAS_TERM_EN)
      log.info("comparing release data and IHR annotation data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
      addDirectMapCodesData = util.jumbledDataframes(sourceCodes, ihrOntologyData, codeType)
      addDirectMapCodesData = addDirectMapCodesData.dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)
      log.info("generated directMap data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
    }

    val groupedDirectMapCodes = addDirectMapCodesData
      .groupBy(col(SparkSQLConstants.CONCEPT_ID) as SparkSQLConstants.GROUP_CONCEPT_ID)
      .agg(max(col(SparkSQLConstants.MATCH_RANK)) as SparkSQLConstants.MAX_RANK)
      
    addDirectMapCodesData = addDirectMapCodesData.join(
      groupedDirectMapCodes,
      groupedDirectMapCodes(SparkSQLConstants.GROUP_CONCEPT_ID) === addDirectMapCodesData(SparkSQLConstants.CONCEPT_ID) &&
        groupedDirectMapCodes(SparkSQLConstants.MAX_RANK) === addDirectMapCodesData(SparkSQLConstants.MATCH_RANK))
         .withColumn(
          SparkSQLConstants.MATCH_TYPE,
          when(col(SparkSQLConstants.MAX_RANK) === 9, GlobalConstants.LONG_COMMON_PT)
            .when(col(SparkSQLConstants.MAX_RANK) === 8, GlobalConstants.LONG_COMMON_LABEL)
            .when(col(SparkSQLConstants.MAX_RANK) === 7, GlobalConstants.LONG_COMMON_ALIAS))

    addDirectMapCodesData.select(
      SparkSQLConstants.TAXONOMY_FSN,
      SparkSQLConstants.CONCEPT_ID,
      SparkSQLConstants.PREFERRED_TERM,
      SparkSQLConstants.EFFECTIVE_TIME,
      SparkSQLConstants.LANGUAGE_CODE,
      SparkSQLConstants.IHR_MAP,
      SparkSQLConstants.ALIAS_TERM,
      SparkSQLConstants.MATCH_TYPE,
      SparkSQLConstants.MATCH_VALUE,
      SparkSQLConstants.CHANGECODE_FLAG
      )    
      addDirectMapCodesData 
  }

  def getWorklistID(workBenchData: DataFrame, taxonomyName: String): String = {
    val workListIdDF = workBenchData.filter(col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
      .select(SparkSQLConstants.WORKLIST_ID)

    var workListID = GlobalConstants.EMPTY_STRING
    var loop = new Breaks
    loop.breakable(
      workListIdDF.collect().foreach(row => {
        workListID = row.getAs[String](0).trim()
        loop.break()
      }))
    workListID
  }

}