package com.ihr.oea.comparator.fdb

import scala.collection.mutable.WrappedArray
import scala.util.control.Breaks

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.max
import org.apache.spark.sql.functions.split
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.when
import java.util.ArrayList
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.ArrayType
import org.apache.spark.sql.Row
@throws(classOf[Exception])
class FdbCompareUtil {
  val log = Logger.getLogger(getClass.getName)
  
  def buildSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.TYPE, StringType, true),
        StructField(SparkSQLConstants.PREFERRED_TERM, StringType, true),       
        StructField(SparkSQLConstants.STATUS, StringType, true),
        StructField(SparkSQLConstants.GEN_MED_ID, StringType, true),
        StructField(SparkSQLConstants.IHR_MAP, StringType, true),       
        StructField(SparkSQLConstants.MATCH_TYPE, StringType, true),
        StructField(SparkSQLConstants.MATCH_VALUE, StringType, true),
        StructField(SparkSQLConstants.MSP_DDID, StringType, true),
        StructField(SparkSQLConstants.MSP_PNID, StringType, true),
        StructField(SparkSQLConstants.MSP_RPID, StringType, true),
        StructField(SparkSQLConstants.CHANGECODE_FLAG, StringType, true),
        StructField(SparkSQLConstants.SUPER_CLASS_STATUS, StringType, true)
        ))
    schema
  }
  
   def buildSCSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
         StructField(SparkSQLConstants.TYPE, StringType, true),
        StructField(SparkSQLConstants.PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.PREFERRED_TERM_EN, StringType, true),
        StructField(SparkSQLConstants.STATUS, StringType, true),
        StructField(SparkSQLConstants.GEN_MED_ID, StringType, true),
         StructField(SparkSQLConstants.CHANGECODE_FLAG, StringType, true)))
    schema
  }
  
   
     val same_array = udf { (t1: WrappedArray[String], t2: WrappedArray[String]) =>
		     if (t1 != null && t2 != null && t1.length == t2.length &&
          (t1.map(_.trim().toLowerCase()).intersect(t2.map(_.trim().toLowerCase())).length == t2.length))
          { true }  
        else if (t1 == null && t2 == null) { true }
        else if ((t1 == null && t2 != null) || (t2 == null && t1 != null)) { false }        
        else { false }
      }
    
      def replaceString = udf((pt: String) => { 
        var result :String = null
         if(null==pt || pt.equals(GlobalConstants.EMPTY_STRING) || pt.isEmpty()){
					null
    		   } else{
          		var ptList = pt.split(GlobalConstants.SPACE)
          		
          		for (ptVal <- ptList) {
                     if(ptVal.equals(GlobalConstants.EXTERNAL) ) {
                        result =  pt.trim().replaceAll(GlobalConstants.EXTERNAL, GlobalConstants.TOPICAL)             
              			 } else  if (ptVal.equals(GlobalConstants.TOPICAL) ){
                        result =   pt.replaceAll(GlobalConstants.TOPICAL,GlobalConstants.EXTERNAL)
              			 } else if  (ptVal.equals(GlobalConstants.external) ) {
                        result =  pt.trim().replaceAll(GlobalConstants.external, GlobalConstants.TOPICAL)             
              			 } else  if (ptVal.equals(GlobalConstants.topical) ){
                        result =   pt.replaceAll(GlobalConstants.topical,GlobalConstants.EXTERNAL)
              			 } 
                }
    		    result
    		}
		  })
 
  
  def generateFdbIhrMapData(taxonomyName: String, sourceCodes: DataFrame, codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
  
    log.info("generating annotations files path taxonomy " + taxonomyName + " for FDB releaseId : " + releaseID)
  
   
    var ihrAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.IHR_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      ihrAnnotationBasePath = ihrAnnotationBasePath.substring(5)
    }
    var sourceCodesDF = sourceCodes 
    var directCodes =  SparkSession.builder().getOrCreate().emptyDataFrame
    var mapKey = taxonomyName
    log.info("loading loinc superclass data for taxonomy " + taxonomyName + " for FDB releaseId : " + releaseID)
    
   
     var ihrDirectCodes = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], buildSchema())
     
     val ihrFileName = GlobalConstants.fdbIHRAnnotationMap
     var ihrOntologyData = SparkSession.builder().getOrCreate().emptyDataFrame
     var ihrProductDeviceData = SparkSession.builder().getOrCreate().emptyDataFrame
     var ihrProductMedicationData = SparkSession.builder().getOrCreate().emptyDataFrame
     for(ihrOntologyFile <- ihrFileName ) {
     log.info("ihrFileName..."+ihrOntologyFile);
     if (null != ihrOntologyFile) {
          log.info("Loading IHR annotation data for taxonomy " + taxonomyName + " for FDB releaseId : " + releaseID)        
          ihrOntologyData = loadIHRDumpData(spark, ihrAnnotationBasePath ,ihrOntologyFile)
    
      log.info("comparing add data and IHR annotation data for taxonomy " + taxonomyName + " for FDB releaseId : " + releaseID)     
      ihrOntologyData = compareDataframes(sourceCodesDF, ihrOntologyData, codeType) 
         
      ihrOntologyData = getIHRMatchType(ihrOntologyData,ihrOntologyFile)
        .select(
          SparkSQLConstants.TAXONOMY_FSN,
          SparkSQLConstants.CONCEPT_ID,
          SparkSQLConstants.TYPE,
          SparkSQLConstants.PREFERRED_TERM,
          SparkSQLConstants.STATUS,
          SparkSQLConstants.GEN_MED_ID,
          SparkSQLConstants.IHR_MAP,
          SparkSQLConstants.MATCH_TYPE,
          SparkSQLConstants.MATCH_VALUE,
          SparkSQLConstants.MSP_DDID,
          SparkSQLConstants.MSP_PNID,
          SparkSQLConstants.MSP_RPID,
          SparkSQLConstants.CHANGECODE_FLAG,
          SparkSQLConstants.SUPER_CLASS_STATUS)
        .cache()     
      
      sourceCodesDF = sourceCodesDF.join(ihrOntologyData, ihrOntologyData(SparkSQLConstants.CONCEPT_ID) === sourceCodesDF(SparkSQLConstants.CONCEPT_ID),SparkSQLConstants.ANTI_LEFT_JOIN)
      ihrDirectCodes = ihrDirectCodes.union(ihrOntologyData) 
      directCodes = ihrDirectCodes.dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)
     }
    }
    directCodes 
    
}
  
 def generateFdbSCMapData(taxonomyName: String,  directCodes: DataFrame, sourceCodes: DataFrame,codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
     
    var superClassBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SUPERCLASS_DUMP_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      superClassBasePath = superClassBasePath.substring(5)
    }
    var sourceDF = sourceCodes.join(directCodes, directCodes(SparkSQLConstants.CONCEPT_ID) === sourceCodes(SparkSQLConstants.CONCEPT_ID) ,   SparkSQLConstants.ANTI_LEFT_JOIN)
    
    var finalDirectCode = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], buildSchema())
    var scCodes = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], buildSchema())
    var fdbSCOntologyFile =  GlobalConstants.fdbSuperClassMap
    var fdbSourceAnnotation = List(GlobalConstants.fdbSourceAnnotationMap)  
    var fdbSCFirstTwoFiles = fdbSCOntologyFile.take(2)
    var fdbSCLastFiles = fdbSCOntologyFile.takeRight(3)
    if (taxonomyName == GlobalConstants.FDDC)       
           fdbSCOntologyFile = fdbSCFirstTwoFiles  ::: fdbSourceAnnotation ::: fdbSCLastFiles
           
    for (fdbSuperClassOntologyFile <- fdbSCOntologyFile) {

      log.info("loading loinc superclass data for taxonomy " + fdbSuperClassOntologyFile)
      var scMatchType = matchTypeSCData(fdbSuperClassOntologyFile)
      var fdbSuperClassData = loadSuperClassData(spark, superClassBasePath , fdbSuperClassOntologyFile)
      
      
      log.info("comparaing fdb superclass data and add code for taxonomy " + taxonomyName + " for FDB releaseId : " + releaseID)
      
      if(fdbSuperClassOntologyFile.equals(GlobalConstants.fdbSourceAnnotationMap)){
        var taxonomyId = GlobalConstants.fdbTaxonomyIds.apply(taxonomyName)
        var fdbtaxonomyId:String = taxonomyId+GlobalConstants.UNDER_SCORE
           sourceDF = sourceDF.select(GlobalConstants.STAR).withColumn(SparkSQLConstants.FDB_TAXONOMYID,concat(lit(fdbtaxonomyId),sourceDF.col(SparkSQLConstants.GEN_MED_ID)));
        
           scCodes =  sourceDF.join(fdbSuperClassData, fdbSuperClassData(SparkSQLConstants.CLASS_ID) === sourceDF(SparkSQLConstants.FDB_TAXONOMYID))
                         .withColumn(SparkSQLConstants.MATCH_TYPE, lit(scMatchType))
                          .withColumn(SparkSQLConstants.MATCH_VALUE, fdbSuperClassData(SparkSQLConstants.CLASS_ID))
      }else{
           scCodes = sourceDF.join(fdbSuperClassData, 
                     same_array(split(sourceDF(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE), split((fdbSuperClassData(SparkSQLConstants.EXISTING_LABEL)),GlobalConstants.SPACE)))
                       .withColumn(SparkSQLConstants.MATCH_TYPE, lit(scMatchType))
                        .withColumn(SparkSQLConstants.MATCH_VALUE, fdbSuperClassData(SparkSQLConstants.EXISTING_LABEL))
      }
           
        scCodes = scCodes.withColumn(SparkSQLConstants.IHR_MAP, fdbSuperClassData(SparkSQLConstants.SUPERCLASS_LABEL))      
        .withColumn( SparkSQLConstants.MSP_DDID, lit(GlobalConstants.EMPTY_STRING))
        .withColumn(SparkSQLConstants.MSP_PNID, lit(GlobalConstants.EMPTY_STRING))
        .withColumn(SparkSQLConstants.MSP_RPID,lit(GlobalConstants.EMPTY_STRING))
        .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, when(col(SparkSQLConstants.MATCH_TYPE) === GlobalConstants.FDB_SC_DUMP, GlobalConstants.SV).otherwise(GlobalConstants.EMPTY_STRING)) 
        .select(
          SparkSQLConstants.TAXONOMY_FSN,
          SparkSQLConstants.CONCEPT_ID,
          SparkSQLConstants.TYPE,
          SparkSQLConstants.PREFERRED_TERM,
          SparkSQLConstants.STATUS,
          SparkSQLConstants.GEN_MED_ID,
          SparkSQLConstants.IHR_MAP,
          SparkSQLConstants.MATCH_TYPE,
          SparkSQLConstants.MATCH_VALUE,
          SparkSQLConstants.MSP_DDID,
          SparkSQLConstants.MSP_PNID,
          SparkSQLConstants.MSP_RPID,SparkSQLConstants.CHANGECODE_FLAG,SparkSQLConstants.SUPER_CLASS_STATUS)
         
          
      sourceDF = sourceDF.join(scCodes, scCodes(SparkSQLConstants.CONCEPT_ID) === sourceDF(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
      finalDirectCode = finalDirectCode.union(scCodes)
        .select(
          SparkSQLConstants.TAXONOMY_FSN,
          SparkSQLConstants.CONCEPT_ID,
          SparkSQLConstants.TYPE,
          SparkSQLConstants.PREFERRED_TERM,
          SparkSQLConstants.STATUS,
          SparkSQLConstants.GEN_MED_ID,
          SparkSQLConstants.IHR_MAP,
          SparkSQLConstants.MATCH_TYPE,
          SparkSQLConstants.MATCH_VALUE,
          SparkSQLConstants.MSP_DDID,
          SparkSQLConstants.MSP_PNID,
          SparkSQLConstants.MSP_RPID,SparkSQLConstants.CHANGECODE_FLAG,SparkSQLConstants.SUPER_CLASS_STATUS)
          .cache()
    }
       finalDirectCode = finalDirectCode.union(directCodes).dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)
     finalDirectCode 
   }

  def compareDataframes(df1: DataFrame, df2: DataFrame, codeType: String): DataFrame = {
    var sourceAddCodesData = df1.sort(SparkSQLConstants.PREFERRED_TERM_EN)
    var ihrOntologyData = df2.sort(SparkSQLConstants.PREFERRED_TERM_EN, SparkSQLConstants.LABEL1, SparkSQLConstants.ALIAS_TERM_EN)


      //pt-label
    val same_pt_label = udf((t: String, t2: String) => {
      if (t != null && t2 != null  && t2.length() > 0) {
        var label = GlobalConstants.EMPTY_STRING
        if (t2.contains(GlobalConstants.SQUARE_BRACKET))
          label = t2.substring(0, t2.lastIndexOf(GlobalConstants.SQUARE_BRACKET))
        else
          label = t2
          
          var arrLabel = label.split(GlobalConstants.SPACE)
          var t1 = t.split(GlobalConstants.SPACE)
      
            if (t1 != null && arrLabel != null && t1.length == arrLabel.length &&
          (t1.map(_.trim().toLowerCase()).intersect(arrLabel.map(_.trim().toLowerCase())).length == arrLabel.length))
          { true }  
        else if (t1 == null && arrLabel == null) { true }
        else if ((t1 == null && arrLabel != null) || (arrLabel == null && t1 != null)) { false }        
        else { false }

      
      } else false
    })
 //pt-alias
    val pt_in_alias = udf((pt: WrappedArray[String], alias: WrappedArray[String]) => {
      if (pt != null && alias != null)  {
        var new_alias = alias.map(_.trim().toLowerCase())
        var t2 = new_alias.flatMap(_.split(GlobalConstants.SPACE))
       
         if (pt != null && t2 != null && pt.length == t2.length &&
             (pt.map(_.trim().toLowerCase()).intersect(t2).length == t2.length))
         { 
           true }
        else {
          false }
      } else false

    })

    var directMapCodesData = sourceAddCodesData.join(
      ihrOntologyData,
      same_array(split(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE), split(ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE)) ||
        same_pt_label(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM_EN), ihrOntologyData(SparkSQLConstants.LABEL1)) ||
         pt_in_alias(split(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE), ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN)))
      .withColumn(SparkSQLConstants.ALIAS_TERM, ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN))
      .withColumn(SparkSQLConstants.IHR_MAP, ihrOntologyData(SparkSQLConstants.LABEL1))
      .withColumn(
        SparkSQLConstants.MATCH_RANK,
        when(same_array(split(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE), split(ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE)), 9)
          .when(same_pt_label(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM_EN), ihrOntologyData(SparkSQLConstants.LABEL1)), 8)
           .when(pt_in_alias(split(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE), ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN)), 7))
      .withColumn(SparkSQLConstants.MATCH_VALUE, concat_ws(
        GlobalConstants.COMMA,
        ihrOntologyData(SparkSQLConstants.LABEL1), ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN),
        concat_ws(GlobalConstants.PIPE, ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN))))
    directMapCodesData
  }
  

  def getWorklistID(workBenchData: DataFrame, taxonomyName: String): String = {
    val workListIdDF = workBenchData.filter(col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
      .select(SparkSQLConstants.WORKLIST_ID)

    var workListID = GlobalConstants.EMPTY_STRING
    var loop = new Breaks
    loop.breakable(
      workListIdDF.collect().foreach(row => {
        workListID = row.getAs[String](0).trim()
        loop.break()
      }))
    workListID
  }
  
   val validLabel = udf((t: String) => {
              var result: String = null
              if (null != t && !(t.isEmpty())) {
                if (t.contains(GlobalConstants.ROUND_BRACKET)){
                    result = t.substring(0, t.lastIndexOf(GlobalConstants.ROUND_BRACKET)).trim()
                }else{
                  result = t.trim()
                }
              }
              result
     })

  def loadSuperClassData(spark: SparkSession, filePath: String, file: String): DataFrame = {
    var superClassData = spark.read
      .format(GlobalConstants.CSV_FORMAT)
      .option(GlobalConstants.HEADER, true)
      .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
      .load(filePath+file)
      .withColumn(SparkSQLConstants.SUPERCLASS_CONCEPT_ID, split(col(SparkSQLConstants.CLASS_ID), GlobalConstants.ESCAPE_UNDERSCORE).getItem(1))      
      .withColumnRenamed(SparkSQLConstants.MAPPED_CLASS_LABEL, SparkSQLConstants.SUPERCLASS_LABEL)
      
      if(file.equals(GlobalConstants.MEDISPAN_PRODUCT)){
        superClassData= superClassData.withColumn(SparkSQLConstants.EXISTING_LABEL, split(col(SparkSQLConstants.LABEL), GlobalConstants.SPACE_BRACKET).getItem(0))
      }else{
            if(file.equals(GlobalConstants.SNOMED_PHARMA)){
                superClassData  = superClassData.withColumn(SparkSQLConstants.EXISTING_LABEL, split(col(SparkSQLConstants.LABEL), GlobalConstants.ESCAPE_UNDERSCORE).getItem(2))
                 superClassData  = superClassData.withColumn(SparkSQLConstants.EXISTING_LABEL, validLabel(col(SparkSQLConstants.EXISTING_LABEL)))
            }else{
                superClassData  = superClassData.withColumn(SparkSQLConstants.EXISTING_LABEL, split(col(SparkSQLConstants.LABEL), GlobalConstants.ESCAPE_UNDERSCORE).getItem(2))
            }
      }
    
    superClassData = superClassData.select(SparkSQLConstants.SUPERCLASS_CONCEPT_ID, SparkSQLConstants.SUPERCLASS_LABEL, SparkSQLConstants.MAPPED_CLASS_ID, SparkSQLConstants.EXISTING_LABEL,SparkSQLConstants.CLASS_ID)
    superClassData
  }
  
  
  def loadIHRDumpData(spark: SparkSession, filePath: String, file: String): DataFrame = {
    var ihrData =  spark.read .format(GlobalConstants.CSV_FORMAT)
        .option(GlobalConstants.HEADER, true)
        .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
        .load(filePath+file)
        .withColumn(SparkSQLConstants.LABEL1, col(SparkSQLConstants.LABEL))
        .withColumnRenamed(SparkSQLConstants.CLASS_ID, SparkSQLConstants.MAPPED_CLASS_ID)
        .withColumn(SparkSQLConstants.ALIAS_TERM_EN, split(col(SparkSQLConstants.ALIAS_TERM_EN), GlobalConstants.SQUARE_PIPE))
        if(file.equals(GlobalConstants.PRODUCT_DEVICE_ONT)){
         ihrData = ihrData.withColumn(SparkSQLConstants.MSP_DDID, lit(GlobalConstants.EMPTY_STRING))
                  .withColumn(SparkSQLConstants.MSP_PNID, lit(GlobalConstants.EMPTY_STRING))
                   .withColumn(SparkSQLConstants.MSP_RPID, lit(GlobalConstants.EMPTY_STRING))
        }
       ihrData =ihrData .select(
          SparkSQLConstants.MAPPED_CLASS_ID,
          SparkSQLConstants.LABEL1,
          SparkSQLConstants.PREFERRED_TERM_EN,           
          SparkSQLConstants.ALIAS_TERM_EN,SparkSQLConstants.MSP_DDID,SparkSQLConstants.MSP_PNID,SparkSQLConstants.MSP_RPID)
 
    ihrData
  }
  
  def matchTypeSCData(file: String): String = {
    var matchType : String = GlobalConstants.EMPTY_STRING
    
    if(file.equals(GlobalConstants.MEDISPAN_PRODUCT)){
          matchType = GlobalConstants.MSPD_SC_DUMP
          }else if(file.equals(GlobalConstants.NDC_ONT)){
           matchType = GlobalConstants.NDC_SC_DUMP
          }else if(file.equals(GlobalConstants.fdbSourceAnnotationMap)){
           matchType = GlobalConstants.FDB_SC_DUMP
          }else if(file.equals(GlobalConstants.RXN_ONT)){
           matchType = GlobalConstants.RX_SC_DUMP
          }else if(file.equals(GlobalConstants.MULTUM_SRC_VOCB)){
           matchType = GlobalConstants.MULTUM_SC_DUMP
          }else if(file.equals(GlobalConstants.SNOMED_PHARMA)){
           matchType = GlobalConstants.SNORX_SC_DUMP
      }
    matchType
  }
  
   def getIHRMatchType(ihrCompData: DataFrame, file: String): DataFrame = {
      var ihrData = ihrCompData
      
        val ihrRankData = ihrData
        .groupBy(col(SparkSQLConstants.CONCEPT_ID) as SparkSQLConstants.GROUP_CONCEPT_ID)
        .agg(max(col(SparkSQLConstants.MATCH_RANK)) as SparkSQLConstants.MAX_RANK)
      
      ihrData = ihrData.join(ihrRankData,  ihrRankData(SparkSQLConstants.GROUP_CONCEPT_ID) === ihrData(SparkSQLConstants.CONCEPT_ID) &&
                            ihrRankData(SparkSQLConstants.MAX_RANK) === ihrData(SparkSQLConstants.MATCH_RANK))
                            .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.QUEST_AP))
       if(file == GlobalConstants.PRODUCT_MEDICATION_ONT)
             ihrData=ihrData  .withColumn(
          SparkSQLConstants.MATCH_TYPE,
          when(col(SparkSQLConstants.MAX_RANK) === 9, GlobalConstants.PT_MED_IHR_DUMP)
            .when(col(SparkSQLConstants.MAX_RANK) === 8, GlobalConstants.LABELMED_IHR_DUMP)
            .when(col(SparkSQLConstants.MAX_RANK) === 7, GlobalConstants.ALIAS_MED_IHR_DUMP))
            else
            ihrData=ihrData  .withColumn(
          SparkSQLConstants.MATCH_TYPE,
          when(col(SparkSQLConstants.MAX_RANK) === 9, GlobalConstants.PT_DEV_IHR_DUMP)
            .when(col(SparkSQLConstants.MAX_RANK) === 8, GlobalConstants.LABEL_DEV_IHR_DUMP)
            .when(col(SparkSQLConstants.MAX_RANK) === 7, GlobalConstants.ALIAS_DEV_IHR_DUMP))
      ihrData
  }
   
   def generateFdbSCEditMapData(taxonomyName: String,  sourceCodes: DataFrame,codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
     
    var superClassBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SUPERCLASS_DUMP_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      superClassBasePath = superClassBasePath.substring(5)
    }
     
     var scCodes = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], buildSchema())
     var scDumpCodes = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], buildSCSchema())
     var fdbSourceAnnotation = GlobalConstants.fdbSourceAnnotationMap 
       var sourceDF = sourceCodes
       var fdbSuperClassData = loadSuperClassData(spark, superClassBasePath , fdbSourceAnnotation)
      
       var taxonomyId = GlobalConstants.fdbTaxonomyIds.apply(taxonomyName)
       var fdbtaxonomyId:String = taxonomyId+GlobalConstants.UNDER_SCORE
       sourceDF = sourceDF.select(GlobalConstants.STAR).withColumn(SparkSQLConstants.FDB_TAXONOMYID,concat(lit(fdbtaxonomyId),sourceDF.col(SparkSQLConstants.CONCEPT_ID)));

      scCodes = sourceDF.join(fdbSuperClassData, fdbSuperClassData(SparkSQLConstants.CLASS_ID) === sourceDF(SparkSQLConstants.FDB_TAXONOMYID), SparkSQLConstants.ANTI_LEFT_JOIN)
                      .select(SparkSQLConstants.TAXONOMY_FSN,
                        SparkSQLConstants.CONCEPT_ID,
                        SparkSQLConstants.TYPE,
                        SparkSQLConstants.PREFERRED_TERM,
                        SparkSQLConstants.PREFERRED_TERM_EN,
                        SparkSQLConstants.STATUS,
                        SparkSQLConstants.GEN_MED_ID,
                        SparkSQLConstants.CHANGECODE_FLAG)
    scCodes
   }
   
}