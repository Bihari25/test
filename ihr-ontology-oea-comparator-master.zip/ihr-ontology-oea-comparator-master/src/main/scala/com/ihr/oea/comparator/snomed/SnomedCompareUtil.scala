package com.ihr.oea.comparator.snomed

import scala.collection.mutable.ArrayBuffer
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import scala.collection.mutable.WrappedArray
import scala.util.control.Breaks
import org.apache.spark.sql.types.ArrayType
import scala.util.control.Breaks.break
import scala.util.control.Breaks.breakable
import com.ihr.oea.util.ComparatorUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lower
import org.apache.spark.sql.functions.concat_ws
import org.apache.spark.sql.functions.collect_list
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.max
import org.apache.spark.sql.functions.split
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.functions.trim
import org.apache.spark.sql.functions.regexp_replace
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import org.apache.spark.sql.Row

@throws(classOf[Exception])
object SnomedCompareUtil{
  val log = Logger.getLogger(getClass.getName)
  val util = new ComparatorUtil
   val mongoDAO = new MongoDAO
  def generateSnomedWorklistData(taxonomyName: String, sourceCodes: DataFrame, codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
   
    log.info("generating the IHR annotation path for snomed releaseId : " + releaseID)
    var ihrAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.IHR_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      ihrAnnotationBasePath = ihrAnnotationBasePath.substring(5)
    }
    var isProcedureTax = false
    var isMorphologyTax = false

    var ihrOntologyFiles = GlobalConstants.snomedIHRAnnotationMap.apply(taxonomyName)
    var sourceAddCodesDF = sourceCodes
    var addDirectMapCodesDF = sourceCodes
    
    if (null != ihrOntologyFiles) {
      log.info("Loading IHR annotation data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
      val ihrOntologyFilesArray = ihrOntologyFiles.split(GlobalConstants.COMMA)
      ihrOntologyFilesArray.foreach(ihrOntologyFile => {
        if (ihrOntologyFile.contains(GlobalConstants.BODYSTRUCTURE_ONT)) {
          sourceAddCodesDF = sourceCodes.filter(
            col(SparkSQLConstants.FSN).like(GlobalConstants.BODY_STRUCTURE_PATTERN) ||
              col(SparkSQLConstants.FSN).like(GlobalConstants.CELL_STRUCTURE_PATTERN) ||
              col(SparkSQLConstants.FSN).like(GlobalConstants.CELL_PATTERN))
        }
        if (ihrOntologyFile.contains(GlobalConstants.MORPHOLOGY_ONT)) {
          sourceAddCodesDF = sourceCodes.filter(col(SparkSQLConstants.FSN).like(GlobalConstants.MORPHOLOGIC_PATTERN))
          isMorphologyTax = true
        }
        if (ihrOntologyFile.contains(GlobalConstants.PROCEDURE_ONT) && taxonomyName.contains(GlobalConstants.SITUATION_PATTERN)) {
          isProcedureTax = true
          sourceAddCodesDF = sourceAddCodesDF.join(addDirectMapCodesDF, sourceAddCodesDF(SparkSQLConstants.CONCEPT_ID) === addDirectMapCodesDF(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
        }
        
        val fullIHROntologyDF = spark.read
          .format(GlobalConstants.CSV_FORMAT)
          .option(GlobalConstants.HEADER, true)
          .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
          .load(ihrAnnotationBasePath + ihrOntologyFile)          
          .withColumn(SparkSQLConstants.ALIAS_TERM_EN, split(col(SparkSQLConstants.ALIAS_TERM_EN), GlobalConstants.SQUARE_PIPE))
         .withColumnRenamed(col("Label1").toString(),SparkSQLConstants.LABEL)
      
        var ihrOntologyDF = fullIHROntologyDF.select(
          SparkSQLConstants.CLASS_ID,
          SparkSQLConstants.LABEL,
          SparkSQLConstants.PREFERRED_TERM_EN,
          SparkSQLConstants.ALIAS_TERM_EN)
          

        log.info("comparing release data and IHR annotation data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
        if (isMorphologyTax) {
          isMorphologyTax = false
          addDirectMapCodesDF = addDirectMapCodesDF.union(compareDataFrames(sourceAddCodesDF, ihrOntologyDF, codeType))
        } else if (isProcedureTax) {
          isProcedureTax = false  
          addDirectMapCodesDF = addDirectMapCodesDF.union(compareDataFrames(sourceAddCodesDF, ihrOntologyDF, codeType))
        } else {
          addDirectMapCodesDF = compareDataFrames(sourceAddCodesDF, ihrOntologyDF, codeType)
        }
        //ihr File Loop
      })
    }

    log.info("generated directMap data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
    val groupedDirectMapCodes = addDirectMapCodesDF
      .groupBy(col(SparkSQLConstants.CONCEPT_ID) as SparkSQLConstants.GROUP_CONCEPT_ID)
      .agg(max(col(SparkSQLConstants.MATCH_RANK)) as SparkSQLConstants.MAX_RANK)

    addDirectMapCodesDF = addDirectMapCodesDF.join(
      groupedDirectMapCodes,
      groupedDirectMapCodes(SparkSQLConstants.GROUP_CONCEPT_ID) === addDirectMapCodesDF(SparkSQLConstants.CONCEPT_ID) &&
        groupedDirectMapCodes(SparkSQLConstants.MAX_RANK) === addDirectMapCodesDF(SparkSQLConstants.MATCH_RANK))
      .withColumn(
        SparkSQLConstants.MATCH_TYPE,
        when(col(SparkSQLConstants.MAX_RANK) === 9, GlobalConstants.PT_PT)
          .when(col(SparkSQLConstants.MAX_RANK) === 8, GlobalConstants.PT_LABEL)
          .when(col(SparkSQLConstants.MAX_RANK) === 7, GlobalConstants.PT_ALIAS)
          .when(col(SparkSQLConstants.MAX_RANK) === 6, GlobalConstants.FSN_PT)
          .when(col(SparkSQLConstants.MAX_RANK) === 5, GlobalConstants.FSN_LABEL)
          .when(col(SparkSQLConstants.MAX_RANK) === 4, GlobalConstants.FSN_ALIAS)
          .when(col(SparkSQLConstants.MAX_RANK) === 3, GlobalConstants.SYN_PT)
          .when(col(SparkSQLConstants.MAX_RANK) === 2, GlobalConstants.SYN_LABEL)
          .when(col(SparkSQLConstants.MAX_RANK) === 1, GlobalConstants.SYN_ALIAS))

         
    addDirectMapCodesDF.select(
      SparkSQLConstants.TAXONOMY_FSN,
      SparkSQLConstants.CONCEPT_ID,
      SparkSQLConstants.FSN,
      SparkSQLConstants.PREFERRED_TERM,
      SparkSQLConstants.SYNONYM,
      SparkSQLConstants.EFFECTIVE_TIME,
      SparkSQLConstants.LANGUAGE_CODE,
      SparkSQLConstants.IHR_MAP,
      SparkSQLConstants.MATCH_TYPE,
      SparkSQLConstants.MATCH_VALUE, SparkSQLConstants.CHANGECODE_FLAG)
  }

  def compareDataFrames(df1: DataFrame, df2: DataFrame, codeType: String): DataFrame = {
    var sourceAddCodesDF = df1.sort(SparkSQLConstants.PREFERRED_TERM, SparkSQLConstants.FSN, SparkSQLConstants.SYNONYM)
 
    var ihrOntologyDF = df2.sort(SparkSQLConstants.PREFERRED_TERM_EN, SparkSQLConstants.LABEL1, SparkSQLConstants.ALIAS_TERM_EN)
   
    var addDirectMapCodesDF = sourceAddCodesDF.join(
      ihrOntologyDF,
        same_array_snomed(split(sourceAddCodesDF(SparkSQLConstants.PREFERRED_TERM),GlobalConstants.SPACE), split(ihrOntologyDF(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE)) ||
        same_pt_label_snomed(sourceAddCodesDF(SparkSQLConstants.PREFERRED_TERM), ihrOntologyDF(SparkSQLConstants.LABEL1)) ||
         pt_in_alias_snomed(split(sourceAddCodesDF(SparkSQLConstants.PREFERRED_TERM),GlobalConstants.SPACE), ihrOntologyDF(SparkSQLConstants.ALIAS_TERM_EN)) ||
        same_fsn_pten_snomed(sourceAddCodesDF(SparkSQLConstants.FSN), ihrOntologyDF(SparkSQLConstants.PREFERRED_TERM_EN)) ||
        same_fsn_label_snomed(sourceAddCodesDF(SparkSQLConstants.FSN), ihrOntologyDF(SparkSQLConstants.LABEL1)) ||
        fsn_in_alias_snomed(sourceAddCodesDF(SparkSQLConstants.FSN), ihrOntologyDF(SparkSQLConstants.ALIAS_TERM_EN)) ||
        syn_in_pten_snomed(sourceAddCodesDF(SparkSQLConstants.SYNONYM), split(ihrOntologyDF(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE)) ||
        syn_in_label_snomed(sourceAddCodesDF(SparkSQLConstants.SYNONYM), ihrOntologyDF(SparkSQLConstants.LABEL1)) ||
        syn_in_alias_snomed(sourceAddCodesDF(SparkSQLConstants.SYNONYM), ihrOntologyDF(SparkSQLConstants.ALIAS_TERM_EN)))
      .withColumn(SparkSQLConstants.IHR_MAP, ihrOntologyDF(SparkSQLConstants.LABEL1))
      .withColumn(
        SparkSQLConstants.MATCH_RANK,
        when( same_array_snomed(split(sourceAddCodesDF(SparkSQLConstants.PREFERRED_TERM),GlobalConstants.SPACE), split(ihrOntologyDF(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE)), 9)
          .when(same_pt_label_snomed(sourceAddCodesDF(SparkSQLConstants.PREFERRED_TERM), ihrOntologyDF(SparkSQLConstants.LABEL1)) , 8)
          .when(pt_in_alias_snomed(split(sourceAddCodesDF(SparkSQLConstants.PREFERRED_TERM),GlobalConstants.SPACE), ihrOntologyDF(SparkSQLConstants.ALIAS_TERM_EN)), 7)
          .when(same_fsn_pten_snomed(sourceAddCodesDF(SparkSQLConstants.FSN), ihrOntologyDF(SparkSQLConstants.PREFERRED_TERM_EN)), 6)
          .when(same_fsn_label_snomed(sourceAddCodesDF(SparkSQLConstants.FSN), ihrOntologyDF(SparkSQLConstants.LABEL1)), 5)
          .when( fsn_in_alias_snomed(sourceAddCodesDF(SparkSQLConstants.FSN), ihrOntologyDF(SparkSQLConstants.ALIAS_TERM_EN)), 4)
          .when(syn_in_pten_snomed(sourceAddCodesDF(SparkSQLConstants.SYNONYM), split(ihrOntologyDF(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE)), 3)
          .when(syn_in_label_snomed(sourceAddCodesDF(SparkSQLConstants.SYNONYM), ihrOntologyDF(SparkSQLConstants.LABEL1)), 2)
          .when(syn_in_alias_snomed(sourceAddCodesDF(SparkSQLConstants.SYNONYM), ihrOntologyDF(SparkSQLConstants.ALIAS_TERM_EN)), 1))

      .withColumn(SparkSQLConstants.MATCH_VALUE, concat_ws(
        GlobalConstants.COMMA,
        ihrOntologyDF(SparkSQLConstants.LABEL1), ihrOntologyDF(SparkSQLConstants.PREFERRED_TERM_EN),
        concat_ws(GlobalConstants.PIPE, ihrOntologyDF(SparkSQLConstants.ALIAS_TERM_EN))))
        
    addDirectMapCodesDF
  }

  def getWorklistID(workBenchData: DataFrame, taxonomyName: String): String = {
    val workListIdDF = workBenchData.filter(col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
      .select(SparkSQLConstants.WORKLIST_ID)

    var workListID = GlobalConstants.EMPTY_STRING
    var loop = new Breaks
    loop.breakable(
      workListIdDF.collect().foreach(row => {
        workListID = row.getAs[String](0).trim()
        loop.break()
      }))
    workListID
  }

  def dropDuplicateColumns(df: DataFrame): DataFrame = {
    log.info("starting droping duplicate columns from dataframe...")
    val df_cols = df.columns.toArray
    val mandatoryColumns = Seq(SparkSQLConstants.LABEL1, SparkSQLConstants.PREFERRED_TERM_EN, SparkSQLConstants.ALIAS_TERM_EN).toArray
    var dropList = ArrayBuffer[String]()
    var renameList = ArrayBuffer[String]()
    var colCount = 0
    // check if there are duplicate mandatory columns
    breakable {
      for (c1 <- mandatoryColumns) {
        colCount = 0
        for (c2 <- df_cols) {
          if (c2.contains(c1)) {
            colCount = colCount + 1
          }
        }
        if (colCount > 1) break
      }
    }
    //do not proceed further - return original dataframe if there are no duplicate columns
    if (colCount <= 1) return df
    // identify duplicate columns that are empty or null rows
    for (c1 <- mandatoryColumns) {
      for (c2 <- df_cols) {
        if (c2.contains(c1)) {
          if (df.filter((df.col(c2) =!= GlobalConstants.EMPTY_STRING) || (df.col(c2).isNotNull)).head(1).isEmpty)
            dropList += c2
          else
            renameList += c2
        }
      }
    }

    // check if duplicate columns still exist with row values in both columns containing data
    for (c1 <- mandatoryColumns) {
      colCount = 0
      for (c2 <- renameList) {
        if (c2.contains(c1)) {
          colCount = colCount + 1
        }
      }
    }

    // if not duplicate columns then return filtered dataframe with defined column names from mandatory columns array
    if (colCount <= 1) {
      // drop the unwanted columns
      val filtered_df = df.drop(dropList: _*)
      // fetch all the column names of the filtered dataframe
      var columnNames = filtered_df.columns.toArray
      // rename duplicate columns as per definition from the mandatory columns array
      for (c1 <- mandatoryColumns) {
        breakable {
          for (i <- 0 until columnNames.length) {
            if (columnNames(i).contains(c1)) {
              columnNames(i) = c1
              break
            }
          }
        }
      }
      log.info("droping duplicate columns from dataframe completed.")
      return filtered_df.toDF(columnNames: _*)
    } else {
      // merge columns (need to define requirements)
      return df
    }
  }
  def generatePropconjDF(df1:DataFrame, df2:DataFrame, codeType:String) : DataFrame = {
    
     var src_df= df1.withColumnRenamed(SparkSQLConstants.PREFERRED_TERM,GlobalConstants.PREFERRED_TERM_SRC)
      .withColumnRenamed(SparkSQLConstants.FSN,GlobalConstants.FSN_SRC)
      .withColumnRenamed(SparkSQLConstants.SYNONYM,GlobalConstants.SYS_SRC )
      .withColumnRenamed(SparkSQLConstants.PT, SparkSQLConstants.PREFERRED_TERM)
      .withColumnRenamed(SparkSQLConstants.LABEL, SparkSQLConstants.FSN)
      .withColumnRenamed(SparkSQLConstants.SYN_ALIAS, SparkSQLConstants.SYNONYM)

      var ihr_df= df2.withColumnRenamed(SparkSQLConstants.PREFERRED_TERM_EN,GlobalConstants.IHR_preferredTerm_en)
      .withColumnRenamed(SparkSQLConstants.LABEL,GlobalConstants.IHR_label)
      .withColumnRenamed(SparkSQLConstants.ALIAS_TERM_EN,GlobalConstants.IHR_alias_en )
      .withColumnRenamed(GlobalConstants.PTEN, SparkSQLConstants.PREFERRED_TERM_EN)
      .withColumnRenamed(GlobalConstants.LabelEN, SparkSQLConstants.LABEL)
      .withColumnRenamed(SparkSQLConstants.SYN_ALIAS_EN, SparkSQLConstants.ALIAS_TERM_EN)

      var prop_conj_jumbled_df = compareDataFrames(src_df, ihr_df, codeType)
      
      
      val groupedDirectMapCodes = prop_conj_jumbled_df
      .groupBy(col(SparkSQLConstants.CONCEPT_ID) as SparkSQLConstants.GROUP_CONCEPT_ID)
      .agg(max(col(SparkSQLConstants.MATCH_RANK)) as SparkSQLConstants.MAX_RANK)

    prop_conj_jumbled_df = prop_conj_jumbled_df.join(
      groupedDirectMapCodes,
      groupedDirectMapCodes(SparkSQLConstants.GROUP_CONCEPT_ID) === prop_conj_jumbled_df(SparkSQLConstants.CONCEPT_ID) &&
        groupedDirectMapCodes(SparkSQLConstants.MAX_RANK) === prop_conj_jumbled_df(SparkSQLConstants.MATCH_RANK))
      .withColumn(
        SparkSQLConstants.MATCH_TYPE,
        when(col(SparkSQLConstants.MAX_RANK) === 9, GlobalConstants.PT_PT)
          .when(col(SparkSQLConstants.MAX_RANK) === 8, GlobalConstants.PT_LABEL)
          .when(col(SparkSQLConstants.MAX_RANK) === 7, GlobalConstants.PT_ALIAS)
          .when(col(SparkSQLConstants.MAX_RANK) === 6, GlobalConstants.FSN_PT)
          .when(col(SparkSQLConstants.MAX_RANK) === 5, GlobalConstants.FSN_LABEL)
          .when(col(SparkSQLConstants.MAX_RANK) === 4, GlobalConstants.FSN_ALIAS)
          .when(col(SparkSQLConstants.MAX_RANK) === 3, GlobalConstants.SYN_PT)
          .when(col(SparkSQLConstants.MAX_RANK) === 2, GlobalConstants.SYN_LABEL)
          .when(col(SparkSQLConstants.MAX_RANK) === 1, GlobalConstants.SYN_ALIAS))
    prop_conj_jumbled_df = prop_conj_jumbled_df.select(
      SparkSQLConstants.TAXONOMY_FSN,
      SparkSQLConstants.CONCEPT_ID, GlobalConstants.PREFERRED_TERM_SRC, GlobalConstants.FSN_SRC, GlobalConstants.SYS_SRC,
      SparkSQLConstants.EFFECTIVE_TIME,
      SparkSQLConstants.LANGUAGE_CODE,
      SparkSQLConstants.MATCH_TYPE,
      SparkSQLConstants.MATCH_VALUE,SparkSQLConstants.CHANGECODE_FLAG,
      GlobalConstants.IHR_label
      )
      
    val propConjJumbledDF = prop_conj_jumbled_df.select(GlobalConstants.STAR).withColumnRenamed(GlobalConstants.PREFERRED_TERM_SRC, SparkSQLConstants.PREFERRED_TERM)
      .withColumnRenamed(GlobalConstants.FSN_SRC, SparkSQLConstants.FSN)
      .withColumnRenamed(GlobalConstants.SYS_SRC, SparkSQLConstants.SYNONYM)
      .withColumnRenamed(GlobalConstants.IHR_label, SparkSQLConstants.IHR_MAP)
    
    propConjJumbledDF.select(
      SparkSQLConstants.TAXONOMY_FSN,
      SparkSQLConstants.CONCEPT_ID,
      SparkSQLConstants.FSN,
      SparkSQLConstants.PREFERRED_TERM,
      SparkSQLConstants.SYNONYM,
      SparkSQLConstants.EFFECTIVE_TIME,
      SparkSQLConstants.LANGUAGE_CODE,
      SparkSQLConstants.IHR_MAP,
      SparkSQLConstants.MATCH_TYPE,
      SparkSQLConstants.MATCH_VALUE, SparkSQLConstants.CHANGECODE_FLAG)
      
      propConjJumbledDF
      
  }
  
  def compareSRCPrepoConjDF( propConj: DataFrame, scrCodes: DataFrame,spark: SparkSession) : DataFrame = {
      
      var propConjDF = SparkSession.builder().getOrCreate().emptyDataFrame
       var propConjDF_new = SparkSession.builder().getOrCreate().emptyDataFrame
      import spark.implicits._
      val keyVal = propConj.map(r =>( r(0).toString, r(1).toString ) ).collect.toMap
      
      val getVal = udf[String, String] (x => x.split(GlobalConstants.SPACE).map(x => keyVal.get(x).getOrElse(x) ).mkString( GlobalConstants.SPACE ) )
      
     propConjDF = (scrCodes.withColumn(GlobalConstants.TEMP_PT ,  regexp_replace( getVal(lower(scrCodes(SparkSQLConstants.PREFERRED_TERM)))  , GlobalConstants.REG_PATTERN, GlobalConstants.SPACE)     )
                           .withColumn(GlobalConstants.TEMP_LABEL , regexp_replace( getVal(lower(scrCodes(SparkSQLConstants.FSN)))  , GlobalConstants.REG_PATTERN, GlobalConstants.SPACE)     )
                          .withColumn(SparkSQLConstants.SYN ,concat_ws(GlobalConstants.PIPE, scrCodes(SparkSQLConstants.SYNONYM)))).dropDuplicates(SparkSQLConstants.CONCEPT_ID)
     propConjDF_new = propConjDF.withColumn(SparkSQLConstants.ALIAS , regexp_replace( getVal(lower(propConjDF(SparkSQLConstants.SYN)))  , GlobalConstants.REG_PATTERN, GlobalConstants.SPACE)     ) 

     propConjDF_new =  propConjDF_new.withColumn(GlobalConstants.TEMPPT, when(col(GlobalConstants.TEMP_PT) === GlobalConstants.EMPTY_STRING, null).otherwise(trim(col(GlobalConstants.TEMP_PT))))
                                      .withColumn(GlobalConstants.TEMPFSN, when(col(GlobalConstants.TEMP_LABEL) === GlobalConstants.EMPTY_STRING, null).otherwise(trim(col(GlobalConstants.TEMP_LABEL))))
                                      .withColumn(GlobalConstants.TEMPSYN, when(col(SparkSQLConstants.ALIAS) === GlobalConstants.EMPTY_STRING, null).otherwise(trim(col(SparkSQLConstants.ALIAS))))
                                      .withColumnRenamed(GlobalConstants.TEMPPT, SparkSQLConstants.PT )
                                      .withColumnRenamed(GlobalConstants.TEMPFSN, SparkSQLConstants.LABEL)
     propConjDF_new = propConjDF_new.   withColumn(SparkSQLConstants.SYN_ALIAS, split(propConjDF_new(GlobalConstants.TEMPSYN),GlobalConstants.ESCAPE_PIPE))
                                
     propConjDF_new.select(SparkSQLConstants.RELEASE_ID, SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.TAXONOMY_FSN, SparkSQLConstants.PREFERRED_TERM,
                            SparkSQLConstants.PT,  SparkSQLConstants.FSN,  SparkSQLConstants.LABEL ,  SparkSQLConstants.SYNONYM,  SparkSQLConstants.SYN_ALIAS, SparkSQLConstants.EFFECTIVE_TIME,
                            SparkSQLConstants.LANGUAGE_CODE)
                    
      propConjDF_new 
    }
  
    val colValCheck = udf((t: String) => {
      var value = GlobalConstants.EMPTY_STRING
      if (t != null) {
        value = t.trim()
      } else {
        value
      }
      value
    })
       
  
 def buildSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.CLASS_ID, StringType, true),
        StructField(SparkSQLConstants.PREFERRED_TERM_EN, StringType, true),
         StructField("PT-EN", StringType, true),
        StructField(SparkSQLConstants.LABEL, StringType, true),
        StructField("Label-EN", StringType, true),
        StructField("aliasTerm@en", ArrayType(StringType), true),
         StructField("SYN_ALIAS_EN", ArrayType(StringType), true)))
    schema
  }
   def compareIHRPrepoConjDF(taxonomyName: String, propConj: DataFrame,spark: SparkSession,oesConfiguration: OESConfiguration,releaseID: String) : DataFrame = {
    var ihrAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.IHR_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      ihrAnnotationBasePath = ihrAnnotationBasePath.substring(5)
    } 
      var finalDF = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], buildSchema())
      var isProcedureTax = false
      var isMorphologyTax = false
      var propConjDF = SparkSession.builder().getOrCreate().emptyDataFrame
       var finalpropConjDF = SparkSession.builder().getOrCreate().emptyDataFrame
        var ihrOntologyFiles = GlobalConstants.snomedIHRAnnotationMap.apply(taxonomyName)
   
             if(null != ihrOntologyFiles) {
                val ihrOntologyFilesArray = ihrOntologyFiles.split(GlobalConstants.COMMA)
              ihrOntologyFilesArray.foreach(ihrOntologyFile => {
                     var fullIHROntologyDF = spark.read
                  .format(GlobalConstants.CSV_FORMAT)
                  .option(GlobalConstants.HEADER, true)
                  .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
                 .load(ihrAnnotationBasePath + ihrOntologyFile)
                  .withColumn(SparkSQLConstants.ALIAS_TERM_EN, split(col(SparkSQLConstants.ALIAS_TERM_EN), GlobalConstants.SQUARE_PIPE))
                  .withColumnRenamed(col("Label1").toString(),SparkSQLConstants.LABEL)
                  
                 if (ihrOntologyFile.contains(GlobalConstants.MORPHOLOGY_ONT)) {
                      isMorphologyTax = true
                      }
                  if (ihrOntologyFile.contains(GlobalConstants.PROCEDURE_ONT) && taxonomyName.contains(GlobalConstants.SITUATION_PATTERN)) {
                    isProcedureTax = true
                  }
                  
                var ihrOntologyDF =   fullIHROntologyDF.select(
                  SparkSQLConstants.CLASS_ID,
                  SparkSQLConstants.LABEL,
                  SparkSQLConstants.PREFERRED_TERM_EN,
                  SparkSQLConstants.ALIAS_TERM_EN)
                  
                  import spark.implicits._
      val keyVal = propConj.map(r =>( r(0).toString, r(1).toString ) ).collect.toMap
      val getVal = udf[String, String] (x => x.split(GlobalConstants.SPACE).map(x => keyVal.get(x).getOrElse(x) ).mkString( GlobalConstants.SPACE ) )
    
     propConjDF = (ihrOntologyDF.withColumn(SparkSQLConstants.PT_EN , regexp_replace( getVal(colValCheck(lower(ihrOntologyDF(SparkSQLConstants.PREFERRED_TERM_EN)))) , GlobalConstants.REG_PATTERN, GlobalConstants.SPACE) )
                           .withColumn(SparkSQLConstants.Label_EN , regexp_replace( getVal(colValCheck(lower(ihrOntologyDF(SparkSQLConstants.LABEL1)))) , GlobalConstants.REG_PATTERN, GlobalConstants.SPACE)     )
                          .withColumn(SparkSQLConstants.SYN_EN ,concat_ws(GlobalConstants.PIPE, ihrOntologyDF(SparkSQLConstants.ALIAS_TERM_EN))))
                        
     var propConjDF_new = propConjDF.withColumn(SparkSQLConstants.ALIAS_EN , regexp_replace( getVal(lower(propConjDF(SparkSQLConstants.SYN_EN)))  , GlobalConstants.REG_PATTERN, GlobalConstants.SPACE) )               
     
     propConjDF_new =  propConjDF_new.withColumn(GlobalConstants.TEMPPT, when(col(SparkSQLConstants.PT_EN) === GlobalConstants.EMPTY_STRING, null).otherwise(trim(col(SparkSQLConstants.PT_EN))))
                                      .withColumn(GlobalConstants.TEMPFSN, when(col(SparkSQLConstants.Label_EN) === GlobalConstants.EMPTY_STRING, null).otherwise(trim(col(SparkSQLConstants.Label_EN))))
                                      .withColumn(GlobalConstants.TEMPSYN, when(col(SparkSQLConstants.ALIAS_EN) === GlobalConstants.EMPTY_STRING, null).otherwise(trim(col(SparkSQLConstants.ALIAS_EN))))
                                      .withColumn(SparkSQLConstants.IHR_STATUS, lit(GlobalConstants.QUEST_AP))
                                      .withColumnRenamed(GlobalConstants.TEMPPT, GlobalConstants.PTEN)
                                      .withColumnRenamed(GlobalConstants.TEMPFSN, GlobalConstants.LabelEN)
                                      
     finalpropConjDF = propConjDF_new.withColumn(SparkSQLConstants.SYN_ALIAS_EN, split(propConjDF_new(GlobalConstants.TEMPSYN),GlobalConstants.ESCAPE_PIPE))
                         
    
     finalpropConjDF = finalpropConjDF.select( SparkSQLConstants.CLASS_ID, SparkSQLConstants.PREFERRED_TERM_EN,
                           GlobalConstants.PTEN,  SparkSQLConstants.LABEL1,  GlobalConstants.LabelEN,  SparkSQLConstants.ALIAS_TERM_EN,  SparkSQLConstants.SYN_ALIAS_EN )
                 
                if (isMorphologyTax) {
                        isMorphologyTax = false
                        finalDF = finalDF.union(finalpropConjDF).distinct()
                      } else if (isProcedureTax) {
                        isProcedureTax = false  
                        finalDF = finalDF.union(finalpropConjDF).distinct()
                      } else {
                      finalDF = finalDF.union(finalpropConjDF).distinct()
                      }                
                    
                 })
               }
      finalDF
  }
   
   
   def compareRemoveTermstDF( termDf: DataFrame, srcCodes: DataFrame,spark: SparkSession) : DataFrame = {
      var propConjDF = SparkSession.builder().getOrCreate().emptyDataFrame
       var propConjDF_new = SparkSession.builder().getOrCreate().emptyDataFrame
      import spark.implicits._
      val keyVal = termDf.map(r =>( r(0).toString, r(1).toString ) ).collect.toMap
      val getVal = udf[String, String] (x => x.split(GlobalConstants.SPACE).map(x => keyVal.get(x).getOrElse(x) ).mkString( GlobalConstants.SPACE ) )
      
     propConjDF = (srcCodes.select(GlobalConstants.STAR).withColumn(GlobalConstants.TEMP_PT ,  regexp_replace( getVal(lower(srcCodes(SparkSQLConstants.PREFERRED_TERM)))  , GlobalConstants.REG_PATTERN, GlobalConstants.SPACE)     )
                           .withColumn(GlobalConstants.TEMP_LABEL , regexp_replace( getVal(lower(srcCodes(SparkSQLConstants.FSN)))  , GlobalConstants.REG_PATTERN, GlobalConstants.SPACE)     )
                          .withColumn(SparkSQLConstants.SYN ,concat_ws(GlobalConstants.PIPE, srcCodes(SparkSQLConstants.SYNONYM)))).dropDuplicates(SparkSQLConstants.CONCEPT_ID)
                          
     propConjDF_new = propConjDF.withColumn(SparkSQLConstants.ALIAS , regexp_replace( getVal(lower(propConjDF(SparkSQLConstants.SYN)))  , GlobalConstants.REG_PATTERN, GlobalConstants.SPACE)     ) 
     
     
     propConjDF_new =  propConjDF_new.withColumn(GlobalConstants.TEMP_PT, when(col(GlobalConstants.TEMP_PT ) === GlobalConstants.EMPTY_STRING, null).otherwise(trim(col(GlobalConstants.TEMP_PT))))
                                      .withColumn(GlobalConstants.TEMPFSN, when(col(GlobalConstants.TEMP_LABEL) === GlobalConstants.EMPTY_STRING, null).otherwise(trim(col(GlobalConstants.TEMP_LABEL))))
                                      .withColumn(GlobalConstants.TEMPSYN, when(col(SparkSQLConstants.ALIAS) === GlobalConstants.EMPTY_STRING, null).otherwise(trim(col(SparkSQLConstants.ALIAS))))
                                      .withColumnRenamed(GlobalConstants.TEMP_PT, SparkSQLConstants.PT )
                                      .withColumnRenamed(GlobalConstants.TEMPFSN, SparkSQLConstants.LABEL)
     
     propConjDF_new = propConjDF_new.withColumn(SparkSQLConstants.SYN_ALIAS, split(propConjDF_new(GlobalConstants.TEMPSYN),GlobalConstants.ESCAPE_PIPE))
     
     propConjDF_new = propConjDF_new.select(SparkSQLConstants.RELEASE_ID, SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.TAXONOMY_FSN, SparkSQLConstants.PREFERRED_TERM,
                            SparkSQLConstants.PT,  SparkSQLConstants.FSN,  SparkSQLConstants.LABEL,  SparkSQLConstants.SYNONYM,  SparkSQLConstants.SYN_ALIAS, SparkSQLConstants.EFFECTIVE_TIME,
                            SparkSQLConstants.LANGUAGE_CODE,SparkSQLConstants.CHANGECODE_FLAG)
                            .withColumnRenamed(SparkSQLConstants.PREFERRED_TERM,GlobalConstants.PREFERRED_TERM_SRC)                      
                            .withColumnRenamed(SparkSQLConstants.FSN,GlobalConstants.FSN_SRC)
                            .withColumnRenamed(SparkSQLConstants.SYNONYM,GlobalConstants.SYS_SRC )
                            .withColumnRenamed(SparkSQLConstants.SYN_ALIAS,SparkSQLConstants.SYNONYM )
                            
       var termDF = propConjDF_new.select(trim(col(SparkSQLConstants.PT)).as(SparkSQLConstants.PREFERRED_TERM),trim(col(SparkSQLConstants.LABEL)).as(SparkSQLConstants.FSN),
                                   trim(col(SparkSQLConstants.CONCEPT_ID)).as(SparkSQLConstants.ID)) 
      val finalDF = termDF.join(propConjDF_new, propConjDF_new(SparkSQLConstants.CONCEPT_ID)  === termDF(SparkSQLConstants.ID))
      
      finalDF 
  }

   
   

       //pt-label
    val same_pt_label_snomed = udf((t: String, t2: String) => {
      if (t != null && t2 != null  && t2.length() > 0) {
        t.trim()
        var label = GlobalConstants.EMPTY_STRING
        if (t2.contains(GlobalConstants.SQUARE_BRACKET))
          label = t2.substring(0, t2.lastIndexOf(GlobalConstants.SQUARE_BRACKET)).trim()
        else
          label = t2.trim()
          
          var arrLabel = label.split(GlobalConstants.SPACE)
          var t1 = t.split(GlobalConstants.SPACE)
      
            if (t1 != null && arrLabel != null && t1.length == arrLabel.length &&
          (t1.map(_.trim().toLowerCase()).intersect(arrLabel.map(_.trim().toLowerCase())).length == arrLabel.length))
          { if(arrLabel.length!=1 ||arrLabel(0).equals(GlobalConstants.EMPTY_STRING) ){true} else false}  
        else if (t1 == null && arrLabel == null) { false }
        else if ((t1 == null && arrLabel != null) || (arrLabel == null && t1 != null)) { false }        
        else { false }

      
      } else false
    })


         
     val syn_in_pten_snomed = udf(( alias: WrappedArray[String], pt: WrappedArray[String]) => { 
        var result :Boolean = false
         if(null==pt || pt.equals(GlobalConstants.EMPTY_STRING) || null==alias ||  alias.equals(GlobalConstants.EMPTY_STRING)){
                                 false
                } else{
                    for (aliasVal <- alias) {
                      var syn :WrappedArray[String] = aliasVal.split(GlobalConstants.SPACE)
                       if (syn != null && pt != null && syn.length == pt.length && (syn.map(_.trim().toLowerCase()).intersect(pt.map(_.trim().toLowerCase())).length == pt.length)){
                         if((syn.length!=1|| syn(0).equals(GlobalConstants.EMPTY_STRING))){result = true   } else result=false                 
                       }
                }
                 result
             }
      })
    
     val syn_in_label_snomed = udf((alias: WrappedArray[String], label : String)=>{
       var t2 = GlobalConstants.EMPTY_STRING
       var result :Boolean = false
         if(null == label || label.equals(GlobalConstants.EMPTY_STRING) || null == alias || alias.equals(GlobalConstants.EMPTY_STRING)){
           false
         }
         else{
           if (label.contains(GlobalConstants.SQUARE_BRACKET))
            t2 = label.substring(0, label.lastIndexOf(GlobalConstants.SQUARE_BRACKET)).trim()
          else
            t2 = label.trim()
            var arrlabel = t2.split(GlobalConstants.SPACE)
           for(aliasVal <- alias){
               var syn :WrappedArray[String] = aliasVal.split(GlobalConstants.SPACE)
               if (syn != null && arrlabel != null && syn.length == arrlabel.length && (syn.map(_.trim().toLowerCase()).intersect(arrlabel.map(_.trim().toLowerCase())).length == arrlabel.length)){
                         if((syn.length!=1|| syn(0).equals(GlobalConstants.EMPTY_STRING))){result = true   }  else result=false                       
                 }
           }
           result
         }
     })
     val syn_in_alias_snomed = udf((syn: WrappedArray[String], alias: WrappedArray[String])=>{
        var result :Boolean = false
         if(null==syn || syn.equals(GlobalConstants.EMPTY_STRING) || null==alias ||  alias.equals(GlobalConstants.EMPTY_STRING)){
                false
         } else{
             for(synVal <- syn){
               var syn_data : WrappedArray[String] = synVal.split(GlobalConstants.SPACE)
                 for(aliasVal <- alias ){
                    var alias_data : WrappedArray[String] = aliasVal.split(GlobalConstants.SPACE)
                      if(alias_data !=null && syn_data != null && alias_data.length == syn_data.length && (alias_data.map(_.trim().toLowerCase()).intersect(syn_data.map(_.trim().toLowerCase())).length == syn_data.length)){
                        if((alias_data.length!=1 || alias_data(0).equals(GlobalConstants.EMPTY_STRING))){result = true} else result=false
                      }
                 }
             }
             result
         }
     })
   val same_array_snomed = udf { (t1: WrappedArray[String], t2: WrappedArray[String]) =>

		     if (t1 != null && t2 != null && t1.length == t2.length &&
          (t1.map(_.trim().toLowerCase()).intersect(t2.map(_.trim().toLowerCase())).length == t2.length) && t2.length!=0)
          {
		       true }  
        else if (t1 == null && t2 == null) { 
          false }
        else if ((t1 == null && t2 != null) || (t2 == null && t1 != null)) {
          false }        
        else { 
          false }
   }
    
    
    //pt-alias
    def pt_in_alias_snomed = udf((pt: WrappedArray[String], alias: WrappedArray[String]) => { 
        var result :Boolean = false
         if(null==pt || pt.equals(GlobalConstants.EMPTY_STRING) || null==alias ||  alias.equals(GlobalConstants.EMPTY_STRING)){
                                 false
                } else{
                    for (aliasVal <- alias) {
                      var t2 :WrappedArray[String] = aliasVal.split(GlobalConstants.SPACE)
                       if (pt != null && t2 != null && pt.length == t2.length && (pt.map(_.trim().toLowerCase()).intersect(t2.map(_.trim().toLowerCase())).length == t2.length)){
                         if((t2.length!=1 || t2(0).equals(GlobalConstants.EMPTY_STRING))){result = true } else result=false                
                       }
                }
                 result
             }
      })
              
   val same_fsn_pten_snomed = udf((t1: String, t2: String) => {
      if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0) {
        var fsn = GlobalConstants.EMPTY_STRING
        if (t1.contains(GlobalConstants.ROUND_BRACKET))
          fsn = t1.substring(0, t1.lastIndexOf(GlobalConstants.ROUND_BRACKET)).trim()
        else
          fsn = t1.trim()        
        var arrFsn = fsn.split(GlobalConstants.SPACE)
          var pt = t2.split(GlobalConstants.SPACE)      
            if (pt != null && arrFsn != null && pt.length == arrFsn.length &&
          (arrFsn.map(_.trim().toLowerCase()).intersect(pt.map(_.trim().toLowerCase())).length == pt.length))
          { if(arrFsn.length!=1 || arrFsn(0).equals(GlobalConstants.EMPTY_STRING)){true} else false }  
        else if (pt == null && arrFsn == null) { false }
        else if ((pt == null && arrFsn != null) || (arrFsn == null && pt != null)) { false }        
        else { false }
      } else false
    })

 val same_fsn_label_snomed = udf((t1: String, t2: String) => {

      if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0) {
        var fsn = GlobalConstants.EMPTY_STRING
        var label = GlobalConstants.EMPTY_STRING
        
        if (t1.contains(GlobalConstants.ROUND_BRACKET))
          fsn = t1.substring(0, t1.lastIndexOf(GlobalConstants.ROUND_BRACKET)).trim()
        else
          fsn = t1.trim()          
        if (t2.contains(GlobalConstants.SQUARE_BRACKET))
          label = t2.substring(0, t2.lastIndexOf(GlobalConstants.SQUARE_BRACKET)).trim()
        else
          label = t2.trim()
        var arrFsn = fsn.split(GlobalConstants.SPACE)
       
        var arrlabel = label.split(GlobalConstants.SPACE)
              
        if (arrlabel != null && arrFsn != null && arrlabel.length == arrFsn.length &&
          (arrFsn.map(_.trim().toLowerCase()).intersect(arrlabel.map(_.trim().toLowerCase())).length == arrlabel.length) )
          {
          if(arrFsn.length!=1 && arrFsn(0).equals(GlobalConstants.EMPTY_STRING))
          { 
          true } else false }
        else if (arrlabel == null && arrFsn == null) {           
          false}
        else if ((arrlabel == null && arrFsn != null) || (arrFsn == null && arrlabel != null)) { false }        
        else { false }
      } else false
    })
    
    
     def fsn_in_alias_snomed = udf((fsnVal: String, alias: WrappedArray[String]) => { 
        var result :Boolean = false
         if(null==fsnVal || fsnVal.equals(GlobalConstants.EMPTY_STRING) || null==alias ||  alias.equals(GlobalConstants.EMPTY_STRING)){
                                 false
                } else{
                   var fsn = GlobalConstants.EMPTY_STRING
                      if (fsnVal.contains(GlobalConstants.ROUND_BRACKET))
                        fsn = fsnVal.substring(0, fsnVal.lastIndexOf(GlobalConstants.ROUND_BRACKET)).trim()
                      else
                        fsn = fsnVal.trim()
                   
                         var arrVal :WrappedArray[String] = fsn.split(GlobalConstants.SPACE)
                        
                    for (aliasVal <- alias) {
                      var t2 :WrappedArray[String] = aliasVal.split(GlobalConstants.SPACE)
                       if (arrVal != null && t2 != null && arrVal.length == t2.length && (arrVal.map(_.trim().toLowerCase()).intersect(t2.map(_.trim().toLowerCase())).length == t2.length)){
                         if((t2.length!=1 || t2(0).equals(GlobalConstants.EMPTY_STRING))){result = true  }
                         else result=false
                       }
                }
                 result
             }
         })
}