# oea-release-data-processor
Spark Job to process release files and generate the final release concepts.
