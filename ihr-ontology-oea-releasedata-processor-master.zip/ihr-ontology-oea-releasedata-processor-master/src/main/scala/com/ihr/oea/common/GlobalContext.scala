package com.ihr.oea.common

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

class GlobalContext {
  val log = Logger.getLogger(getClass.getName)
  def createSparkSession(oesConfiguration: OESConfiguration, codeSetType: String): SparkSession = {
    try {
      val spark = SparkSession.builder()
        .master("local[*]")
        .getOrCreate()
      if (codeSetType.equalsIgnoreCase(GlobalConstants.QUEST)) {
        spark.conf.set("spark.sql.broadcastTimeout", 36000)
        spark.conf.set("spark.sql.caseSensitive", false)
      }

      spark

    } catch {
      case e: Exception =>
        log.error(s"Exception while creating spark session  \n" + e)
        throw e
    }
  }

}
