package com.ihr.oea.dataloader

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.udf

import com.ihr.oea.common.DataLoaderUtil
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants

class QuestReleaseDataLoader {
  val log = Logger.getLogger(getClass.getName)

  def loadQuestReleaseFileData(spark: SparkSession, releaseId: String, fileName: String, releaseDate: String, oesConfiguration: OESConfiguration) {
    try {
      log.info("Starting Quest data loader  for releaseId :" + releaseId)
      val util = new DataLoaderUtil
      val activeProfile = oesConfiguration.PROFILE
      val releaseFolder = util.buildReleaseFolderPath(releaseId, fileName, oesConfiguration)
      var questFileName = releaseFolder + GlobalConstants.QUEST_FILE_NAME
      if (!activeProfile.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
        questFileName = questFileName.substring(5)
      }

      val removeSpace = udf((string: String) => {
        var result: String = null
        if (null != string && !(string.isEmpty())) {
          result = string.trim().replaceAll(GlobalConstants.spacePattern, GlobalConstants.SPACE)
        }
        result
      })

      val validCPT = udf((CPT: String) => {
        var result: String = null
        if (null != CPT && !(CPT.isEmpty())) {
          var cpt = CPT.trim()
          var cptList: Set[String] = Set()
          if (cpt.contains(GlobalConstants.PIPE)) {
            val data = cpt.split(GlobalConstants.QUOTE_PIPE)
            for (code <- data) {
              if (code.contains(GlobalConstants.-)) {
                val actualCodes = code.split(GlobalConstants.QUOTE_HYPHEN)
                for (actualCode <- actualCodes) {
                  if (actualCode.trim().matches(GlobalConstants.cptPattern) && actualCode.trim().length() == 5) {
                    cptList = cptList + actualCode.trim()
                  }
                }
              } else {
                if (code.trim().matches(GlobalConstants.cptPattern) && code.trim().length() == 5) {
                  cptList = cptList + code.trim()
                }
              }
            }
          } else if (cpt.contains(GlobalConstants.-)) {
            val actualCodes = cpt.split(GlobalConstants.QUOTE_HYPHEN)
            for (actualCode <- actualCodes) {
              if (actualCode.trim().matches(GlobalConstants.cptPattern) && actualCode.trim().length() == 5) {
                cptList = cptList + actualCode.trim()
              }
            }
          } else {
            if (cpt.matches(GlobalConstants.cptPattern) && cpt.trim().length() == 5) {
              cptList = cptList + cpt
            }
          }
          result = cptList.mkString(GlobalConstants.PIPE).trim()
          if (result.startsWith(GlobalConstants.PIPE))
            result = result.substring(1)
          if (result.endsWith(GlobalConstants.PIPE))
            result = result.substring(0, result.length() - 1)
        }
        result
      })

      val validLoinc = udf((loinc: String) => {
        var result: String = null
        if (null != loinc && !(loinc.isEmpty())) {
          if (loinc.matches(GlobalConstants.loincPattern))
            result = loinc
        }
        result
      })

      log.info("Quest file path  : " + questFileName)
      log.info("Reading Quest file for releaseId : " + releaseId)
      log.info("Generating level 1 cleansing dataframe for releaseId :" + releaseId)
      val questLevel1 = util.loadQuestCSVData(questFileName, spark)
        .withColumn(SparkSQLConstants.TEST_CD, removeSpace(col(SparkSQLConstants.TEST_CD)))
        .withColumn(SparkSQLConstants.TEST_NAME, removeSpace(col(SparkSQLConstants.TEST_NAME)))
        .withColumn(SparkSQLConstants.CPT, validCPT(removeSpace(col(SparkSQLConstants.CPT))))
        .withColumn(SparkSQLConstants.STANDARD_RESULT_CODE, removeSpace(col(SparkSQLConstants.STANDARD_RESULT_CODE)))
        .withColumn(SparkSQLConstants.STANDARD_RESULT_CODE_NAME, removeSpace(col(SparkSQLConstants.STANDARD_RESULT_CODE_NAME)))
        .withColumn(SparkSQLConstants.LOINC_NUMBER, validLoinc(removeSpace(col(SparkSQLConstants.LOINC_NUMBER))))
        .withColumn(SparkSQLConstants.REGENSTRIEF_COMPONENT_NAMES, removeSpace(col(SparkSQLConstants.REGENSTRIEF_COMPONENT_NAMES)))
        .select(
          SparkSQLConstants.TYPE,
          SparkSQLConstants.TEST_CD,
          SparkSQLConstants.TEST_NAME,
          SparkSQLConstants.CPT,
          SparkSQLConstants.STANDARD_RESULT_CODE,
          SparkSQLConstants.STANDARD_RESULT_CODE_NAME,
          SparkSQLConstants.LOINC_NUMBER,
          SparkSQLConstants.REGENSTRIEF_COMPONENT_NAMES)

      log.info("Generated level 1 cleansing dataframe for releaseId :" + releaseId)
      questLevel1.cache()

      val questLevel2Stage1 = questLevel1.columns.foldLeft(questLevel1)((questLevel1, STANDARD_RESULT_CODE_NAME) =>
        questLevel1.withColumn(STANDARD_RESULT_CODE_NAME, regexp_replace(col(STANDARD_RESULT_CODE_NAME), "\\\\", "")))
        .columns.foldLeft(questLevel1)((questLevel1, TEST_NAME) =>
          questLevel1.withColumn(TEST_NAME, regexp_replace(col(TEST_NAME), "\\\\", "")))
          
      log.info("Generating non processed quest data for releaseId :" + releaseId)
      questLevel2Stage1.createOrReplaceTempView(SparkSQLConstants.LEVEL2_STAGE1_TABLE)
      
         
      val stage = spark.sql(SparkSQLConstants.STAGE).persist()
      stage.createOrReplaceTempView(SparkSQLConstants.STAGE_TABLE)

      val nprStage1 = spark.sql(SparkSQLConstants.NPR_STAGE1).persist()
      nprStage1.createOrReplaceTempView(SparkSQLConstants.NPR_STAGE1_TABLE)
      
       val nprStage2 = spark.sql(SparkSQLConstants.NPR_STAGE2).persist()
      nprStage2.createOrReplaceTempView(SparkSQLConstants.NPR_STAGE2_TABLE)
      
        val nprStage3 = spark.sql(SparkSQLConstants.NPR_STAGE3).persist()
      nprStage3.createOrReplaceTempView(SparkSQLConstants.NPR_STAGE3_TABLE)    
      


      log.info("Generating processed quest data for releaseId :" + releaseId)
      val prStage1 = spark.sql(SparkSQLConstants.PR_STAGE1).cache()
      prStage1.createOrReplaceTempView(SparkSQLConstants.PR_STAGE1_TABLE)
      
      val prStage2 = spark.sql(SparkSQLConstants.PR_STAGE2).cache()
      prStage2.createOrReplaceTempView(SparkSQLConstants.PR_STAGE2_TABLE)
      
      val prStage3 = spark.sql(SparkSQLConstants.PR_STAGE3).cache()
      prStage3.createOrReplaceTempView(SparkSQLConstants.PR_STAGE3_TABLE)
      
      val prStage4 = spark.sql(SparkSQLConstants.PR_STAGE4).cache()
      prStage4.createOrReplaceTempView(SparkSQLConstants.PR_STAGE4_TABLE)
      
      val prStage5 = spark.sql(SparkSQLConstants.PR_STAGE5).cache()
      prStage5.createOrReplaceTempView(SparkSQLConstants.PR_STAGE5_TABLE)
      
       val nprStage4 = spark.sql(SparkSQLConstants.NPR_STAGE4).persist()
      nprStage4.createOrReplaceTempView(SparkSQLConstants.NPR_STAGE4_TABLE)
	  
	  val prStage6 = spark.sql(SparkSQLConstants.PR_STAGE6).cache()
      prStage6.createOrReplaceTempView(SparkSQLConstants.PR_STAGE6_TABLE)
      
       val nprStage5 = spark.sql(SparkSQLConstants.NPR_STAGE5).persist()
      nprStage5.createOrReplaceTempView(SparkSQLConstants.NPR_STAGE5_TABLE)
      
      val processedData = spark.sql(SparkSQLConstants.PROCESSED_QUERY)
        .select(
          SparkSQLConstants.TAXONOMY_FSN,
          SparkSQLConstants.TYPE,
          SparkSQLConstants.CONCEPT_ID,
          SparkSQLConstants.PREFERRED_TERM,
          SparkSQLConstants.CPT_CODE,
          SparkSQLConstants.LOINC_CODE)
        .withColumn(SparkSQLConstants.PROCESS_STATUS, lit(GlobalConstants.PROCESSED))
        .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseId))
        .withColumn(SparkSQLConstants.EFFECTIVE_TIME, lit(releaseDate))
        
        processedData.createOrReplaceTempView(SparkSQLConstants.HPRF)
        
        
         val nonProcessedData = spark.sql(SparkSQLConstants.NON_PROCESSED_QUERY)
        .select(
          SparkSQLConstants.TAXONOMY_FSN,
          SparkSQLConstants.TYPE,
          SparkSQLConstants.CONCEPT_ID,
          SparkSQLConstants.PREFERRED_TERM,
          SparkSQLConstants.CPT_CODE,
          SparkSQLConstants.LOINC_CODE)
        .withColumn(SparkSQLConstants.PROCESS_STATUS, lit(GlobalConstants.NON_PROCESSED))
        .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseId))
        .withColumn(SparkSQLConstants.EFFECTIVE_TIME, lit(releaseDate))
        
        
      log.info("Generated processed quest data for releaseId :" + releaseId)
      // write to mongoDB
      log.info("saving Quest processed release data into mongoDB for releaseId : " + releaseId)
      util.saveReleaseConcepts(processedData, oesConfiguration)
      log.info("successfully saved  Quest processed release data into mongoDB for releaseId : " + releaseId)
      
       log.info("Generated non processed quest data for releaseId :" + releaseId)
      // write to mongoDB
      log.info("saving Quest non processed release data into mongoDB for releaseId : " + releaseId)
      util.saveReleaseConcepts(nonProcessedData, oesConfiguration)
      log.info("successfully saved  Quest non processed release data into mongoDB for releaseId : " + releaseId)


    } catch {
      case e: Exception =>
        log.error(s"Exception while running the quest data loader for release Id : " + releaseId)
        log.error(e.printStackTrace())
        throw e
    }
  }
}
