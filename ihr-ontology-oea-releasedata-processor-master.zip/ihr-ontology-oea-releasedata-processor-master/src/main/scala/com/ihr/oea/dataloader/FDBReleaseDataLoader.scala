package com.ihr.oea.dataloader

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.udf
import java.nio.file.FileSystems
import java.nio.file.Files
import java.io.File
import org.apache.hadoop.fs._
import org.apache.hadoop.fs._
import org.apache.hadoop.fs.FileUtil
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import com.ihr.oea.common.DataLoaderUtil
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType

class FDBReleaseDataLoader {
  val log = Logger.getLogger(getClass.getName)

  def loadFDBReleaseFileData(spark: SparkSession, releaseId: String, fileName: String, releaseDate: String, oesConfiguration: OESConfiguration) {
    try {
      log.info("Starting FDB data loader  for releaseId :" + releaseId)
      
   def buildFDBMNSchema(): StructType = {
    val schema = StructType(
      Array(
            StructField(SparkSQLConstants.FDB_CHG_STATUS, StringType, true),
            StructField(SparkSQLConstants.FDB_MEDNAME_ID, StringType, true),
            StructField(SparkSQLConstants.FDB_MEDNAME, StringType, true),
            StructField(SparkSQLConstants.FDB_MEDNAME_TYPE, StringType, true),
            StructField(SparkSQLConstants.FDB_MED_STATUS, StringType, true)))
    schema
  }
      
   def buildFDBRDSchema(): StructType = {
    val schema = StructType(
      Array(
          StructField(SparkSQLConstants.FDB_CHG_STATUS, StringType, true),
            StructField(SparkSQLConstants.FDB_ROUTEMED_ID, StringType, true),
            StructField(SparkSQLConstants.MED_NAMEID, StringType, true),
            StructField(SparkSQLConstants.MED_ROUTEMED_ID, StringType, true),
            StructField(SparkSQLConstants.FDB_RTDMED_DESC, StringType, true),
            StructField(SparkSQLConstants.FDB_MED_STATUS, StringType, true)))
    schema
  }
   
    def buildFDDCSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.FDB_CHG_STATUS, StringType, true),
        StructField(SparkSQLConstants.FDB_MEDNAME_ID , StringType, true),
        StructField(SparkSQLConstants.RTD_DSG_FORM_MEDID , StringType, true),
        StructField(SparkSQLConstants.MED_STRNGTH , StringType, true),
        StructField(SparkSQLConstants.MED_STRNGTH_UOM , StringType, true),
        StructField(SparkSQLConstants.FDB_MED_DESC , StringType, true),
        StructField(SparkSQLConstants.GCN_SEQ_NO , StringType, true),
        StructField(SparkSQLConstants.GCN_SEQ_NO_ASGNCD , StringType, true),
        StructField(SparkSQLConstants.NAME_SRC_CODE , StringType, true),
        StructField(SparkSQLConstants.REF_FED_LEG_IND, StringType, true),
        StructField(SparkSQLConstants.REF_FED_DEAC_CODE , StringType, true),
        StructField(SparkSQLConstants.REF_FED_MULTI_SRC_CODE , StringType, true),
        StructField(SparkSQLConstants.REG_GEN_MED_NAME_CODE , StringType, true),
        StructField(SparkSQLConstants.NOT_USED_ONE , StringType, true),
        StructField(SparkSQLConstants.NOT_USED_TWO , StringType, true),        
        StructField(SparkSQLConstants.REF_INNOVATE_IND , StringType, true),
        StructField(SparkSQLConstants.REF_GEN_THERAP_CODE , StringType, true),
        StructField(SparkSQLConstants.REF_DESI_IND , StringType, true),
        StructField(SparkSQLConstants.REF_DESI_IND2 , StringType, true),
        StructField(SparkSQLConstants.MED_STATUS_CODE , StringType, true),
        StructField(SparkSQLConstants.GEN_MED_ID , StringType, true)))
    schema
  }
          
      val util = new DataLoaderUtil
      val configuration = new Configuration();
      val fs = FileSystem.get(configuration);
      val activeProfile = oesConfiguration.PROFILE
      val releaseFolder = util.buildReleaseFolderPath(releaseId, fileName, oesConfiguration)
      var fdbmnFileName = releaseFolder + GlobalConstants.FDBMN_FILENAME
      var fdbrdFileName = releaseFolder + GlobalConstants.FDBRD_FILENAME
      var fddcFileName = releaseFolder + GlobalConstants.FDDC_FILENAME
      val dstPath = GlobalConstants.MAPRFS + releaseFolder.substring(5)
      val srcCSVPath = oesConfiguration.RELEASE_BASE_PATH + releaseId.trim() + GlobalConstants.FORWARD_SLASH +
        GlobalConstants.UNZIP_FOLDER + GlobalConstants.FORWARD_SLASH
      var csvFilePath = GlobalConstants.MAPRFS + srcCSVPath.substring(5) + GlobalConstants.LABCORP_LEVEL_ONE
      if (!activeProfile.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
        fdbmnFileName = fdbmnFileName.substring(5)
        fdbrdFileName = fdbrdFileName.substring(5)
        fddcFileName = fddcFileName.substring(5)
      }


      log.info("fdb file path  : " + fdbmnFileName)
      log.info("Reading FDB file for releaseId : " + releaseId)
      log.info("Generating level 1 cleansing dataframe for releaseId :" + releaseId)

      spark.sql(GlobalConstants.CASESENSITIVE)
      spark.conf.set(GlobalConstants.BROADCASTTIMEOUT, 36000)
      spark.conf.set(GlobalConstants.WHOLESTAGE, false)
      spark.conf.set(GlobalConstants.OFFHEAP_ENABLED, true)
      spark.conf.set(GlobalConstants.OFFHEAP_SIZE, GlobalConstants.FORTY_G)
      
       def removeLeadingZeros = udf((zeroVal: String) => {
    			var result: String = null
    			if (null != zeroVal && !(zeroVal.isEmpty())) {
    			 result =zeroVal.trim().replaceAll(GlobalConstants.REMOVE_ZERO, GlobalConstants.EMPTY_STRING)
    			}
    			result
			})

			  // Reading fdbmn data
      val fdbmnLevel = util.loadFDBTXTData(fdbmnFileName, GlobalConstants.PIPE, spark,buildFDBMNSchema())
      val fdbmnLevelOne = fdbmnLevel.withColumn(SparkSQLConstants.FDB_CHG_STATUS, trim(col(SparkSQLConstants.FDB_CHG_STATUS)))
              .withColumn(SparkSQLConstants.FDB_MEDNAME_ID, removeLeadingZeros(col(SparkSQLConstants.FDB_MEDNAME_ID)))
							.withColumnRenamed(SparkSQLConstants.FDB_MEDNAME_ID, SparkSQLConstants.CONCEPT_ID )
							.withColumnRenamed(SparkSQLConstants.FDB_MEDNAME, SparkSQLConstants.PREFERRED_TERM)
							.withColumnRenamed(SparkSQLConstants.FDB_MEDNAME_TYPE, SparkSQLConstants.TYPE)
							.withColumnRenamed(SparkSQLConstants.FDB_MED_STATUS, SparkSQLConstants.STATUS_DB)
     
			        fdbmnLevelOne.createOrReplaceTempView(SparkSQLConstants.FDBMN)
			val fdbmnFinalQuery = spark.sql(SparkSQLConstants.FDBMN_LEVEL1)
                  			 .withColumn(SparkSQLConstants.TAXONOMY_FSN, lit(SparkSQLConstants.FDBMN)) 
                          .withColumn(SparkSQLConstants.PROCESS_STATUS, lit(GlobalConstants.PROCESSED))
                          .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseId))
                          .withColumn(SparkSQLConstants.EFFECTIVE_TIME, lit(releaseDate))
                          
	  // Reading fdbrd data
       val fdbrdLevel = util.loadFDBTXTData(fdbrdFileName, GlobalConstants.PIPE, spark,buildFDBRDSchema())
       val fdbrdLevelOne = fdbrdLevel.withColumn(SparkSQLConstants.FDB_CHG_STATUS, trim(col(SparkSQLConstants.FDB_CHG_STATUS)))
							.withColumn(SparkSQLConstants.FDB_ROUTEMED_ID, removeLeadingZeros(col(SparkSQLConstants.FDB_ROUTEMED_ID)))
							.withColumnRenamed(SparkSQLConstants.FDB_ROUTEMED_ID, SparkSQLConstants.CONCEPT_ID )
							.withColumnRenamed(SparkSQLConstants.FDB_RTDMED_DESC, SparkSQLConstants.PREFERRED_TERM)
							.withColumnRenamed(SparkSQLConstants.FDB_MED_STATUS, SparkSQLConstants.STATUS_DB)
     
		        	fdbrdLevelOne.createOrReplaceTempView(SparkSQLConstants.FDBRD)
			val fdbrdFinalQuery = spark.sql(SparkSQLConstants.FDBRD_LEVEL1).select(GlobalConstants.STAR)
                  			 .withColumn(SparkSQLConstants.TAXONOMY_FSN, lit(SparkSQLConstants.FDBRD)) 
                          .withColumn(SparkSQLConstants.PROCESS_STATUS, lit(GlobalConstants.PROCESSED))
                          .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseId))
                          .withColumn(SparkSQLConstants.EFFECTIVE_TIME, lit(releaseDate))
			
				// Reading fddc data
      val fddcLevel =  util.loadFDBTXTData(fddcFileName, GlobalConstants.PIPE, spark,buildFDDCSchema())                   
      val fddcLevelOne = fddcLevel.withColumn(SparkSQLConstants.FDB_CHG_STATUS, trim(col(SparkSQLConstants.FDB_CHG_STATUS)))
							.withColumn(SparkSQLConstants.FDB_MEDNAME_ID, removeLeadingZeros(col(SparkSQLConstants.FDB_MEDNAME_ID)))
							.withColumn(SparkSQLConstants.GEN_MED_ID, removeLeadingZeros(col(SparkSQLConstants.GEN_MED_ID)))
							.withColumnRenamed(SparkSQLConstants.FDB_MEDNAME_ID, SparkSQLConstants.CONCEPT_ID )
							.withColumnRenamed(SparkSQLConstants.FDB_MED_DESC, SparkSQLConstants.PREFERRED_TERM)
							.withColumnRenamed(SparkSQLConstants.MED_STATUS_CODE, SparkSQLConstants.STATUS_DB)
     
			        fddcLevelOne.createOrReplaceTempView(SparkSQLConstants.FDDC)
			val fddcFinalQuery =spark.sql(SparkSQLConstants.FDDC_LEVEL1).select(GlobalConstants.STAR)
                  			 .withColumn(SparkSQLConstants.TAXONOMY_FSN, lit(SparkSQLConstants.FDDC)) 
                          .withColumn(SparkSQLConstants.PROCESS_STATUS, lit(GlobalConstants.PROCESSED))
                          .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseId))
                          .withColumn(SparkSQLConstants.EFFECTIVE_TIME, lit(releaseDate))
			
     
      log.info("Generated processed labCorp data for releaseId :" + releaseId)
      // write to mongoDB
      util.saveReleaseConcepts(fdbmnFinalQuery, oesConfiguration)
      log.info("saving labCorp processed release data into mongoDB for releaseId : " + releaseId)
      // write to mongoDB
      util.saveReleaseConcepts(fdbrdFinalQuery, oesConfiguration)
      log.info("successfully saved  labCorp processed release data into mongoDB for releaseId : " + releaseId)
      log.info("Generated non processed labCorp data for releaseId :" + releaseId)
      // write to mongoDB
      log.info("saving labCorp non processed release data into mongoDB for releaseId : " + releaseId)
     util.saveReleaseConcepts(fddcFinalQuery, oesConfiguration)
      log.info("successfully saved  labCorp non processed release data into mongoDB for releaseId : " + releaseId)

    } catch {
      case e: Exception =>
        log.error(s"Exception while running the labCorp data loader for release Id : " + e.printStackTrace())
        log.error(e.printStackTrace())
        throw e
    }
  }
}
