      package com.ihr.oea.dataloader
      
      import org.apache.log4j.Logger
      import org.apache.spark.sql.SparkSession
      import org.apache.spark.sql.functions._
      import org.apache.spark.sql.functions.col
      import org.apache.spark.sql.functions.udf
      import java.nio.file.FileSystems
      import java.nio.file.Files
      import java.io.File
      import org.apache.hadoop.fs._
      import org.apache.hadoop.fs._
      import org.apache.hadoop.fs.FileUtil
      import org.apache.hadoop.fs.FileSystem;
      import org.apache.hadoop.conf.Configuration;
      import org.apache.hadoop.fs.Path;
      import com.ihr.oea.common.DataLoaderUtil
      import com.ihr.oea.common.GlobalConstants
      import com.ihr.oea.common.OESConfiguration
      import com.ihr.oea.common.SparkSQLConstants
      import org.apache.spark.sql.expressions.Window
      
      class LabCorpReleaseDataLoader {
        val log = Logger.getLogger(getClass.getName)
      
        def loadLabCorpReleaseFileData(spark: SparkSession, releaseId: String, fileName: String, releaseDate: String, oesConfiguration: OESConfiguration) {
          try {
            log.info("Starting LabCorp data loader  for releaseId :" + releaseId)
            val util = new DataLoaderUtil
            val configuration = new Configuration();
            val fs = FileSystem.get(configuration);
            val activeProfile = oesConfiguration.PROFILE
            val releaseFolder = util.buildReleaseFolderPath(releaseId, fileName, oesConfiguration)
            var labCorpFileName = releaseFolder + GlobalConstants.LABCORP_FILE_NAME
            var srcPath = util.buildLabCorpFilePath(oesConfiguration)
             log.info("Starting LabCorp data loader  for srcPath :" + srcPath)
            var lcJunkFile = GlobalConstants.MAPRFS + srcPath.substring(5)+ GlobalConstants.LC_JUNK_FILE_NMAE
             log.info("Starting LabCorp data loader  for lcJunkFile :" + lcJunkFile)
            val dstPath = GlobalConstants.MAPRFS + releaseFolder.substring(5)
            val srcCSVPath = oesConfiguration.RELEASE_BASE_PATH + releaseId.trim() + GlobalConstants.FORWARD_SLASH +
              GlobalConstants.UNZIP_FOLDER + GlobalConstants.FORWARD_SLASH
            var csvFilePath = GlobalConstants.MAPRFS + srcCSVPath.substring(5) + GlobalConstants.LABCORP_LEVEL_ONE
            if (!activeProfile.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
              labCorpFileName = labCorpFileName.substring(5)
            }
      
            val validLoinc = udf((loinc: String) => {
              var result: String = null
              if (null != loinc && !(loinc.isEmpty())) {
                if (loinc.matches(GlobalConstants.loincPattern))
                  result = loinc
              }
              result
            })
      
            log.info("LabCorp file path  : " + labCorpFileName)
            log.info("Reading LabCorp file for releaseId : " + releaseId)
            log.info("Generating level 1 cleansing dataframe for releaseId :" + releaseId)
      
            spark.sql(GlobalConstants.CASESENSITIVE)
            spark.conf.set(GlobalConstants.BROADCASTTIMEOUT, 36000)
            spark.conf.set(GlobalConstants.WHOLESTAGE, false)
            spark.conf.set(GlobalConstants.OFFHEAP_ENABLED, true)
            spark.conf.set(GlobalConstants.OFFHEAP_SIZE, GlobalConstants.FORTY_G)
            spark.udf.register(GlobalConstants.IS_NUMERIC, (inpColumn: Int) => BigInt(inpColumn).isInstanceOf[BigInt])
      
            val labCorpLevel = util.loadTXTData(labCorpFileName, GlobalConstants.TAB, spark)
      
              .withColumn(SparkSQLConstants.TEST_NUMBER, col(SparkSQLConstants.TEST_NUMBER))
              .withColumn(SparkSQLConstants.TYPE, col(SparkSQLConstants.TYPE))
              .withColumn(SparkSQLConstants.NAME, col(SparkSQLConstants.NAME))
              .withColumn(SparkSQLConstants.PROCEDURE_CLASS, col(SparkSQLConstants.PROCEDURE_CLASS))
              .withColumn(SparkSQLConstants.LAB_LOINC_CODE, validLoinc(col(SparkSQLConstants.LAB_LOINC_CODE)))
              .withColumn(SparkSQLConstants.RESULT_TYPE, col(SparkSQLConstants.RESULT_TYPE))
              .withColumn(SparkSQLConstants.TEST_UNITS, col(SparkSQLConstants.TEST_UNITS))
              .select(
                SparkSQLConstants.TEST_NUMBER,
                SparkSQLConstants.LAB_TYPE,
                SparkSQLConstants.NAME,
                SparkSQLConstants.PROCEDURE_CLASS,
                SparkSQLConstants.LAB_LOINC_CODE,
                SparkSQLConstants.RESULT_TYPE,
                SparkSQLConstants.TEST_UNITS)
      
            val labCorpLevel2 = labCorpLevel.columns.foldLeft(labCorpLevel)((labCorpLevel, NAME) => labCorpLevel.withColumn(NAME, regexp_replace(col(NAME), "\\\\", "")))
      
            labCorpLevel2.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_NPR)
      
            val nprLevel1 = spark.sql(SparkSQLConstants.LABCORP_NPR_LEVEL1).persist()
            nprLevel1.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_NPR_1)
      
            val nprLevel2 = spark.sql(SparkSQLConstants.LABCORP_NPR_LEVEL2).persist()
            nprLevel2.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_NPR_2)
      
            val nprLevel3 = spark.sql(SparkSQLConstants.LABCORP_NPR_LEVEL3).persist()
            nprLevel3.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_NPR_3)
      
            val LC_JUNK_DF = spark.read.format(GlobalConstants.CSV_FORMAT).option(GlobalConstants.WHOLEFILE, true).option(GlobalConstants.MUTLILINE, true).option(GlobalConstants.HEADER, true).option(GlobalConstants.INFER_SCHEMA, GlobalConstants.TRUE).option(GlobalConstants.DELIMITER, GlobalConstants.TAB).option(GlobalConstants.ENCODING, "ISO-8859-1").option(GlobalConstants.ESCAPE, GlobalConstants.ESCAPE_CHAR).option(GlobalConstants.CHARSET, GlobalConstants.ISO).option(GlobalConstants.QUOTE, GlobalConstants.ESCAPE_CHAR).option(GlobalConstants.IGNORE_LEADING_SPACES, false).option(GlobalConstants.IGNORE_TRAILING_SPACES, false).load(lcJunkFile).cache()
            LC_JUNK_DF.createOrReplaceTempView(SparkSQLConstants.LCJUNK)
      
            val nprLevel4 = spark.sql(SparkSQLConstants.LABCORP_NPR_LEVEL4).persist()
            nprLevel4.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_NPR_4)
      
            val prLevel = spark.sql(SparkSQLConstants.LABCORP_PR).persist()
            prLevel.createOrReplaceTempView(SparkSQLConstants.LABCORP_PR1)
      
            val nprLevelData = nprLevel4.select(
              SparkSQLConstants.TYPE,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.PREFERRED_TERM,
              SparkSQLConstants.PROCEDURECLASS,
              SparkSQLConstants.LOINC_CODE,
              SparkSQLConstants.RESULTTYPE)
              .withColumnRenamed(SparkSQLConstants.PROCEDURECLASS, SparkSQLConstants.CLASS_NAME)
              .withColumn(SparkSQLConstants.PROCESS_STATUS, lit(GlobalConstants.NON_PROCESSED))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseId))
              .withColumn(SparkSQLConstants.EFFECTIVE_TIME, lit(releaseDate))
      
            val nprLevelProc = spark.sql(SparkSQLConstants.LABCORP_NPR_PROC_LEVEL5).persist()
            nprLevelProc.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_PROC_NPR_5)
      
            val nprLevelObs = spark.sql(SparkSQLConstants.LABCORP_NPR_OBS_LEVEL5).persist()
            nprLevelObs.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_OBS_NPR_5)
      
            val prLevel1 = spark.sql(SparkSQLConstants.LABCORP_PR_LEVEL1).persist()
            prLevel1.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_PR_1)
      
            val prLevel2 = spark.sql(SparkSQLConstants.LABCORP_PR_LEVEL2).persist()
            prLevel2.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_PR_2)
      
            val prLevel3 = spark.sql(SparkSQLConstants.LABCORP_PR_LEVEL3).persist()
            prLevel3.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_PR_3)
      
            val prLevel4 = spark.sql(SparkSQLConstants.LABCORP_PR_LEVEL4).persist()
            prLevel4.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_PR_4)
      
            val prLevel5 = spark.sql(SparkSQLConstants.LABCORP_PR_LEVEL5).persist()
            prLevel5.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_PR_5)
      
            val prLevel6 = spark.sql(SparkSQLConstants.LABCORP_PR_LEVEL6).persist()
            prLevel6.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_PR_6)
      
            val processedData = spark.sql(SparkSQLConstants.LABCORP_PR_LEVEL7).persist()
      
            val finalPR = processedData.select(
              SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.TYPE,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.PREFERRED_TERM,
              SparkSQLConstants.PROCEDURECLASS,
              SparkSQLConstants.LOINC_CODE,
              SparkSQLConstants.RESULTTYPE)
              .withColumnRenamed(SparkSQLConstants.PROCEDURECLASS, SparkSQLConstants.CLASS_NAME)
              .withColumn(SparkSQLConstants.PROCESS_STATUS, lit(GlobalConstants.PROCESSED))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseId))
              .withColumn(SparkSQLConstants.EFFECTIVE_TIME, lit(releaseDate))
      
            val nonProcessedData = spark.sql(SparkSQLConstants.LABCORP_FINAL_NPR)
            nonProcessedData.createOrReplaceTempView(SparkSQLConstants.LABCORP_LEVEL_FINAL_NPR);
            nonProcessedData.show()
            val finalNPR = nonProcessedData.select(
              SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.TYPE,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.PREFERRED_TERM,
              SparkSQLConstants.PROCEDURECLASS,
              SparkSQLConstants.LOINC_CODE,
              SparkSQLConstants.RESULTTYPE)
              .withColumnRenamed(SparkSQLConstants.PROCEDURECLASS, SparkSQLConstants.CLASS_NAME)
              .withColumn(SparkSQLConstants.PROCESS_STATUS, lit(GlobalConstants.NON_PROCESSED))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseId))
              .withColumn(SparkSQLConstants.EFFECTIVE_TIME, lit(releaseDate))
      
            val filePath = new File(csvFilePath)
            if (filePath.exists() && filePath.isDirectory) {
              prLevel.write.option(GlobalConstants.HEADER, GlobalConstants.FALSE).option(GlobalConstants.FILE_TYPE, GlobalConstants.CSV_FORMAT).mode(GlobalConstants.APPENED_MODE).option(GlobalConstants.IGNORE_LEADING_SPACES, GlobalConstants.FALSE).option(GlobalConstants.IGNORE_TRAILING_SPACES, GlobalConstants.FALSE).option(GlobalConstants.SEPARATOR, GlobalConstants.COMMA)
                .csv(csvFilePath + GlobalConstants.DOT_CSV_FORMAT)
            } else {
              prLevel.write.option(GlobalConstants.HEADER, GlobalConstants.FALSE).option(GlobalConstants.FILE_TYPE, GlobalConstants.CSV_FORMAT).mode(GlobalConstants.APPENED_MODE).option(GlobalConstants.IGNORE_LEADING_SPACES, GlobalConstants.FALSE).option(GlobalConstants.IGNORE_TRAILING_SPACES, GlobalConstants.FALSE).option(GlobalConstants.SEPARATOR, GlobalConstants.COMMA)
                .csv(csvFilePath + GlobalConstants.DOT_CSV_FORMAT)
            }
      
            FileUtil.copyMerge(fs, new Path(csvFilePath + GlobalConstants.DOT_CSV_FORMAT), fs, new Path(dstPath), false, configuration, GlobalConstants.EMPTY_STRING)
      
            log.info("Generated processed labCorp data for releaseId :" + releaseId)
            // write to mongoDB
            util.saveReleaseConcepts(nprLevelData, oesConfiguration)
            log.info("saving labCorp processed release data into mongoDB for releaseId : " + releaseId)
            // write to mongoDB
            util.saveReleaseConcepts(finalNPR, oesConfiguration)
            log.info("successfully saved  labCorp processed release data into mongoDB for releaseId : " + releaseId)
            log.info("Generated non processed labCorp data for releaseId :" + releaseId)
            // write to mongoDB
            log.info("saving labCorp non processed release data into mongoDB for releaseId : " + releaseId)
            util.saveReleaseConcepts(finalPR, oesConfiguration)
            log.info("successfully saved  labCorp non processed release data into mongoDB for releaseId : " + releaseId)
      
          } catch {
            case e: Exception =>
              log.error(s"Exception while running the labCorp data loader for release Id : " + e.printStackTrace())
              log.error(e.printStackTrace())
              throw e
          }
        }
      }
