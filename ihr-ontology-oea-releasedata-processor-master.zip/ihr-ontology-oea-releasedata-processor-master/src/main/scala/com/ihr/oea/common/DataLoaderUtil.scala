package com.ihr.oea.common

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.StructType
import org.apache.log4j.Logger
import com.mongodb.spark.MongoSpark

class DataLoaderUtil {
  val log = Logger.getLogger(getClass.getName)

  def loadCSVData(file: String, spark: SparkSession): DataFrame = {
    val dataframe = spark.read
      .format(GlobalConstants.CSV_FORMAT)
      .option(GlobalConstants.HEADER, true)
      .option(GlobalConstants.DELIMITER, GlobalConstants.COMMA)
      .option(GlobalConstants.WHOLEFILE, true)
      .option(GlobalConstants.MUTLILINE, true)
      .option(GlobalConstants.INFER_SCHEMA, GlobalConstants.TRUE)
      .option(GlobalConstants.ENCODING, GlobalConstants.UTF_8)
      .option(GlobalConstants.CHARSET, GlobalConstants.UTF_8)
      .option(GlobalConstants.QUOTE, GlobalConstants.ESCAPE_CHAR)
      .option(GlobalConstants.ESCAPE, GlobalConstants.ESCAPE_CHAR)
      .load(file)
    dataframe
  }
  
  def loadQuestCSVData(file: String, spark: SparkSession): DataFrame = {
    val dataframe = spark.read
      .format(GlobalConstants.CSV_FORMAT)
      .option(GlobalConstants.HEADER, true)
      .option(GlobalConstants.DELIMITER, GlobalConstants.COMMA)
      .option(GlobalConstants.WHOLEFILE, true)
      .option(GlobalConstants.MUTLILINE, true)
      .option(GlobalConstants.INFER_SCHEMA, GlobalConstants.TRUE)
      .option(GlobalConstants.ENCODING, GlobalConstants.UTF_8)
      .option(GlobalConstants.CHARSET, GlobalConstants.UTF_8)
      .option(GlobalConstants.QUOTE, GlobalConstants.ESCAPE_CHAR)
      .option(GlobalConstants.ESCAPE, GlobalConstants.ESCAPE_CHAR)
      .option("ignoreLeadingWhiteSpace",false)
      .option("ignoreTrailingWhiteSpace",false)
      .load(file)
    dataframe
  }

  def loadTXTData(file: String, delimiter: String, spark: SparkSession): DataFrame = {
    val dataframe = spark.read
      .format(GlobalConstants.CSV_FORMAT)
      .option(GlobalConstants.HEADER, true)
      .option(GlobalConstants.DELIMITER, delimiter)
      .load(file)
    dataframe
  }
  
   def loadFDBTXTData(file: String, delimiter: String, spark: SparkSession,buildFDBSchema:StructType): DataFrame = {
    val dataframe =       
      spark.read.format(GlobalConstants.DATABRICKS)
      .option(GlobalConstants.WHOLEFILE, true)
      .option(GlobalConstants.MUTLILINE,true)
      .option(GlobalConstants.HEADER, false)
      .option(GlobalConstants.INFER_SCHEMA, GlobalConstants.TRUE)
      .option(GlobalConstants.DELIMITER, delimiter)
      .option(GlobalConstants.ENCODING, GlobalConstants.ISO)
      .option(GlobalConstants.ESCAPE,GlobalConstants.ESCAPE_CHAR)
      .option(GlobalConstants.QUOTE, GlobalConstants.ESCAPE_SPL_CHAR)
      .option(GlobalConstants.CHARSET,  GlobalConstants.ISO)
      .option(GlobalConstants.IGNORE_LEADING_SPACES,true)
      .option(GlobalConstants.IGNORE_TRAILING_SPACES,true)
      .schema(buildFDBSchema)
      .load(file)
      
    dataframe
  }

   def loadTxtData(file: String, delimiter: String, spark: SparkSession): DataFrame = {
    val dataframe= spark.read.format(GlobalConstants.CSV_FORMAT).option(GlobalConstants.WHOLEFILE, true).option(GlobalConstants.MUTLILINE,true).option(GlobalConstants.HEADER, true).option(GlobalConstants.INFER_SCHEMA, "true").option(GlobalConstants.DELIMITER, GlobalConstants.TAB).option(GlobalConstants.ENCODING, GlobalConstants.ISO).option(GlobalConstants.ESCAPE,GlobalConstants.ESCAPE_CHAR).option(GlobalConstants.CHARSET, GlobalConstants.ISO).option(GlobalConstants.QUOTE,GlobalConstants.ESCAPE_CHAR).option(GlobalConstants.IGNORE_LEADING_SPACES,false).option(GlobalConstants.IGNORE_TRAILING_SPACES,false).load(file).cache()   
    dataframe
  }

  def buildReleaseFolderPath(releaseId: String, fileName: String, oesConfiguration: OESConfiguration): String = {
    val releaseFolder = oesConfiguration.RELEASE_BASE_PATH + releaseId.trim() + GlobalConstants.FORWARD_SLASH +
      GlobalConstants.UNZIP_FOLDER + GlobalConstants.FORWARD_SLASH + fileName + GlobalConstants.FORWARD_SLASH
    releaseFolder
  }
  
   def buildLabCorpFilePath(oesConfiguration: OESConfiguration): String = {
    val  BASE_PATH = oesConfiguration.RELEASE_BASE_PATH.replace(GlobalConstants.RELEASE,  GlobalConstants.FORWARD_SLASH)
    val lcJuncfilePath = BASE_PATH  +  GlobalConstants.SPARKCONFIG  + GlobalConstants.LABCORP + GlobalConstants.FORWARD_SLASH
    lcJuncfilePath
  }

   def readDataFrameFromMongo(spark: SparkSession, oesConfiguration: OESConfiguration, collectionName: String): DataFrame = {
    val dataframe = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
      .option(GlobalConstants.URI, oesConfiguration.MONGO_URL)
      .option(GlobalConstants.DATABASE, oesConfiguration.DATABASE_NAME)
      .option(GlobalConstants.COLLECTION, collectionName)
      .load()

    dataframe
  }
  def saveReleaseConcepts(dataframe: DataFrame, oesConfiguration: OESConfiguration) {
    dataframe.write
      .format(GlobalConstants.MONGO)
      .mode(GlobalConstants.APPENED_MODE)
      .option(GlobalConstants.URI, oesConfiguration.MONGO_URL)
      .option(GlobalConstants.DATABASE, oesConfiguration.DATABASE_NAME)
      .option(GlobalConstants.COLLECTION, GlobalConstants.RELEASE_CONCEPTS)
      .save()
  }
}