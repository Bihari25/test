package com.ihr.oea.dataloader

import java.nio.file.FileSystems
import java.nio.file.Files
import java.util.ArrayList

import scala.collection.JavaConverters.asScalaIteratorConverter
import scala.collection.mutable.WrappedArray

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.collect_list
import org.apache.spark.sql.functions.date_format
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.split
import org.apache.spark.sql.functions.to_date
import org.apache.spark.sql.functions.udf

import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.config.Util
import com.ihr.oea.common.DataLoaderUtil

class SnomedReleaseDataLoader {
	val log = Logger.getLogger(getClass.getName)
	def loadSnomedReleaseFileData(spark:SparkSession, releaseId:String, fileName:String, releaseType:String, 
	    edition:String, oesConfiguration : OESConfiguration) {
		try {
		    log.info("Running dataloader for release Id : "+releaseId)
  		  val fileList  : List[String] = List()
				val activeProfile = oesConfiguration.PROFILE
				val util = new DataLoaderUtil
    	  var releaseFolder = util.buildReleaseFolderPath(releaseId, fileName, oesConfiguration)+releaseType
				log.info("final release file path  : "+releaseFolder)
				val dir = FileSystems.getDefault.getPath(releaseFolder)
				val list = Files.walk(dir).iterator().asScala.filter(Files.isRegularFile(_)).toList
				val javaList = new ArrayList[String]
						for(file <- list) {
							var fileName :String = file.toFile().getAbsolutePath.toString()
									if(activeProfile.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE))
										javaList.add(fileName)
										else{
											val requiredFileName : String =	fileName.substring(5)
													javaList.add(requiredFileName)
										}
						}

		    val conceptFile =  Util.getFileByName(GlobalConstants.CONCEPTS_FILE_PATTERN+releaseType,javaList)
				val desFile = Util.getFileByName(GlobalConstants.DESCRIPTION_FILE_PATTERN+releaseType,javaList)
				val refAssocationFile = Util.getFileByName(GlobalConstants.REFSET_ASSOCIATION_FILE_PATTERN+releaseType,javaList)
				val refArrtibuteFile = Util.getFileByName(GlobalConstants.REFSET_ATTRIBUTEVALUE_FILE_PATTERN+releaseType,javaList)
				val refSimpleFile =  Util.getFileByName(GlobalConstants.REFSET_SIMPLE_FILE_PATTERN+releaseType,javaList)
				val refLangFile = Util.getFileByName(GlobalConstants.REFSET_LANGUAGE_FILE_PATTERN+releaseType,javaList)
				val relationFile = Util.getFileByName(GlobalConstants.RELATIONSHIP_FILE_PATTERN+releaseType,javaList)

				log.info("conceptFile : "+conceptFile)
				log.info("desFile : "+desFile)
				log.info("relationFile : "+relationFile)
				log.info("refAssocationFile : "+refAssocationFile)
				log.info("refArrtibuteFile : "+refArrtibuteFile)
				log.info("refSimpleFile : "+refSimpleFile)
				log.info("refLangFile : "+refLangFile)
				
				log.info("loading files into dataframes for release Id : "+releaseId)

				val SCT_CONCEPTS_DF = util.loadTXTData(conceptFile, GlobalConstants.TAB, spark) 
				val SCT_DESC_DF = util.loadTXTData(desFile, GlobalConstants.TAB, spark) 
				val SCT_LANG_DF =  util.loadTXTData(refLangFile, GlobalConstants.TAB, spark) 
				val SCT_ASSOC_DF = util.loadTXTData(refAssocationFile, GlobalConstants.TAB, spark) 
				val SCT_ATTR_DF = util.loadTXTData(refArrtibuteFile, GlobalConstants.TAB, spark)
				val SCT_SIMP_DF = util.loadTXTData(refSimpleFile, GlobalConstants.TAB, spark)
				val SCT_REL_DF = util.loadTXTData(relationFile, GlobalConstants.TAB, spark)
				var transitiveClosureFilePath = GlobalConstants.EMPTY_STRING
				if(activeProfile.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)){
					transitiveClosureFilePath = releaseFolder + oesConfiguration.TRANSITIVE_CLOSURE_FILE
				}else{
					transitiveClosureFilePath = releaseFolder.substring(5) + oesConfiguration.TRANSITIVE_CLOSURE_FILE
				} 

		  log.info("Transitive Closure FilePath for  : "+transitiveClosureFilePath)
		  val SCT_TRNSC_DF = util.loadTXTData(transitiveClosureFilePath, GlobalConstants.TAB, spark)
		                         .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseId));

    	// Register temporary tables for refset data
    	SCT_LANG_DF.createOrReplaceTempView(SparkSQLConstants.SCT_LANG_TABLE)
    	SCT_ASSOC_DF.createOrReplaceTempView(SparkSQLConstants.SCT_ASSOC_TABLE)
    	SCT_ATTR_DF.createOrReplaceTempView(SparkSQLConstants.SCT_ATTR_TABLE)
    	SCT_SIMP_DF.createOrReplaceTempView(SparkSQLConstants.SCT_SIMP_TABLE)
    
    	// Create the refset dataframe
    	val SCT_REFSET_DF = spark.sql(SparkSQLConstants.SCT_REFSET_QUERY)
    	// Register temporary tables for concept details data
    	SCT_CONCEPTS_DF.createOrReplaceTempView(SparkSQLConstants.SCT_CONCEPTS_TABLE)
    	SCT_DESC_DF.createOrReplaceTempView(SparkSQLConstants.SCT_DESC_TABLE)
    	SCT_REFSET_DF.createOrReplaceTempView(SparkSQLConstants.SCT_REFSET_TABLE)
    	SCT_REL_DF.createOrReplaceTempView(SparkSQLConstants.SCT_REL_TABLE)
    	SCT_TRNSC_DF.createOrReplaceTempView(SparkSQLConstants.SCT_TRNSC_TABLE)
    
    	def normalizeSyn = udf((synonym: String) => {  
    		if(synonym.startsWith(GlobalConstants.PIPE))
				synonym.substring(1)
				else if(null==synonym || synonym.equals(GlobalConstants.EMPTY_STRING) || synonym.isEmpty())
					null
				else synonym
		  })

		// Create dataframe and register tables for fetching the immediate parent and children
		val SCT_PARENT_DF = SCT_CONCEPTS_DF.join(SCT_REL_DF, SCT_CONCEPTS_DF.col(SparkSQLConstants.ID) === SCT_REL_DF.col(SparkSQLConstants.SOURCE_ID), SparkSQLConstants.INNER_JOIN)
		.filter(SCT_CONCEPTS_DF.col(SparkSQLConstants.ACTIVE) === SparkSQLConstants.ONE && SCT_REL_DF.col(SparkSQLConstants.ACTIVE) === SparkSQLConstants.ONE && SCT_REL_DF.col(SparkSQLConstants.TYPE_ID) === SparkSQLConstants.IS_RELATION)
		.groupBy(SCT_REL_DF.col(SparkSQLConstants.SOURCE_ID).alias(SparkSQLConstants.CONCEPT_ID))
		.agg(collect_list(SCT_REL_DF.col(SparkSQLConstants.DESTINATION_ID)).alias(SparkSQLConstants.PARENT))

		val SCT_CHILDREN_DF = SCT_CONCEPTS_DF.join(SCT_REL_DF, SCT_CONCEPTS_DF.col(SparkSQLConstants.ID) === SCT_REL_DF.col(SparkSQLConstants.DESTINATION_ID), SparkSQLConstants.INNER_JOIN)
		.filter(SCT_CONCEPTS_DF.col(SparkSQLConstants.ACTIVE) === SparkSQLConstants.ONE && SCT_REL_DF.col(SparkSQLConstants.ACTIVE) === SparkSQLConstants.ONE && SCT_REL_DF.col(SparkSQLConstants.TYPE_ID) === SparkSQLConstants.IS_RELATION)
		.groupBy(SCT_REL_DF.col(SparkSQLConstants.DESTINATION_ID).alias(SparkSQLConstants.CONCEPT_ID))
		.agg(collect_list(SCT_REL_DF.col(SparkSQLConstants.SOURCE_ID)).alias(SparkSQLConstants.CHILDREN))

		val SCT_CONCEPT_DETAILS_TEMP_DF = spark.sql(SparkSQLConstants.SCT_CONCEPT_DETAILS_QUERY)
		.withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseId))
		val SCT_CONCEPT_DETAILS_DF = SCT_CONCEPT_DETAILS_TEMP_DF.withColumn(SparkSQLConstants.SYNONYM, normalizeSyn(col(SparkSQLConstants.SYNONYM)))

		val SCT_CONCEPT_REL_DF = SCT_PARENT_DF.join(SCT_CHILDREN_DF, Seq(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.FULL_OUTER_JOIN)

		val SCT_TAXONOMY_DF = spark.sql(SparkSQLConstants.SCT_TAXONOMY_QUERY)
		SCT_TAXONOMY_DF.createOrReplaceTempView(SparkSQLConstants.SCT_TAXONOMY_TABLE)

		SCT_CONCEPT_DETAILS_DF.createOrReplaceTempView(SparkSQLConstants.SCT_CONCEPT_DETAILS_TABLE)

		val SCT_TAXONOMY_DETAILS_DF = spark.sql(SparkSQLConstants.SCT_TAXONOMY_DETAILS_QUERY)

		// Final release report is the join of concept details, relations and taxonomy
		val SCT_CONCEPT_REL_TAX_DF = SCT_CONCEPT_REL_DF.join(SCT_TAXONOMY_DETAILS_DF, SparkSQLConstants.CONCEPT_ID)

		val SCT_FINAL_TEMP_DF = SCT_CONCEPT_DETAILS_DF.join(SCT_CONCEPT_REL_TAX_DF, SparkSQLConstants.CONCEPT_ID)

		//de dupe check and removal Udf from synonyms
		val dedup_normlize_array = udf { (t1: WrappedArray[String], s1:String, s2: String) =>  { 
			if (t1 !=null && t1.size == 1 && t1.toArray(scala.reflect.classTag[String])(0).length == 0) { null } 
			else if (t1 !=null && t1.size > 0) {
				// Make a set to eliminate the duplicate
				var t2 = t1.toSet.toArray.filter(!_.isEmpty);
				if ( s1 !=null && s1.length > 0 ) {
					var ns1 = s1;
					// Strip the brackets in s1
					if(s1.indexOf("(") != -1) { 
						ns1 = s1.substring(0, s1.lastIndexOf("(")).trim 
					}                                                                        
					// Remove ns1 from the t2 array
					t2 = t2.filter(!_.matches("(?i)^\\Q"+ns1+"\\E$"))
				} 
				if ( s2 !=null && s2.length > 0 ) {
					// Remove s2 from the t2 array
					t2 = t2.filter(!_.matches("(?i)^\\Q"+s2+"\\E$"))
				}
				if(t2 != null && t2.size > 0) { t2.toArray } 
				else { null }
			}
			else { null }
		} 
		}

    log.info("generating final dataframes for all taxonomy for release Id : "+releaseId)
		var SCT_FINAL_DF = SCT_FINAL_TEMP_DF.withColumn(SparkSQLConstants.SYNONYM,
				dedup_normlize_array(split(col(SparkSQLConstants.SYNONYM),GlobalConstants.SQUARE_PIPE),
						col(SparkSQLConstants.FSN),col(SparkSQLConstants.PREFERRED_TERM)))
		// write to mongoDB
		log.info("Saving final data into Mongo for all taxonomy for release Id : "+releaseId)
		if(edition.equalsIgnoreCase(SparkSQLConstants.SNOMED_US)){
		  SCT_FINAL_DF = SCT_FINAL_DF.filter(col(SparkSQLConstants.MODULE_ID) === SparkSQLConstants.US_MODULE_ID)
		}
    
		SCT_FINAL_DF = SCT_FINAL_DF
		.drop(SparkSQLConstants.MODULE_ID)
		.withColumn(SparkSQLConstants.EFFECTIVE_TIME,
		    date_format(to_date(col(SparkSQLConstants.EFFECTIVE_TIME),GlobalConstants.SNOMED_DATE_FORMAT), GlobalConstants.OUTPUT_DATE_FORMAT))
		//applying taxonomy fsn mapping rules from mongo spark COnfig configuration
		if(edition.equalsIgnoreCase(SparkSQLConstants.SNOMED_US)){
				SCT_FINAL_DF.createOrReplaceTempView(SparkSQLConstants.SCT_FINAL_TABLE)			
				val snomedmapping = util.readDataFrameFromMongo(spark, oesConfiguration, GlobalConstants.SPARK_CONFIG_COLLECTION)
						.filter(col(GlobalConstants.TYPE_FILTER) === GlobalConstants.MAPPING && col(GlobalConstants.CODESET) === GlobalConstants.CODESET_SNOMED && col(GlobalConstants.JOB_TYPE) === GlobalConstants.LOADER)
				snomedmapping.createOrReplaceTempView(SparkSQLConstants.SCT_TAXONOMY_MAP_TABLE)
				SCT_FINAL_DF = spark.sql(SparkSQLConstants.SCT_FINAL_MAP_QUERY)
					}
		log.info("saving snomed release data into mongoDB for releaseId : "+releaseId)
		util.saveReleaseConcepts(SCT_FINAL_DF, oesConfiguration)
		log.info("Successfully saved final data into Mongo for all taxonomy for release Id : "+releaseId)
		}catch {
				case e: Exception => log.error(s"Exception while running the data loader for release Id : "+releaseId)
			  log.error(e.printStackTrace())
				throw e
		}
  }
}