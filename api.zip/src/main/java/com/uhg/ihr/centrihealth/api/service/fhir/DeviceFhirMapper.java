package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthDevice;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Device;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.StringType;


@Slf4j
@Value(staticConstructor = "of")
public class DeviceFhirMapper implements FhirMapper<HealthDevice, Device> {

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getHealthDevices())) {
            map(fhirResource, dataClasses.getHealthDevices());
        }
    }

    @Override
    public void map(FhirResource fhirResource, HealthDevice healthDevice) {
        Patient patient = fhirResource.getPatient();
        Bundle bundle = fhirResource.getBundle();

        Device device = new Device();
        device.setId(new IdType(createIdURI()));
        //record key
        if (null != healthDevice.getRecordKey()) {
            device.addIdentifier().setValue(healthDevice.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }
        //object id
        if (null != healthDevice.getObjectId()) {
            device.addIdentifier().setValue(healthDevice.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(healthDevice.getReferenceIds())) {
            device.addIdentifier().setValue(AppUtils.jsonEscape(healthDevice.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));
        }
        //medical device
        if (null != healthDevice.getMedicalDevice()) {
            device.setType(new CodeableConcept()
                    .setText(healthDevice.getMedicalDevice().getIhrLaymanTerm())
                    .addCoding(new Coding().
                            setDisplay(healthDevice.getMedicalDevice().getIhrTerm())
                            .setSystem(healthDevice.getMedicalDevice().getSourceVocabulary())
                            .setCode(healthDevice.getMedicalDevice().getSourceVocabularyCode())));

            if (StringUtils.isNotBlank(healthDevice.getMedicalDevice().getCpthcpcsCode())) {
                device.getType().addCoding(new Coding()
                        .setSystem(Constants.CPTHCPCS_CODE_URL)
                        .setCode(healthDevice.getMedicalDevice().getCpthcpcsCode()));
            }
        }
        //medical device status
        if (null != healthDevice.getMedicalDeviceStatus()) {
            device.addExtension(Constants.STATUS_URL, new CodeableConcept()
                    .setText(healthDevice.getMedicalDeviceStatus().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthDevice.getMedicalDeviceStatus().getIhrTerm())
                            .setSystem(healthDevice.getMedicalDeviceStatus().getSourceVocabulary())
                            .setCode(healthDevice.getMedicalDeviceStatus().getSourceVocabularyCode())));
        }
        //presence state term
        if (StringUtils.isNotBlank(healthDevice.getPresenceStateTerm())) {
            device.addExtension(Constants.PRESENCE_STATE_TERM_URL, new StringType(healthDevice.getPresenceStateTerm()));
        }
        //supplier
        if (null != healthDevice.getSupplier()) {
            Identifier identifier = new Identifier()
                    .setValue(healthDevice.getSupplier().getNpinum())
                    .setSystem(Constants.NPI_URL);
            Organization organization = getOrCreateOrganization(fhirResource, identifier);
            device.setOwner(new Reference(organization).setDisplay(healthDevice.getSupplier().getName()));
        }
        //medicalDeviceDate
        if (StringUtils.isNotBlank(healthDevice.getMedicalDeviceDate())) {
            device.addExtension(Constants.MEDICAL_DEVICE_START_DATE_URL, toDateTimeTypeFromDate(healthDevice.getMedicalDeviceDate()));
        }
        //clinicallyRelevantDate
        if (StringUtils.isNotBlank(healthDevice.getClinicallyRelevantDate())) {
            device.addExtension(Constants.CLINICALLY_RELEVANT_DATE_URL, toDateTimeTypeFromDate(healthDevice.getClinicallyRelevantDate()));
        }
        //last dispense date
        if (StringUtils.isNotBlank(healthDevice.getLastDispenseDate())) {
            device.addExtension(Constants.LAST_DISPENSE_DATE_URL, toDateTimeTypeFromDate(healthDevice.getLastDispenseDate()));
        }
        // note
        if (CollectionUtils.isNotEmpty(healthDevice.getNote())) {
            for (Note note : healthDevice.getNote()) {
                device.addNote(getAnnotation(patient, note, fhirResource));
            }
        }
        //related care team
        if (CollectionUtils.isNotEmpty(healthDevice.getRelatedCareTeam())) {
            device.addIdentifier().setValue(AppUtils.jsonEscape(healthDevice.getRelatedCareTeam()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CARE_TEAM_INSTANCE_IDS));
        }
        //data source
        if (CollectionUtils.isNotEmpty(healthDevice.getDataSource())) {
            device.addExtension(Constants.DATA_SOURCE_URL, new StringType(AppUtils.jsonEscape(healthDevice.getDataSource())));
        }

        //last updated date
        if (StringUtils.isNotBlank(healthDevice.getLastUpdateDate())) {
            device.setMeta(new Meta().setLastUpdatedElement(toInstantTypeFromDate(healthDevice.getLastUpdateDate())));
        }

        //sensitivity classes
        if (CollectionUtils.isNotEmpty(healthDevice.getSensitivityClasses())) {
            device.addExtension(Constants.SENSITIVITY_CLASSES_URL,
                    new StringType(AppUtils.jsonEscape(healthDevice.getSensitivityClasses())));
        }
        device.setPatient(new Reference(patient));

        // add resource into bundle
        bundle.addEntry().setFullUrl(device.getId()).setResource(device);
    }
}
