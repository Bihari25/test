package com.uhg.ihr.centrihealth.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Condition;
import org.hl7.fhir.r4.model.Location;
import org.hl7.fhir.r4.model.Observation;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.Specimen;

import javax.validation.constraints.NotBlank;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FhirResource {

    @JsonProperty
    @NotBlank(message = "A bundle object must required.")
    private Bundle bundle;

    @JsonProperty
    @NotBlank(message = "A patient object must required.")
    private Patient patient;

    @JsonProperty
    private Map<String, Practitioner> practitioner;

    @JsonProperty
    private Map<String, PractitionerRole> practitionerRole;

    @JsonProperty
    private Map<String, RelatedPerson> relatedPerson;

    @JsonProperty
    private Map<String, Organization> organization;

    @JsonProperty
    private Map<String, Condition> condition;

    @JsonProperty
    private Map<String, Observation> observation;

    @JsonProperty
    private Map<String, Location> location;

    @JsonProperty
    private Map<String, Specimen> specimen;
}
