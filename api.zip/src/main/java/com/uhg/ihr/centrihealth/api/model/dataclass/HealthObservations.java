package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@NoArgsConstructor
public class HealthObservations {
    private String recordType;
    private String recordKey;
    private String observationDate;
    private String lastUpdateDate;
    private String valueString;
    private IhrTerm observation;
    private IhrTerm observationUnitOfMeasure;
    private IhrTerm observationValue;
    private String referenceRange;
    private IhrTerm abnormalObservation;
    private BigInteger objectId;
    private List<String> sensitivityClasses;
    private List<String> dataSource;
    private List<String> referenceIds;
    private List<Note> note;
    private IhrTerm status;
}
