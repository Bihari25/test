package com.uhg.ihr.centrihealth.api.configuration;

import io.micronaut.context.annotation.Property;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * VersionConfiguration class used to give version, data, schema information of a api.
 *
 * @author ihr extract engineering team.
 * copyright (C) All rights reserved to UHG
 */
@Data
@NoArgsConstructor
public class VersionConfiguration {

    @Property(name = "versionConfig.dataVersion")
    private String dataVersion;

    @Property(name = "versionConfig.schemaVersion")
    private String schemaVersion;
}
