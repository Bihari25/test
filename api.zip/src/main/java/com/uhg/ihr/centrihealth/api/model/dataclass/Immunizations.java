package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigInteger;
import java.util.List;

@Data
@NoArgsConstructor
public class Immunizations {
    private String recordType;
    private String recordKey;
    private String healthEventDate;
    private String clinicallyRelevantDate;
    private Boolean genericFlag;
    private IhrTerm medication;
    private Float dosageQuantity;
    private IhrTerm concept;
    private IhrTerm dosageUnit;
    private String dosageFrequency;
    private IhrTerm dosageForm;
    private BigInteger objectId;
    private List<String> sensitivityClasses;
    private List<String> sourceClaimIds;
    private List<BigInteger> relatedConditions;
    private List<BigInteger> relatedObservations;
    private List<BigInteger> relatedCareTeam;
    private String presenceStateTerm;
    private List<BigInteger> relatedServiceProviders;
    private List<String> dataSource;
    private String lastUpdateDate;
    private List<String> referenceIds;
    private List<Note> note;
}
