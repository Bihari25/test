package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrderingProvider {
    private String orderingProviderName;
    private String orderingProviderNPInum;
}
