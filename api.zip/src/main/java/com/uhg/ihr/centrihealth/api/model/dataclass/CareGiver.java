package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class CareGiver {
    private String recordType;
    private String recordKey;
    private String relationshipToIndividual;
    private String relatedEntityName;
    private String relatedEntityRoleTerm;
    private String relationshipStartDate;
    private String relationshipEndDate;
    private BigInteger objectId;
    private List<String> referenceIds;
}
