package com.uhg.ihr.centrihealth.api.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.google.common.collect.ImmutableMap;
import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * SenzingTokenHelper class used to generate senzing token during runtime.
 *
 * @author ihr engineering team.
 * copyright (C) All rights reserved UHG
 */
@Slf4j
public class SenzingTokenHelper {
    private static final String DEFAULT_AUD = "secure-app";
    private static final String DEFAULT_ISS = "ihr-senzing-api-gateway";
    private static final String DEFAULT_SUBJECT = "ihr-api";
    private static final String TOKEN_BEARER = "Bearer ";
    private static final String TOKEN_TYPE = "JWT";
    private static final String HEADER_TYPE = "typ";
    public static final Map<String, Object> HEADER_CLAIMS = ImmutableMap.of(HEADER_TYPE, TOKEN_TYPE);


    /**
     * Method to generate senzing token. https://en.wikipedia.org/wiki/JSON_Web_Token#Standard_fields
     *
     * @param sub        Identifies the subject of the JWT.
     * @param iss        Identifies principal that issued the JWT.
     * @param aud        Identifies the recipients that the JWT is intended for. Each principal intended to process the JWT must identify itself with a value in the audience claim. If the principal processing the claim does not identify itself with a value in the aud claim when this claim is present, then the JWT must be rejected.
     * @param iat        Identifies the time at which the JWT was issued. The value must be a NumericDate.
     * @param duration   used to build the expiration time. Now + duration ms is used. Identifies the expiration time on and after which the JWT must not be accepted for processing. The value must be a NumericDate:[9] either an integer or decimal, representing seconds past 1970-01-01 00:00:00Z.
     * @param roles      the roles for which the token is being generated
     * @param signingKey the senzing secretKey used to sign tokens
     * @return String the token
     */
    public static String generateToken(String sub, String iss, String aud, Date iat, long duration,
                                       List<String> roles, String signingKey) {

        return TOKEN_BEARER.concat(JWT.create()
                .withSubject(sub != null ? sub : DEFAULT_SUBJECT)
                .withIssuer(iss != null ? iss : DEFAULT_ISS)
                .withHeader(HEADER_CLAIMS)
                .withAudience(aud != null ? aud : DEFAULT_AUD)
                .withClaim("rol", roles)
                .withIssuedAt(iat)
                .withExpiresAt(new Date(iat.getTime() + duration))
                .sign(Algorithm.HMAC512(signingKey.getBytes(StandardCharsets.UTF_8))));
    }

}