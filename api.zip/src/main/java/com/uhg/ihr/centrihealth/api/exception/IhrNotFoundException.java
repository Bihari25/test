package com.uhg.ihr.centrihealth.api.exception;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class IhrNotFoundException extends RuntimeException {
    public IhrNotFoundException(String message) {
        super(message);
    }
}