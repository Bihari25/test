package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@NoArgsConstructor
public class HealthDevice {
    private String recordType;
    private String recordKey;
    private String medicalDeviceDate;
    private IhrTerm medicalDevice;
    private IhrTerm medicalDeviceStatus;
    private String lastDispenseDate;
    private Supplier supplier;
    private List<BigInteger> relatedCareTeam;
    private String presenceStateTerm;
    private BigInteger objectId;
    private List<String> dataSource;
    private String clinicallyRelevantDate;
    private List<String> referenceIds;
    private String lastUpdateDate;
    private List<String> sensitivityClasses;
    private List<Note> note;
}
