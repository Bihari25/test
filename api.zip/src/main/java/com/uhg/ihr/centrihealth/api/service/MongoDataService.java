package com.uhg.ihr.centrihealth.api.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.mongodb.client.model.ReplaceOptions;
import com.mongodb.reactivestreams.client.MongoClient;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.exception.IhrNotFoundException;
import com.uhg.ihr.centrihealth.api.filter.DataClassesFilter;
import com.uhg.ihr.centrihealth.api.filter.DataFilter;
import com.uhg.ihr.centrihealth.api.logging.LoggingFilter;
import com.uhg.ihr.centrihealth.api.model.MongoDataRequest;
import com.uhg.ihr.centrihealth.api.model.Payload;
import com.uhg.ihr.centrihealth.api.model.RecordType;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import de.undercouch.bson4jackson.BsonFactory;
import io.micronaut.context.annotation.Property;
import io.micronaut.core.util.CollectionUtils;
import io.micronaut.http.HttpRequest;
import io.reactivex.Flowable;
import io.reactivex.Maybe;
import io.reactivex.Single;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.bson.BsonBinaryWriter;
import org.bson.Document;
import org.bson.codecs.DocumentCodec;
import org.bson.codecs.EncoderContext;
import org.bson.io.BasicOutputBuffer;

import javax.inject.Named;
import javax.inject.Singleton;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.mongodb.client.model.Filters.eq;

/**
 * MongoDataService class used to query payload collection for given ihrId and filter payload response for given data classes
 *
 * @author ihr api engineering team
 * copyright (C) All rights reserved UHG
 */
@Slf4j
@Singleton
public class MongoDataService {
    public static final String BASIC_IHR = "returnBasicIhr";
    private static final String ENG_ISO_CODE = "EN";
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final ObjectMapper BSON_MAPPER = new ObjectMapper(new BsonFactory());
    private static final long MONGO_TIMEOUT_MS = 9000;

    // used to create an empty json node in case a data class is completely filtered out
    // use hashmap built from Immutable for access speed
    // https://stackoverflow.com/questions/15756940/guava-immutablemap-has-noticeably-slower-access-than-hashmap
    protected static final Map<String, String> REQUEST_DC_TO_JSON_DC = Maps.newHashMap(ImmutableMap.<String, String>builder()
            .put(RecordType.ADVERSE_REACTION.toString().toLowerCase(), "adverseReactions")
            .put(RecordType.CARE_GIVER.toString().toLowerCase(), "careGivers")
            .put(RecordType.CARE_TEAM.toString().toLowerCase(), "careTeam")
            .put(RecordType.HEALTH_CONDITION.toString().toLowerCase(), "conditions")
            .put(RecordType.HEALTH_DEVICE.toString().toLowerCase(), "healthDevices")
            .put(RecordType.HEALTH_OBSERVATIONS.toString().toLowerCase(), "healthObservations")
            .put(RecordType.HEALTH_STATUS.toString().toLowerCase(), "healthStatuses")
            .put(RecordType.IMMUNIZATIONS.toString().toLowerCase(), "immunizations")
            .put(RecordType.PROCEDURE_HISTORY.toString().toLowerCase(), "procedureHistory")
            .put(RecordType.HEALTH_MEDICATION.toString().toLowerCase(), "medications")
            .put(RecordType.SERVICE_FACILITY_PROVIDER.toString().toLowerCase(), "serviceProviders")
            .put(RecordType.VISIT_HISTORY.toString().toLowerCase(), "visitHistory")
            .build());

    protected static final Map<String, String> JSON_DC_TO_REQUEST_DC =
            REQUEST_DC_TO_JSON_DC.entrySet().stream().collect(Collectors.toMap(Map.Entry::getValue, Map.Entry::getKey));

    // used to ensure we are only responding with valid dataclasses in the json
    protected static final Set<String> VALID_RESPONSE_CLASSES = new HashSet<>(REQUEST_DC_TO_JSON_DC.values());

    private final MongoClient mongoB50Client;
    private final MongoClient mongoB50SecondClient;

    public final String b50SecondCollection;
    public final boolean b50SecondEnabled;
    public final String b50SecondDatabase;

    @Property(name = "mongo.b50Database")
    public String b50Database;

    @Property(name = "mongo.b50Collection")
    public String b50Collection;

    @Property(name = "mongo.testDataSbrBackup")
    public String sbrBackupCollection;

    @Property(name = "mongo.testDataSbrWorking")
    public String sbrWorkingCollection;

    @Property(name = "mongo.testDataTranscribedBackup")
    public String transcribedBackupCollection;



    public MongoDataService(@Named("b50") MongoClient mongoB50Client,
                            @Named("b50Second") MongoClient mongoB50SecondClient,
                            @Property(name = "mongo.b50SecondCollection") String b50SecondCollection,
                            @Property(name = "mongo.b50SecondDatabase") String b50SecondDatabase,
                            @Property(name = "mongo.b50SecondEnabled") boolean b50SecondEnabled) {

        this.mongoB50Client = mongoB50Client;
        this.mongoB50SecondClient = mongoB50SecondClient;
        this.b50SecondCollection = b50SecondCollection;
        this.b50SecondEnabled = b50SecondEnabled;
        this.b50SecondDatabase = b50SecondDatabase;
        log.info("B50_SECOND_ENABLED is {}, B50_SECOND_COLLECTION is {}", this.b50SecondEnabled, this.b50SecondCollection);
    }

    /**
     * Method to get data payload from mongo.
     *
     * @return Maybe<JsonNode>
     */
    public Maybe<JsonNode> getDataResponse(final MongoDataRequest mongoDataRequest, final HttpRequest<?> request) {
        //TODO: seems like this could be better
        String computedDatabase = b50Database;
        String computedCollection = getLanguageCollection(mongoDataRequest.getLanguage(), b50Collection);

        log.info("Fetching data from mongoDB database: {}, collection: {}", computedDatabase, computedCollection);

        Maybe<Document> searchedPayload = Flowable.fromPublisher(mongoB50Client.getDatabase(computedDatabase).getCollection(computedCollection)
                    .find(eq("_id", mongoDataRequest.getIhrId()))
                    .maxTime(MONGO_TIMEOUT_MS, TimeUnit.MILLISECONDS) // to prevent queries from building up server side in case of request timeout
                    .limit(1))
                    .firstOrError()
                    .toMaybe()
                    .onErrorResumeNext(getSecondDatabaseResponse(mongoDataRequest, request))
                    .onErrorReturn(error -> buildBasicIhr(request, error));

        // Filter the payload
        return searchedPayload.map(payloadDoc -> filterPayload(payloadDoc, mongoDataRequest.getDataClasses(), mongoDataRequest.getDataFilters()));
    }

    private static String getLanguageCollection(String reqLanguage, String originalCollection) {
        if (!ENG_ISO_CODE.equalsIgnoreCase(reqLanguage)) {
            return originalCollection + "_" + reqLanguage.toLowerCase();
        }
        return originalCollection;
    }

    public Maybe<Document> getSecondDatabaseResponse(final MongoDataRequest mongoDataRequest, final HttpRequest<?> request) {
        // used to ensure the driver can be chained up by the flowable even if the b50SecondCollection isn't specified
        String secondCollection = getLanguageCollection(mongoDataRequest.getLanguage(),
                StringUtils.isNotBlank(b50SecondCollection) ? b50SecondCollection : b50Collection);
        String b50PreferedDatabase = b50SecondEnabled ? b50SecondDatabase : b50Database;
        MongoClient mongoB50PreferedClient = b50SecondEnabled ? mongoB50SecondClient : mongoB50Client;

        return Flowable.fromPublisher(mongoB50PreferedClient.getDatabase(b50PreferedDatabase).getCollection(secondCollection)
                .find(eq("_id", mongoDataRequest.getIhrId()))
                .maxTime(MONGO_TIMEOUT_MS, TimeUnit.MILLISECONDS) // to prevent queries from building up server side in case of request timeout
                .limit(1))
                .doOnSubscribe(sub -> {
                    if (!b50SecondEnabled) {
                        throw new IhrNotFoundException("user was matched but no data was found");
                    }
                    LoggingFilter.addAttribute(request, "secondDatabase", true);
                    log.info("attempting to grab from second database: {}, collection: {}", b50PreferedDatabase, secondCollection);
                })
                .firstOrError()
                .toMaybe()
                .onErrorResumeNext(Maybe.error(new IhrNotFoundException("user was matched but no second data was found")));
    }

    /**
     * Method to filter response payload based user defined data classes (It's kind of customized response)
     *
     * @param document    the mongo document
     * @param dataClasses the dataclasses to return
     * @param dataFilters the filters to apply
     * @return JsonNode
     */
    public static JsonNode filterPayload(final Document document, final Set<RecordType> dataClasses, final List<DataFilter> dataFilters) {
        if (Objects.isNull(document)) {
            throw new IhrNotFoundException("user was matched but no corresponding data was found");
        }

        JsonNode responseJsonNode;

        try {
            responseJsonNode = documentToJsonNode(document);
        } catch (Exception ex) {
            log.error("Unable to translate mongodb document to jsonNode exception message: {}", ex.getMessage());
            throw new IhrNotFoundException("Unable to translate mongodb document to jsonNode ".concat(ex.getMessage()));
        }

        return filteredResponse(responseJsonNode, dataClasses, dataFilters);
    }

    private static Document buildBasicIhr(final HttpRequest<?> request, final Throwable error) {

        LoggingFilter.addAttribute(request, BASIC_IHR, true);
        LoggingFilter.addAttribute(request, "mongoReason", error.getMessage());

        final DataClass dataClass = DataClass.builder()
                .adverseReactions(new ArrayList<>())
                .careGivers(new ArrayList<>())
                .careTeam(new ArrayList<>())
                .conditions(new ArrayList<>())
                .healthDevices(new ArrayList<>())
                .healthObservations(new ArrayList<>())
                .healthStatuses(new ArrayList<>())
                .immunizations(new ArrayList<>())
                .medications(new ArrayList<>())
                .procedureHistory(new ArrayList<>())
                .serviceProviders(new ArrayList<>())
                .visitHistory(new ArrayList<>()).build();

        return BSON_MAPPER.convertValue(dataClass, Document.class);
    }

    /**
     * Method to filter payload response
     *
     * @param payload     the payload returned from mongo
     * @param dataClasses the dataclasses to return from the payload
     * @param dataFilters the filters to apply to the payload
     * @return JsonNode
     */
    public static JsonNode filteredResponse(final JsonNode payload, final Set<RecordType> dataClasses, final List<DataFilter> dataFilters) throws IhrBadRequestException {
        // Translate user request data classes properties to lower cases.
        Set<String> dcStrings = dataClassesPropertiesToLowerCase(dataClasses);

        // Filter payload response based on user requested data classes
        // for example, the request only wants 5 DCs, the payload has all 12, cut it down to 5
        Map<String, JsonNode> filteredDataClasses = filterDataClasses(payload, dcStrings);

        // Filter the data classes by additional data filter criteria.
        // for example, the request only wants PresenceState = present
        Map<String, JsonNode> filteredDataClassesContent = DataClassesFilter.filterAllowedDataClassesByCriteria(filteredDataClasses, dataFilters);

        // post processor for empty array data classes
        // for example, if all health devices get filtered out and become null even though it was requested, add an empty array
        // this is just a safety net - if we have extreme confidence the original source is always schema perfect
        // and the filters arent excessive, this could be removed
        addEmptyClassesBack(dcStrings, filteredDataClassesContent);

        // Build the custom data view node
        JsonNode customDataViewNode = MAPPER.convertValue(filteredDataClassesContent, JsonNode.class);
        return MAPPER.createObjectNode().set(Payload.DATA_CLASSES, customDataViewNode);
    }

    /**
     * Method to filter data classes based on user request.
     *
     * @param payload   the payload returned from mongo
     * @param dcStrings the dataclasses to return
     * @return LinkedHashMap
     */
    public static Map<String, JsonNode> filterDataClasses(JsonNode payload, Set<String> dcStrings) {
        Map<String, JsonNode> customDataView = new LinkedHashMap<>();

        // Validate if the payload is null or empty without data classes.
        if (Objects.nonNull(payload) && Objects.nonNull(payload.get(Payload.DATA_CLASSES))) {
            // Iterate over the json node tree and filter the response based on the user requested data classes.
            for (Iterator<Map.Entry<String, JsonNode>> it = payload.get(Payload.DATA_CLASSES).fields(); it.hasNext(); ) {
                Map.Entry<String, JsonNode> objNode = it.next();

                // Filter and build custom view for data classes and also keep track of the empty results for requested data classes.
                if (objNode.getValue().size() > 0) {
                    String recType = objNode.getValue().get(0).get(RecordType.RECORD_TYPE) == null ? "" : objNode.getValue().get(0).get(RecordType.RECORD_TYPE).asText();
                    if (dcStrings.contains(recType.toLowerCase())) {
                        customDataView.put(objNode.getKey(), objNode.getValue());
                    }
                } else if (dcStrings.contains(JSON_DC_TO_REQUEST_DC.get(objNode.getKey()))) {
                    customDataView.put(objNode.getKey(), objNode.getValue());
                }
            }
        }

        return customDataView;
    }

    /**
     * Method to translate mongodb document to json node
     */
    public static JsonNode documentToJsonNode(final Document document) throws IOException {
        InputStream is = documentToInputStream(document);
        return BSON_MAPPER.readTree(is);
    }

    /**
     * Method to covert document to input stream.
     */
    private static InputStream documentToInputStream(final Document document) {
        BasicOutputBuffer outputBuffer = new BasicOutputBuffer();
        BsonBinaryWriter writer = new BsonBinaryWriter(outputBuffer);
        new DocumentCodec().encode(writer, document, EncoderContext.builder().isEncodingCollectibleDocument(true).build());
        return new ByteArrayInputStream(outputBuffer.toByteArray());
    }

    /**
     * converts request/input data classes properties to lowercase
     */
    private static Set<String> dataClassesPropertiesToLowerCase(final Set<RecordType> dataClasses) {
        return Objects.isNull(dataClasses) ? Collections.emptySet() :
                dataClasses.stream().map(Objects::toString).map(String::toLowerCase).collect(Collectors.toSet());
    }

    /**
     * Adds data classes back in that have been requested but were left out or
     * fully filtered out by dataclass filtering or content filtering
     * acts as a safety net
     *
     * @param dcStrings the input dataclasses from the request
     * @param payload   the filtered outbound payload
     */
    public static void addEmptyClassesBack(Set<String> dcStrings, Map<String, JsonNode> payload) {
        if (CollectionUtils.isNotEmpty(dcStrings)) {
            for (String dc : dcStrings) {
                String json = REQUEST_DC_TO_JSON_DC.get(dc);
                if (json != null && !payload.containsKey(json)) {
                    payload.put(json, MAPPER.createArrayNode());
                }
            }
        }
    }

    //find SBR in gold, write SBR to working. find transcribed in gold, write transcribed to working
    public void resetData(final String ihrId) {
        log.info("resetting ihrId {}. grabbing backup transcribed from {}:{}", ihrId, b50Database, transcribedBackupCollection);

        Document transcribedBackup = Flowable.fromPublisher(mongoB50Client.getDatabase(b50Database).getCollection(transcribedBackupCollection)
                .find(eq("_id", ihrId))
                .limit(1))
                .firstOrError()
                .onErrorResumeNext(e -> Single.error(new IhrNotFoundException("cannot find transcribed document for " + ihrId)))
                .blockingGet();

        Flowable.fromPublisher(mongoB50Client.getDatabase(b50Database).getCollection(b50Collection)
                .replaceOne(eq("_id", ihrId), transcribedBackup, new ReplaceOptions().upsert(true))).blockingSubscribe();

        log.info("reset transcribed for {}, wrote into {}:{}", ihrId, b50Database, b50Collection);
        log.info("resetting ihrId {}. grabbing backup sbr from {}:{}", ihrId, b50Database, sbrBackupCollection);

        Document sbrBackup = Flowable.fromPublisher(mongoB50Client.getDatabase(b50Database).getCollection(sbrBackupCollection)
                .find(eq("_id", ihrId))
                .limit(1))
                .firstOrError()
                .onErrorResumeNext(e -> Single.error(new IhrNotFoundException("cannot find sbr document for " + ihrId)))
                .blockingGet();

        Flowable.fromPublisher(mongoB50Client.getDatabase(b50Database).getCollection(sbrWorkingCollection)
                .replaceOne(eq("_id", ihrId), sbrBackup, new ReplaceOptions().upsert(true))).blockingSubscribe();

        log.info("reset sbr for {}, wrote into {}:{}", ihrId, b50Database, sbrWorkingCollection);

    }
}