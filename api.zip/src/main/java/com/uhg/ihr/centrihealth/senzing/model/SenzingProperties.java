package com.uhg.ihr.centrihealth.senzing.model;

import io.micronaut.context.annotation.Property;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * SenzingProperties class used to map senzing properties from yml/yaml file.
 *
 * @author ihr api team.
 * copyright (C) All rights reserved UHG
 */
@Data
@NoArgsConstructor
public class SenzingProperties {

    @Property(name = "micronaut.http.services.b50Senzing.urls")
    private String senzingUrl;

    @Property(name = "micronaut.http.services.b50SenzingSecond.urls")
    private String senzingUrlSecond;

    @Property(name = "senzing.subject")
    private String subject;

    @Property(name = "senzing.duration")
    private Long duration;

    @Property(name = "senzing.secretKey")
    private String secretKey;

    @Property(name = "senzing.secretKeySecond")
    private String secretKeySecond;

    @Property(name = "senzing.roles")
    private List<String> roles;

    @Property(name = "senzing.audience")
    private String audience;

    @Property(name = "senzing.secondEnabled")
    private boolean secondEnabled;

}