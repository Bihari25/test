package com.uhg.ihr.centrihealth.api.filter;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.ImmutableSet;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * PresenceStateFilter used to filter data content of dataclass for given presence states.
 *
 * @author ihr api team
 * copyright (C) all rights reserved UHG
 */
@Slf4j
public class PresenceStateFilter implements DataFilter {
    private static final Set<String> PRESENCE_STATE_TYPES = ImmutableSet.of("Present", "Not Present", "Past Occurrence", "Planned Occurrence");

    private final List<String> presenceStates;

    public PresenceStateFilter(String presenceState) {
        // Validate presence state value is null or empty.
        if (StringUtils.isBlank(presenceState)) {
            throw new IhrBadRequestException("PresenceState value can't be null or empty");
        }

        // Validate requested presence state value is valid or not.
        this.presenceStates = Arrays.asList(presenceState.split("\\s*,\\s*"));
        validatePresenceState();
    }

    @Override
    public boolean isFilterableDataClass(String dataClass) {
        return DataFilter.DATA_CLASS_FILTERS.contains(dataClass);
    }

    @Override
    public Set<String> getFilterableDataClasses() {
        return DataFilter.DATA_CLASS_FILTERS;
    }

    @Override
    public boolean filter(JsonNode dataNode) {
        String presenceState;

        // Validate to handle  data structure requests which don't have presence state term.
        JsonNode presenceStateTermNode = dataNode.get(AppUtils.PRESENCE_STATE_TERM);
        if (Objects.isNull(presenceStateTermNode)) {
            log.warn("There is no presence state term field in the data node");
            return false;
        } else {
            presenceState = presenceStateTermNode.textValue();
        }

        // Validate given input present states exists or not.
        return StringUtils.isBlank(presenceState) || this.presenceStates.contains(presenceState);
    }

    /**
     * Method to validate given presence state is valid value or not.
     */
    private void validatePresenceState() {

        List<Boolean> isAnyPresenceStates = new ArrayList<>();

        // Iterate and validate requested presence state filter value with reference presence state values.
        for (String requestedPresentState : this.presenceStates) {
            boolean isValuePresent = PRESENCE_STATE_TYPES.contains(requestedPresentState);

            // Keep track on the requested present state filter values.
            if (!isValuePresent) {
                isAnyPresenceStates.add(isValuePresent);
            }
        }

        // Validate requested presence state filters are not matching any of the presence state types.
        if (isAnyPresenceStates.size() == this.presenceStates.size()) {
            throw new IhrBadRequestException("Requested presence state filter values are invalid");
        }
    }

}
