package com.uhg.ihr.centrihealth.api.model.dataclass;

import java.util.Map;

public enum DataClassEnums {

    HEALTH_STATUS("HEALTH_STATUS"),
    ADVERSE_REACTION("ADVERSE_REACTION"),
    HEALTH_CONDITION("HEALTH_CONDITION"),
    HEALTH_DEVICE("HEALTH_DEVICE"),
    CARE_GIVER("CARE_GIVER"),
    CARE_TEAM("CARE_TEAM"),
    HEALTH_MEDICATION("HEALTH_MEDICATION"),
    HEALTH_OBSERVATIONS("HEALTH_OBSERVATIONS"),
    IMMUNIZATIONS("IMMUNIZATIONS"),
    PROCEDURE_HISTORY("PROCEDURE_HISTORY"),
    SERVICE_FACILITY_PROVIDER("SERVICE_FACILITY_PROVIDER"),
    VISIT_HISTORY("VISIT_HISTORY");


    private String value;

    private Map<String, DataClassEnums> dataClassEnumsMap;

    DataClassEnums(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public Map<String, DataClassEnums> getMap() {
        dataClassEnumsMap.put("adverseReaction", ADVERSE_REACTION);
        dataClassEnumsMap.put("healthCondition", HEALTH_CONDITION);
        dataClassEnumsMap.put("healthDevice", HEALTH_DEVICE);
        dataClassEnumsMap.put("careGiver", CARE_GIVER);
        dataClassEnumsMap.put("careTeam", CARE_TEAM);
        dataClassEnumsMap.put("healthMedications", HEALTH_MEDICATION);
        dataClassEnumsMap.put("healthObservations", HEALTH_OBSERVATIONS);
        dataClassEnumsMap.put("healthStatus", HEALTH_STATUS);
        dataClassEnumsMap.put("immunizations", IMMUNIZATIONS);
        dataClassEnumsMap.put("procedureHistory", PROCEDURE_HISTORY);
        dataClassEnumsMap.put("serviceFacilityProvider", SERVICE_FACILITY_PROVIDER);
        dataClassEnumsMap.put("visitHistory", VISIT_HISTORY);
        return dataClassEnumsMap;
    }
}
