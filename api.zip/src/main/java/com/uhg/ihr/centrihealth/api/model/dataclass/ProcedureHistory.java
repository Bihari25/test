package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@NoArgsConstructor
public class ProcedureHistory {
    private String recordKey;
    private DataClassEnums recordType;
    private String healthEventDate;
    private String healthEventOrderDate;
    private String healthEventCategoryText;
    private IhrTerm healthEvent;
    private List<IhrTerm> specimens;
    private String presenceStateTerm;
    private IhrTerm healthEventStatus;
    private String lastUpdateDate;
    private BigInteger objectId;
    private List<String> sensitivityClasses;
    private List<String> sourceClaimIds;
    private List<BigInteger> relatedConditions;
    private List<BigInteger> relatedObservations;
    private List<BigInteger> relatedCareTeam;
    private List<BigInteger> relatedServiceProviders;
    private List<String> dataSource;
    private String clinicallyRelevantDate;
    private List<String> referenceIds;
    private List<Note> note;
}
