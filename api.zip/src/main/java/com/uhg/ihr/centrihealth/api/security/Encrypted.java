package com.uhg.ihr.centrihealth.api.security;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Encrypted {
    private byte[] encryptedKey;
    private byte[] encryptedMessage;
    private byte[] iv;

}
