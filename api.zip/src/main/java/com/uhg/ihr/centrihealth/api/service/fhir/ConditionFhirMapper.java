package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthCondition;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Condition;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.StringType;

@Slf4j
@Value(staticConstructor = "of")
public class ConditionFhirMapper implements FhirMapper<HealthCondition, Condition> {

    private static final String IHR_CONDITION_CLINICAL_COURSE_URL = "https://new-wiki.optum.com/display/IHRI/IHR+API+Clinical+Course";
    private static final String IHR_CONDITION_STATUS = "IHR Condition Status";

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getConditions())) {
            map(fhirResource, dataClasses.getConditions());
        }
    }

    @Override
    public void map(FhirResource fhirResource, HealthCondition healthCondition) {
        Patient patient = fhirResource.getPatient();
        Bundle bundle = fhirResource.getBundle();

        Condition condition = new Condition();
        condition.setId(new IdType(createIdURI()));
        //record key
        if (null != healthCondition.getRecordKey()) {
            condition.addIdentifier().setValue(healthCondition.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }
        //object id
        if (null != healthCondition.getObjectId()) {
            condition.addIdentifier()
                    .setValue(healthCondition.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }
        //health condition
        if (null != healthCondition.getHealthCondition()) {
            condition.setCode(new CodeableConcept()
                    .setText(healthCondition.getHealthCondition().getIhrTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthCondition.getHealthCondition().getIhrLaymanTerm())
                            .setSystem(healthCondition.getHealthCondition().getSourceVocabulary())
                            .setCode(healthCondition.getHealthCondition().getSourceVocabularyCode())));
            if (StringUtils.isNotBlank(healthCondition.getHealthCondition().getIcd10cmCode())) {
                condition.getCode()
                        .addCoding(new Coding()
                                .setSystem(Constants.ICD_10_CM_CODE_URL)
                                .setCode(healthCondition.getHealthCondition().getIcd10cmCode()));
            }
            //Condition Clinical Course
            if (StringUtils.isNotBlank(healthCondition.getHealthCondition().getClinicalCourse())) {
                condition.addExtension(IHR_CONDITION_CLINICAL_COURSE_URL, new StringType(healthCondition.getHealthCondition().getClinicalCourse()));
            }
        }
        //Last Update Date
        if (StringUtils.isNotBlank(healthCondition.getLastUpdateDate())) {
            condition.setMeta(new Meta().setLastUpdatedElement(toInstantTypeFromDate(healthCondition.getLastUpdateDate())));
        }
        //status
        if (null != healthCondition.getStatus()) {
            condition.addExtension(Constants.STATUS_URL, new CodeableConcept()
                    .setText(healthCondition.getStatus().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthCondition.getStatus().getIhrTerm())
                            .setSystem(healthCondition.getStatus().getSourceVocabulary())
                            .setCode(healthCondition.getStatus().getSourceVocabularyCode())));

        }
        //presence state term
        if (StringUtils.isNotBlank(healthCondition.getPresenceStateTerm())) {
            condition.addExtension(Constants.PRESENCE_STATE_TERM_URL, new StringType(healthCondition.getPresenceStateTerm()));
        }
        // note
        if (CollectionUtils.isNotEmpty(healthCondition.getNote())) {
            for (Note note : healthCondition.getNote()) {
                condition.addNote(getAnnotation(patient, note, fhirResource));
            }
        }
        //add subject
        condition.setSubject(new Reference(patient));

        //onset date
        if (StringUtils.isNotBlank(healthCondition.getOnsetDate())) {
            condition.setOnset(toDateTimeTypeFromDate(healthCondition.getConditionStartDate()));
        }
        //Clinically relevant date
        if (StringUtils.isNotBlank(healthCondition.getClinicallyRelevantDate())) {
            condition.addExtension(Constants.CLINICALLY_RELEVANT_DATE_URL, toDateTimeTypeFromDate(healthCondition.getClinicallyRelevantDate()));

        }
        //condition start date
        if (StringUtils.isNotBlank(healthCondition.getConditionStartDate())) {
            condition.setRecordedDateElement(toDateTimeTypeFromDate(healthCondition.getConditionStartDate()));
        }
        //sensitivity class
        if (CollectionUtils.isNotEmpty(healthCondition.getSensitivityClasses())) {
            condition.addExtension(Constants.SENSITIVITY_CLASSES_URL,
                    new StringType(AppUtils.jsonEscape(healthCondition.getSensitivityClasses())));
        }
        //related conditions
        if (CollectionUtils.isNotEmpty(healthCondition.getRelatedConditions())) {
            condition.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthCondition.getRelatedConditions()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CONDITION_INSTANCE_IDS));
        }
        //related observations
        if (CollectionUtils.isNotEmpty(healthCondition.getRelatedObservations())) {
            condition.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthCondition.getRelatedObservations()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_OBSERVATION_INSTANCE_IDS));
        }
        //related care team
        if (CollectionUtils.isNotEmpty(healthCondition.getRelatedCareTeam())) {
            condition.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthCondition.getRelatedCareTeam()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CARE_TEAM_INSTANCE_IDS));
        }
        //source claim ids
        if (CollectionUtils.isNotEmpty(healthCondition.getSourceClaimIds())) {
            condition.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthCondition.getSourceClaimIds()))
                    .setType(new CodeableConcept().setText(Constants.SOURCE_CLAIM_IDS));
        }
        //data sources
        if (CollectionUtils.isNotEmpty(healthCondition.getDataSource())) {
            condition.addExtension(Constants.DATA_SOURCE_URL, new StringType(AppUtils.jsonEscape(healthCondition.getDataSource())));
        }
        //referenceId
        if (CollectionUtils.isNotEmpty(healthCondition.getReferenceIds())) {
            condition.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthCondition.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));

        }
        // add resource into bundle
        bundle.addEntry().setFullUrl(condition.getId()).setResource(condition);
    }
}
