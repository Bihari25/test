package com.uhg.ihr.centrihealth.api.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import io.micronaut.context.annotation.Requires;
import io.micronaut.core.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;

import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;

@Slf4j
@Requires(property = "micronaut.security.stargate.enabled", notEquals = StringUtils.FALSE)
public class StargateJwtValidator {

    /**
     * Used to validate a Stargate JWT. JWT tokens are base64 encoded string, https://jwt.io to learn more
     *
     * @param token               {String}      the raw JWT token found in HTTP Header "JWT"
     * @param requestBody         {InputStream} an inputstream of the request payload found in the HTTP body
     * @param trustManagerFactory {KeyStore}    a loaded instance of your truststore (KeyStore ks; ks.load(keyStoreInputStream, pwdCharArray);)
     * @throws StargateJwtException this exception is thrown if the token is not valid
     * @throws CertificateException this exception is thrown if the certificate is not valid
     */
    public static void validate(String token, InputStream requestBody, TrustManagerFactory trustManagerFactory, int leeway)
            throws StargateJwtException, CertificateException {
        // Decode the unauthenticated JWT to retrieve the x509 cert
        X509Certificate cert = extractCertFromJWT(token);

        // Validate x509 cert against our truststore
        validateTrustedCertificate(trustManagerFactory, cert);

        PublicKey publicKey = cert.getPublicKey(); // Instantiates public key for token validation

        try {
            // Validate signature and expiry on JWT
            DecodedJWT jwt = JWT.require(Algorithm.RSA256((RSAPublicKey) publicKey, null)).acceptLeeway(leeway).build().verify(token); // Verify JWT with public key
            // Compared HTTP Request body hash with Payload hash claim
            //String payLoadHash = jwt.getClaim("payloadhash").asString();
            //validatePayloadHash(requestBody, payLoadHash);
        } catch (JWTVerificationException exception) {
            log.error("Could not validate the token", exception);
            throw new StargateJwtException(exception.getMessage());
        }
    }

    private static X509Certificate extractCertFromJWT(String token) throws CertificateException {
        String encodedCert;
        try {
            DecodedJWT unauthenticatedJWT = JWT.decode(token);
            Claim x5cClaim = unauthenticatedJWT.getHeaderClaim("x5c");
            String[] claimArray = x5cClaim.asArray(String.class);
            encodedCert = claimArray[0];
        } catch (Exception e) {
            log.debug("unable to decode JWT and x5c claim {}", e.getMessage());
            throw new StargateJwtException("unable to decode JWT and x5c claim");
        }
        InputStream in = new ByteArrayInputStream(Base64.decodeBase64(encodedCert.getBytes(StandardCharsets.UTF_8)));
        return (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(in);
    }

    private static void validateTrustedCertificate(TrustManagerFactory trustManagerFactory, X509Certificate cert) throws StargateJwtException {
        for (TrustManager trustManager : trustManagerFactory.getTrustManagers()) {
            if (trustManager instanceof X509TrustManager) {
                X509TrustManager x509TrustManager = (X509TrustManager) trustManager;
                // If the certificate is trusted by the trust manager, do nothing - else throw exception
                try {
                    x509TrustManager.checkServerTrusted(new X509Certificate[]{cert}, "RSA");
                } catch (CertificateException e) {
                    log.info("Unable to validate certificate included in JWT {}", e.getMessage());
                    throw new StargateJwtException(e.getMessage() + "\nUnable to validate certificate included in JWT header");
                }
            }
        }
    }
}
