package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm;
import com.uhg.ihr.centrihealth.api.model.dataclass.VisitHistory;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Condition;
import org.hl7.fhir.r4.model.Encounter;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Period;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.StringType;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Value(staticConstructor = "of")
public class EncounterFhirMapper implements FhirMapper<VisitHistory, Encounter> {
    private static final String DISCHARGE_DIAGNOSIS_URL = "Discharge Diagnosis";
    private static final String ADMITTING_DIAGNOSIS_CODE = "AD";
    private static final String ADMITTING_DIAGNOSIS = "Admitting Diagnosis";
    private static final String DISCHARGE_DIAGNOSIS_CODE = "DD";
    private static final String DISCHARGE_DIAGNOSIS = "Discharge Diagnosis";
    private static final String DIAGNOSIS_URL = "http://hl7.org/implement/standards/fhir/valueset-diagnosis-role.html";

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getVisitHistory())) {
            map(fhirResource, dataClasses.getVisitHistory());
        }
    }

    @Override
    public void map(FhirResource fhirResource, VisitHistory visitHistory) {
        Bundle bundle = fhirResource.getBundle();

        Encounter encounter = new Encounter();
        encounter.setId(new IdType(createIdURI()));
        //record key
        if (null != visitHistory.getRecordKey()) {
            encounter.addIdentifier().setValue(visitHistory.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }
        //object id
        if (null != visitHistory.getObjectId()) {
            encounter.addIdentifier().setValue(visitHistory.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(visitHistory.getReferenceIds())) {
            encounter.addIdentifier().setValue(AppUtils.jsonEscape(visitHistory.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));

        }
        //admit date discharge date
        Period period = new Period();
        if (StringUtils.isNotBlank(visitHistory.getAdmitDate())) {
            period.setStartElement(toDateTimeTypeFromDate(visitHistory.getAdmitDate()));
        }
        if (StringUtils.isNotBlank(visitHistory.getDischargeDate())) {
            period.setEndElement(toDateTimeTypeFromDate(visitHistory.getDischargeDate()));
        }
        encounter.setPeriod(period);
        //visit concept
        if (null != visitHistory.getVisit()) {
            CodeableConcept concept = new CodeableConcept();
            List<CodeableConcept> conceptList = new ArrayList<>();
            concept.setText(visitHistory.getVisit().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(visitHistory.getVisit().getIhrTerm())
                            .setSystem(visitHistory.getVisit().getSourceVocabulary())
                            .setCode(visitHistory.getVisit().getSourceVocabularyCode()));
            if (StringUtils.isNotBlank(visitHistory.getVisit().getCpthcpcsCode())) {
                concept.addCoding(new Coding()
                        .setCode(visitHistory.getVisit().getCpthcpcsCode())
                        .setSystem(Constants.CPTHCPCS_CODE_URL));
            }
            conceptList.add(concept);
            encounter.setType(conceptList);
        }
        //discharge disposition
        if (null != visitHistory.getDischargeDisposition()) {
            encounter.setHospitalization(new Encounter.EncounterHospitalizationComponent()
                    .setDischargeDisposition(new CodeableConcept().setText(visitHistory.getDischargeDisposition().getIhrLaymanTerm())
                            .addCoding(new Coding()
                                    .setDisplay(visitHistory.getDischargeDisposition().getIhrTerm())
                                    .setSystem(visitHistory.getDischargeDisposition().getSourceVocabulary())
                                    .setCode(visitHistory.getDischargeDisposition().getSourceVocabularyCode()))));
        }
        //admitting diagnosis
        if (null != visitHistory.getAdmittingDiagnosis() && !visitHistory.getAdmittingDiagnosis().isEmpty()) {
            for (IhrTerm term : visitHistory.getAdmittingDiagnosis()) {
                CodeableConcept codeableConcept = new CodeableConcept()
                        .setText(term.getIhrLaymanTerm())
                        .addCoding(new Coding()
                                .setDisplay(term.getIhrTerm())
                                .setCode(term.getSourceVocabularyCode())
                                .setSystem(term.getSourceVocabulary()));

                Condition condition = getOrCreateCondition(fhirResource, codeableConcept);
                encounter.addDiagnosis()
                        .setUse(new CodeableConcept().addCoding(new Coding()
                                .setSystem(DIAGNOSIS_URL)
                                .setCode(ADMITTING_DIAGNOSIS_CODE)
                                .setDisplay(ADMITTING_DIAGNOSIS)))
                        .setCondition(new Reference(condition));
            }
        }
        //discharge diagnosis
        if (null != visitHistory.getDischargeDiagnosis() && !visitHistory.getDischargeDiagnosis().isEmpty()) {
            for (IhrTerm term : visitHistory.getDischargeDiagnosis()) {
                CodeableConcept codeableConcept = new CodeableConcept()
                        .setText(term.getIhrLaymanTerm())
                        .addCoding(new Coding()
                                .setDisplay(term.getIhrTerm())
                                .setCode(term.getSourceVocabularyCode())
                                .setSystem(term.getSourceVocabulary()));

                Condition condition = getOrCreateCondition(fhirResource, codeableConcept);
                encounter.addDiagnosis()
                        .setUse(new CodeableConcept().addCoding(new Coding()
                                .setSystem(DIAGNOSIS_URL)
                                .setCode(DISCHARGE_DIAGNOSIS_CODE)
                                .setDisplay(DISCHARGE_DIAGNOSIS)))
                        .setCondition(new Reference(condition));
            }
        }
        //admit source
        if (StringUtils.isNotBlank(visitHistory.getAdmitSource())) {
            encounter.getHospitalization().setAdmitSource(new CodeableConcept().addCoding(new Coding().setDisplay(visitHistory.getAdmitSource())));
        }
        //presence state term
        if (StringUtils.isNotBlank(visitHistory.getPresenceStateTerm())) {
            encounter.addExtension(Constants.PRESENCE_STATE_TERM_URL, new StringType(visitHistory.getPresenceStateTerm()));
        }
        //last update date
        if (StringUtils.isNotBlank(visitHistory.getLastUpdateDate())) {
            encounter.setMeta(new Meta().setLastUpdatedElement(toInstantTypeFromDate(visitHistory.getLastUpdateDate())));
        }
        //sensitivity classes
        if (CollectionUtils.isNotEmpty(visitHistory.getSensitivityClasses())) {
            encounter.addExtension(Constants.SENSITIVITY_CLASSES_URL,
                    new StringType(AppUtils.jsonEscape(visitHistory.getSensitivityClasses())));
        }
        //related conditions
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedConditions())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedConditions()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CONDITION_INSTANCE_IDS));
        }
        //relation medications
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedMedications())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedMedications()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_MEDICATION_INSTANCE_IDS));
        }
        //related procedures
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedProcedures())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedProcedures()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_PROCEDURE_INSTANCE_IDS));
        }
        //related devices
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedDevices())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedDevices()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_DEVICE_INSTANCE_IDS));
        }
        //related immunizations
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedImmunizations())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedImmunizations()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_IMMUNIZATION_INSTANCE_IDS));
        }
        //related observation
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedObservations())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedObservations()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_OBSERVATION_INSTANCE_IDS));
        }
        //related care team
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedCareTeam())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedCareTeam()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CARE_TEAM_INSTANCE_IDS));
        }
        //related service providers
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedServiceProviders())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedServiceProviders()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS));
        }
        //data source
        if (CollectionUtils.isNotEmpty(visitHistory.getDataSource())) {
            encounter.addExtension(Constants.DATA_SOURCE_URL, new StringType(AppUtils.jsonEscape(visitHistory.getDataSource())));
        }
        //clinically relevant date
        if (StringUtils.isNotBlank(visitHistory.getClinicallyRelevantDate())) {
            encounter.addExtension(Constants.CLINICALLY_RELEVANT_DATE_URL, this.toDateTimeTypeFromDate(visitHistory.getClinicallyRelevantDate()));
        }
        //visit type
        if (StringUtils.isNotBlank(visitHistory.getVisitType())) {
            encounter.setClass_(new Coding().setDisplay(visitHistory.getVisitType()));
        }
        //place of service
        if (null != visitHistory.getPlaceOfService() && !visitHistory.getPlaceOfService().isEmpty()) {
            encounter.addLocation().setLocation(new Reference().setDisplay(visitHistory.getPlaceOfService()));
        }
        //source claim ids
        if (CollectionUtils.isNotEmpty(visitHistory.getSourceClaimIds())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getSourceClaimIds()))
                    .setType(new CodeableConcept().setText(Constants.SOURCE_CLAIM_IDS));
        }

        // add resource into bundle
        bundle.addEntry().setFullUrl(encounter.getId()).setResource(encounter);
    }
}
