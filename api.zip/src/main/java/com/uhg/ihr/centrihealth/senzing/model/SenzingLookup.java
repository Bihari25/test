package com.uhg.ihr.centrihealth.senzing.model;

/**
 * SenzingLookup  class used to hold look up keys to read senzing response
 *
 * @author ihr api team.
 * copyright (C) All rights reserved UHG
 */
public class SenzingLookup {
    public static final int INDICATOR_LEVEL_1 = 1;
    public static final int INDICATOR_LEVEL_2 = 2;
    public static final String LOG_RESULTS = "logResults";
    public static final String FILTERED_IHR_IDS = "filteredIhrIds";
    public static final String FILTERED_IHR_LOBS = "filteredIhrLobs";
    public static final String RECORDS = "records";
    public static final String ORIG_SOURCE_DATA = "originalSourceData";
    public static final String ORIG_SOURCE_DATA_CHID = "Global_Actor_ID";
    public static final String ORIG_SOURCE_DATA_LOB = "LOB";

    public static final String DATA = "data";
    public static final String RESULTS = "searchResults";
    public static final String MATCH_LEVEL = "matchLevel";
    public static final String MATCH_KEY = "matchKey";
    public static final String IDENTIFIER_DATA = "identifierData";
    public static final String RECORD_SUMMARIES = "recordSummaries";
    public static final String RECORD_COUNT = "recordCount";

}