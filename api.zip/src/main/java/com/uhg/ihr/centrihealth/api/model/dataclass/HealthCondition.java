package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@NoArgsConstructor
public class HealthCondition {
    private DataClassEnums recordType;
    private String recordKey;
    private String lastUpdateDate;
    private IhrTerm healthCondition;
    private IhrTerm status;
    private String onsetDate;
    private String conditionStartDate;
    private String presenceStateTerm;
    private String clinicallyRelevantDate;
    private List<String> sensitivityClasses;
    private BigInteger objectId;
    private List<BigInteger> relatedConditions;
    private List<Integer> relatedObservations;
    private List<BigInteger> relatedCareTeam;
    private List<String> sourceClaimIds;
    private List<String> dataSource;
    private List<String> referenceIds;
    private List<Note> note;
}
