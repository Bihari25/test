package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthStatus;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Goal;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Observation;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.StringType;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Value(staticConstructor = "of")
public class GoalFhirMapper implements FhirMapper<HealthStatus, Goal> {

    private static final String EXPECTED_ACHIEVEMENT_URL = "https://new-wiki.optum.com/display/IHRI/IHR+API+Goal+Expected+Achievement";
    private static final String TARGET_TYPE_URL = "https://new-wiki.optum.com/display/IHRI/IHR+API+Target+Type";

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getHealthStatuses())) {
            map(fhirResource, dataClasses.getHealthStatuses());
        }
    }

    @Override
    public void map(FhirResource fhirResource, HealthStatus healthStatus) {
        Bundle bundle = fhirResource.getBundle();

        Goal goal = new Goal();
        goal.setId(new IdType(createIdURI()));

        //record key
        if (null != healthStatus.getRecordKey()) {
            goal.addIdentifier().setValue(healthStatus.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }
        //object id
        if (null != healthStatus.getObjectId()) {
            goal.addIdentifier().setValue(healthStatus.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(healthStatus.getReferenceIds())) {
            goal.addIdentifier().setValue(AppUtils.jsonEscape(healthStatus.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));
        }
        //concept
        if (null != healthStatus.getConcept()) {
            goal.setDescription(new CodeableConcept()
                    .setText(healthStatus.getConcept().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthStatus.getConcept().getIhrTerm())));
        }
        //classification
        if (null != healthStatus.getClassification()) {
            CodeableConcept category = new CodeableConcept();
            category.setText(healthStatus.getClassification().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthStatus.getClassification().getIhrTerm()));
            goal.addCategory(category);
        }
        //start date
        if (StringUtils.isNotBlank(healthStatus.getStartDate())) {
            goal.setStart(toDateTypeFromDate(healthStatus.getStartDate()));
        }
        // clinically relevant date
        if (StringUtils.isNotBlank(healthStatus.getClinicallyRelevantDate())) {
            goal.addExtension(Constants.CLINICALLY_RELEVANT_DATE_URL, toDateTimeTypeFromDate(healthStatus.getClinicallyRelevantDate()));
        }
        //expected achievement
        if (StringUtils.isNotBlank(healthStatus.getExpectedAchievement())) {
            goal.addExtension(EXPECTED_ACHIEVEMENT_URL, new StringType(healthStatus.getExpectedAchievement()));
        }
        //due date
        if (StringUtils.isNotBlank(healthStatus.getDueDate())) {
            goal.addTarget().setDue(toDateTypeFromDate(healthStatus.getDueDate()));
        }
        //last update date
        if (StringUtils.isNotBlank(healthStatus.getLastUpdateDate())) {
            goal.setMeta(new Meta().setLastUpdatedElement(toInstantTypeFromDate(healthStatus.getLastUpdateDate())));
        }
        //presence state
        if (null != healthStatus.getPresenceState()) {
            goal.addExtension(Constants.PRESENCE_STATE_TERM_URL, new CodeableConcept()
                    .setText(healthStatus.getPresenceState().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthStatus.getPresenceState().getIhrTerm())));
        }
        //evaluation
        if (null != healthStatus.getEvaluation()) {
            Observation observation = getOrCreateObservation(fhirResource, healthStatus.getEvaluation());
            List<Reference> referenceRequest = new ArrayList<>();
            referenceRequest.add(new Reference(observation));
            goal.setOutcomeReference(referenceRequest);

            //target
            if (StringUtils.isNotBlank(healthStatus.getEvaluation().getTarget())) {
                goal.addTarget().setDetail(new StringType(healthStatus.getEvaluation().getTarget()));
            }
            //target type
            if (null != healthStatus.getEvaluation().getTargetType()) {
                goal.addExtension(TARGET_TYPE_URL, new CodeableConcept()
                        .setText(healthStatus.getEvaluation().getTargetType().getIhrLaymanTerm())
                        .addCoding(new Coding()
                                .setDisplay(healthStatus.getEvaluation().getTargetType().getIhrTerm())));
            }
            //status
            if (null != healthStatus.getEvaluation().getStatus()) {
                goal.setAchievementStatus(new CodeableConcept()
                        .setText(healthStatus.getEvaluation().getStatus().getIhrLaymanTerm())
                        .addCoding(new Coding()
                                .setDisplay(healthStatus.getEvaluation().getStatus().getIhrTerm())));
            }
            //comment
            if (StringUtils.isNotBlank(healthStatus.getEvaluation().getComment())) {
                goal.addNote().setText(healthStatus.getEvaluation().getComment());
            }
        }
        //sensitivity classes
        if (CollectionUtils.isNotEmpty(healthStatus.getSensitivityClasses())) {
            goal.addExtension(Constants.SENSITIVITY_CLASSES_URL, new StringType(AppUtils.jsonEscape(healthStatus.getSensitivityClasses())));
        }
        //related conditions
        if (CollectionUtils.isNotEmpty(healthStatus.getRelatedConditions())) {
            goal.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthStatus.getRelatedConditions()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CONDITION_INSTANCE_IDS));
        }
        //data source
        if (CollectionUtils.isNotEmpty(healthStatus.getDataSource())) {
            goal.addExtension(Constants.DATA_SOURCE_URL, new StringType(AppUtils.jsonEscape(healthStatus.getDataSource())));
        }
        // add resource into bundle
        bundle.addEntry().setFullUrl(goal.getId()).setResource(goal);
    }
}

