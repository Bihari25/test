package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.Evaluation;
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.model.dataclass.Supplier;
import io.micronaut.core.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Condition;
import org.hl7.fhir.r4.model.DateTimeType;
import org.hl7.fhir.r4.model.DateType;
import org.hl7.fhir.r4.model.Extension;
import org.hl7.fhir.r4.model.HumanName;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.InstantType;
import org.hl7.fhir.r4.model.Location;
import org.hl7.fhir.r4.model.Narrative;
import org.hl7.fhir.r4.model.Observation;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.Resource;
import org.hl7.fhir.r4.model.Specimen;
import org.hl7.fhir.r4.model.StringType;
import org.hl7.fhir.r4.model.Type;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Pattern;

public interface FhirMapper<T, U extends Resource> {
    @Slf4j
    final class Log { }

    DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy/MM/dd", Locale.US);
    DateTimeFormatter FORMATTER_HYPHEN = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US);

    int DATE_TIME_LENGTH = 10;
    String DATE_REGEX_SLASH = "((?:19|20)\\d\\d)/(0?[1-9]|1[012])/([12][0-9]|3[01]|0?[1-9])";
    String DATE_REGEX_HYPHEN = "^20[0-2][0-9]-((0[1-9])|(1[0-2]))-(0[1-9]|[1-2][0-9]|3[0-1])$";
    Pattern DATE_PATTERN_SLASH = Pattern.compile(DATE_REGEX_SLASH);
    Pattern DATE_PATTERN_HYPHEN = Pattern.compile(DATE_REGEX_HYPHEN);

    void map(FhirResource fhirResource, DataClass dataClass);

    void map(FhirResource fhirResource, T dataClass);

    default void map(FhirResource fhirResource, List<T> dataClasses) {
        if (CollectionUtils.isNotEmpty(dataClasses)) {
            dataClasses.forEach(dataClass -> map(fhirResource, dataClass));

        }
    }

    default Narrative createNarrative(String value) {
        Narrative narrative = new Narrative();
        narrative.setId(value);
        return narrative;
    }

    static Date toDate(String date) {
        try {
            if (isDateTime(date)) {
                return Date.from(ZonedDateTime.parse(date).toInstant());
            } else if (isDatePatternSlash(date)) {
                LocalDate ld = LocalDate.parse(date, FORMATTER);
                return Date.from(ld.atStartOfDay(ZoneOffset.UTC).toInstant());
            } else if (isDatePatternHyphen(date)) {
                LocalDate ld = LocalDate.parse(date, FORMATTER_HYPHEN);
                return Date.from(ld.atStartOfDay(ZoneOffset.UTC).toInstant());
            } else {
                Log.log.error("Invalid date or datetime pattern: {}", date);
                return null;
            }
        } catch (DateTimeParseException de) {
            Log.log.error("Could not parse date {}", de.getMessage());
            return null;
        }
    }

    default DateType toDateTypeFromDate(String date) {
        return new DateType(toDate(date));
    }

    default DateTimeType toDateTimeTypeFromDate(String date) {
        Date dateValue = toDate(date);
        return new DateTimeType(dateValue == null ? "" : dateValue.toInstant().toString());
    }

    default InstantType toInstantTypeFromDate(String date) {
        Date dateValue = toDate(date);
        return new InstantType(dateValue == null ? "" : dateValue.toInstant().toString());
    }

    default boolean isExtensionExists(List<Extension> extensions, String url, String valueString) {
        return extensions.stream().anyMatch((ext -> url.equalsIgnoreCase(ext.getUrl())
                && valueString.equalsIgnoreCase(ext.getValue().toString())));
    }

    static boolean isDatePatternSlash(String date) {
        return date != null && DATE_PATTERN_SLASH.matcher(date).matches();
    }

    static boolean isDatePatternHyphen(String date) {
        return date != null && DATE_PATTERN_HYPHEN.matcher(date).matches();
    }

    static boolean isDateTime(String dateTime) {
        return dateTime != null && dateTime.length() > DATE_TIME_LENGTH;
    }

    default Annotation getAnnotation(Patient patient, final Note note, FhirResource fhirResource) {
        Annotation annotation = new Annotation();
        annotation.setTimeElement(this.toDateTimeTypeFromDate(note.getTime()))
                .setText(note.getText())
                .addExtension(Constants.NOTE_TYPE_URL, new StringType(note.getNoteType()));
        if (StringUtils.isNotEmpty(note.getAuthor())) {
            Identifier identifier = new Identifier()
                    .setValue(note.getAuthor())
                    .setType(new CodeableConcept().setText(Constants.DATA_AUTHOR_IDENTIFIER));
            if (Constants.CLINICAL_NOTE.equals(note.getNoteType())) {
                Practitioner notePractitioner = getOrCreatePractitioner(fhirResource, identifier);
                annotation.setAuthor(new Reference(notePractitioner));
            } else {
                if (!isIdentifierExists(patient.getIdentifier(), identifier)) {
                    patient.addIdentifier(identifier);
                }
                annotation.setAuthor(new Reference(patient));
            }
        }
        return annotation;
    }

    default boolean isIdentifierExists(final List<Identifier> identifierList, final Identifier identifier) {
        return identifierList.stream().anyMatch(idr ->
                omitNull(idr.getType().getText()).equals(identifier.getType().getText())
                        && omitNull(idr.getValue()).equalsIgnoreCase(identifier.getValue()));
    }

    default String createIdURI() {
        return "urn:uuid:" + UUID.randomUUID().toString();
    }

    private Practitioner createPractitioner(FhirResource fhirResource, final String practitionerKey) {
        Practitioner practitioner = new Practitioner();
        practitioner.setId(createIdURI());
        fhirResource.getPractitioner().put(practitionerKey, practitioner);
        fhirResource.getBundle().addEntry().setFullUrl(practitioner.getId()).setResource(practitioner);
        return practitioner;
    }

    default Practitioner getOrCreatePractitioner(final FhirResource fhirResource, final Identifier identifier) {
        String practitionerKey = getPractitionerKey(identifier);
        Practitioner practitioner = fhirResource.getPractitioner().get(practitionerKey);
        if (practitioner == null) {
            practitioner = createPractitioner(fhirResource, practitionerKey);
            practitioner.addIdentifier(identifier);
        }
        return practitioner;
    }

    default Practitioner getOrCreatePractitioner(final FhirResource fhirResource, final HumanName humanName) {
        String practitionerKey = getHumanNameKey(humanName);
        Practitioner practitioner = fhirResource.getPractitioner().get(practitionerKey);
        if (practitioner == null) {
            practitioner = createPractitioner(fhirResource, practitionerKey);
            practitioner.addName(humanName);
        }
        return practitioner;
    }

    private PractitionerRole createPractitionerRole(FhirResource fhirResource, final String practitionerRoleKey) {
        PractitionerRole practitionerRole = new PractitionerRole();
        practitionerRole.setId(createIdURI());
        fhirResource.getPractitionerRole().put(practitionerRoleKey, practitionerRole);
        fhirResource.getBundle().addEntry().setFullUrl(practitionerRole.getId()).setResource(practitionerRole);
        return practitionerRole;
    }

    default PractitionerRole getOrCreatePractitionerRole(final FhirResource fhirResource, final Identifier identifier) {
        String practitionerRoleKey = getPractitionerRoleKey(identifier);
        PractitionerRole practitionerRole = fhirResource.getPractitionerRole().get(practitionerRoleKey);
        if (practitionerRole == null) {
            practitionerRole = createPractitionerRole(fhirResource, practitionerRoleKey);
            practitionerRole.addIdentifier(identifier);
        }
        return practitionerRole;
    }

    default PractitionerRole getOrCreatePractitionerRole(final FhirResource fhirResource, final CodeableConcept practitionerCode) {
        String practitionerRoleKey = omitNull(practitionerCode.getText());
        PractitionerRole practitionerRole = fhirResource.getPractitionerRole().get(practitionerRoleKey);
        if (practitionerRole == null) {
            practitionerRole = createPractitionerRole(fhirResource, practitionerRoleKey);
            practitionerRole.addCode(practitionerCode);
        }
        return practitionerRole;
    }

    private RelatedPerson createRelatedPerson(FhirResource fhirResource, final String relatedPersonKey) {
        RelatedPerson relatedPerson = new RelatedPerson();
        relatedPerson.setId(createIdURI());
        fhirResource.getRelatedPerson().put(relatedPersonKey, relatedPerson);
        fhirResource.getBundle().addEntry().setFullUrl(relatedPerson.getId()).setResource(relatedPerson);
        return relatedPerson;
    }

    default RelatedPerson getOrCreateRelatedPerson(final FhirResource fhirResource, final HumanName humanName) {
        String relatedPersonKey = getHumanNameKey(humanName);
        RelatedPerson relatedPerson = fhirResource.getRelatedPerson().get(relatedPersonKey);
        if (relatedPerson == null) {
            relatedPerson = createRelatedPerson(fhirResource, relatedPersonKey);
            relatedPerson.addName(humanName);
        }
        return relatedPerson;
    }

    default RelatedPerson getOrCreateRelatedPerson(final FhirResource fhirResource, final CodeableConcept relationShip) {
        String relatedPersonKey = omitNull(relationShip.getText());
        RelatedPerson relatedPerson = fhirResource.getRelatedPerson().get(relatedPersonKey);
        if (relatedPerson == null) {
            relatedPerson = createRelatedPerson(fhirResource, relatedPersonKey);
            relatedPerson.addRelationship(relationShip);
        }
        return relatedPerson;
    }

    private Organization createOrganization(FhirResource fhirResource, final String organizationKey) {
        Organization organization = new Organization();
        organization.setId(createIdURI());
        fhirResource.getOrganization().put(organizationKey, organization);
        fhirResource.getBundle().addEntry().setFullUrl(organization.getId()).setResource(organization);
        return organization;
    }

    default Organization getOrCreateOrganization(final FhirResource fhirResource, final Identifier identifier) {
        String organizationKey = getOrganizationKey(identifier);
        Organization organization = fhirResource.getOrganization().get(organizationKey);
        if (organization == null) {
            organization = createOrganization(fhirResource, organizationKey);
            organization.addIdentifier(identifier);
        }
        return organization;
    }

    private Condition createCondition(FhirResource fhirResource, final String conditionKey) {
        Condition condition = new Condition();
        condition.setId(createIdURI());
        fhirResource.getCondition().put(conditionKey, condition);
        fhirResource.getBundle().addEntry().setFullUrl(condition.getId()).setResource(condition);
        return condition;
    }

    default Condition getOrCreateCondition(final FhirResource fhirResource, final CodeableConcept codeableConcept) {
        String conditionKey = getConditionKey(codeableConcept);
        Condition condition = fhirResource.getCondition().get(conditionKey);
        if (condition == null) {
            condition = createCondition(fhirResource, conditionKey);
            condition.setCode(codeableConcept);
        }
        return condition;
    }

    private Observation createObservation(FhirResource fhirResource, final String observationKey) {
        Observation observation = new Observation();
        observation.setId(createIdURI());
        fhirResource.getObservation().put(observationKey, observation);
        fhirResource.getBundle().addEntry().setFullUrl(observation.getId()).setResource(observation);
        return observation;
    }

    default Observation getOrCreateObservation(final FhirResource fhirResource, final Evaluation evaluation) {
        DateTimeType dateTimeType = toDateTimeTypeFromDate(evaluation.getDate());
        StringType targetResult = new StringType(evaluation.getTargetResult());
        String observationKey = getObservationKey(dateTimeType, targetResult);
        Observation observation = fhirResource.getObservation().get(observationKey);
        if (observation == null) {
            observation = createObservation(fhirResource, observationKey);
            observation.setEffective(dateTimeType);
            observation.setValue(targetResult);
        }
        return observation;
    }

    private Location createLocation(FhirResource fhirResource, final Supplier supplier, final String locationKey) {
        Location location = new Location()
                .setName(supplier.getName())
                .addIdentifier(new Identifier()
                        .setValue(supplier.getNpinum())
                        .setType(new CodeableConcept()
                                .addCoding(new Coding().setCode(Constants.NPI)
                                        .setDisplay(Constants.NPI_DISPLAY)
                                        .setSystem(Constants.NPI_URL))));
        location.setId(createIdURI());
        fhirResource.getLocation().put(locationKey, location);
        fhirResource.getBundle().addEntry().setFullUrl(location.getId()).setResource(location);
        return location;
    }

    default Location getOrCreateLocation(final FhirResource fhirResource, final Supplier supplier) {
        String locationKey = getLocationKey(supplier);
        Location location = fhirResource.getLocation().get(locationKey);
        if (location == null) {
            location = createLocation(fhirResource, supplier, locationKey);
        }
        return location;
    }

    private Specimen createSpecimen(FhirResource fhirResource, final IhrTerm ihrTerm, final String specimensKey) {
        Specimen specimen = new Specimen();
        specimen.setId(createIdURI());
        CodeableConcept codeableConcept = new CodeableConcept()
                .setText(ihrTerm.getIhrLaymanTerm())
                .addCoding(new Coding()
                        .setCode(ihrTerm.getSourceVocabularyCode())
                        .setDisplay(ihrTerm.getIhrTerm())
                        .setSystem(ihrTerm.getSourceVocabulary()));
        specimen.setType(codeableConcept);
        fhirResource.getSpecimen().put(specimensKey, specimen);
        fhirResource.getBundle().addEntry().setFullUrl(specimen.getId()).setResource(specimen);
        return specimen;
    }

    default Specimen getOrCreateSpecimen(final FhirResource fhirResource, final IhrTerm ihrTerm) {
        String specimensKey = getSpecimensKey(ihrTerm);
        Specimen specimen = fhirResource.getSpecimen().get(specimensKey);
        if (specimen == null) {
            specimen = createSpecimen(fhirResource, ihrTerm, specimensKey);
        }
        return specimen;
    }

    private String getHumanNameKey(final HumanName humanName) {
        return omitNull(humanName.getFamily()) + omitNull(humanName.getGivenAsSingleString())
                + omitNull(humanName.getText()) + omitNull(humanName.getPrefixAsSingleString());
    }

    private String getPractitionerKey(final Identifier identifier) {
        return omitNull(identifier.getType().getText()) + omitNull(identifier.getValue());
    }

    private String getPractitionerRoleKey(final Identifier identifier) {
        return omitNull(identifier.getValue()) + omitNull(identifier.getType().getCoding().get(0).getCode());
    }

    private String getOrganizationKey(final Identifier identifier) {
        return omitNull(identifier.getValue()) + omitNull(identifier.getSystem());
    }

    private String getConditionKey(final CodeableConcept codeableConcept) {
        Coding coding = codeableConcept.getCoding().get(0);
        return omitNull(codeableConcept.getText()) + omitNull(coding.getCode()) + omitNull(coding.getDisplay())
                + omitNull(coding.getSystem());
    }

    private String getObservationKey(final DateTimeType dateTimeType, final StringType targetResult) {
        return omitNull(dateTimeType) + omitNull(targetResult);
    }

    private String getLocationKey(final Supplier supplier) {
        return omitNull(supplier.getNpinum()) + omitNull(supplier.getName());
    }

    private String getSpecimensKey(final IhrTerm ihrTerm) {
        return omitNull(ihrTerm.getIhrLaymanTerm()) + omitNull(ihrTerm.getSourceVocabulary())
                + omitNull(ihrTerm.getSourceVocabularyCode()) + omitNull(ihrTerm.getIhrTerm());
    }

    default String omitNull(final String value) {
        return value == null ? "" : value;
    }

    default String omitNull(final Type value) {
        return value == null ? "" : value.toString();
    }
}