package com.uhg.ihr.centrihealth.api.service;

import com.google.common.collect.ImmutableSet;
import com.uhg.ihr.centrihealth.api.model.Big5;
import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrResponse;
import com.uhg.ihr.centrihealth.api.service.fhir.AllergyIntoleranceFhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.CareGiverFhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.CareTeamFhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.ConditionFhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.DeviceFhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.EncounterFhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.FhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.GoalFhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.ImmunizationFhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.MedicationStatementFhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.ObservationFhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.PracitionerRoleFhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.ProcedureFhirMapper;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Bundle.BundleType;
import org.hl7.fhir.r4.model.HumanName;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Resource;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.UUID;

@Slf4j
public class IhrFhirMapper {

    private static final ImmutableSet<FhirMapper<?, ? extends Resource>> MAPPERS =
            ImmutableSet.<FhirMapper<?, ? extends Resource>>builder()
                    .add(CareTeamFhirMapper.of())
                    .add(CareGiverFhirMapper.of())
                    .add(ConditionFhirMapper.of())
                    .add(DeviceFhirMapper.of())
                    .add(EncounterFhirMapper.of())
                    .add(ObservationFhirMapper.of())
                    .add(GoalFhirMapper.of())
                    .add(ImmunizationFhirMapper.of())
                    .add(AllergyIntoleranceFhirMapper.of())
                    .add(MedicationStatementFhirMapper.of())
                    .add(PracitionerRoleFhirMapper.of())
                    .add(ProcedureFhirMapper.of())
                    .build();

    public static Patient buildPatientResource(Big5 big5) {
        Patient patient = new Patient();
        patient.setId("urn:uuid:" + UUID.nameUUIDFromBytes(big5.getSearchId().getBytes(StandardCharsets.UTF_8)).toString());
        patient.addName(new HumanName()
                .setFamily(big5.getLastName())
                .addGiven(big5.getFirstName()));
        patient.setBirthDate(FhirMapper.toDate(big5.getDateOfBirth()));
        return patient;
    }

    public Bundle getFhirMapping(IhrResponse responseObject) {

        Bundle bundle = new Bundle().setType(BundleType.SEARCHSET);
        if (responseObject.getDataClasses() == null) {
            return null;
        }

        try {
            Patient patient = buildPatientResource(responseObject.getMbrId().getBig5());
            FhirResource fhirResource = FhirResource.builder()
                    .bundle(bundle)
                    .patient(patient)
                    .practitioner(new HashMap<>())
                    .practitionerRole(new HashMap<>())
                    .relatedPerson(new HashMap<>())
                    .organization(new HashMap<>())
                    .condition(new HashMap<>())
                    .observation(new HashMap<>())
                    .location(new HashMap<>())
                    .specimen(new HashMap<>())
                    .build();
            //TODO: catch inside so that bundle can partially succeed (?)
            MAPPERS.forEach(m -> m.map(fhirResource, responseObject.getDataClasses()));
            bundle.addEntry().setFullUrl(fhirResource.getPatient().getId()).setResource(fhirResource.getPatient());
        } catch (Exception e) {
            log.error("error building bundle {}", e.getMessage());
        }
        return bundle;
    }
}
