package com.uhg.ihr.centrihealth.api.model;

import com.uhg.ihr.centrihealth.api.filter.DataFilter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Set;

/**
 * MongoDataRequest class used as a request object for mongodb service.
 *
 * @author ihr extract engineering team
 * Copyright (C) All rights reserved UHG
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MongoDataRequest {

    private String ihrId;
    private Set<RecordType> dataClasses;
    private List<DataFilter> dataFilters;
    private String language;
}
