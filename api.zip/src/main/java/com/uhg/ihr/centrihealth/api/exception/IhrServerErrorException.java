package com.uhg.ihr.centrihealth.api.exception;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class IhrServerErrorException extends RuntimeException {
    public IhrServerErrorException(String message) {
        super(message);
    }
}