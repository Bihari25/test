package com.uhg.ihr.centrihealth.api.logging;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.optum.eis.NessLogEvent;
import com.optum.eis.NessLogger;
import com.optum.eis.event.model.logClass;
import com.optum.eis.event.model.outcome;
import com.uhg.ihr.centrihealth.api.configuration.VersionConfiguration;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.exception.IhrGoneException;
import com.uhg.ihr.centrihealth.api.exception.IhrNotAcceptableException;
import com.uhg.ihr.centrihealth.api.exception.IhrNotFoundException;
import com.uhg.ihr.centrihealth.api.model.IhrApiRequest;
import com.uhg.ihr.centrihealth.api.model.MId;
import com.uhg.ihr.centrihealth.api.security.Encrypted;
import com.uhg.ihr.centrihealth.api.security.Encryptor;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micronaut.context.annotation.Context;
import io.micronaut.context.annotation.Property;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Filter;
import io.micronaut.http.filter.OncePerRequestHttpServerFilter;
import io.micronaut.http.filter.ServerFilterChain;
import io.micronaut.security.authentication.AuthenticationException;
import io.reactivex.Flowable;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.reactivestreams.Publisher;
import org.slf4j.MDC;

import javax.inject.Inject;
import javax.validation.ConstraintViolationException;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.time.Duration;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Slf4j
@Context
@Filter("/**")
public class LoggingFilter extends OncePerRequestHttpServerFilter {

    public static final String API_VERSION = "API_VERSION";
    public static final String DATA_VERSION = "DATA_VERSION";
    public static final String SCHEMA_VERSION = "SCHEMA_VERSION";
    public static final String LOG_MAP = "logMap";
    public static final String LOG_NESS = "logNess";
    private static final String TOTAL = "total";
    private static final String HTTP_STATUS = "httpStatus";
    private static final String REQUEST_ID_MDC_KEY = "requestId";
    private static final String UNKNOWN_ERROR = "Unknown Error";
    public static final String FAILURE = "failure";
    public static final String START = "_start";
    public static final String OPTUM_CID_EXT = "optum-cid-ext";

    private static final Map<String, String> ENVIRONMENTALS = new HashMap<>();
    private static final Set<String> ENV_VARS = ImmutableSet.of("CLUSTER", "DATACENTER", "ENVIRONMENT");
    static final ObjectMapper MAPPER = new ObjectMapper();

    public static boolean nessEnabled;
    public static NessLogger nessLogger;
    private static KafkaLogger big5logger;
    private static boolean nessInitialized = false;
    private static Encryptor encryptor;
    private final static String TICKET_KEY = "ssl.truststore.password";
    private final static String TICKET_VAL = "truststore.ticket";
    private final static String CONFIG_PATH = "config.properties";

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private static final Map<Class<?>, HttpStatus> RESPONSE_MAP = ImmutableMap.<Class<?>, HttpStatus>builder()
            .put(AuthenticationException.class, HttpStatus.UNAUTHORIZED)
            .put(ConstraintViolationException.class, HttpStatus.BAD_REQUEST)
            .put(IhrBadRequestException.class, HttpStatus.BAD_REQUEST)
            .put(IhrGoneException.class, HttpStatus.GONE)
            .put(IhrNotAcceptableException.class, HttpStatus.NOT_ACCEPTABLE)
            .put(IhrNotFoundException.class, HttpStatus.NOT_FOUND)
            .build();

    @Inject
    public LoggingFilter(@Property(name = "ness.enabled") boolean nessEnabled,
                         final VersionConfiguration versionConfig,
                         final Encryptor encryptor,
                         final KafkaLogger big5logger) {
        LoggingFilter.nessEnabled = nessEnabled;
        LoggingFilter.encryptor = encryptor;
        this.big5logger = big5logger;

        ENV_VARS.forEach(env -> ENVIRONMENTALS.put(env, System.getenv(env)));
        ENVIRONMENTALS.put("APPLICATION_NAME", "ihr-api");
        ENVIRONMENTALS.put(API_VERSION, AppUtils.getBuildVersionFromManifestInfo());
        ENVIRONMENTALS.put(DATA_VERSION, versionConfig.getDataVersion());
        ENVIRONMENTALS.put(SCHEMA_VERSION, versionConfig.getSchemaVersion());

        log.info("Api Version: {}, Data Version: {}, Schema Version: {}",
                ENVIRONMENTALS.get(API_VERSION), ENVIRONMENTALS.get(DATA_VERSION), ENVIRONMENTALS.get(SCHEMA_VERSION));

        try {
            ENVIRONMENTALS.put("host", InetAddress.getLocalHost().getHostName());
        } catch (Exception e) {
            log.warn("unable to resolve hostname, hostname won't be present in the logs.");
        }

        if (nessEnabled) {
            log.info("NESS_ENABLED/ness.enabled is true, initializing ness publisher");

            try {
                log.info("loading ness truststore at: {}", CONFIG_PATH);
                InputStream inputStream = AppUtils.readResourceAsStream(CONFIG_PATH);
                nessLogger = new NessLogger(updateNessProperties(inputStream));
                nessInitialized = true;
            } catch (Exception ex) {
                log.error("failed loading ness config file: {}, error: {}", CONFIG_PATH, ex.getMessage());
            }
        } else {
            log.info("NESS_ENABLED/ness.enabled is false, not initializing ness publisher. Will NOT be logging to ness.");
        }
    }

    private static Properties updateNessProperties(InputStream inputStream) throws IOException {
        Properties configProps = new Properties();
        configProps.load(inputStream);
        configProps.setProperty(TICKET_KEY, configProps.getProperty(TICKET_VAL));
        configProps.remove(TICKET_VAL);
        log.info("reading config properties, applicationName {}", configProps.getProperty("applicationName"));
        return configProps;
    }

    private static String logMapToString(final HttpRequest<?> req) {
        try {
            return MAPPER.writeValueAsString(req.getAttribute(LOG_MAP).orElseGet(HashMap::new));
        } catch (Exception e) {
            return String.format("error parsing logMap: %s", e.getMessage());
        }
    }

    @Override
    protected Publisher<MutableHttpResponse<?>> doFilterOnce(HttpRequest<?> request, ServerFilterChain chain) {
        initializeLogMap(request);
        initializeNessLogMap(request);
        String requestId = request.getHeaders().get(OPTUM_CID_EXT);
        MDC.put(REQUEST_ID_MDC_KEY, requestId);
        return Flowable.fromPublisher(chain.proceed(request))
                .doOnNext(res -> log(request, res, null))
                .doOnError(e -> log(request, null, e))
                .doFinally(MDC::clear);
    }

    public static void log(final HttpRequest<?> req, final MutableHttpResponse<?> res, final Throwable error) {
        if (error != null) {
            String message = error.getMessage() == null ? error.toString() : error.getMessage();
            LoggingFilter.addAttribute(req, "error", message);
            addErrorHttpStatus(req, res, error);
        } else {
            LoggingFilter.addAttribute(req, HTTP_STATUS, res.getStatus() == null ? 0 : res.getStatus().getCode());
        }

        if (nessInitialized && nessEnabled) {
            Instant start = Instant.now();
            publishNessLog(req, res, error);
            LoggingFilter.addAttribute(req, "nessMs", Duration.between(start, Instant.now()).toMillis());
        }

        //these two lines should be last so we can capture the entire duration, even including ness processing
        LoggingFilter.setDuration(req, TOTAL);
        LoggingFilter.addAttribute(req, "requestEnd", ZonedDateTime.now().format(FORMATTER));
        log.info(logMapToString(req));
        //log kafka message

        Map<String, Object> logMap = req.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElseGet(HashMap<String,Object>::new);
        if (req.getPath().matches("^/individual-health-records/.*$")) {
            Encrypted big5Encrypted = (Encrypted) ((Map) req.getAttribute(LOG_MAP).orElseGet(HashMap<String, Object>::new)).get("big5");
            if (big5Encrypted != null) {
                String encryptedKey = Base64.getEncoder().encodeToString(big5Encrypted.getEncryptedKey());
                String encryptedMessage = Base64.getEncoder().encodeToString(big5Encrypted.getEncryptedMessage());
                String iv = Base64.getEncoder().encodeToString(big5Encrypted.getIv());
                logMap.put("encryptedKey", encryptedKey);
                logMap.put("encryptedMessage", encryptedMessage);
                logMap.put("iv", iv);
                logMap.remove("big5");
                req.setAttribute(LOG_MAP, logMap);
            }
            try {
                big5logger.logBig5(req.getHeaders().get(OPTUM_CID_EXT), MAPPER.writeValueAsString(logMap));
            } catch (Exception e) {
                log.error("Failed to send log report to Kafka due to error: " + e.getMessage());
            }
        }
    }

    public static void addErrorHttpStatus(final HttpRequest<?> req, final MutableHttpResponse<?> res, final Throwable error) {
        HttpStatus status = RESPONSE_MAP.getOrDefault(error.getClass(), HttpStatus.INTERNAL_SERVER_ERROR);
        LoggingFilter.addAttribute(req, HTTP_STATUS, status.getCode());
    }

    void initializeNessLogMap(final HttpRequest<?> request) {
        if (nessEnabled) {
            Map<String, Object> nessMap = request.getAttribute(LoggingFilter.LOG_NESS, Map.class).orElseGet(HashMap::new);
            nessMap.put("receivedTime", Instant.now().toEpochMilli());
            request.setAttribute(LoggingFilter.LOG_NESS, nessMap);
        }
    }

    public void initializeLogMap(final HttpRequest<?> req) {
        Map<String, Object> logMap = new LinkedHashMap<>(ENVIRONMENTALS);
        logMap.put("requestStart", ZonedDateTime.now().format(FORMATTER));
        logMap.put(TOTAL + START, Instant.now());

        req.getBody(IhrApiRequest.class).ifPresent(apiReq -> {
            try {
                logMap.put("big5", encryptor.encrypt(MAPPER.writeValueAsString(apiReq)));
            } catch (Exception e) {
                try {
                    logMap.put("big5", MAPPER.writeValueAsString(encryptor.encrypt(apiReq.toString())));
                } catch (JsonProcessingException ex) {
                    log.error("Json parse error {}", ex.getMessage());
                }
            }
            MId mbrId = apiReq.getMbrId();
            if (apiReq.getRequestor() != null) {
                logMap.put("sharing", !mbrId.getBig5().equals(apiReq.getRequestor()));
            } else {
                logMap.put("sharing", false);
            }
            logMap.put("requesteeSearchId", mbrId.getBig5().getSearchId());
            if (apiReq.getRequestor() != null) {
                logMap.put("requestorSearchId", apiReq.getRequestor().getSearchId());
            }
            logMap.put("request-corr-id", apiReq.getCorrelationId());
            logMap.put(mbrId.getIdType(), mbrId.getIdValue());
        });

        logMap.put("path", req.getPath());
        logMap.put(AppUtils.X_CONSUMER_HEADER, req.getHeaders().get(AppUtils.X_CONSUMER_HEADER));
        logMap.put("Accept", req.getHeaders().get("Accept"));
        logMap.put(OPTUM_CID_EXT, req.getHeaders().get(OPTUM_CID_EXT));

        req.setAttribute(LOG_MAP, logMap);
    }

    @Override
    public int getOrder() { //we want this to be earlier than most filters, which default to 0
        return -1;
    }

    public static void publishNessLog(final HttpRequest<?> request, final MutableHttpResponse<?> res, final Throwable error) {
        try {
            Map<String, Object> nessMap = request.getAttribute(LoggingFilter.LOG_NESS, Map.class).orElseGet(HashMap::new);
            Map<String, Object> logMap = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElseGet(HashMap::new);
            Long receivedTime = (Long) nessMap.get("receivedTime");
            boolean success = false;
            String correlationId = logMap.get(OPTUM_CID_EXT) != null ? logMap.get(OPTUM_CID_EXT).toString() : "";
            if (res != null && res.getStatus().getCode() == 200) {
                success = true;
            }
            NessLogEvent logEvent = nessLogger.createLogEvent(success ? "IHR API request processed successfully for correlation id: " + correlationId :
                            "IHR API request failed for correlation id: " + correlationId,
                    success ? "IHR API resource accessed successfully for correlation id: " + correlationId :
                            "IHR API resource accessed failed for correlation id: " + correlationId)
                    .setLogEvtOutcome(success ? outcome.SUCCESS : outcome.FAILURE)
                    .setLogEvtStart(receivedTime).setLogEvtEnd(Instant.now().toEpochMilli())
                    .setRequestRequest(request.getPath())
                    .setRequestUserAgent(request.getRemoteAddress() == null ? "" : request.getRemoteAddress().getHostName())
                    .setRequestOptumCIDExt(logMap.get(OPTUM_CID_EXT) == null ? "" : logMap.get(OPTUM_CID_EXT).toString())
                    .setRequestMethod(request.getMethod().name())
                    .setRequestIn(request.getContentLength())
                    .setRequestOut(success ? res.getBody().toString().length() : 0)
                    .setLogEvtAct(request.getMethod().name())
                    .setLogEvtLogClass(logClass.SECURITY_SUCCESS)
                    .setLogEvtReason(getReason(res, error));
            log.debug("Published logEvent: {}", logEvent);
            nessLogger.publish(logEvent);
        } catch (Exception ex) {
            log.warn("publish to ness failed: {}", ex.getMessage());
        }
    }

    private static String getReason(final MutableHttpResponse<?> res, final Throwable error) {
        if (error != null && StringUtils.isNotEmpty(error.getMessage())) {
            return error.getMessage();
        } else if (StringUtils.isNotEmpty(res.getStatus())) {
            return res.getStatus().getReason();
        } else {
            return UNKNOWN_ERROR;
        }
    }

    @SuppressWarnings("unchecked")
    public static void setDuration(final HttpRequest<?> request, final String method) {
        Map<String, Object> map = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElseGet(HashMap::new);
        String startString = method + START;
        Instant start = (Instant) map.get(startString);
        if (start == null) {
            log.error("tried to get start time for {} and failed", startString);
            map.put("logError", "tried to get start time for " + method + "_start and failed");
        } else {
            map.put(method + "Ms", Duration.between(start, Instant.now()).toMillis());
            map.remove(startString);
        }
        request.setAttribute(LoggingFilter.LOG_MAP, map);
    }

    @SuppressWarnings("unchecked")
    public static void addAttribute(final HttpRequest<?> request, final String key, final Object value) {
        Map<String, Object> map = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElseGet(HashMap::new);
        map.put(key, value);
        request.setAttribute(LoggingFilter.LOG_MAP, map);
    }

    @SuppressWarnings("unchecked")
    public static Object getAttribute(final HttpRequest<?> request, final String key) {
        Map<String, Object> map = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElseGet(HashMap::new);
        return map.get(key);
    }

    public static void logStart(final HttpRequest<?> request, final String method) {
        addAttribute(request, method + START, Instant.now());
    }

    @SuppressWarnings("unchecked")
    public static void logSuccess(final HttpRequest<?> request, final String method) {
        setDuration(request, method);
        Map<String, Object> map = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElseGet(HashMap::new);
        map.put(method + "Status", "success");
        request.setAttribute(LoggingFilter.LOG_MAP, map);
    }

    @SuppressWarnings("unchecked")
    public static void logFail(final HttpRequest<?> request, final String method, final String reason) {
        setDuration(request, method);
        Map<String, Object> map = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElseGet(HashMap::new);
        map.put(method + "Status", FAILURE);
        map.put(method + "Reason", reason);
        request.setAttribute(LoggingFilter.LOG_MAP, map);
    }
}