package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.Immunizations;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.BooleanType;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Immunization;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Quantity;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.StringType;

@Slf4j
@Value(staticConstructor = "of")
public class ImmunizationFhirMapper implements FhirMapper<Immunizations, Immunization> {

    private static final String DOSAGE_UNIT_URL = "https://new-wiki.optum.com/display/IHRI/IHR+API+Dose+Unit+of+Measure";
    private static final String DOSAGE_FORM_URL = " https://new-wiki.optum.com/display/IHRI/IHR+API+Dose+Form";
    private static final String DOSAGE_FREQUENCY_URL = "https://new-wiki.optum.com/display/IHRI/IHR+API+Dose+Frequency";
    private static final String GENERIC_FLAG_URL = "https://new-wiki.optum.com/display/IHRI/Medication+generic+flag";
    private static final String IMMUNIZATION_CONCEPT_URL = "Concept";

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getImmunizations())) {
            map(fhirResource, dataClasses.getImmunizations());
        }
    }

    @Override
    public void map(FhirResource fhirResource, Immunizations ihrImmunization) {
        Patient patient = fhirResource.getPatient();
        Bundle bundle = fhirResource.getBundle();

        Immunization immunization = new Immunization();
        immunization.setId(new IdType(createIdURI()));
        //record key
        if (null != ihrImmunization.getRecordKey()) {
            immunization.addIdentifier().setValue(ihrImmunization.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }
        //object id
        if (null != ihrImmunization.getObjectId()) {
            immunization.addIdentifier().setValue(ihrImmunization.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(ihrImmunization.getReferenceIds())) {
            immunization.addIdentifier().setValue(AppUtils.jsonEscape(ihrImmunization.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));
        }
        //health event date administartion date
        if (StringUtils.isNotBlank(ihrImmunization.getHealthEventDate())) {
            immunization.setOccurrence(toDateTimeTypeFromDate(ihrImmunization.getHealthEventDate()));
        }
        //medication
        if (null != ihrImmunization.getMedication()) {
            immunization.setVaccineCode(new CodeableConcept().setText(ihrImmunization.getMedication().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(ihrImmunization.getMedication().getIhrTerm())
                            .setSystem(ihrImmunization.getMedication().getSourceVocabulary())
                            .setCode(ihrImmunization.getMedication().getSourceVocabularyCode())));
        }
        //sensitivity classes
        if (CollectionUtils.isNotEmpty(ihrImmunization.getSensitivityClasses())) {
            immunization.addExtension(Constants.SENSITIVITY_CLASSES_URL,
                    new StringType(AppUtils.jsonEscape(ihrImmunization.getSensitivityClasses())));
        }
        //source claim ids
        if (CollectionUtils.isNotEmpty(ihrImmunization.getSourceClaimIds())) {
            immunization.addIdentifier().setValue(AppUtils.jsonEscape(ihrImmunization.getSourceClaimIds()))
                    .setType(new CodeableConcept().setText(Constants.SOURCE_CLAIM_IDS));
        }
        //dosage unit
        if (null != ihrImmunization.getDosageUnit()) {
            immunization.addExtension(DOSAGE_UNIT_URL, new CodeableConcept()
                    .setText(ihrImmunization.getDosageUnit().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(ihrImmunization.getDosageUnit().getIhrTerm())
                            .setSystem(ihrImmunization.getDosageUnit().getSourceVocabulary())
                            .setCode(ihrImmunization.getDosageUnit().getSourceVocabularyCode())));
        }
        //dosage form
        if (null != ihrImmunization.getDosageForm()) {
            immunization.addExtension(DOSAGE_FORM_URL, new CodeableConcept()
                    .setText(ihrImmunization.getDosageForm().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(ihrImmunization.getDosageForm().getIhrTerm())
                            .setSystem(ihrImmunization.getDosageForm().getSourceVocabulary())
                            .setCode(ihrImmunization.getDosageForm().getSourceVocabularyCode())));
        }
        //dosage frequency
        if (null != ihrImmunization.getDosageFrequency()) {
            immunization.addExtension(DOSAGE_FREQUENCY_URL, new StringType(ihrImmunization.getDosageFrequency()));
        }
        //related care team
        if (CollectionUtils.isNotEmpty(ihrImmunization.getRelatedCareTeam())) {
            immunization.addIdentifier().setValue(AppUtils.jsonEscape(ihrImmunization.getRelatedCareTeam()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CARE_TEAM_INSTANCE_IDS));
        }
        //related service facility providers
        if (CollectionUtils.isNotEmpty(ihrImmunization.getRelatedServiceProviders())) {
            immunization.addIdentifier().setValue(AppUtils.jsonEscape(ihrImmunization.getRelatedServiceProviders()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS));
        }
        //related observations
        if (CollectionUtils.isNotEmpty(ihrImmunization.getRelatedObservations())) {
            immunization.addIdentifier().setValue(AppUtils.jsonEscape(ihrImmunization.getRelatedObservations()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_OBSERVATION_INSTANCE_IDS));
        }
        //Related Conditions
        if (CollectionUtils.isNotEmpty(ihrImmunization.getRelatedConditions())) {
            immunization.addIdentifier().setValue(AppUtils.jsonEscape(ihrImmunization.getRelatedConditions()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CONDITION_INSTANCE_IDS));
        }
        //presence state term
        if (null != ihrImmunization.getPresenceStateTerm()) {
            immunization.addExtension(Constants.PRESENCE_STATE_TERM_URL, new StringType(ihrImmunization.getPresenceStateTerm()));
        }
        //data source
        if (CollectionUtils.isNotEmpty(ihrImmunization.getDataSource())) {
            immunization.addExtension(Constants.DATA_SOURCE_URL, new StringType(AppUtils.jsonEscape(ihrImmunization.getDataSource())));
        }
        //last update date
        if (StringUtils.isNotBlank(ihrImmunization.getLastUpdateDate())) {
            immunization.setMeta(new Meta().setLastUpdatedElement(toInstantTypeFromDate(ihrImmunization.getLastUpdateDate())));
        }
        //concept
        if (null != ihrImmunization.getConcept()) {
            CodeableConcept code = new CodeableConcept();
            code.setText(ihrImmunization.getConcept().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(ihrImmunization.getConcept().getIhrTerm())
                            .setCode(ihrImmunization.getConcept().getSourceVocabularyCode())
                            .setSystem(ihrImmunization.getConcept().getSourceVocabulary()));
            if (StringUtils.isNotBlank(ihrImmunization.getConcept().getCpthcpcsCode())) {
                code.addCoding()
                        .setCode(ihrImmunization.getConcept().getCpthcpcsCode())
                        .setSystem(Constants.CPTHCPCS_CODE_URL);
            }
            immunization.addExtension(IMMUNIZATION_CONCEPT_URL, code);
        }
        //Clinically relevant date
        if (StringUtils.isNotBlank(ihrImmunization.getClinicallyRelevantDate())) {
            immunization.addExtension(Constants.CLINICALLY_RELEVANT_DATE_URL, this.toDateTimeTypeFromDate(ihrImmunization.getClinicallyRelevantDate()));
        }
        //dosagequantity
        if (null != ihrImmunization.getDosageQuantity()) {
            immunization.setDoseQuantity(new Quantity(ihrImmunization.getDosageQuantity()));
        }
        // note
        if (CollectionUtils.isNotEmpty(ihrImmunization.getNote())) {
            for (Note note : ihrImmunization.getNote()) {
                immunization.addNote(getAnnotation(patient, note, fhirResource));
            }
        }
        immunization.setPatient(new Reference(patient));
        //generic flag
        if (null != ihrImmunization.getGenericFlag()) {
            immunization.addExtension(GENERIC_FLAG_URL, new BooleanType(ihrImmunization.getGenericFlag()));
        }

        // add resource into bundle
        bundle.addEntry().setFullUrl(immunization.getId()).setResource(immunization);
    }
}
