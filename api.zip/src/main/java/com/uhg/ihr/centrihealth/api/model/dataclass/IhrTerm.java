package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IhrTerm {
    private String ihrLaymanTerm;
    private String ihrTerm;
    private String ihrCode;
    private String sourceVocabulary;
    private String sourceVocabularyCode;
    private String fdbCode;
    private String fdbCodeType;
    private String rxNormCode;
    private String mediSpanCode;
    private String icd10cmCode;
    private String cpthcpcsCode;
    private String clinicalCourse;
    private String medicalDomain;
    private String loincCode;
    private String conceptChid;
}
