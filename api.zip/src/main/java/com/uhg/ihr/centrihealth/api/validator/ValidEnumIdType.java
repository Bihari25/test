package com.uhg.ihr.centrihealth.api.validator;


import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import javax.validation.Constraint;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Target({FIELD, PARAMETER})
@Retention(RUNTIME)
@Constraint(validatedBy = ValidEnumIdTypeValidator.class)
public @interface ValidEnumIdType {
    String message() default "invalid IdType";

    Class<?>[] groups() default {};

    Class<? extends String>[] payload() default {};

    boolean optional() default false;
}