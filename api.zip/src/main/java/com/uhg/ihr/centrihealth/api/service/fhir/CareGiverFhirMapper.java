package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.CareGiver;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CareTeam;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.HumanName;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Period;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.RelatedPerson;


@Slf4j
@Value(staticConstructor = "of")
public class CareGiverFhirMapper implements FhirMapper<CareGiver, CareTeam> {

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getCareGivers())) {
            map(fhirResource, dataClasses.getCareGivers());
        }
    }

    @Override
    public void map(FhirResource fhirResource, CareGiver careGiver) {
        Bundle bundle = fhirResource.getBundle();
        CareTeam careTeam = new CareTeam();
        careTeam.setId(new IdType(createIdURI()));
        //record type
        if (StringUtils.isNotBlank(careGiver.getRecordType())) {
            careTeam.setText(createNarrative(careGiver.getRecordType()));
        }
        //record key
        if (StringUtils.isNotBlank(careGiver.getRecordKey())) {
            careTeam.addIdentifier().setValue(careGiver.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }
        //object id
        if (null != careGiver.getObjectId()) {
            careTeam.addIdentifier().setValue(String.valueOf(careGiver.getObjectId()))
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(careGiver.getReferenceIds())) {
            careTeam.addIdentifier().setValue(AppUtils.jsonEscape(careGiver.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));
        }
        //related entity name
        RelatedPerson person = null;
        if (StringUtils.isNotBlank(careGiver.getRelatedEntityName())) {
            HumanName humanName = new HumanName()
                    .setFamily("")
                    .addGiven("")
                    .addGiven("")
                    .setText(careGiver.getRelatedEntityName())
                    .addPrefix("");

            person = getOrCreateRelatedPerson(fhirResource, humanName);
            careTeam.getParticipantFirstRep().setMember(new Reference(person));
        }
       //related entity role term
        if (StringUtils.isNotBlank(careGiver.getRelatedEntityRoleTerm())) {
            if (person == null) {
                CodeableConcept relationShip = new CodeableConcept().setText(careGiver.getRelatedEntityRoleTerm());
                person = getOrCreateRelatedPerson(fhirResource, relationShip);
                careTeam.getParticipantFirstRep().setMember(new Reference(person));
            } else {
                person.addRelationship(new CodeableConcept().setText(careGiver.getRelatedEntityRoleTerm()));
            }
        }
        Period period = new Period();
        //relationship start and end date
        if (StringUtils.isNotBlank(careGiver.getRelationshipStartDate())) {
            period.setStartElement(toDateTimeTypeFromDate(careGiver.getRelationshipStartDate()));
        }
        if (StringUtils.isNotBlank(careGiver.getRelationshipEndDate())) {
            period.setEndElement(toDateTimeTypeFromDate(careGiver.getRelationshipEndDate()));
        }
        careTeam.setPeriod(period);
        //add resource into bundle
        bundle.addEntry().setFullUrl(careTeam.getId()).setResource(careTeam);
    }
}