package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigInteger;
import java.util.List;

@Builder(toBuilder = true)
@AllArgsConstructor
@Data
@NoArgsConstructor
public class HealthMedication {
    private DataClassEnums recordType;
    private String recordKey;
    private String medicationStartDate;
    private IhrTerm medication;
    private IhrTerm medicationStatus;
    private Integer daysSupply;
    private Integer dosageQuantity;
    private String dosageFrequency;
    private IhrTerm dosageForm;
    private Float dispensedQuantity;
    private IhrTerm dosageUnit;
    private IhrTerm dispensedQuantityUnit;
    private String lastFillDate;
    private String icueSeqId;
    private String icueLastUpdateDate;
    private String clinicallyRelevantDate;
    private String orderDate;
    private String firstDoseDate;
    private String endDate;
    private String holdDate;
    private String restartedDate;
    private Boolean takenAsOrdered;
    private String adherenceStopDate;
    private Integer refillAuthorizedNumber;
    private Float refillCount;
    private IhrTerm refillCountUnit;
    private Boolean genericFlag;
    private String expectedFillDate;
    private String adminInstructions;
    private List<String> prescriptionId;
    private String lastUpdateDate;
    private String presenceStateTerm;
    private List<String> sensitivityClasses;
    private BigInteger objectId;
    private List<BigInteger> relatedConditions;
    private List<BigInteger> relatedProcedures;
    private List<BigInteger> relatedDevices;
    private List<BigInteger> relatedCareTeam;
    private List<BigInteger> relatedServiceProviders;
    private List<BigInteger> sourceClaims;
    private List<String> referenceIds;
    private List<String> dataSource;
    private List<String> drugClass;
    private String deaSchedule;
    private OrderingProvider orderingProvider;
    private Supplier supplier;
    private String genericDrugName;
    private String medicationReviewDate;
    private String reviewedBy;
    private String reviewerIhrActorIdentifier;
    private String informer;
    private String medicationReviewLastUpdateDate;
    private List<Note> note;
    private List<BigInteger> relatedAllergies;
    private String doseQuantityUnit;
    private IhrTerm dosageRoute;
    private List<IhrTerm> medicationReason;
    private  String ihrMedicationStartDate;
}
