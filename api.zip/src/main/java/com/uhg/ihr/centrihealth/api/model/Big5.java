package com.uhg.ihr.centrihealth.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.uhg.ihr.centrihealth.api.validator.ValidDate;
import com.uhg.ihr.centrihealth.api.validator.ValidEnumIdTypeNullable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"firstName", "lastName", "dateOfBirth", "policyNumber", "searchId", "searchIdType", "ids"})
public class Big5 {
    @JsonProperty
    @NotBlank(message = "The request could not be validated. A first name was not provided.")
    private String firstName;

    @JsonProperty
    @NotBlank(message = "The request could not be validated. A last name was not provided.")
    private String lastName;

    @JsonProperty
    @ValidDate(message = "The request could not be validated. A date of birth was not provided.")
    private String dateOfBirth;

    @EqualsAndHashCode.Exclude
    @JsonProperty
    private String policyNumber;

    @JsonProperty
    @NotBlank(message = "The request could not be validated. A search id was not provided.")
    private String searchId;

    @EqualsAndHashCode.Exclude
    @JsonProperty("searchIdType")
    @ValidEnumIdTypeNullable(message = "Not a valid searchIdType. Valid Types are - memberId, searchId, EID, SSN, MBI, subscriberId, hcId,icue")
    private IdType idType;

    @EqualsAndHashCode.Exclude
    @JsonProperty
    @Valid
    private List<Id> ids;

}