package com.uhg.ihr.centrihealth.api.model;

public enum IdType {
    memberId, searchId, SSN, MBI, subscriberId, hcId
}