package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@NoArgsConstructor
public class VisitHistory {
    private String recordType;
    private String admitDate;
    private String recordKey;
    private String dischargeDate;
    private IhrTerm visit;
    private IhrTerm dischargeDisposition;
    private List<IhrTerm> admittingDiagnosis;
    private List<IhrTerm> dischargeDiagnosis;
    private String admitSource;
    private String presenceStateTerm;
    private String lastUpdateDate;
    private List<String> sensitivityClasses;
    private BigInteger objectId;
    private List<BigInteger> relatedConditions;
    private List<BigInteger> relatedMedications;
    private List<BigInteger> relatedProcedures;
    private List<BigInteger> relatedDevices;
    private List<BigInteger> relatedImmunizations;
    private List<BigInteger> relatedObservations;
    private List<BigInteger> relatedCareTeam;
    private List<BigInteger> relatedServiceProviders;
    private List<String> dataSource;
    private String visitType;
    private String placeOfService;
    private String clinicallyRelevantDate;
    private List<String> sourceClaimIds;
    private List<String> referenceIds;
}
