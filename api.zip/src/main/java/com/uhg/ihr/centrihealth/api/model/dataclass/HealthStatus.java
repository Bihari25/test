package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@NoArgsConstructor
public class HealthStatus {
    private String recordType;
    private BigInteger objectId;
    private IhrTermWithId concept;
    private IhrTermWithId classification;
    private String clinicallyRelevantDate;
    private String expectedAchievement;
    private String startDate;
    private String dueDate;
    private String lastUpdateDate;
    private IhrTermWithId presenceState;
    private Evaluation evaluation;
    private List<String> sensitivityClasses;
    private List<BigInteger> relatedConditions;
    private List<String> dataSource;
    private String recordKey;
    private List<String> referenceIds;
}
