package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@NoArgsConstructor
public class ServiceProviders {
    private String recordType;
    private String recordKey;
    private String providerType;
    private String relatedEntityName;
    private String relatedEntityNPInum;
    private String relatedEntityMPIN;
    private String relatedEntityRoleTerm;
    private String relationshipStartDate;
    private String relationshipEndDate;
    private BigInteger objectId;
    private List<Occupation> occupations;
    private List<String> referenceIds;
}
