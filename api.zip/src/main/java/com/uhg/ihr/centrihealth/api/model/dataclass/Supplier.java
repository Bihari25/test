package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Supplier {
    private String npinum;
    private String name;
}
