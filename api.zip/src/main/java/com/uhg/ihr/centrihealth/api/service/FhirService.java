package com.uhg.ihr.centrihealth.api.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhg.ihr.centrihealth.api.model.IhrApiResponse;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrResponse;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Bundle;

import javax.inject.Singleton;


@Slf4j
@Singleton
public class FhirService {
    private static final ObjectMapper MAPPER = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    static IhrFhirMapper mapper = new IhrFhirMapper();

    public static Bundle fhirConvert(IhrApiResponse ihrApiResponse) {
        IhrResponse resp = new IhrResponse();
        try {
            resp.setDataClasses(MAPPER.treeToValue(ihrApiResponse.getDataClasses(), DataClass.class));
            resp.setMbrId(ihrApiResponse.getMbrId());
        } catch (Exception e) {
            log.error("Unable to parse v2 ihrApiResponse for FHIR conversion. Likely a schema issue with the data: {}", e.getMessage());
            throw new RuntimeException("Unable to parse v2 ihrApiResponse for FHIR conversion");
        }

        return mapper.getFhirMapping(resp);
    }

}
