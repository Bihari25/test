package com.uhg.ihr.centrihealth.api.filter;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;

import java.util.Date;
import java.util.Objects;
import java.util.Set;

/**
 * ClinicallyRelevantDateFilter used to filter data content of dataclass for given start and end date.
 *
 * @author ihr api team
 * copyright (C) all rights reserved UHG
 */
@Slf4j
public class ClinicallyRelevantDateFilter implements DataFilter {
    private Date startDate;
    private Date endDate;

    public ClinicallyRelevantDateFilter(String startDate, String endDate) {
        validateDatesAndRange(startDate, endDate);
    }

    @Override
    public boolean isFilterableDataClass(String dataClass) {
        return DataFilter.DATA_CLASS_FILTERS.contains(dataClass);
    }

    @Override
    public Set<String> getFilterableDataClasses() {
        return DataFilter.DATA_CLASS_FILTERS;
    }

    @Override
    public boolean filter(JsonNode dataNode) {
        String crdate;
        try {
            // Validate to handle for api version < 2.3 data structure requests.
            JsonNode crdDataNode = dataNode.get(AppUtils.CLINICALLY_RELEVANT_DATE);
            if (Objects.isNull(crdDataNode)) {
                log.warn("There is no clinical relevant date field in the data node");
                return false;
            } else {
                crdate = crdDataNode.textValue();
            }

            // Validate clinically relevant date is empty or null; If it empty/null return true to get api response for given data node.
            if (StringUtils.isNotBlank(crdate)) {
                Date clinicalRelevantDate = DateUtils.parseDateStrictly(crdate, AppUtils.DATE_PATTERNS);
                return AppUtils.isDateInBetween(this.startDate, this.endDate, clinicalRelevantDate);
            } else {
                return true;
            }
        } catch (Exception ex) {
            throw new IhrBadRequestException("Invalid clinical relevant date format from data node of payload; exception: ".concat(ex.getMessage()));
        }
    }

    /**
     * Method to validate date range for start and end date.
     */
    private void validateDatesAndRange(String startDate, String endDate) {
        try {
            this.startDate = DateUtils.parseDateStrictly(startDate, AppUtils.DATE_PATTERNS);
            this.endDate = DateUtils.parseDateStrictly(endDate, AppUtils.DATE_PATTERNS);
        } catch (Exception ex) {
            throw new IhrBadRequestException("Invalid date format either in start/end date; exception: ".concat(ex.getMessage()));
        }

        // Validate start and end date range as a 2nd level validation so that appropriate and meaningful exception message will bubble up.
        if (this.startDate.after(this.endDate)) {
            throw new IhrBadRequestException("Invalid date range start date is after (greater than) end date.");
        }
    }

}
