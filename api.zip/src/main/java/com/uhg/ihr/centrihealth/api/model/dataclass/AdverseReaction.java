package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class AdverseReaction {
    private DataClassEnums recordType;
    private String recordKey;
    private String lastUpdateDate;
    private IhrTerm adversereactiontype;
    private List<IhrTerm> allergens;
    private List<Reaction> reactions;
    private IhrTerm status;
    private String presenceStateTerm;
    private List<String> sensitivityClasses;
    private BigInteger objectId;
    private List<String> dataSource;
    private String startDate;
    private String clinicallyRelevantDate;
    private List<String> referenceIds;
    private String onsetDate;
    private String endDate;
    private String allergenType;
    private String allergyIntolerance;
    private String recordedDate;
    private String recorder;
    private String asserter;
    private List<Note> note;
}


