package com.uhg.ihr.centrihealth.api.model.dataclass;

import java.math.BigInteger;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class IhrCareTeam {
    private DataClassEnums recordType;
    private String recordKey;
    private String personRoleTerm;
    private String prefix;
    private String firstName;
    private String middleName;
    private String lastName;
    private String relatedEntityName;
    private String relatedEntityNPInum;
    private String relatedEntityMPIN;
    private String relatedEntityRoleTerm;
    private String relationshipStartDate;
    private String relationshipEndDate;
    private String relationshipStatus;
    private BigInteger objectId;
    private List<Occupation> occupations;
    private List<String> referenceIds;
}
