package com.uhg.ihr.centrihealth.api.exception;

import com.uhg.ihr.centrihealth.api.controller.ApiController;
import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.server.exceptions.ExceptionHandler;

import javax.inject.Singleton;
import java.util.concurrent.TimeoutException;

@Produces
@Singleton
@Requires(classes = {TimeoutException.class, ExceptionHandler.class})
public class TimeoutExceptionHandler implements ExceptionHandler<TimeoutException, HttpResponse<?>> {

    private static final String ERROR = "Request timed out after " + ApiController.REQUEST_TIMEOUT_MS + "ms";

    @Override
    public HttpResponse<?> handle(HttpRequest request, TimeoutException exception) {
        return HttpResponse.status(HttpStatus.INTERNAL_SERVER_ERROR, exception.getMessage()).body(ErrorHelper.handleError(request, ERROR));
    }

}
