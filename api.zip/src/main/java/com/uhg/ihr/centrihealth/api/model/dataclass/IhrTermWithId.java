package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class IhrTermWithId {
    private String ihrLaymanTerm;
    private String ihrTerm;
    private String ihrId;
    private String sourceVocabulary;
    private String sourceVocabularyCode;
}
