package com.uhg.ihr.centrihealth.api.client;

import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Header;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.client.annotation.Client;
import io.micronaut.retry.annotation.Retryable;
import io.reactivex.Maybe;

import javax.validation.constraints.NotNull;
import java.util.LinkedHashMap;

@Client("b50Senzing")
@Retryable(attempts = "2", delay = "500ms", maxDelay = "1")
public interface B50SenzingClient {
    @Post("/entities/")
    @Header(name = "Content-Type", value = "application/json")
    Maybe<LinkedHashMap<String, Object>> fetchEntities(final @Header("Authorization") String token,
                                                       final @Header("X-Correlation-ID") String correlationId,
                                                       final @Header("X-content-size") String forceMinimal,
                                                       final @Body @NotNull SenzingRequest senzingRequest);
}