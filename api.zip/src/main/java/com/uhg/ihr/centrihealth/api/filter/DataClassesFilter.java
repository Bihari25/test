package com.uhg.ihr.centrihealth.api.filter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import io.micronaut.core.util.CollectionUtils;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * DataClassesFilter class used to filter data classes category objects based on given filtering criteria, So that payload data get filtered content.
 *
 * @author ihr api team
 * copyright (C) all rights reserved UHG
 */
@Slf4j
@NoArgsConstructor
public class DataClassesFilter {

    /**
     * Method to filter data classes content by criteria.
     */
    public static Map<String, JsonNode> filterAllowedDataClassesByCriteria(Map<String, JsonNode> dataClassesPayload, List<DataFilter> dataFilters) {
        if (CollectionUtils.isNotEmpty(dataFilters) && Objects.nonNull(dataClassesPayload)) {

            //collect data classes worth inspecting by taking the union of the data classes filtered by each filter
            Set<String> classesToFilter = getClassesToFilter(dataFilters);

            for (Map.Entry<String, JsonNode> dataClass : dataClassesPayload.entrySet()) {

                // Validate and apply filters only for defined data classes which have data.
                if (classesToFilter.contains(dataClass.getKey()) && dataClass.getValue().size() > 0) {

                    // Computed filtered data.
                    JsonNode filteredData = filterDataByCriteria(dataClass.getKey(), dataClass.getValue(), dataFilters);
                    dataClassesPayload.put(dataClass.getKey(), filteredData);
                }
            }
        }

        return dataClassesPayload;
    }

    public static Set<String> getClassesToFilter(List<DataFilter> dataFilters) {
        return CollectionUtils.isEmpty(dataFilters) ? Collections.emptySet() : dataFilters.stream().flatMap(f -> f.getFilterableDataClasses().stream()).collect(Collectors.toSet());
    }

    /**
     * Method to filter data in data classes using filter criteria.
     */
    public static JsonNode filterDataByCriteria(String dataClass, JsonNode dataNode, List<DataFilter> dataFilters) {
        ArrayNode passingNodes = new ArrayNode(JsonNodeFactory.instance);

        for (JsonNode jsonNode : dataNode) {
            boolean isPassingFilter = false;

            // iterate over the data filters and test to see if the node passes
            for (DataFilter dataFilter : dataFilters) {
                isPassingFilter = passesFilter(dataClass, dataFilter, jsonNode);

                // if any filter doesn't pass, break out of the loop
                if (!isPassingFilter) {
                    break;
                }
            }

            // collect the nodes that pass all filter criteria
            if (isPassingFilter) {
                passingNodes.add(jsonNode);
            }
        }

        return passingNodes;
    }

    public static boolean passesFilter(String dataClass, DataFilter dataFilter, JsonNode node) {
        // if the class shouldn't be filtered, let it through
        if (!dataFilter.isFilterableDataClass(dataClass)) {
            return true;
        }
        // if it should be filtered, return the filter result
        return dataFilter.filter(node);
    }

}
