package com.uhg.ihr.centrihealth.senzing.model

import com.uhg.ihr.centrihealth.api.model.Id
import com.uhg.ihr.centrihealth.api.model.IdType
import com.uhg.ihr.centrihealth.api.util.AppUtils
import com.uhg.ihr.centrihealth.util.JsonUtils
import spock.lang.Specification
import spock.lang.Unroll

@Unroll
class SenzingRequestSpec extends Specification {
    def senzingRequest = buildSenzingRequest()

    def "setters/getters"() {
        expect:
        senzingRequest.getDateOfBirth() == "00-00-3000"
        senzingRequest.getNameFirst() == "tFirst"
        senzingRequest.getNameLast() == "tLast"
        senzingRequest.getHcId() == "1234"
        senzingRequest.getMemberId() == "7890"
    }

    def "it has a toString"() {
        expect:
        senzingRequest.toString().contains("00-00-3000")
    }

    def "toBuilder"() {
        expect:
        SenzingRequest.builder().nameLast("tLast").nameFirst("tFirst").build()
    }

    def "properties translation for senzing request"() {
        given:
        def sampleSenzingRequest = SenzingRequest.builder().nameLast("tLast").nameFirst("tFirst")
                .dateOfBirth("99-99-7777").hcId("1666666666").memberId("1666666666")
                .build()

        when:
        def requestJson = JsonUtils.serializeJson(sampleSenzingRequest)

        then:
        requestJson.contains("uhcins_member_id\":\"1666666666")
    }

    def "Senzing request build scenarios: #desc"() {
        given:
        def sampleIdInput = [:] as Map<IdType, Id>
        sampleIdInput.put(IdType.SSN, Id.builder().id(inputSearchId).idType(IdType.SSN).build())
        sampleIdInput.put(IdType.MBI, Id.builder().id(inputSearchId).idType(IdType.MBI).build())
        sampleIdInput.put(IdType.hcId, Id.builder().id(inputSearchId).idType(IdType.hcId).build())
        sampleIdInput.put(IdType.searchId, Id.builder().id(inputSearchId).idType(IdType.searchId).build())
        sampleIdInput.put(IdType.memberId, Id.builder().id(inputSearchId).idType(IdType.memberId).build())
        sampleIdInput.put(IdType.subscriberId, Id.builder().id(inputSearchId).idType(IdType.subscriberId).build())

        when:
        def result = SenzingRequest.builder().id(sampleIdInput)

        then:
        result
        result.memberId == inputSearchId
        result.altMemberId == inputSearchId
        result.ssnNumber == inputSearchId
        result.medicareBenfId == inputSearchId
        result.hcId == inputSearchId
        result.subscriberId == expectedSubscriberId
        result.subscriberIdPad == expectedSubscriberPadId

        where:
        desc                                         | inputSearchId   || expectedSubscriberId || expectedSubscriberPadId
        "SearchId without zero"                      | "123456789"     || "123456789"          || "00123456789"
        "11 digits search id"                        | "11123456789"   || "11123456789"        || "11123456789"
        "SearchId with more than 11 digits has zero" | "0012345678999" || "12345678999"        || "0012345678999"
        "10 digit, already has a zero"               | "0123456789"    || "123456789"          || "0123456789"
        "7 digit, already has a zero"                | "0123456"       || "123456"             || "0123456"
        "8 digit, already has a zero"                | "00123456"      || "123456"             || "00123456"
        "9 digit, already has a zero"                | "000123456"     || "123456"             || "000123456"
    }

    def "computeSubscriberIds scenario: #desc"() {
        when:
        def result = SenzingRequest.builder().computePaddedIds(inputSearchId)

        then:
        result
        result['unpaddedId'] == expectedSubscriberId
        result['paddedId'] == expectedSubscriberPadId

        where:
        desc                                         | inputSearchId   || expectedSubscriberId || expectedSubscriberPadId
        "SearchId without zero"                      | "123456789"     || "123456789"          || "00123456789"
        "11 digits search id"                        | "11123456789"   || "11123456789"        || "11123456789"
        "SearchId with more than 11 digits has zero" | "0012345678999" || "12345678999"        || "0012345678999"
        "10 digit, already has a zero"               | "0123456789"    || "123456789"          || "0123456789"
        "7 digit, already has a zero"                | "0123456"       || "123456"             || "0123456"
        "8 digit, already has a zero"                | "00123456"      || "123456"             || "00123456"
        "9 digit, already has a zero"                | "000123456"     || "123456"             || "000123456"
    }


    /**
     * Method to build sample senzing request.
     *
     * @return SenzingRequest
     */
    private static SenzingRequest buildSenzingRequest() {
        def sampleRequestJson = AppUtils.readResource("senzing-request.json")
        return JsonUtils.deserializeJson(SenzingRequest.class, sampleRequestJson)
    }
}