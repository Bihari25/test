package com.uhg.ihr.centrihealth.api.service.fhir

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ArrayNode
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.service.FhirService
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.Extension
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.Procedure
import org.hl7.fhir.r4.model.ResourceType
import org.hl7.fhir.r4.model.ServiceRequest
import org.hl7.fhir.r4.model.Specimen

class ProcedureFhirMapperSpec extends BaseFhirSpecification {

    def text = "This medication is not working for me, I'd like to request a higher strength."

    def "procedure mapper happy path "() {

        given:
        Payload samplePayload = TestData.buildSamplePayload("procedure.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        Procedure procedure = getFirstBundleResource(bundle, ResourceType.Procedure)

        Identifier instanceId = getIdentifierFromList(procedure.getIdentifier(), Constants.INSTANCE_ID)
        Identifier referenceIds = getIdentifierFromList(procedure.getIdentifier(), Constants.REFERENCE_IDS)
        Identifier conditionInstanceId = getIdentifierFromList(procedure.getIdentifier(), Constants.RELATED_CONDITION_INSTANCE_IDS)
        Identifier observationInstanceId = getIdentifierFromList(procedure.getIdentifier(), Constants.RELATED_OBSERVATION_INSTANCE_IDS)
        Identifier careTeamInstanceId = getIdentifierFromList(procedure.getIdentifier(), Constants.RELATED_CARE_TEAM_INSTANCE_IDS)
        Identifier sfpInstanceId = getIdentifierFromList(procedure.getIdentifier(), Constants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS)

        Extension healthItem = getExtensionFromList(procedure.getExtension(), Constants.IHR_PROCEDURE_CATEGORY_TEXT)
        Extension presenceState = getExtensionFromList(procedure.getExtension(), Constants.PRESENCE_STATE_TERM_URL)
        Extension clinicallyRelevantDate = getExtensionFromList(procedure.getExtension(), Constants.CLINICALLY_RELEVANT_DATE_URL)
        String clinicallyRelevantDateValue = clinicallyRelevantDate.castToDateTime(clinicallyRelevantDate.getValue()).getValueAsString()
        ArrayNode relatedConditionInstanceIds = MAPPER.readTree(conditionInstanceId.getValue()) as ArrayNode
        Coding code = getCodingFromList(procedure.getCode().getCoding(), Constants.CPTHCPCS_CODE_URL)
        String performedDate = procedure.getPerformedDateTimeType().getValueAsString()

        ServiceRequest serviceRequest = procedure.getBasedOn().get(0).getResource()
        def authoredOn = serviceRequest.getAuthoredOnElement().getValueAsString()

        Specimen specimen = serviceRequest.getSpecimen().get(0).getResource()
        Coding type = getCodingFromList(specimen.getType().getCoding(), "Blood")

        Extension extensionSen = getExtensionFromList(procedure.getExtension(), Constants.SENSITIVITY_CLASSES_URL)
        Extension extensionDat = getExtensionFromList(procedure.getExtension(), Constants.DATA_SOURCE_URL)

        expect:
        instanceId.getValue().toString() == "19724674502241"
        relatedConditionInstanceIds.size() == 2
        relatedConditionInstanceIds.get(1).asInt() == 789
        healthItem.getValue().toString() == "Billing Service"
        authoredOn.substring(0, 10) == "2019-01-24"
        type.getSystem() == "SNOMEDCT Specimen Foreign Key"
        code.getSystem() == Constants.CPTHCPCS_CODE_URL
        performedDate.substring(0, 10) == "2019-01-24"
        presenceState.getUrl().toString() == Constants.PRESENCE_STATE_TERM_URL
        clinicallyRelevantDateValue.substring(0, 10) == "2019-10-15"
        referenceIds.getValue().toString() == "[\"2019-01-02T03:04:44Z-Rally-1sE\"]"
        conditionInstanceId.getValue().toString() == "[123456,789]"
        observationInstanceId.getValue().toString() == "[7123456,7689]"
        careTeamInstanceId.getValue().toString() == "[2110756776942227460,2110756776942227460]"
        sfpInstanceId.getValue().toString() == "[13356001458,525266262]"
        extensionSen.getValue().toString() == "[\"Substance Abuse\"]"
        extensionDat.getValue().toString() == "[\"System Interface Data Acquisition Method\"]"
    }
}