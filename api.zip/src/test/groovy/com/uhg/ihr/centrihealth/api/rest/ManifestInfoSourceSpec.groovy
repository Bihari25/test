package com.uhg.ihr.centrihealth.api.rest

import spock.lang.Specification

class ManifestInfoSourceSpec extends Specification {
    ManifestInfoSource manifestInfoSource = new ManifestInfoSource()

    def "ManifestInfoSource :: getSource happy path"() {
        when:
        def result = manifestInfoSource.getSource()

        then:
        result
    }
}