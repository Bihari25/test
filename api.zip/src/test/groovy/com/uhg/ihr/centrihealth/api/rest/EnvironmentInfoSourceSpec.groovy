package com.uhg.ihr.centrihealth.api.rest

import spock.lang.Specification

class EnvironmentInfoSourceSpec extends Specification {
    EnvironmentInfoSource environmentInfoSource = new EnvironmentInfoSource()

    def "EnvironmentInfoSource :: getSource happy path"() {
        when:
        def result = environmentInfoSource.getSource()
        then:
        result
    }
}