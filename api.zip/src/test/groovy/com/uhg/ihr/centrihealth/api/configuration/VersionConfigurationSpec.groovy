package com.uhg.ihr.centrihealth.api.configuration

import spock.lang.Specification

class VersionConfigurationSpec extends Specification {
    VersionConfiguration versionConfig = new VersionConfiguration(dataVersion: "1.0.1", schemaVersion: "1.0.2")

    def "Method to test getters/setter"() {
        when:
        VersionConfiguration versionConfiguration = versionConfig

        then:
        versionConfiguration.getDataVersion() == "1.0.1"
        versionConfiguration.getSchemaVersion() == "1.0.2"
    }

    def "Method to test toString"() {
        when:
        def result = versionConfig.toString()

        then:
        result.contains("VersionConfiguration(dataVersion=1.0.1, schemaVersion=1.0.2)")
    }
}
