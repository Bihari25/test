package com.uhg.ihr.centrihealth.api.filter

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.fasterxml.jackson.databind.node.TextNode
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.util.TestData
import spock.lang.Specification
import spock.lang.Unroll

@Unroll
class ClinicallyRelevantDateFilterSpec extends Specification {

    TestData testData = new TestData()

    def "filter happy path scenarios: #desc"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']['medications'][0]
        ClinicallyRelevantDateFilter clinicallyRelevantDateFilter = new ClinicallyRelevantDateFilter(startDate, endDate)

        when:
        def result = clinicallyRelevantDateFilter.filter(dataNode)

        then:
        result == expectedResult

        where:
        desc                                     | startDate    | endDate      || expectedResult
        "CRDate with in same start and end date" | '2018-12-25' | '2018-12-25' || true
        "CRDate with in start and end date"      | '2018-01-15' | '2018-12-25' || true
        "CRDate before start and end date"       | '2018-12-26' | '2018-12-31' || false
        "CRDate after start and end date"        | '2018-01-15' | '2018-12-24' || false
    }

    def "filter empty clinical relevant date edge case: #desc"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']['medications'][0]
        dataNode.putAt('clinicallyRelevantDate', crdValue)

        ClinicallyRelevantDateFilter clinicallyRelevantDateFilter = new ClinicallyRelevantDateFilter('2018-12-25', '2018-12-25')

        when:
        def result = clinicallyRelevantDateFilter.filter(dataNode)

        then:
        result == true

        where:
        desc                                   | crdValue
        "Null clinically relevant date"        | null
        "Empty space clinically relevant date" | new TextNode(" ")
        "Empty clinically relevant date"       | new TextNode("")
    }

    def "filter for if there is no clinical relevant date edge case"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']['medications'][0]
        ((ObjectNode)dataNode).remove('clinicallyRelevantDate')

        ClinicallyRelevantDateFilter clinicallyRelevantDateFilter = new ClinicallyRelevantDateFilter('2018-12-25', '2018-12-25')

        when:
        def result = clinicallyRelevantDateFilter.filter(dataNode)

        then:
        result == false
    }

    def "constructor start and end failure path scenarios: #desc"() {
        when:
        ClinicallyRelevantDateFilter clinicallyRelevantDateFilter = new ClinicallyRelevantDateFilter(startDate, endDate)

        then:
        IhrBadRequestException ihrBadRequestEx = thrown()
        ihrBadRequestEx.message.contains("Invalid date format either in start/end date; exception: Unable to parse the date: ".concat(exMessage))

        where:
        desc                         | startDate    | endDate      || exMessage
        "Invalid start date"         | '2018-12/25' | '2018-12-25' || '2018-12/25'
        "Invalid end date"           | '2018-01-15' | '2018/12-25' || '2018/12-25'
        "Invalid start and end date" | '2018/12/26' | '2018/12-31' || '2018/12/26'
    }

    def "Invalid clinically relevant date patterns scenarios: #desc"() {
        given:
        ClinicallyRelevantDateFilter crdFilter = new ClinicallyRelevantDateFilter(startDate, endDate)
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']['medications'][0]
        dataNode.putAt('clinicallyRelevantDate', new TextNode(crdDate))

        when:
        def result = crdFilter.filter(dataNode)

        then:
        IhrBadRequestException ihrBadRequestEx = thrown()
        ihrBadRequestEx.message.contains("Invalid clinical relevant date format from data node of payload; exception: Unable to parse the date: ".concat(crdDate))

        where:
        desc               | startDate    | endDate      | crdDate
        "Invalid crd date" | '2018-12-25' | '2018-12-25' | '2018-12/25'
    }

    def "Start & End date range scenarios: #desc"() {
        when:
        ClinicallyRelevantDateFilter clinicallyRelevantDateFilter = new ClinicallyRelevantDateFilter(startDate, endDate)

        then:
        IhrBadRequestException ihrBadRequestEx = thrown()
        ihrBadRequestEx.message.contains("Invalid date range start date is after (greater than) end date.")

        where:
        desc                               | startDate    | endDate
        "Start date greater than End Date" | '2018-12-25' | '2018-12-23'
    }

}
