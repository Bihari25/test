package com.uhg.ihr.centrihealth.api;

import io.micronaut.http.client.HttpClientConfiguration;
import io.micronaut.runtime.ApplicationConfiguration;

import javax.inject.Singleton;
import java.time.Duration;

@Singleton
public class WireMockHttpClientConfiguration extends HttpClientConfiguration {

    public WireMockHttpClientConfiguration(ApplicationConfiguration applicationConfiguration) {
        super(applicationConfiguration);
        this.setReadTimeout(Duration.ofSeconds(60));
    }

    @Override
    public ConnectionPoolConfiguration getConnectionPoolConfiguration() {
        return new ConnectionPoolConfiguration();
    }
}
