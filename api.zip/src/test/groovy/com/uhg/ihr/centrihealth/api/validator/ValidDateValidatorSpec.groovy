package com.uhg.ihr.centrihealth.api.validator

import spock.lang.Specification
import spock.lang.Unroll

class ValidDateValidatorSpec extends Specification {

    @Unroll
    void "it validate the date format as #desc"() {
        given:
        def validDateValidator = new ValidDateValidator()
        expect:
        validDateValidator.isValid(dateValues, null) == expected
        where:
        desc             | dateValues   || expected
        "VALID_FORMAT"   | "2013/09/09" || true
        "INVALID_FORMAT" | "09/12/1920" || false
        "INVALID_FORMAT" | "07/12/20"   || false
        "INVALID_FORMAT" | "20-20-2020" || false
        "INVALID_FORMAT" | "2012-12-05" || false
        "EMPTY"          | ""           || false
        "EMPTY"          | "  "         || false
        "null"           | null         || false
        "INVALID_ENTRY"  | "abcd"       || false
    }
}
