package com.uhg.ihr.centrihealth.api.service.fhir

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ArrayNode
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.service.FhirService
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.Extension
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.Immunization
import org.hl7.fhir.r4.model.Quantity
import org.hl7.fhir.r4.model.ResourceType

class ImmunizationsFhirMapperSpec extends BaseFhirSpecification {

    def "immunizations mapper happy path "() {

        given:
        Payload samplePayload = TestData.buildSamplePayload("immunizations.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        Immunization immunization = getFirstBundleResource(bundle, ResourceType.Immunization)

        String lastUpdated = getLastUpdateDate(immunization.getMeta())
        Identifier instanceId = getIdentifierFromList(immunization.getIdentifier(), Constants.INSTANCE_ID)
        Identifier careTeamInstanceId = getIdentifierFromList(immunization.getIdentifier(), Constants.RELATED_CARE_TEAM_INSTANCE_IDS)
        Identifier referenceIds = getIdentifierFromList(immunization.getIdentifier(), Constants.REFERENCE_IDS)
        Identifier sourceClaimIds = getIdentifierFromList(immunization.getIdentifier(), Constants.SOURCE_CLAIM_IDS)
        Identifier observationInstanceId = getIdentifierFromList(immunization.getIdentifier(), Constants.RELATED_OBSERVATION_INSTANCE_IDS)
        Identifier sfpInstanceId = getIdentifierFromList(immunization.getIdentifier(), Constants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS)

        Identifier conditionInstanceId = getIdentifierFromList(immunization.getIdentifier(), Constants.RELATED_CONDITION_INSTANCE_IDS)
        ArrayNode relatedConditionInstanceIds = MAPPER.readTree(conditionInstanceId.getValue()) as ArrayNode
        Extension dosageFreq = getExtensionFromList(immunization.getExtension(), ImmunizationFhirMapper.DOSAGE_FREQUENCY_URL)
        Extension extensionDat = getExtensionFromList(immunization.getExtension(), Constants.DATA_SOURCE_URL)
        Extension extensionSen = getExtensionFromList(immunization.getExtension(), Constants.SENSITIVITY_CLASSES_URL)
        Extension genericFlag = getExtensionFromList(immunization.getExtension(), Constants.GENERIC_FLAG_URL)
        Boolean genericFlagValue = genericFlag.castToBoolean(genericFlag.getValue()).getValue()
        Extension doseUnit = getExtensionFromList(immunization.getExtension(), ImmunizationFhirMapper.DOSAGE_UNIT_URL)
        CodeableConcept doseUnitConcept = doseUnit.castToCodeableConcept(doseUnit.getValue())
        Coding doseUnitCode = getCodingFromList(doseUnitConcept.getCoding(), "IHR Ontology")

        Quantity dosageQuantity = immunization.getDoseQuantity()
        Coding vaccineCode = getCodingFromList(immunization.getVaccineCode().getCoding(), "NDC Foreign Key")
        def occurenceDate = immunization.getOccurrenceDateTimeType().getValueAsString()

        expect:
        lastUpdated.substring(0, 10) == "2019-02-15"
        instanceId.getValue().toString() == "19190818001542"
        relatedConditionInstanceIds.size() == 2
        relatedConditionInstanceIds.get(0).asInt() == 123456
        !genericFlagValue
        doseUnitCode.getCode().toString() == "mcg/mL"
        dosageQuantity.getValue() == 1.0
        vaccineCode.getCode().toString() == "49281040010"
        dosageFreq.getValue().toString() == "nightly at bedtime"
        occurenceDate.substring(0, 10) == "2019-02-15"
        careTeamInstanceId.getValue().toString() == "[2110756776942227460,2110756776942227460,2110756776942227460]"
        referenceIds.getValue().toString() == "[\"2019-01-02T03:04:44Z-Rally-1sE\"]"
        sourceClaimIds.getValue().toString() == "[\"922190462038500\",\"918190509006000\",\"918190843574800\",\"918190843609900\",\"922190462038500\"]"
        observationInstanceId.getValue().toString() == "[7123456,7689]"
        sfpInstanceId.getValue().toString() == "[123456,789]"
        conditionInstanceId.getValue().toString() == "[123456,789]"
        extensionSen.getValue().toString() == "[\"Substance Abuse\"]"
        extensionDat.getValue().toString() == "[\"System Interface Data Acquisition Method\"]"
    }
}
