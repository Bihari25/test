package com.uhg.ihr.centrihealth.api.service.fhir

import com.fasterxml.jackson.databind.JsonNode
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.service.FhirService
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.Extension
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.Observation
import org.hl7.fhir.r4.model.ResourceType

class ObservationsFhirMapperSpec extends BaseFhirSpecification {

    def expected_recordKey = "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h"

    def "healthobservations mapper happy path "() {

        given:
        Payload samplePayload = TestData.buildSamplePayload("healthobservations.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        Observation observation = getFirstBundleResource(bundle, ResourceType.Observation)

        Identifier instanceId = getIdentifierFromList(observation.getIdentifier(), Constants.INSTANCE_ID)
        Identifier recordKey = getIdentifierFromList(observation.getIdentifier(), Constants.RECORD_KEY)
        Identifier referenceIds = getIdentifierFromList(observation.getIdentifier(), Constants.REFERENCE_IDS)
        Extension extension = getExtensionFromList(observation.getExtension(), ObservationFhirMapper.OBSERVATION_UNITS_URL)
        Coding code = getCodingFromList(observation.getCode().getCoding(), "LOINC Observation Foreign Key")
        def referenceRange = observation.getReferenceRange().get(0).getText().toString()
        def valueString = observation.getValue().toString()
        Coding interpretationCode = getCodingFromList(observation.getComponent().get(1).getInterpretation().get(0).getCoding(), "Abnormal")
        def effectiveDatetTime = observation.getEffectiveDateTimeType().getValueAsString()

        Extension extensionSen = getExtensionFromList(observation.getExtension(), Constants.SENSITIVITY_CLASSES_URL)
        Extension extensionDat = getExtensionFromList(observation.getExtension(), Constants.DATA_SOURCE_URL)

        expect:
        instanceId.getValue().toString() == "535644710"
        recordKey.getValue().toString() == expected_recordKey
        referenceRange == "3.8-10.8"
        valueString == "10.4"
        code.getCode().toString() == "6690-2"
        extension.getUrl() == "http://unitsofmeasure.org"
        interpretationCode.getDisplay().toString() == "Abnormal"
        effectiveDatetTime.substring(0, 10) == "2018-03-10"
        referenceIds.getValue().toString() == "[\"2019-01-02T03:04:44Z-Rally-1sE\"]"
        extensionSen.getValue().toString() == "[\"Substance Abuse\"]"
        extensionDat.getValue().toString() == "[\"System Interface Data Acquisition Method\"]"
    }
}
