package com.uhg.ihr.centrihealth.api.rest

import com.google.common.collect.ImmutableList
import com.uhg.ihr.centrihealth.api.WireMockBaseTest
import com.uhg.ihr.centrihealth.api.controller.ApiController
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.model.Big5
import com.uhg.ihr.centrihealth.api.model.Id
import com.uhg.ihr.centrihealth.api.model.IdType
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest
import com.uhg.ihr.centrihealth.util.TestData
import groovy.json.JsonSlurper
import io.micronaut.context.annotation.Property
import io.micronaut.http.HttpHeaders
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.HttpStatus
import io.micronaut.http.MediaType
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.test.annotation.MicronautTest
import spock.lang.Ignore
import spock.lang.Unroll

// see https://stackoverflow.com/questions/39636792/jvm-takes-a-long-time-to-resolve-ip-address-for-localhost/39698914#39698914
// if tests take a while

@MicronautTest
@Property(name = "micronaut.security.stargate.enabled", value = "false")
@Property(name = "ness.enabled", value = "false")
@Unroll
class ApiControllerSpec extends WireMockBaseTest {

    static Map<String, Big5> big5Map

    def setupSpec() {
        initBig5Map()
    }

    // remove senzing/data matching routes set after each test
    def cleanup() {
        clearMatches()
    }

    def "it gets version from header #desc"() {
        when:
        HttpHeaders headers = Mock(HttpHeaders)
        headers.accept() >> ImmutableList.of(MediaType.of(input))

        then:
        output == ApiController.getVersionFromHeader(headers)

        where:
        desc           | input                             || output
        "current"      | "application/json"                || 1
        "all"          | "*/*"                             || 1
        "version 1"    | "application/vnd.uhg.v1+json"     || 1
        "version 35"   | "application/vnd.uhg.v35+json"    || 35
        "doesnt match" | "application/vndasdasda.v35+json" || -1
    }

    def "it gets version from multiple headers #desc"() {
        when:
        HttpHeaders headers = Mock(HttpHeaders)
        headers.accept() >> input

        then:
        output == ApiController.getVersionFromHeader(headers)

        where:
        desc         | input                                                                                                      || output
        "one way"    | ImmutableList.of(MediaType.of("application/vnd.uhg.v1+json"), MediaType.of("application/vnd.uhg.v2+json")) || 2
        "other way"  | ImmutableList.of(MediaType.of("application/vnd.uhg.v2+json"), MediaType.of("application/vnd.uhg.v1+json")) || 2
        "vs current" | ImmutableList.of(MediaType.of("application/json"), MediaType.of("application/vnd.uhg.v2+json"))            || 2
    }

    def "it returns 406 when type isn't deliverable"() {
        when:
        HttpRequest req = baseRequest().accept(MediaType.of("application/vnd.nah.v1+json"))

        then:
        def caught = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hcre) {
            assert hcre.status == HttpStatus.GONE
            caught = true
        }

        caught
    }

    @Ignore
    //FIXME: inject mock for faster response?
    def "it returns media type and versions in 2.0 response"() {
        //match senzing and cause a basic ihr to return
        when:
        matchSenzingToChid(TestData.sampleBig5(), "ACT123")
        HttpRequest req = baseRequest().accept(MediaType.of("application/vnd.uhg.v2+json"))

        then:
        HttpResponse<String> rsp = httpClient.toBlocking().exchange(req, String.class)
        def jsonSlurper = new JsonSlurper()
        def body = jsonSlurper.parseText(rsp.getBody().get())
        "uhg.v2.4.0" == rsp.header("x-uhg-media-type")
        "0.0.1" == body.apiVersion
        "2.0.0" == body.dataVersion
        "2.4.0" == body.schemaVersion
        body.mbrId
    }

    def "it 404s when big5 doesnt match"() {
        when:
        notMatchSenzing(TestData.sampleBig5())
        HttpRequest req = baseRequest().accept(MediaType.of("application/vnd.uhg.v2+json"))

        then:
        def exceptionThrown = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hcre) {
            assert hcre.getMessage().contains('unable to match user')
            assert 404 == hcre.getResponse().getStatus().code
            assert hcre.getResponse().getBody(String.class).get().contains('unable to match user or requestee: Unable to find ihr identifier (IhrId) because senzing response search results are empty')
            exceptionThrown = true
        }

        exceptionThrown
    }

    def "it 500s on overall timeout"() {
        when:
        senzingTimeout()
        HttpRequest req = baseRequest().accept(MediaType.of("application/vnd.uhg.v2+json"))

        then:
        def exceptionThrown = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hcre) {
            assert hcre.getMessage().contains('Request timed out after 8500ms')
            assert 500 == hcre.getResponse().getStatus().code
            assert hcre.getResponse().getBody(String.class).get().contains('Request timed out after 8500ms')
            exceptionThrown = true
        }

        exceptionThrown
    }

    @Ignore
    //FIXME: inject mock for faster error response
    def "it 500s when payload has an issue"() {
        when:
        matchSenzingToChid(TestData.sampleBig5(), TestData.randomChid())
        HttpRequest req = baseRequest().accept(MediaType.of("application/json"))

        then:
        def exceptionThrown = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hcre) {
            assert hcre.getMessage().contains('Request timed out after 8500ms')
            assert 500 == hcre.getResponse().getStatus().code
            assert hcre.getResponse().getBody(String.class).get().contains('Request timed out after 8500ms')
            exceptionThrown = true
        }

        exceptionThrown
    }

    def "it 500s when senzing has an issue"() {
        when:
        clearMatches()
        errorSenzing(TestData.sampleBig5())
        HttpRequest req = baseRequest().accept(MediaType.of("application/vnd.uhg.v2+json"))

        then:
        def exceptionThrown = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hce) {
            assert hce.getMessage().contains('error with the identity service')
            assert 500 == hce.getResponse().getStatus().code
            assert hce.getResponse().getBody(String.class).get().contains('error with the identity service')
            exceptionThrown = true
        }

        exceptionThrown
    }

    def "it builds senzing request #inputBig5"() {
        when:
        def big5 = big5Map.get(inputBig5)
        def req = SenzingRequest.buildSenzingRequest(big5)

        then:
        big5 != null
        req.getSearchId() == search_id
        if (null != req.getIdentifiers()) {
            req.getIdentifiers().size() == size
        }
        req.getMemberId() == mem_id
        req.getHcId() == hc_id
        req.getSubscriberId() == sub_id
        req.getSsnNumber() == ssn_id
        req.getMedicareBenfId() == mbi_id
        req.getNameFirst() == big5Base().firstName
        req.getNameLast() == big5Base().lastName
        req.getDateOfBirth() == big5Base().dateOfBirth

        where:
        inputBig5                          | search_id | size | mem_id     | sub_id         | hc_id  | ssn_id | mbi_id
        "Big5IdTypeSSN"                    | null      | 0    | null       | null           | null   | "SSN"  | null
        "Big5IdTypeMbi"                    | null      | 0    | null       | null           | null   | null   | "MBI"
        "Big5IdTypeMemberId"               | null      | 0    | "memberId" | null           | null   | null   | null
        "Big5IdTypeHcId"                   | null      | 0    | null       | null           | "hcId" | null   | null
        "Big5IdTypeSubscriberId"           | null      | 0    | null       | "subscriberId" | null   | null   | null
        "Big5IdTypeSearchIdIdsSSN"         | null      | 2    | null       | null           | null   | "SSN"  | null
        "Big5IdTypeNullIdsSSN"             | null      | 0    | null       | null           | null   | "SSN"  | null
        "Big5IdTypeSSNIdsSearchId"         | null      | 0    | null       | null           | null   | "SSN"  | null
        "Big5IdTypeSSNIdsSubcscriberIdMBI" | null      | 0    | "memberId" | "subscriberId" | null   | "SSN"  | "MBI"
    }

    def "Check if Identifier exists or not "() {
        when:
        def big5 = big5Map.get(inputBig5)
        def req = SenzingRequest.buildSenzingRequest(big5)

        then:
        big5 != null
        req.getSearchId() == search_id
        req.getIdentifiers().size() == size
        req.getIdentifiers().get(0).containsValue(identifiers_0)
        req.getIdentifiers().get(1).containsValue(identifiers_1)
        req.getMemberId() == mem_id
        req.getHcId() == hc_id
        req.getSubscriberId() == sub_id
        req.getSsnNumber() == ssn_id
        req.getMedicareBenfId() == mbi_id
        req.getNameFirst() == big5Base().firstName
        req.getNameLast() == big5Base().lastName
        req.getDateOfBirth() == big5Base().dateOfBirth

        where:
        inputBig5                           | search_id | size | identifiers_0 | identifiers_1 | mem_id     | sub_id         | hc_id  | ssn_id | mbi_id
        "Big5IdTypeSearchId"                | null      | 2    | "000searchId" | "searchId"    | null       | null           | null   | null   | null
        "Big5IdTypeSearchIdIdsMemberId"     | null      | 2    | "000searchId" | "searchId"    | "memberId" | null           | null   | null   | null
        "Big5IdTypeSearchIdIdsSubscriberId" | null      | 2    | "000searchId" | "searchId"    | null       | "subscriberId" | null   | null   | null
        "Big5IdTypeSearchIdIdsHcId"         | null      | 2    | "000searchId" | "searchId"    | null       | null           | "hcId" | null   | null
        "Big5IdTypeSearchIdIdsSSN"          | null      | 2    | "000searchId" | "searchId"    | null       | null           | null   | "SSN"  | null
        "Big5IdTypeSearchIdIdsMBI"          | null      | 2    | "000searchId" | "searchId"    | null       | null           | null   | null   | "MBI"
        "Big5IdTypeSearchIdAllIdsPresent"   | null      | 2    | "000searchId" | "searchId"    | "memberId" | "subscriberId" | "hcId" | "SSN"  | "MBI"

    }

    def "it sends bad request on id conflicts #inputBig5"() {
        when:
        def big5 = big5Map.get(inputBig5)
        def caught = false

        then:
        try {
            SenzingRequest.buildSenzingRequest(big5)
        } catch (IhrBadRequestException ibre) {
            assert ibre.getMessage().contains(conflicting_id)
            caught = true
        }

        caught

        where:
        inputBig5                          || conflicting_id
        //Duplicates
        "DuplicateSearchIdNullSearchIdNew" || "searchId"
        "DuplicateSearchIdOldSearchIdNew"  || "searchId"
        "DuplicateSearchIdNewSearchIdNew"  || "searchId"
        "DuplicateSSNOldSSNNew"            || "SSN"
        "DuplicateSSNNewSSNNew"            || "SSN"
    }

    def initBig5Map() {
        Id memberId = Id.builder().id("memberId").idType(IdType.memberId).build()
        Id subscriberId = Id.builder().id("subscriberId").idType(IdType.subscriberId).build()
        Id searchId = Id.builder().id("searchId").idType(IdType.searchId).build()
        Id ssn = Id.builder().id("SSN").idType(IdType.SSN).build()
        Id mbi = Id.builder().id("MBI").idType(IdType.MBI).build()
        Id hcId = Id.builder().id("hcId").idType(IdType.hcId).build()

        Map<String, Big5> map = new HashMap<>()
        map.put("searchIdAvailable", big5Base().searchId("searchId").build())
        map.put("IdTypeSearchId", big5Base().searchId("searchId").idType(IdType.searchId).build())
        map.put("Big5IdTypeSSN", big5Base().searchId("SSN").idType(IdType.SSN).build())
        map.put("Big5IdTypeMbi", big5Base().searchId("MBI").idType(IdType.MBI).build())
        map.put("Big5IdTypeMemberId", big5Base().searchId("memberId").idType(IdType.memberId).build())
        map.put("Big5IdTypeHcId", big5Base().searchId("hcId").idType(IdType.hcId).build())
        map.put("Big5IdTypeSubscriberId", big5Base().searchId("subscriberId").idType(IdType.subscriberId).build())

        map.put("Big5IdTypeSearchIdIdsSSN", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(ssn)).build())
        map.put("Big5IdTypeNullIdsSSN", big5Base().searchId("searchId")
                .ids(ImmutableList.of(ssn)).build())
        map.put("Big5IdTypeSSNIdsSearchId", big5Base().searchId("SSN").idType(IdType.SSN)
                .ids(ImmutableList.of(searchId)).build())
        map.put("Big5IdTypeSSNIdsSubcscriberIdMBI", big5Base().searchId("SSN").idType(IdType.SSN)
                .ids(ImmutableList.of(memberId, subscriberId, mbi)).build())


        //conflicting
        map.put("conflictingSearchIdNullMemberNew", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(memberId)).build())
        map.put("conflictingSearchIdOldMemberNew", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(memberId)).build())
        map.put("conflictingSearchIdOldSubscriberNew", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(subscriberId)).build())
        map.put("conflictingMemberOldSearchIdNew", big5Base().searchId("memberId").idType(IdType.memberId)
                .ids(ImmutableList.of(searchId)).build())
        map.put("conflictingSubscriberOldSearchIdNew", big5Base().searchId("subscriberId").idType(IdType.subscriberId)
                .ids(ImmutableList.of(searchId)).build())

        //Duplicates
        map.put("DuplicateSearchIdNullSearchIdNew", big5Base().searchId("searchId")
                .ids(ImmutableList.of(searchId)).build())
        map.put("DuplicateSearchIdOldSearchIdNew", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(searchId)).build())
        map.put("DuplicateSearchIdNewSearchIdNew", big5Base().searchId("SSN").idType(IdType.SSN)
                .ids(ImmutableList.of(searchId, searchId)).build())
        map.put("DuplicateSSNOldSSNNew", big5Base().searchId("SSN").idType(IdType.SSN)
                .ids(ImmutableList.of(ssn)).build())
        map.put("DuplicateSSNNewSSNNew", big5Base().searchId("memberId").idType(IdType.memberId)
                .ids(ImmutableList.of(ssn, ssn)).build())

        map.put("searchIdPresentMemberIdPresent", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(memberId)).build())
        map.put("searchIdPresentHcIdPresent", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(hcId)).build())
        map.put("searchIdPresentSubIdPresent", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(subscriberId)).build())
        map.put("searchIdPresentSSNIdPresent", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(ssn)).build())
        map.put("searchIdPresentMBIPresent", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(mbi)).build())
        map.put("searchIdPresentAndAllIdPresent", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(memberId, hcId, subscriberId, ssn, mbi)).build())
        map.put("searchIdAbsentMBIIsSearchIdAndAllIdPresent", big5Base().searchId("searchId").idType(IdType.MBI)
                .ids(ImmutableList.of(memberId, hcId, subscriberId, ssn)).build())
        map.put("Big5IdTypeSearchId", big5Base().searchId("searchId").idType(IdType.searchId).build())
        map.put("Big5IdTypeSearchIdIdsMemberId", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(memberId)).build())
        map.put("Big5IdTypeSearchIdIdsSubscriberId", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(subscriberId)).build())
        map.put("Big5IdTypeSearchIdIdsHcId", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(hcId)).build())
        map.put("Big5IdTypeSearchIdIdsSSN", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(ssn)).build())
        map.put("Big5IdTypeSearchIdIdsMBI", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(mbi)).build())
        map.put("Big5IdTypeSearchIdAllIdsPresent", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(memberId, hcId, subscriberId, ssn, mbi)).build())

        //build new
        /*map.put("memberSsn", big5Base().ids(ImmutableList.of(memberId, ssn)).build())
        map.put("searchSsn", big5Base().ids(ImmutableList.of(searchId, ssn)).build())
        map.put("searchMbi", big5Base().ids(ImmutableList.of(searchId, mbi)).build())
        map.put("memberSubSsnMbi", big5Base().ids(ImmutableList.of(memberId, subscriberId, ssn, mbi)).build())
        //conflicts/duplicates
        //new only
        map.put("member2x", big5Base().ids(ImmutableList.of(memberId, memberId)).build())
        map.put("memberSearch", big5Base().ids(ImmutableList.of(memberId, searchId)).build())
        map.put("searchSubscriber", big5Base().ids(ImmutableList.of(searchId, subscriberId)).build())*/

        //new and old
        /*map.put("searchOldNew", big5Base().searchId("searchId")
                .ids(ImmutableList.of(searchId)).build())
        map.put("memberOldNew", big5Base().searchId("memberId").idType(IdType.memberId)
                .ids(ImmutableList.of(searchId)).build())
        map.put("searchOldMemberNew", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(memberId)).build())
        map.put("subscriberOldSearchNew", big5Base().searchId("subscriberId").idType(IdType.subscriberId)
                .ids(ImmutableList.of(searchId)).build())*/

        big5Map = map
    }

    def "it builds senzing request when searchId exists #inputBig5"() {
        when:
        def big5 = big5Map.get(inputBig5)
        def req = SenzingRequest.buildSenzingRequest(big5)

        then:
        big5 != null
        req.getMemberId() == mem_id
        req.getHcId() == hc_id
        req.getAltMemberId() == mem_id
        req.getIdentifiers().size() == size
        req.getSearchId() == null
        req.getSsnNumber() == ssn_id
        req.getMedicareBenfId() == mbi_id
        req.getNameFirst() == big5Base().firstName
        req.getNameLast() == big5Base().lastName
        req.getDateOfBirth() == big5Base().dateOfBirth

        where:
        inputBig5                        | mem_id     | sub_id         | hc_id  | ssn_id | mbi_id | size | search_id | new_search
        "searchIdPresentMemberIdPresent" | "memberId" | null           | null   | null   | null   | 2    | null      | true
        "searchIdPresentHcIdPresent"     | null       | null           | "hcId" | null   | null   | 2    | null      | true
        "searchIdPresentSubIdPresent"    | null       | "subscriberId" | null   | null   | null   | 2    | null      | true
        "searchIdPresentSSNIdPresent"    | null       | null           | null   | "SSN"  | null   | 2    | null      | true
        "searchIdPresentMBIPresent"      | null       | null           | null   | null   | "MBI"  | 2    | null      | true
        "searchIdPresentAndAllIdPresent" | "memberId" | "subscriberId" | "hcId" | "SSN"  | "MBI"  | 2    | null      | true
    }

    def "it builds senzing request when search Id does not exists #inputBig5"() {
        when:
        def big5 = big5Map.get(inputBig5)
        def req = SenzingRequest.buildSenzingRequest(big5)

        then:
        big5 != null
        req.getMemberId() == mem_id
        req.getHcId() == hc_id
        req.getAltMemberId() == mem_id
        req.getSearchId() == search_id
        req.getSsnNumber() == ssn_id
        req.getMedicareBenfId() == mbi_id
        req.getNameFirst() == big5Base().firstName
        req.getNameLast() == big5Base().lastName
        req.getDateOfBirth() == big5Base().dateOfBirth

        where:
        inputBig5                                    | mem_id     | sub_id         | hc_id  | ssn_id | mbi_id     | search_id
        "searchIdAbsentMBIIsSearchIdAndAllIdPresent" | "memberId" | "subscriberId" | "hcId" | "SSN"  | "searchId" | null
    }

    // for the status endpoint. testing here since spinning up the Micronaut app is heavy/relatively slow
    def "it returns 200 on the status endpoint"() {
        when:
        HttpRequest req = HttpRequest.GET("/status")

        then:
        HttpResponse<String> rsp = httpClient.toBlocking().exchange(req, String.class)
        200 == rsp.getStatus().code
    }

    @Ignore //for now, works locally but timeout on jenkins
    def "it returns 401 when trying to reset a user's data"() {
        when:
        HttpRequest req = HttpRequest.PUT("/individual-health-records/v1.0/123MOCK123/reset", "")
        HttpResponse<String> rsp = httpClient.toBlocking().exchange(req, String.class)

        then:
        def error = thrown(HttpClientResponseException)
        error.getMessage() == "Unauthorized"
    }
}
