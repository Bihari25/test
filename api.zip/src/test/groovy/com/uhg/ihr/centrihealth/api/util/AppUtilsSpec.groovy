package com.uhg.ihr.centrihealth.api.util

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.service.fhir.BaseFhirSpecification
import net.minidev.json.JSONArray
import net.minidev.json.parser.JSONParser
import net.minidev.json.parser.ParseException
import org.apache.commons.lang3.time.DateUtils
import spock.lang.Unroll

@Unroll
class AppUtilsSpec extends BaseFhirSpecification {


    def "parseInputDate happy path : #scenario"() {
        when:
        def result = parseInputDate(inputValue, "no exception")

        then:
        result

        where:
        scenario               | inputValue
        "Valid date value"     | "2019-12-25"
        "Valid iso date value" | "2019-12-25 10:21:23"
    }

    def "parseInputDate exception path : #scenario"() {
        when:
        parseInputDate(inputValue, exceptionMsg)

        then:
        IhrBadRequestException ihrBadRequestEx = thrown()
        ihrBadRequestEx.message.contains(exceptionMsg)

        where:
        scenario                                 | inputValue          | exceptionMsg
        "Valid text value"                       | "test value"        | "Non date value"
        "Invalid date without days"              | "2018-12"           | "Date value without day"
        "Invalid date without month"             | "2018--12"          | "Date value without month"
        "Invalid iso date value only hours"      | "2019-12-25 12"     | "Date value only hours"
        "Invalid iso date value without minutes" | "2019-12-25 12::12" | "Date value only hours without minutes"
        "Invalid iso date value without seconds" | "2019-12-25 12:25"  | "Date value only hours without seconds"
        "Invalid date value separator /"         | "2019/12/25"        | "Invalid date value separator /"
        "Invalid date value separator -/"        | "2019-12/25"        | "Invalid date value separator /"
        "Empty date value"                       | ""                  | "Empty date value"
        "Null date value"                        | null                | "Null date value"
    }

    def "AppUtils::isDateInBetween : #scenario"() {
        given:
        def startDateValue = parseInputDate(startDate, "no exception")
        def endDateValue = parseInputDate(endDate, "no exception")
        def crDateValue = parseInputDate(crDate, "no exception")

        when:
        def result = AppUtils.isDateInBetween(startDateValue, endDateValue, crDateValue)

        then:
        result == expectedResult

        where:
        scenario                      | startDate    | endDate      | crDate       || expectedResult
        "CR Date with in range"       | "2018-12-25" | "2019-12-25" | "2019-02-27" || true
        "CR Date equal to start date" | "2018-12-25" | "2019-12-25" | "2018-12-25" || true
        "CR Date equal to end date"   | "2018-12-25" | "2019-12-25" | "2019-12-25" || true
        "CR Date before start date"   | "2018-12-25" | "2019-12-25" | "2018-12-24" || false
        "CR Date after end date"      | "2018-12-25" | "2019-12-25" | "2019-12-26" || false
    }

    def "TEST json escape "() {

        when:
        def strList = ["Brain Disorder", "Brain Disorder, Health"] as List<String>
        def sinList = ["Brain Disorder, Health"] as List<String>
        def intList = [5112345, 5112343, 5112341] as List<Integer>

        then:
        def strListJson = AppUtils.jsonEscape(strList)
        def sinListJson = AppUtils.jsonEscape(sinList)
        def intListJson = AppUtils.jsonEscape(intList)

        expect:
        strListJson == "[\"Brain Disorder\",\"Brain Disorder, Health\"]"
        def aList = getStrList(strListJson)
        strList.forEach( {e -> aList.contains(e)})

        sinListJson == "[\"Brain Disorder, Health\"]"
        def sList = getStrList(strListJson)
        strList.forEach( {e -> sList.contains(e)})

        intListJson == "[5112345,5112343,5112341]"
        def iList = getStrList(strListJson)
        strList.forEach( {e -> iList.contains(e)})
    }

    static List<String> getStrList(String value) throws ParseException {
        JSONParser parser = new JSONParser()
        JSONArray jsonArray = (JSONArray) parser.parse(value)
        List<String> strList = new ArrayList<>()
        for (Object ff : jsonArray) {
            strList.add((String)ff)
        }
        return strList
    }

    static List<Integer> getIntList(String value) throws ParseException {
        JSONParser parser = new JSONParser()
        JSONArray jsonArray = (JSONArray) parser.parse(value)
        List<Integer> intList = new ArrayList<>()
        for (Object ff : jsonArray) {
            intList.add((Integer)ff)
        }
        return intList
    }

    static Date parseInputDate(String filterDate, String exceptionMessage) throws IhrBadRequestException {
        Date date

        try {
            date = DateUtils.parseDateStrictly(filterDate, AppUtils.DATE_PATTERNS)
        } catch (Exception ex) {
            throw new IhrBadRequestException(exceptionMessage.concat(ex.getMessage()))
        }

        return date
    }

}
