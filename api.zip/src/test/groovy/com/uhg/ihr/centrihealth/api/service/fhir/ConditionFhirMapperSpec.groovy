package com.uhg.ihr.centrihealth.api.service.fhir

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ArrayNode
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.service.FhirService
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.Condition
import org.hl7.fhir.r4.model.Extension
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.ResourceType

class ConditionFhirMapperSpec extends BaseFhirSpecification {

    def "condition mapper happy path "() {

        given:
        Payload samplePayload = TestData.buildSamplePayload("conditions.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses'] as JsonNode
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        Condition cd = getFirstBundleResource(bundle, ResourceType.Condition)

        Identifier identifier1 = getIdentifierFromList(cd.getIdentifier(), Constants.INSTANCE_ID)
        Identifier identifier2 = getIdentifierFromList(cd.getIdentifier(), Constants.RECORD_KEY)
        Identifier identifier3 = getIdentifierFromList(cd.getIdentifier(), Constants.RELATED_CARE_TEAM_INSTANCE_IDS)
        Identifier referenceId = getIdentifierFromList(cd.getIdentifier(), Constants.REFERENCE_IDS)
        Identifier conditionInstanceId = getIdentifierFromList(cd.getIdentifier(), Constants.RELATED_CONDITION_INSTANCE_IDS)
        Identifier observationInstanceId = getIdentifierFromList(cd.getIdentifier(), Constants.RELATED_OBSERVATION_INSTANCE_IDS)
        Identifier careTeamInstanceId = getIdentifierFromList(cd.getIdentifier(), Constants.RELATED_CARE_TEAM_INSTANCE_IDS)
        Identifier sourceClaimIds = getIdentifierFromList(cd.getIdentifier(), Constants.SOURCE_CLAIM_IDS)

        ArrayNode ids = MAPPER.readTree(identifier3.getValue()) as ArrayNode

        Coding codelist = getCodingFromList(cd.getCode().getCoding(), "ICD10 Diagnosis Code")
        Extension presenceState = getExtensionFromList(cd.getExtension(), Constants.PRESENCE_STATE_TERM_URL)
        Extension status = getExtensionFromList(cd.getExtension(), Constants.STATUS_URL)
        CodeableConcept statusConcept = status.castToCodeableConcept(status.getValue())
        Coding statusCode = getCodingFromList(statusConcept.getCoding(), "Active")
        Extension clinicallyRelevantDate = getExtensionFromList(cd.getExtension(), Constants.CLINICALLY_RELEVANT_DATE_URL)
        String clinicallyRelevantDateValue = clinicallyRelevantDate.castToDateTime(clinicallyRelevantDate.getValue()).getValueAsString()

        Extension extensionSen = getExtensionFromList(cd.getExtension(), Constants.SENSITIVITY_CLASSES_URL)
        Extension extensionDat = getExtensionFromList(cd.getExtension(), Constants.DATA_SOURCE_URL)

        def recordeddate = cd.getRecordedDateElement().getValueAsString()
        String lastUpdated = getLastUpdateDate(cd.getMeta())

        expect:
        identifier1.getValue() == "9"
        ids.size() == 2
        codelist.getSystem() == "ICD10 Diagnosis Code"
        identifier2.getValue() == "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h"

        referenceId.getValue().toString() == "[\"2019-01-02T03:04:44Z-Rally-1sE\"]"
        conditionInstanceId.getValue().toString() == "[123456,789]"
        observationInstanceId.getValue().toString() == "[123456,789]"
        careTeamInstanceId.getValue().toString() == "[123456,789]"
        sourceClaimIds.getValue().toString() == "[\"123456\",\"789\"]"
        recordeddate.substring(0, 10) == "2019-02-18"
        presenceState.getValue().toString() == "Present"
        statusCode.getDisplay().toString() == "Active"
        clinicallyRelevantDateValue == "2019-02-18T00:00:00Z"
        lastUpdated.substring(0, 10) == "2020-05-03"
        extensionSen.getValue().toString() == "[\"Mental Behaviorial Disorder\"]"
        extensionDat.getValue().toString() == "[\"System Interface Data Acquisition Method\"]"
    }
}
