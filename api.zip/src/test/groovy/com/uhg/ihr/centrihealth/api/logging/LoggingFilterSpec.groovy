package com.uhg.ihr.centrihealth.api.logging

import com.uhg.ihr.centrihealth.api.configuration.VersionConfiguration
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.exception.IhrGoneException
import com.uhg.ihr.centrihealth.api.exception.IhrNotAcceptableException
import com.uhg.ihr.centrihealth.api.exception.IhrNotFoundException
import com.uhg.ihr.centrihealth.api.model.IhrApiRequest
import com.uhg.ihr.centrihealth.api.security.Encrypted
import com.uhg.ihr.centrihealth.api.security.Encryptor
import com.uhg.ihr.centrihealth.api.util.AppUtils
import com.uhg.ihr.centrihealth.util.TestData
import io.micronaut.http.HttpMethod
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpStatus
import io.micronaut.http.MutableHttpResponse
import io.micronaut.http.simple.SimpleHttpRequest
import io.micronaut.security.authentication.AuthenticationException
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

import javax.validation.ConstraintViolation
import javax.validation.ConstraintViolationException
import java.time.Instant

class LoggingFilterSpec extends Specification {

    @Shared
    def versionConfig = new VersionConfiguration(dataVersion: "1.0.1", schemaVersion: "1.0.2")

    @Shared
    def loggingFilter = new LoggingFilter(false, versionConfig, new Encryptor("testPublicKey"), new KafkaLoggerStub())

    def httpRequest = HttpRequest.POST("/read", TestData.sampleIhrApiRequest())
            .header("Accept", "application/vnd.uhg.v2+json")
            .header("optum-cid-ext", "Testing")

    def "initializeLogMap"() {
        setup:
        def res = Mock(MutableHttpResponse)

        when:
        if (sharing) {
            ((IhrApiRequest) httpRequest.getBody(IhrApiRequest.class).get()).requestor.searchId = "TSrch4321"
        }
        loggingFilter.initializeLogMap(httpRequest)
        loggingFilter.addAttribute(httpRequest, "startTime", Instant.now())
        loggingFilter.log(httpRequest, res, null)
        Map<String, Object> map = httpRequest.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())

        then:
        (map.get("requesteeSearchId") == "TSrch1234"
                && map.get("requesteeSearchId") == "TSrch1234"
                && map.get("requestorSearchId") == requestorSearchId
                && map.get("request-corr-id") == "CR1234"
                && map.get("sharing") == sharing) == expectedValue

        where:
        desc                || sharing || requestorSearchId || expectedValue
        'Happy Path'        || false   || "TSrch1234"       || true
        'Big5 sharing true' || true    || "TSrch4321"       || true
    }

    def "logFilter logs an encrypted json request"() {
        when:
        Encryptor encryptor = new Encryptor("testPublicKey", "testPrivateKey")
        def loggingFilter = new LoggingFilter(false, versionConfig, encryptor, new KafkaLoggerStub())
        loggingFilter.initializeLogMap(httpRequest)
        Map<String, Object> map = httpRequest.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())
        Encrypted big5 = (Encrypted) map.get("big5")

        // prove the big5 text, when decrypted, can be loaded directly back into a valid request
        def plaintext = encryptor.decrypt(big5)
        def newRequest = LoggingFilter.MAPPER.readValue(plaintext, IhrApiRequest.class)

        then:
        newRequest == TestData.sampleIhrApiRequest()
        plaintext.contains(TestData.sampleIhrApiRequest().getMbrId().getBig5().firstName)
        plaintext.contains(TestData.sampleIhrApiRequest().getMbrId().getBig5().dateOfBirth)
    }

    def "configures ness successfully"() {
        when:
        def nessLoggingFilter = new LoggingFilter(true, versionConfig, new Encryptor("testPublicKey"), new KafkaLoggerStub())
        def res = Mock(MutableHttpResponse)
        res.body(TestData.sampleIhrApiResponse())
        nessLoggingFilter.initializeNessLogMap(httpRequest)

        then:
        nessLoggingFilter.publishNessLog(httpRequest, res, null)
        //nessLoggingFilter.nessLogger.getAskId() == 'UHGWM110-025063'
    }

    @Unroll
    def "it logs httpStatus fail #desc"() {
        when:
        def req = HttpRequest.POST("/read", TestData.sampleIhrApiRequest())
                .header("Accept", "application/vnd.uhg.v2+json")
                .header("optum-cid-ext", "Testing")
        LoggingFilter.addErrorHttpStatus(req, null, inputEx)
        LoggingFilter.getAttribute(req, "httpStatus")
        def code = Integer.valueOf(LoggingFilter.getAttribute(req, "httpStatus").toString())

        then:
        code == expectedCode

        where:
        desc           | inputEx                                                                 || expectedCode
        'notFound'     | new IhrNotFoundException("oh no")                                       || 404
        'badRequest'   | new IhrBadRequestException("oh no")                                     || 400
        'invalid'      | new ConstraintViolationException(new HashSet<ConstraintViolation<?>>()) || 400
        'unacceptable' | new IhrNotAcceptableException("oh no")                                  || 406
        'unauthorized' | new AuthenticationException("oh no")                                    || 401
        'gone'         | new IhrGoneException("oh no")                                           || 410
        'unknown'      | new RuntimeException()                                                  || 500
    }

    @Unroll
    def "it logs httpStatus happy path #desc "() {
        given:
        MutableHttpResponse res = Mock(MutableHttpResponse)
        res.getStatus() >> status
        HttpRequest<IhrApiRequest> req = new SimpleHttpRequest<>(HttpMethod.POST, "http://hello.com/example", null)

        when:
        LoggingFilter.log(req, res, null)
        LoggingFilter.getAttribute(req, "httpStatus")
        def code = Integer.valueOf(LoggingFilter.getAttribute(req, "httpStatus").toString())

        then:
        code == expectedCode

        where:
        desc           | status                  || expectedCode
        'success'      | HttpStatus.OK           || 200
        'unauthorized' | HttpStatus.UNAUTHORIZED || 401
        'empty'        | null                    || 0
    }

    def "Test updateNessProperties : #scenario"() {

        given:
        def resourcePath = "config.properties"

        when:
        def inputStream = AppUtils.readResourceAsStream(resourcePath)
        def prop = LoggingFilter.updateNessProperties(inputStream)
        def result = ""
        if (prop != null) {
            result = prop.getProperty(property)
        }
        then:
        result == expectedResult

        where:
        scenario          | property                  || expectedResult
        "removed key"     | "truststore.ticket"       || null
        "password ket"    | "ssl.truststore.password" || "00001111"
        "location key"    | "ssl.truststore.location" || "./truststore.jks"
        "askid key"       | "askId"                   || "UHGWM110-025063"
        "application key" | "applicationName"         || "IHR-B50-API"
        "topic key"       | "TOPIC"                   || "com_eis_dasi_ness_producer_dev"
        "null key"        | "nulltest"                || null
    }

    def "logSuccess"() {
        given:
        def reason = "success"
        def method = "II"

        when:
        LoggingFilter.logStart(httpRequest, method)
        LoggingFilter.logSuccess(httpRequest, method)
        Map<String, Object> map = httpRequest.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())

        then:
        map.get(method + "Status") == reason
    }

    def "log Fail"() {
        given:
        def method = "senzing"
        def reason = "Not able to find id in senzing"

        when:
        LoggingFilter.logStart(httpRequest, method)
        LoggingFilter.logFail(httpRequest, method, reason)
        Map<String, Object> map = httpRequest.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())

        then:
        map.get(method + "Reason") == reason
    }

    def "setDuration Fail"() {
        given:
        def method = "senzing"

        when:
        LoggingFilter.setDuration(httpRequest, method)
        Map<String, Object> map = httpRequest.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())

        then:
        map.containsKey("logError")
    }

    def "setDuration Success"() {
        given:
        def method = "ii"

        when:
        LoggingFilter.logStart(httpRequest, method)
        LoggingFilter.setDuration(httpRequest, method)
        Map<String, Object> map = httpRequest.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())

        then:
        !map.containsKey(method + "_start")
    }
}