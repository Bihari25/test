package com.uhg.ihr.centrihealth.api.model


import spock.lang.Specification

class FilterPairSpec extends Specification {
    FilterPair sampleFilterPair = new FilterPair(key: 'ClinicalRelevantStartDate', value: '2019-11-17')

    def "FilterPair: getters/setter"() {
        when:
        FilterPair filterPair = sampleFilterPair

        then:
        filterPair.getKey() == "ClinicalRelevantStartDate"
        filterPair.getValue() == "2019-11-17"
    }

    def "FilterPair: toString"() {
        given:
        FilterPair filterPair = sampleFilterPair

        when:
        def result = filterPair.toString()

        then:
        result.contains("FilterPair(key=ClinicalRelevantStartDate, value=2019-11-17)")
    }
}