package com.uhg.ihr.centrihealth.api.model

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import spock.lang.Specification
import spock.lang.Unroll

import javax.validation.ConstraintViolation
import javax.validation.Validation
import javax.validation.Validator
import javax.validation.ValidatorFactory

class IhrApiResponseSpec extends Specification {

    @Unroll
    void "Check for Good Data"() {
        setup:
        def request = new IhrApiResponse()
        def memberId = new MId()
        memberId.setIdType idType
        memberId.setIdValue idValue
        def big5 = new Big5()
        memberId.setBig5 big5
        big5.setDateOfBirth dateOfBirth
        big5.setFirstName firstName
        big5.setLastName lastName
        big5.setPolicyNumber policyNum
        big5.setSearchId searchId
        request.setMbrId memberId
        request.setLanguage language
        request.setCorrelationId correlationId
        ObjectMapper MAPPER = new ObjectMapper()
        JsonNode payloadJson = MAPPER.readValue("{\"message\": \"hello\"}", JsonNode.class)
        request.setDataClasses payloadJson

        when:
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory()
        Validator validator = factory.getValidator()
        Set<ConstraintViolation<Big5>> violations = validator.validate(big5)

        then:
        violations.size() == 0
        request.getDataClasses() != null

        where:
        idType   | idValue   | dateOfBirth  | language | firstName | lastName | policyNum | searchId | correlationId | expected
        "type 1" | "value 1" | "1999/10/10" | "EN"     | "first"   | "last"   | "policy"  | "id"     | "unit test 1" | "The member id record may not be null."
    }

    def "Test Builder"() {
        setup:
        String correlationId = "unit test"
        String language = "EN"

        when:
        def response = IhrApiResponse.builder()
                .correlationId(correlationId)
                .language(language)
                .build()

        then:
        response.correlationId == correlationId
        response.getLanguage() == language
    }

    def "Test No Record Type"() {
        setup:
        def request = new IhrApiRequest()
        def memberId = new MId()
        memberId.setIdType "RALLYID"
        memberId.setIdValue "1"
        def big5 = new Big5()
        memberId.setBig5 big5
        big5.setDateOfBirth "1999/10/10"
        big5.setFirstName "first"
        big5.setLastName "last"
        big5.setPolicyNumber "policy"
        big5.setSearchId "search"
        request.setMbrId memberId
        request.setLanguage "EN"
        request.setCorrelationId "unit test"

        when:
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory()
        Validator validator = factory.getValidator()
        Set<ConstraintViolation<IhrApiRequest>> violations = validator.validate(request)

        then:
        violations.size() == 1
    }
}
