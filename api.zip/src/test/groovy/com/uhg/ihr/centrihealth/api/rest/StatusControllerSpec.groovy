package com.uhg.ihr.centrihealth.api.rest


import spock.lang.Specification

class StatusControllerSpec extends Specification {

    // see ApiControllerSpec def "it returns 200 on the status endpoint"()
    // added the test there to avoid spinning up the entire app just for the one minor test

}
