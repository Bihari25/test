package com.uhg.ihr.centrihealth.api.exception

import io.micronaut.http.HttpRequest
import io.micronaut.http.uri.UriBuilder
import spock.lang.Specification

class ErrorHelperSpec extends Specification {

    def "it handles the exception"() {
        when:
        HttpRequest mockHttpRequest = Mock(HttpRequest)
        mockHttpRequest.getUri() >> UriBuilder.of("http://testExample.com/ohno").build()
        RuntimeException re = new RuntimeException("oops!")
        def resultException = ErrorHelper.handleError(mockHttpRequest, re)
        def resultString = ErrorHelper.handleError(mockHttpRequest, "oops!")

        then:
        '{"errors":"oops!"}' == resultException.toString()
        '{"errors":"oops!"}' == resultString.toString()
    }
}