package com.uhg.ihr.centrihealth.api.service

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ObjectNode
import com.uhg.ihr.centrihealth.api.model.IhrApiResponse
import com.uhg.ihr.centrihealth.api.service.fhir.BaseFhirSpecification
import org.hl7.fhir.r4.model.Bundle
import spock.lang.Shared

class FhirServiceSpec extends BaseFhirSpecification {

    @Shared
    static final ObjectMapper MAPPER = new ObjectMapper()

    def "it errors when v2 parsing fails"() {
        when:
        ObjectNode payload = MAPPER.createObjectNode()
        payload.put("adverseReactions", "bad!")
        IhrApiResponse apiResponse = getApiResponse(payload)
        FhirService.fhirConvert(apiResponse)

        then:
        def e = thrown(RuntimeException)
        e.message == "Unable to parse v2 ihrApiResponse for FHIR conversion"
    }

    def "it ignores extra fields"() {
        when:
        ObjectNode payload = MAPPER.createObjectNode()
        payload.put("i_am_a_new_field", "bad!")
        IhrApiResponse apiResponse = getApiResponse(payload)

        then:
        FhirService.fhirConvert(apiResponse)
    }

    def "it creates a basic bundle"() {
        when:
        ObjectNode payload = MAPPER.createObjectNode()
        IhrApiResponse apiResponse = getApiResponse(payload)
        Bundle bundle = FhirService.fhirConvert(apiResponse)

        then:
        Bundle.BundleType.SEARCHSET == bundle.getType()
    }
}