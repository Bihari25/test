package com.uhg.ihr.centrihealth.api.service.fhir

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.model.dataclass.AdverseReaction
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthMedication
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm
import com.uhg.ihr.centrihealth.api.service.FhirService
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.instance.model.api.IBaseResource
import org.hl7.fhir.r4.model.*
import spock.lang.Shared
import spock.lang.Unroll
@Unroll
class MedicationStatementFhirMapperSpec extends BaseFhirSpecification {

    @Shared
    MedicationStatementFhirMapper mapper=MedicationStatementFhirMapper.of()

    def expectedrecordKey = "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h"

    def "medication mapper happy path "() {

        given:
        Payload samplePayload = TestData.buildSamplePayload("medications.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses'] as JsonNode
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))

        MedicationStatement ms = getFirstBundleResource(bundle, ResourceType.MedicationStatement)

        Period period = (Period) ms.getEffective()
        Identifier recordKey = getIdentifierFromList(ms.getIdentifier(), Constants.RECORD_KEY)
        Identifier referenceIds = getIdentifierFromList(ms.getIdentifier(), Constants.REFERENCE_IDS)
        Identifier careTeamInstanceId = getIdentifierFromList(ms.getIdentifier(), Constants.RELATED_CARE_TEAM_INSTANCE_IDS)
        Identifier sfpInstanceId = getIdentifierFromList(ms.getIdentifier(), Constants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS)
        Identifier conditionInstanceId = getIdentifierFromList(ms.getIdentifier(), Constants.RELATED_CONDITION_INSTANCE_IDS)
        Identifier deviceInstanceId = getIdentifierFromList(ms.getIdentifier(), Constants.RELATED_DEVICE_INSTANCE_IDS)
        Identifier allergiesInstanceId = getIdentifierFromList(ms.getIdentifier(), Constants.RELATED_ALLERGY_INSTANCE_IDS)

        def doseQuantity = ms.getDosageFirstRep().getDoseAndRate().get(0).getDoseQuantity().getValue()
        def dosageFreq = ms.getDosageFirstRep().getTiming().getCode().getCoding().get(0).getDisplay().toString()
        def lastUpdateDate = getLastUpdateDate(ms.getMeta())

        Extension presenceState = getExtensionFromList(ms.getExtension(), Constants.PRESENCE_STATE_TERM_URL)
        Extension genericFlag = getExtensionFromList(ms.getExtension(), Constants.GENERIC_FLAG_URL)
        Boolean genericFlagValue = genericFlag.castToBoolean(genericFlag.getValue()).getValue()
        Extension takenAsOrdered = getExtensionFromList(ms.getExtension(), Constants.TAKEN_AS_ORDERED_URL)
        Boolean takenAsOrderedValue = takenAsOrdered.castToBoolean(takenAsOrdered.getValue()).getValue()
        String firstDoseDateValue = period.getStartElement().getValueAsString()
        String endDateValue = period.getEndElement().getValueAsString()
        Extension holdDate = getExtensionFromList(period.getExtension(), Constants.IHR_HOLD_DATE_URL)
        String holdDateValue = holdDate.castToDateTime(holdDate.getValue()).getValueAsString()
        Extension restartedDate = getExtensionFromList(period.getExtension(), Constants.IHR_RESTART_DATE_URL)
        String restartedDateValue = restartedDate.castToDateTime(restartedDate.getValue()).getValueAsString()
        Extension adherenceStopDate = getExtensionFromList(ms.getExtension(), Constants.IHR_ADHERENCE_DATE_URL)
        String adherenceStopDateValue = adherenceStopDate.castToDateTime(adherenceStopDate.getValue()).getValueAsString()
        Extension status = getExtensionFromList(ms.getExtension(), Constants.STATUS_URL)
        CodeableConcept statusConcept = status.castToCodeableConcept(status.getValue())
        Coding statusCode = getCodingFromList(statusConcept.getCoding(), "Active")
        Extension clinicallyRelevantDate = getExtensionFromList(ms.getExtension(), Constants.CLINICALLY_RELEVANT_DATE_URL)
        String clinicallyRelevantDateValue = clinicallyRelevantDate.castToDateTime(clinicallyRelevantDate.getValue()).getValueAsString()
        Extension extensionSen = getExtensionFromList(ms.getExtension(), Constants.SENSITIVITY_CLASSES_URL)
        Extension extensionDat = getExtensionFromList(ms.getExtension(), Constants.DATA_SOURCE_URL)
        List<Extension> extensionMed = ((Medication) ((Reference) ms.getMedication()).getResource()).getExtension()
        Extension extensionDrug = getExtensionFromList(extensionMed, Constants.DRUG_CLASS_URL)

        Medication medication = (Medication) ms.getMedicationReference().getResource()
        Extension deaSchedule = getExtensionFromList(medication.getExtension(), Constants.DEA_SCHEDULE_URL)
        Extension genericDrugName = getExtensionFromList(medication.getExtension(), Constants.GENERIC_DRUG_URL)
        Coding code = getCodingFromList(medication.getCode().getCoding(), "152028")
        Coding form = getCodingFromList(medication.getForm().getCoding(), "C25158")
        Identifier conceptChid = getIdentifierFromList(medication.getIdentifier(), Constants.CONCEPT_CHID)

        MedicationRequest medicationRequest = (MedicationRequest) ms.getBasedOn().get(0).getResource()
        Duration expectedSupplyDuration = medicationRequest.getDispenseRequest().getExpectedSupplyDuration()
        String authoredOn = medicationRequest.getAuthoredOnElement().getValueAsString()

        Practitioner practitioner = (Practitioner) medicationRequest.getRequester().getResource()
        String orderingProviderName = practitioner.getName().get(0).getText()
        CodeableConcept practitionerType = practitioner.getIdentifierFirstRep().getType()
        Coding orderingNpi = getCodingFromList(practitionerType.getCoding(), Constants.NPI_URL)

        MedicationDispense medicationDispense = (MedicationDispense) ms.getPartOf().get(0).getResource()
        def medicationDispenseQuantity = medicationDispense.getQuantity().getValue()
        def dispenseExt = medicationDispense.getExtension().get(0)
        Coding dispensedQuantityUnit = getCodingFromList(medicationDispense.getType().getCoding(), "Capsule")

        Location location = (Location) medicationDispense.getLocation().getResource()
        String supplierOrganizationName = location.getName()
        CodeableConcept locationType = practitioner.getIdentifierFirstRep().getType()
        Coding supplierNpi = getCodingFromList(locationType.getCoding(), Constants.NPI_URL)

        Extension metaExtension = getExtensionFromList(ms.getMeta().getExtension(), Constants.MEDICATION_REVIEW_DATE_URL)
        def medicationReviewDate = ms.getDateAsserted()
        Identifier reviewBy = getIdentifierFromList(ms.getIdentifier(), Constants.EMPLOYEE_ID)
        Identifier actorIdentifier = getIdentifierFromList(ms.getIdentifier(), Constants.REVIEWER_IHR_ACTOR_ID)
        String metaExtValue = metaExtension.castToDateTime(metaExtension.getValue()).getValueAsString()
        def reviewByValue = reviewBy.getValue()
        def reviewByText = reviewBy.getType().getText()
        def reviewerIhrId = actorIdentifier.getValue()
        // RelatedPerson
        RelatedPerson relatedPerson = new RelatedPerson()
        relatedPerson.addRelationship(new CodeableConcept().setText("Caregiver"))
        ms.setInformationSource(new Reference(relatedPerson))
        def relatedPersonValue = getTextFromResource(ms)
        // PractitionerRole
        PractitionerRole practitionerRole = new PractitionerRole()
        practitionerRole.addCode().setText("Facility Staff")
        ms.setInformationSource(new Reference(practitionerRole))
        def practitionerRoleValue = getTextFromResource(ms)
        def subject = ms.getSubject().getResource()
        //added doseQuantityUnit & dosageRoute
        def doseQuantityUnit = ms.getDosageFirstRep().getDoseAndRate().get(0).getDoseQuantity().getUnit()
        CodeableConcept dosageRoute = ms.getDosageFirstRep().getRoute()
        Coding coding = getCodingFromList(dosageRoute.getCoding(), "oral")
        def dosageRouteSourceVocabulary = coding.getSystem()
        def dosageRouteIHRTerm = coding.getDisplay()
        def dosageRouteSourceVocabularyCode = coding.getCode()
        def dosageRouteLaymanTerm = dosageRoute.getText()

        expect:
        recordKey.getValue().toString() == expectedrecordKey
        doseQuantity == 1
        extensionDrug.getUrl() == Constants.DRUG_CLASS_URL
        dosageFreq == "QOD"
        expectedSupplyDuration.getValue() == 6
        lastUpdateDate.substring(0, 10) == "2019-02-17"
        code.getCode() == "152028"
        code.getSystem() == "2.16.840.1.113883.6.64"
        medicationDispenseQuantity == 8.0
        dispenseExt.getUrl() == "https://new-wiki.optum.com/display/IHRI/IHR+API+Refill+Count"
        dispenseExt.getValue().getProperties().get("valueAsNumber").toString() == "2.0"
        dispensedQuantityUnit.getSystem() == "HL7v2 Units - Table 0575"
        dispensedQuantityUnit.getCode() == "cap"
        dispensedQuantityUnit.getDisplay() == "Capsule"
        presenceState.getValue().toString() == "Past Occurrence"
        !genericFlagValue
        !takenAsOrderedValue
        firstDoseDateValue == "2018-03-28T00:00:00Z"
        endDateValue == "2020-10-28T00:00:00Z"
        holdDateValue == "2018-04-28T00:00:00Z"
        restartedDateValue == "2018-05-28T00:00:00Z"
        adherenceStopDateValue == "2019-06-28T00:00:00Z"
        statusCode.getDisplay().toString() == "Active"
        authoredOn.substring(0, 10) == "2018-03-28"
        form.getSystem() == "FDA Dosage Form Foreign Key"
        deaSchedule.getUrl() == Constants.DEA_SCHEDULE_URL
        deaSchedule.getValue().toString() == "Schedule IV Controlled Substance"
        genericDrugName.getUrl() == Constants.GENERIC_DRUG_URL
        genericDrugName.getValue().toString() == "Fluoxetine Oral Capsule 20 mg"
        orderingProviderName == "Bill Williamson"
        orderingNpi.getDisplay().toString() == "National Provider Identifier"
        supplierOrganizationName == "Walgreens #1092"
        supplierNpi.getDisplay().toString() == "National Provider Identifier"
        clinicallyRelevantDateValue == "2019-10-15T19:04:54Z"
        referenceIds.getValue().toString() == "[\"2019-01-02T03:04:44Z-Rally-1sE\"]"
        careTeamInstanceId.getValue().toString() == "[123456,789]"
        sfpInstanceId.getValue().toString() == "[123456,789]"
        conditionInstanceId.getValue().toString() == "[123456,789]"
        deviceInstanceId.getValue().toString() == "[123456,789,34]"
        allergiesInstanceId.getValue().toString() == "[123456, 789]"
        extensionDrug.getValue().toString() == "[\"Antidepressant\"]"
        extensionSen.getValue().toString() == "[\"Brain Disorder\",\"Mental/Behavioral Health, Disorder\"]"
        extensionDat.getValue().toString() == "[\"System Interface Data Acquisition Method\"]"
        !metaExtValue.isEmpty()
        metaExtValue == "2019-10-15T19:04:54Z"
        medicationReviewDate.toInstant().toString() == "2019-02-17T00:00:00Z"
        reviewByValue == "reviewedBy-12345"
        reviewerIhrId == "ACTP1234567"
        RelatedPersonEnum.ENUM_VALUES.contains(relatedPersonValue)
        PractitionerRoleEnum.ENUM_VALUES.contains(practitionerRoleValue)
        reviewByText == "employeeId"
        subject.fhirType() == ResourceType.Patient.toString()
        !subject.getIdElement().isEmpty()
        doseQuantityUnit == "mg"
        dosageRouteSourceVocabulary == "http://snomed.info/sct"
        dosageRouteSourceVocabularyCode == "26643006"
        dosageRouteIHRTerm == "oral"
        dosageRouteLaymanTerm == "oral"
        conceptChid.getValue().toString() == "MED15930"
    }

    static getTextFromResource(MedicationStatement ms) {
        IBaseResource resource = ((Reference) ms.getInformationSource()).getResource()
        if (resource instanceof RelatedPerson) {
            RelatedPerson relatedPerson = (RelatedPerson) resource
            return relatedPerson.getRelationship().get(0).getText()
        } else if (resource instanceof PractitionerRole) {
            PractitionerRole practitionerRole = (PractitionerRole) resource
            return practitionerRole.getCode().get(0).getText()
        }
        return null
    }

    @Unroll
    def "test medication effective date #desc"() {

        given:
        Payload samplePayload = TestData.buildSamplePayload("medications.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses'] as JsonNode
        if (hasNoStart) {
            ((ObjectNode) dataNode.get("medications").get(0)).put("firstDoseDate", "")
        }
        if (hasNoEnd) {
            ((ObjectNode) dataNode.get("medications").get(0)).put("endDate", "")
        }

        when:
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        MedicationStatement ms = getFirstBundleResource(bundle, ResourceType.MedicationStatement)
        Period period = (Period) ms.getEffective()
        String firstDoseDateValue = period.getStartElement().getValueAsString()
        String endDateValue = period.getEndElement().getValueAsString()

        then:
        firstDoseDateValue == startDate
        endDateValue == endDate

        where:
        desc          | hasNoStart | hasNoEnd | startDate              | endDate
        "HappyPath"   | false      | false    | "2018-03-28T00:00:00Z" | "2020-10-28T00:00:00Z"
        "NoStartDate" | true       | false    | null                   | "2020-10-28T00:00:00Z"
        "NoEndDate"   | false      | true     | "2018-03-28T00:00:00Z" | null
        "NoEndDate"   | true       | true     | null                   | null
    }

    @Unroll
    def "test medication effective date1 #desc"() {
        given:
        Payload samplePayload = TestData.buildSamplePayload("medications.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses'] as JsonNode
        if (valueMissing) {
            ((ObjectNode) dataNode.get("medications").get(0)).remove("dosageQuantity")
        }
        if (unitValueMissing) {
            ((ObjectNode) dataNode.get("medications").get(0)).remove("doseQuantityUnit",)
        }
        when:
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        MedicationStatement ms = getFirstBundleResource(bundle, ResourceType.MedicationStatement)

        def doseQuantity = null
        def doseQuantityUnit = null
        if (null != ms.getDosageFirstRep().getDoseAndRate() && ms.getDosageFirstRep().getDoseAndRate().size() > 0) {
            doseQuantity = ms.getDosageFirstRep().getDoseAndRate().get(0).getDoseQuantity().getValue()
        }
        if (null != ms.getDosageFirstRep().getDoseAndRate() && ms.getDosageFirstRep().getDoseAndRate().size() > 0) {
            doseQuantityUnit = ms.getDosageFirstRep().getDoseAndRate().get(0).getDoseQuantity().getUnit()
        }

        then:
        doseQuantity == doseQuantityValue
        doseQuantityUnit == doseQuantityUnitValue

        where:
        desc             | valueMissing | unitValueMissing | doseQuantityValue | doseQuantityUnitValue
        "Both present"   | false        | false            | 1                 | "mg"
        "value present " | true         | false            | null              | null
        "unit present "  | false        | true             | 1                 | null
        "not present"    | true         | true             | null              | null

    }

    def "test cases for medication ihrMedStartDate & medicationReason  #desc"() {
        when:
        // build v2 resource
        List<IhrTerm> ihrTermList = new ArrayList<>();
        IhrTerm ihrTerm = new IhrTerm()
        ihrTerm.setSourceVocabulary(medSourceVocabulary)
        ihrTerm.setSourceVocabularyCode(medSourceVocabularyCode)
        ihrTermList.add(ihrTerm)

        HealthMedication healthMedication = HealthMedication.builder()
                .ihrMedicationStartDate(startValue)
                .medicationReason(ihrTermList)
                .build()

        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient()).build();

        // map to fhir resource
        mapper.map(fhirResource, healthMedication)
        Bundle bundle = fhirResource.getBundle()

        MedicationStatement ms = getFirstBundleResource(bundle, ResourceType.MedicationStatement) as MedicationStatement

        Extension ihrMedicationStartDate = getExtensionFromList(ms.getExtension(), Constants.IHR_MEDICATION_START_DATE)
        String ihrMedStartDate = ihrMedicationStartDate.castToDateTime(ihrMedicationStartDate.getValue()).getValueAsString()
        CodeableConcept code = ms.getReasonCodeFirstRep()
        String medSystem = code.getCodingFirstRep().getSystem()
        String medCode = code.getCodingFirstRep().getCode()

        then:

        ihrMedStartDate == ihrMedOutputStartDate
        medSystem == medSourceVocabulary
        medCode == medSourceVocabularyCode

        where:
        desc            | startValue             | medSourceVocabulary      | medSourceVocabularyCode || ihrMedOutputStartDate
        "happy path 1"  | "2013-07-13T19:04:54Z" | "http://snomed.info/sct" | "370143000"             || "2013-07-13T19:04:54Z"
        "happy path 2 " | "2019/06/19"           | null                     | "123456789"             || "2019-06-19T00:00:00Z"
        "happy path 3 " | "2019/06/19"           | "http://snomed.info/sct" | null                    || "2019-06-19T00:00:00Z"
        "both empty"    | ""                     | null                     | null                    || ""

    }
}