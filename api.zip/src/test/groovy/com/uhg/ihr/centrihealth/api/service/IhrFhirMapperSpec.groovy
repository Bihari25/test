package com.uhg.ihr.centrihealth.api.service

import com.uhg.ihr.centrihealth.api.service.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.service.fhir.FhirMapper
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.MedicationStatement
import org.hl7.fhir.r4.model.Patient
import spock.lang.Unroll

class IhrFhirMapperSpec extends BaseFhirSpecification {


    def "Test patient object"() {

        when:
        def big5 = TestData.sampleBig5()
        def date = FhirMapper.toDate(big5.getDateOfBirth())
        def patient = IhrFhirMapper.buildPatientResource(big5)

        then:
        patient.getId() != null
        patient.getName().get(0).getFamily() == big5.getLastName()
        patient.getName().get(0).getGiven().get(0).getValue() == big5.getFirstName()
        patient.getBirthDate().toTimestamp() == date.toTimestamp()
    }

    @Unroll
    def "Test fhir mapping"() {

        when:
        def big5 = TestData.sampleBig5()
        def date = FhirMapper.toDate(big5.getDateOfBirth())
        def ihrResponse = TestData.sampleIhrResponse()
        IhrFhirMapper mapper = new IhrFhirMapper()
        Bundle bundle = mapper.getFhirMapping(ihrResponse)
        Patient patient = null
        MedicationStatement ms = null
        for (Bundle.BundleEntryComponent entity : bundle.getEntry()) {
            if (entity.getResource() instanceof  Patient) {
                patient = (Patient) entity.getResource()
            }
            else if (entity.getResource() instanceof  MedicationStatement) {
                ms = (MedicationStatement)entity.getResource()
            }
        }

        then:
        bundle != null
        patient.getId() != null
        patient.getResourceType().toString() == "Patient"
        patient.getName().get(0).getFamily() == big5.getLastName()
        patient.getName().get(0).getGiven().get(0).getValue() == big5.getFirstName()
        patient.getBirthDate().toTimestamp() == date.toTimestamp()
        ms.getResourceType().toString() == "MedicationStatement"
    }
}