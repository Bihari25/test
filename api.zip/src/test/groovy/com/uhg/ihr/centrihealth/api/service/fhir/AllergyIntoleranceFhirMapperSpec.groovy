package com.uhg.ihr.centrihealth.api.service.fhir

import com.fasterxml.jackson.databind.JsonNode
import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.model.dataclass.AdverseReaction
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.service.FhirService
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.instance.model.api.IBaseResource
import org.hl7.fhir.r4.model.*
import spock.lang.Shared
import spock.lang.Unroll

@Unroll
class AllergyIntoleranceFhirMapperSpec extends BaseFhirSpecification {

    @Shared
    AllergyIntoleranceFhirMapper mapper = AllergyIntoleranceFhirMapper.of()

    def expectedrecordKey = "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h"

    def "allerganceintolerance mapper happy path "() {

        given:
        Payload samplePayload = TestData.buildSamplePayload("adversereactions.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses'] as JsonNode
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        AllergyIntolerance allergyIntolerance = getFirstBundleResource(bundle, ResourceType.AllergyIntolerance)

        Identifier instanceId = getIdentifierFromList(allergyIntolerance.getIdentifier(), Constants.INSTANCE_ID)
        Identifier recordKey = getIdentifierFromList(allergyIntolerance.getIdentifier(), Constants.RECORD_KEY)
        Identifier referenceId = getIdentifierFromList(allergyIntolerance.getIdentifier(), Constants.REFERENCE_IDS)

        Coding status = getCodingFromList(allergyIntolerance.getClinicalStatus().getCoding(), "Active")
        Coding code = getCodingFromList(allergyIntolerance.getCode().getCoding(), "ICD-10 Diagnosis")
        List substance = allergyIntolerance.getReaction()

        def recordeddate = allergyIntolerance.getRecordedDateElement().getValueAsString()
        Extension presenceState = getExtensionFromList(allergyIntolerance.getExtension(), Constants.PRESENCE_STATE_TERM_URL)
        Extension clinicallyRelevantDate = getExtensionFromList(allergyIntolerance.getExtension(), Constants.CLINICALLY_RELEVANT_DATE_URL)
        String clinicallyRelevantDateValue = clinicallyRelevantDate.castToDateTime(clinicallyRelevantDate.getValue()).getValueAsString()
        String lastUpdated = getLastUpdateDate(allergyIntolerance.getMeta())

        Extension extensionSEN = getExtensionFromList(allergyIntolerance.getExtension(), Constants.SENSITIVITY_CLASSES_URL)
        Extension extensionDat = getExtensionFromList(allergyIntolerance.getExtension(), Constants.DATA_SOURCE_URL)
        Period onsetPeriod = allergyIntolerance.getOnsetPeriod()
        DateTimeType onsetPeriodStart = onsetPeriod.getStartElement()
        DateTimeType onsetPeriodEnd = onsetPeriod.getEndElement()
        Extension startDate = getExtensionFromList(allergyIntolerance.getExtension(), Constants.START_DATE_URL)
        String startDateValue = startDate.castToDate(startDate.getValue()).getValueAsString()
        def allergenType = allergyIntolerance.getCategory().get(0).getValueAsString()
        def allergyIntoleranceType = allergyIntolerance.getType().toString()
        def recordedDate = allergyIntolerance.getRecordedDateElement().getValueAsString()
        IBaseResource recorderResource = allergyIntolerance.getRecorder().getResource()
        Practitioner practitioner = (Practitioner) recorderResource
        Identifier recorderId = getIdentifierFromList(practitioner.getIdentifier(), Constants.DATA_AUTHOR_IDENTIFIER)
        def practitionerId = recorderId.getValue()
        def patient = allergyIntolerance.getPatient().getResource().fhirType()
        // RelatedPerson
        RelatedPerson relatedPerson = new RelatedPerson()
        relatedPerson.addRelationship(new CodeableConcept().setText("Caregiver"))
        allergyIntolerance.setAsserter(new Reference(relatedPerson))
        def relatedPersonValue = getTextFromResource(allergyIntolerance)
        // PractitionerRole
        PractitionerRole practitionerRole = new PractitionerRole()
        practitionerRole.addCode().setText("Facility Staff")
        allergyIntolerance.setAsserter(new Reference(practitionerRole))
        def practitionerRoleValue = getTextFromResource(allergyIntolerance)

        expect:
        instanceId.getValue().toString() == "19108821002069"
        recordKey.getValue().toString() == expectedrecordKey
        substance.size() == 3
        status.getDisplay().toString() == "Active"
        code.getCode().toString() == "T45.1X5A"
        recordeddate == "2015-09-28T21:09:29Z"
        presenceState.getValue().toString() == "Present"
        clinicallyRelevantDateValue == "2019-06-19T21:09:29Z"
        lastUpdated == "2019-06-10T00:00:00Z"

        referenceId.getValue().toString() == "[\"2019-01-02T03:04:44Z-Rally-1sE\"]"
        extensionSEN.getValue().toString() == "[\"Substance Abuse\",\"Genetics\"]"
        extensionDat.getValue().toString() == "[\"System Interface Data Acquisition Method\"]"
        onsetPeriodStart.getValueAsString() == "2020-06-13T00:00:00Z"
        onsetPeriodEnd.getValueAsString() == "2011-08-01T19:04:54Z"
        allergenType == "food"
        allergyIntoleranceType.toLowerCase() == "allergy"
        recordedDate == "2015-09-28T21:09:29Z"
        patient == ResourceType.Patient.toString()
        practitionerId == "recId123456"
        startDateValue == "2018-06-13"
        RelatedPersonEnum.ENUM_VALUES.contains(relatedPersonValue)
        PractitionerRoleEnum.ENUM_VALUES.contains(practitionerRoleValue)
    }

    def "test period dates #desc"() {
        when:
        // build v2 resource
        AdverseReaction adverseReaction = AdverseReaction.builder()
                .onsetDate(onsetInput).endDate(endDateInput)
                .build()

        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient()).build();
        // map to fhir resource
        mapper.map(fhirResource, adverseReaction)
        Bundle bundle = fhirResource.getBundle()

        AllergyIntolerance allergyIntolerance = getFirstBundleResource(bundle, ResourceType.AllergyIntolerance)

        Period period = allergyIntolerance.getOnsetPeriod()
        DateTimeType onsetPeriodStart = period.getStartElement()
        DateTimeType onsetPeriodEnd = period.getEndElement()

        then:
        onsetPeriodStart.getValueAsString() == startValue
        onsetPeriodEnd.getValueAsString() == endValue

        where:
        desc               | onsetInput   | endDateInput           || startValue             | endValue
        "happy path 1"     | "2019-06-19" | "2019-07-19"           || "2019-06-19T00:00:00Z" | "2019-07-19T00:00:00Z"
        "happy path 2 "    | "2019/06/19" | "2019/07/19"           || "2019-06-19T00:00:00Z" | "2019-07-19T00:00:00Z"
        "happy path 3 "    | "2019/06/19" | "2019-07-19T00:00:00Z" || "2019-06-19T00:00:00Z" | "2019-07-19T00:00:00Z"
        "start date empty" | null         | "2019-07-19T00:00:00Z" || null                   | "2019-07-19T00:00:00Z"
        "end date empty"   | "2019/06/19" | null                   || "2019-06-19T00:00:00Z" | null
        "both empty"       | null         | null                   || null                   | null
    }

    static getTextFromResource(AllergyIntolerance allergyIntolerance) {
        IBaseResource resource = ((Reference) allergyIntolerance.getAsserter()).getResource()
        if (resource instanceof RelatedPerson) {
            RelatedPerson relatedPerson = (RelatedPerson) resource
            return relatedPerson.getRelationship().get(0).getText()
        } else if (resource instanceof PractitionerRole) {
            PractitionerRole practitionerRole = (PractitionerRole) resource
            return practitionerRole.getCode().get(0).getText()
        }
        return null
    }
}
