package com.uhg.ihr.centrihealth.api.validator

import spock.lang.Specification
import spock.lang.Unroll

class ValidLanguageValidatorSpec extends Specification {
    @Unroll
    void "it validates languages #desc"() {
        given:
        def validator = new ValidLanguageValidator()
        expect:
        expected == validator.isValid(language, null)
        where:
        desc    | language || expected
        "EN"    | "EN"     || true
        "FR"    | "FR"     || false
        "null"  | null     || false
        "empty" | ""       || false
    }
}
