package com.uhg.ihr.centrihealth.api.security

import spock.lang.Specification

class EncryptorSpec extends Specification {
    /*
     * The RSA algorithm can only encrypt data that has a maximum byte length of the RSA key length in bits divided with eight minus eleven padding bytes, i.e. number of maximum bytes = key length in bits / 8 - 11.
     */
    // Send the encrypted key and the encrypted message to the log.
    // To decrypt, decrypt the key and use that to decrypt the message.
    void "it can encrypt and decrypt"() {
        given:
        def dataToEncrypt = "{\"firstName\":\"santa\",\"lastName\":\"claus\",\"dateOfBirth\":\"1940/01/01\",\"policyNumber\":\"755742\",\"searchId\":\"12343212\",\"searchIdType\":\"memberId\",\"ids\":[{\"policyNumber\":\"755742\",\"id\":\"12343212\",\"idType\":\"searchId\"},{\"id\":\"34567\",\"idType\":\"EID\"},{\"id\":\"12343212\",\"idType\":\"SSN\"},{\"id\":\"123456789\",\"idType\":\"MBI\"},{\"policyNumber\":\"755742\",\"id\":\"12343212\",\"idType\":\"subscriberId\"},{\"policyNumber\":\"755742\",\"id\":\"12343212\",\"idType\":\"subscriberId\"},{\"policyNumber\":\"755742\",\"id\":\"12343212\",\"idType\":\"subscriberId\"}]}";
        Encryptor encryptor = new Encryptor("testPublicKey", "testPrivateKey")

        when:
        def encrypted = encryptor.encrypt(dataToEncrypt)
        def decText = encryptor.decrypt(encrypted)

        then:
        decText == dataToEncrypt
        new String(encrypted.encryptedMessage) != dataToEncrypt
    }

    void "it can encrypt and decrypt x2"() {
        given:
        def dataToEncrypt = "{\"firstName\":\"santa\",\"lastName\":\"claus\",\"dateOfBirth\":\"1940/01/01\",\"policyNumber\":\"755742\",\"searchId\":\"12343212\",\"searchIdType\":\"memberId\",\"ids\":[{\"policyNumber\":\"755742\",\"id\":\"12343212\",\"idType\":\"searchId\"},{\"id\":\"34567\",\"idType\":\"EID\"},{\"id\":\"12343212\",\"idType\":\"SSN\"},{\"id\":\"123456789\",\"idType\":\"MBI\"},{\"policyNumber\":\"755742\",\"id\":\"12343212\",\"idType\":\"subscriberId\"},{\"policyNumber\":\"755742\",\"id\":\"12343212\",\"idType\":\"subscriberId\"},{\"policyNumber\":\"755742\",\"id\":\"12343212\",\"idType\":\"subscriberId\"}]}";
        Encryptor encryptor = new Encryptor("testPublicKey", "testPrivateKey")

        when:
        def encrypted = encryptor.encrypt(dataToEncrypt)
        def decText = encryptor.decrypt(encrypted)
        def encrypted2 = encryptor.encrypt(dataToEncrypt)
        def decText2 = encryptor.decrypt(encrypted2)

        then:
        decText == dataToEncrypt
        decText2 == dataToEncrypt
        new String(encrypted.encryptedMessage) != dataToEncrypt
    }

    void "it allows initialization with publicKey only"() {
        when:
        new Encryptor("testPublicKey", null)

        then:
        1 == 1
    }
}
