package com.uhg.ihr.centrihealth.api.exception

import io.micronaut.http.HttpRequest
import spock.lang.Specification

class IhrNotFoundExceptionHandlerSpec extends Specification {
    HttpRequest mockHttpRequest = Mock(HttpRequest)
    IhrNotFoundException ihrNotFoundException = new IhrNotFoundException("Test IHR not found exception")

    IhrNotFoundExceptionHandler ihrNotFoundExceptionHandler = new IhrNotFoundExceptionHandler()

    def "IhrNotFoundExceptionHandler:handle"() {
        when:
        def result = ihrNotFoundExceptionHandler.handle(mockHttpRequest, ihrNotFoundException)

        then:
        result
    }
}