package com.uhg.ihr.centrihealth.api.service.fhir

import com.fasterxml.jackson.databind.JsonNode
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.service.FhirService
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CareTeam
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.Organization
import org.hl7.fhir.r4.model.ResourceType

class PracitionerRoleFhirMapperSpec extends BaseFhirSpecification {

    def resource = "SERVICE_FACILITY_PROVIDER"

    def "PracitionerRole mapper happy path "() {

        Payload samplePayload = TestData.buildSamplePayload("servicefaciltyprovider.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses'] as JsonNode
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        CareTeam careTeam = getFirstBundleResource(bundle, ResourceType.CareTeam)

        def value = careTeam.getText().getId()
        String startPeriod = careTeam.getPeriod().getStartElement().getValueAsString()

        Organization organization = (Organization) careTeam.getParticipantFirstRep().getMember().getResource()
        Identifier identifier1 = getIdentifierFromList(organization.getIdentifier(), Constants.INSTANCE_ID)
        Identifier identifier2 = getIdentifierFromList(organization.getIdentifier(), "1699718775")
        Identifier referenceIds = getIdentifierFromList(organization.getIdentifier(), Constants.REFERENCE_IDS)
        Coding type = getCodingFromList(identifier2.getType().getCoding(), "National Provider Identifier")
        Coding role = getCodingFromList(careTeam.getParticipant().get(0).getRole().get(0).getCoding(), "Service Provider Organization")

        expect:
        value.equalsIgnoreCase(resource)
        identifier1.getValue().toString() == "18947334002316"
        type.getSystem().toString() == Constants.NPI_URL
        startPeriod.substring(0, 10) == "2018-09-24"
        referenceIds.getValue().toString() == "[\"2019-01-02T03:04:44Z-Rally-1sE\"]"
        role.getDisplay() == "Service Provider Organization"
    }
}
