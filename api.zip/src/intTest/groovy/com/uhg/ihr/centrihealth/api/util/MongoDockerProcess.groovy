package com.uhg.ihr.centrihealth.api.util

import groovy.util.logging.Slf4j
import io.micronaut.core.io.ResourceResolver
import io.micronaut.core.io.scan.ClassPathResourceLoader
import io.micronaut.core.io.socket.SocketUtils

@Slf4j
class MongoDockerProcess {

    private static String DIRECTORY_PATH = "docker-compose.yml"
    private static String START_COMMAND = "docker-compose up -d"
    private static String STOP_COMMAND = "docker-compose down"

    static void startMongoDocker() {
        executeMongoDocker(true)
    }

    static void stopMongoDocker() {
        executeMongoDocker(false)
    }

    static void executeMongoDocker(boolean start) {

        List<String> commands = new ArrayList<>()
        commands.add("bash")
        commands.add("-c")
        if (start) {
            if (!SocketUtils.isTcpPortAvailable(MongoTestService.PORT)) {
                return
            }
            commands.add(START_COMMAND)
        } else {
            commands.add(STOP_COMMAND)
        }
        ProcessBuilder builder = new ProcessBuilder()
        builder.command(commands)
        String fileResource = readResourcePath(DIRECTORY_PATH)
        builder.directory(new File(fileResource).getParentFile())
        String path = System.getenv("PATH")
        builder.environment().put("PATH", "/usr/bin:" + path)
        builder.redirectErrorStream(true)
        builder.redirectError(ProcessBuilder.Redirect.INHERIT)

        try {
            builder.start()
        } catch (IOException  ioe) {
            log.info("Exception MongoDockerProcess - executeMongoDocker():", ioe.printStackTrace())
        }
    }

    static String readResourcePath(String resourcePath) {
        Optional<ClassPathResourceLoader> loader = new ResourceResolver().getLoader(ClassPathResourceLoader.class)
        if (loader.isPresent()) {
            return loader.get().getResource(resourcePath).get().getPath()
        }
        return null
    }
}
