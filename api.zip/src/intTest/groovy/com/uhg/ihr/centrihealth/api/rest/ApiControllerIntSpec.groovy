package com.uhg.ihr.centrihealth.api.rest

import com.uhg.ihr.centrihealth.api.util.MongoWireMockBaseTest
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpStatus
import io.micronaut.http.MediaType
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.test.annotation.MicronautTest

@MicronautTest
class ApiControllerIntSpec extends MongoWireMockBaseTest {

    def setupSpec() {
    }

    def cleanup() {
        clearMatches()
    }

    def "Senzing errors out"() {
        when:
        def chid = randomChid()
        errorSenzing(randomChidBig5(chid))
        HttpRequest req = baseRequest(chid, "EN").accept(MediaType.of(APPLICATION_CONTENT_TYPE))

        then:
        def exception = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hce) {
            assert hce.getMessage().contains('unable to match user or requestee: Unable to find ihr identifier (IhrId) because senzing response data is empty')
            assert HttpStatus.NOT_FOUND == hce.getResponse().getStatus()
            exception = true
        }
        exception
    }

    def "When senzing has no match"() {
        when:
        def chid = randomChid()
        notMatchSenzing(randomChidBig5(chid))
        HttpRequest req = baseRequest(chid, "EN").accept(MediaType.of(APPLICATION_CONTENT_TYPE))

        then:
        def exception = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hcre) {
            assert hcre.getMessage().contains('unable to match user')
            assert HttpStatus.NOT_FOUND == hcre.getResponse().getStatus()
            assert hcre.getMessage().contains('unable to match user or requestee: Unable to find ihr identifier (IhrId) because senzing response data is empty')
            exception = true
        }
        exception
    }
}
