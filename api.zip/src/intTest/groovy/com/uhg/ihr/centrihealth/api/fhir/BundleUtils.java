package com.uhg.ihr.centrihealth.api.fhir;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.parser.IParser;
import ca.uhn.fhir.parser.StrictErrorHandler;
import com.google.common.io.CharStreams;
import com.uhg.ihr.centrihealth.api.exception.IhrException;
import com.uhg.ihr.centrihealth.api.model.Big5;
import com.uhg.ihr.centrihealth.api.model.Id;
import com.uhg.ihr.centrihealth.api.model.IdType;
import com.uhg.ihr.centrihealth.api.util.MongoWireMockBaseTest;
import groovy.util.logging.Slf4j;
import io.micronaut.core.io.ResourceResolver;
import io.micronaut.core.io.scan.ClassPathResourceLoader;
import io.micronaut.core.util.CollectionUtils;
import io.micronaut.core.util.StringUtils;
import org.hl7.fhir.r4.model.AllergyIntolerance;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CareTeam;
import org.hl7.fhir.r4.model.Condition;
import org.hl7.fhir.r4.model.Coverage;
import org.hl7.fhir.r4.model.Device;
import org.hl7.fhir.r4.model.Encounter;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Immunization;
import org.hl7.fhir.r4.model.MedicationStatement;
import org.hl7.fhir.r4.model.Observation;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Procedure;
import org.hl7.fhir.r4.model.ResourceType;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
public class BundleUtils {

    /*
    Easily reused in multiple contexts, validates that our response is performing as expected, provides helper functions for ease of use
    1) strictly validate the data is correct (if we run into issues, let's discuss them)
        a) that it is FHIR compliant
        b) that the identifier data elements are present and correct
           (recordKey and instanceId both exist, for example)

    2) validate the usability of the data with helper functions (please work to define your own)  - some examples include:
        a) getting the relatedXXXX resources from a dataClass
          (a medication has a relatedCareTeam array with 2 entries. get the instanceId, find the related Care Team resources, and return them)
        b) making the identifiers available - for example: getRecordKey(), getInstanceId()
        c) making the extension data easy to use by creating helper POJOs if needed

    3) this code should be very clean, generic, and reusable. we could use it for the following functions:
        a) integration test cases (internal to the API, run in spock)
        b) integration test cases (external to the API, run by a QA framework)
        c) troubleshooting schema or data issues (does it pass strict validation? are the related[] links broken?)
        d) providing starter code for our clients
        e) identifying areas of improvement for our response mapping and formatting

    Conclusion
    1) code break on use of these methods without instance check
           annotation.getAuthorStringType() or annotation.getAuthorReference()
    2) improvement - good to have reference rosource type as prefix or else resource will be null
          "reference" : "RelatedPerson/4c2f3281-eab3-459c-840c-862c7528279e
           RelatedPerson rp = (RelatedPerson) reference.getResource();
    3) from identifier.getType().getText().contains("relatedProcedureInstanceIds")
       we can get the values ("value": "[6,7]") but these numbers 6 or 7 will not provide related CareTeam (identifier.getAssigner().getResource())
    */

    public static int report = 0;
    private static final Validator VALIDATOR = Validation.buildDefaultValidatorFactory().getValidator();
    private static final FhirContext FHIR_CONTEXT = FhirContext.forR4();
    private static IParser I_PARSER = FHIR_CONTEXT.newJsonParser();

    private static final String INVALID_BUNDLE_ID = "Invalid bundle id";
    private static final String INVALID_RESOURCE_ID = "Invalid resource id";
    private static final String INVALID_RESOURCE = "Request must contain at least one of the following FHIR resources:  ";
    private static final String MANDATORY_RESOURCE = "Request must contain these FHIR resources:  ";
    private static final String DUPLICATE_RESOURCE_IDS = "Duplicate Resource ids";

    public static String readResource(String resourcePath) {
        Optional<ClassPathResourceLoader> loader = new ResourceResolver().getLoader(ClassPathResourceLoader.class);
        if (loader.isPresent()) {
            InputStream is = loader.get().getResourceAsStream("classpath:" + resourcePath)
                    .orElseThrow(() -> new RuntimeException("unable to read resource"));
            try (InputStreamReader reader = new InputStreamReader(is, StandardCharsets.UTF_8)) {
                return CharStreams.toString(reader);
            } catch (Exception ex) {
                throw new IhrException("unable to read resource: ", ex);
            }
        } else {
            throw new IhrException("unable to resolve resource loader");
        }
    }

    private static Bundle getResourceBundle(String resourcePath) {
        String message = readResource(resourcePath);
        I_PARSER.setParserErrorHandler(new StrictErrorHandler());
        return (Bundle) FHIR_CONTEXT.newJsonParser().parseResource(message);
    }

    private static Bundle getResourceBundleFromString(String message) {
        I_PARSER.setParserErrorHandler(new StrictErrorHandler());
        return (Bundle) FHIR_CONTEXT.newJsonParser().parseResource(message);
    }

    public static final Set<ResourceType> ALLOWED_RESOURCE_TYPES = Stream.of(ResourceType.AllergyIntolerance,
            ResourceType.Condition, ResourceType.MedicationStatement).collect(Collectors.toSet());

    public static final Set<ResourceType> REQUIRED_RESOURCE_TYPES =
            Stream.of(ResourceType.Patient, ResourceType.Coverage).collect(Collectors.toSet());

    public static void isRequestValid(String value) {

        // from path
        Bundle resourceBundle = getResourceBundle(value);

        // from string
        if (resourceBundle == null) {
            resourceBundle = getResourceBundleFromString(value);
        }

        System.out.println("Report ## " + ++report + " : Big5");
        Big5 big5 = bundleResourceValidation(resourceBundle);

        Set<ConstraintViolation<Big5>> constraintViolations = VALIDATOR.validate(big5);
        if (CollectionUtils.isNotEmpty(constraintViolations)) {
            System.err.println(constraintViolations.toString());
        } else {
            System.out.println(MongoWireMockBaseTest.convertStringToJson(big5.toString()));
        }
    }

    public static Big5 bundleResourceValidation(Bundle resourceBundle) {

        boolean isResourceAvailable = false;
        int reqResourcesCount = 0;
        Set<String> resourceIds = new HashSet<>();

        Big5 big5 = new Big5();
        Map<String, String> identifierMap = null;

        System.out.println("Report ## " + ++report);
        if (resourceBundle.getId() == null) {
            System.err.println(INVALID_BUNDLE_ID);
        }

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (StringUtils.isEmpty(entity.getResource().getId())) {
                System.out.println("Report ## " + ++report);
                System.err.println(INVALID_RESOURCE_ID + " : " + entity.getResource().getResourceType());
            }
            if (ALLOWED_RESOURCE_TYPES.contains(entity.getResource().getResourceType())) {
                isResourceAvailable = true;
            }
            if (REQUIRED_RESOURCE_TYPES.contains(entity.getResource().getResourceType())) {
                reqResourcesCount++;
            }
            if (entity.getResource().getId() != null) {
                String ids[] = null;
                if (entity.getResource().getId().contains("/")) {
                    ids = entity.getResource().getId().split("/");
                }
                resourceIds.add(ids == null ? entity.getResource().getId() : ids[1]);
            }

            setBig5(entity, big5, identifierMap);
            domainResourceValidation(resourceBundle, entity);
        }

        if (reqResourcesCount < 2) {
            System.err.println(MANDATORY_RESOURCE + REQUIRED_RESOURCE_TYPES);
        }
        if (!isResourceAvailable) {
            System.err.println(INVALID_RESOURCE + ALLOWED_RESOURCE_TYPES);
        }
        if (resourceIds.size() > 0 && resourceIds.size() != resourceBundle.getEntry().size()) {
            System.err.println(DUPLICATE_RESOURCE_IDS);
        }
        return big5;
    }

    private static void setBig5(Bundle.BundleEntryComponent entity, Big5 big5, Map<String, String> identifierMap) {
        if (entity.getResource() instanceof Patient) {
            Patient patient = (Patient) entity.getResource();
            big5.setDateOfBirth(patient.getBirthDateElement().toHumanDisplay());
            big5.setFirstName(patient.getName().get(0).getGivenAsSingleString());
            big5.setLastName(patient.getName().get(0).getFamily());
        }

        if (entity.getResource() instanceof Coverage) {
            identifierMap = new HashMap<>();
            Coverage coverage = (Coverage) entity.getResource();
            for (Identifier identifier : coverage.getIdentifier()) {
                if (identifier.getType() != null) {
                    identifierMap.put(identifier.getType().getText(), identifier.getValue());
                }
            }
        }

        if (CollectionUtils.isNotEmpty(identifierMap)) {
            List<Id> ids = new ArrayList<>();
            identifierMap.forEach((key, value) -> {
                if (IdType.searchId.toString().equalsIgnoreCase(key)) {
                    big5.setSearchId(value);
                    ids.add(createId(value, IdType.searchId));
                } else if (IdType.SSN.toString().equals(key)) {
                    ids.add(createId(value, IdType.SSN));
                } else if (IdType.MBI.toString().equals(key)) {
                    ids.add(createId(value, IdType.MBI));
                } else if (IdType.subscriberId.toString().equals(key)) {
                    ids.add(createId(value, IdType.subscriberId));
                } else if (IdType.memberId.toString().equalsIgnoreCase(key)) {
                    ids.add(createId(value, IdType.memberId));
                }
                big5.setIds(ids);
            });
        }
    }

    private static void domainResourceValidation(Bundle bundle, Bundle.BundleEntryComponent entity) {
        if (entity.getResource() instanceof Condition) {
            Condition resource = (Condition) entity.getResource();
            ResourceValidator.validate(bundle, resource, resource.getMeta(), resource.getNote(),
                    resource.getIdentifier(), resource.getResourceType().name());
        } else if (entity.getResource() instanceof MedicationStatement) {
            MedicationStatement resource = (MedicationStatement) entity.getResource();
            ResourceValidator.validate(bundle, resource, resource.getMeta(), resource.getNote(),
                    resource.getIdentifier(), resource.getResourceType().name());
        } else if (entity.getResource() instanceof AllergyIntolerance) {
            AllergyIntolerance resource = (AllergyIntolerance) entity.getResource();
            ResourceValidator.validate(bundle, resource, resource.getMeta(), resource.getNote(),
                    resource.getIdentifier(), resource.getResourceType().name());
        } else if (entity.getResource() instanceof Observation) {
            Observation resource = (Observation) entity.getResource();
            ResourceValidator.validate(bundle, resource, resource.getMeta(), resource.getNote(),
                    resource.getIdentifier(), resource.getResourceType().name());
        } else if (entity.getResource() instanceof CareTeam) {
            CareTeam resource = (CareTeam) entity.getResource();
            ResourceValidator.validate(bundle, resource, resource.getMeta(), resource.getNote(),
                    resource.getIdentifier(), resource.getResourceType().name());
        } else if (entity.getResource() instanceof Device) {
            Device resource = (Device) entity.getResource();
            ResourceValidator.validate(bundle, resource, resource.getMeta(), resource.getNote(),
                    resource.getIdentifier(), resource.getResourceType().name());
        } else if (entity.getResource() instanceof Immunization) {
            Immunization resource = (Immunization) entity.getResource();
            ResourceValidator.validate(bundle, resource, resource.getMeta(), resource.getNote(),
                    resource.getIdentifier(), resource.getResourceType().name());
        } else if (entity.getResource() instanceof Procedure) {
            Procedure resource = (Procedure) entity.getResource();
            ResourceValidator.validate(bundle, resource, resource.getMeta(), resource.getNote(),
                    resource.getIdentifier(), resource.getResourceType().name());
        } else if (entity.getResource() instanceof Encounter) {
            Encounter resource = (Encounter) entity.getResource();
            ResourceValidator.validate(bundle, resource, resource.getMeta(), null,
                    resource.getIdentifier(), resource.getResourceType().name());
        }
    }

    private static Id createId(String value, IdType idType) {
        return Id.builder().id(value).idType(idType).build();
    }

}
