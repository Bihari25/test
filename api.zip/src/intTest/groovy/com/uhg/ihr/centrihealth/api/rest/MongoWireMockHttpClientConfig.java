package com.uhg.ihr.centrihealth.api.rest;

import io.micronaut.http.client.HttpClientConfiguration;
import io.micronaut.runtime.ApplicationConfiguration;

import javax.inject.Singleton;
import java.time.Duration;

@Singleton
public class MongoWireMockHttpClientConfig extends HttpClientConfiguration {

    public MongoWireMockHttpClientConfig(ApplicationConfiguration applicationConfiguration) {
        super(applicationConfiguration);
        this.setReadTimeout(Duration.ofSeconds(60));
    }

    @Override
    public ConnectionPoolConfiguration getConnectionPoolConfiguration() {
        return new ConnectionPoolConfiguration();
    }
}
