package com.uhg.ihr.centrihealth.api.util

import com.fasterxml.jackson.databind.ObjectMapper
import com.github.tomakehurst.wiremock.junit.WireMockRule
import com.mongodb.client.MongoCollection
import com.uhg.ihr.centrihealth.api.model.Big5
import com.uhg.ihr.centrihealth.api.model.IhrApiRequest
import com.uhg.ihr.centrihealth.api.model.MId
import com.uhg.ihr.centrihealth.api.model.RecordType
import com.uhg.ihr.centrihealth.api.rest.MongoWireMockHttpClientConfig
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest
import groovy.util.logging.Slf4j
import io.jsonwebtoken.lang.Strings
import io.micronaut.context.annotation.Property
import io.micronaut.http.HttpRequest
import io.micronaut.http.client.RxHttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.test.annotation.MicronautTest
import net.minidev.json.JSONObject
import net.minidev.json.parser.JSONParser
import org.apache.commons.lang3.RandomStringUtils
import org.bson.Document
import org.junit.ClassRule
import spock.lang.Shared
import spock.lang.Specification

import javax.inject.Inject

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson
import static com.github.tomakehurst.wiremock.client.WireMock.notFound
import static com.github.tomakehurst.wiremock.client.WireMock.post
import static com.github.tomakehurst.wiremock.client.WireMock.serverError
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo

@Slf4j
@MicronautTest
@Property(name = "micronaut.security.stargate.enabled", value = "false")
@Property(name = "senzing.secretKey", value = "55555555555555555555555555555555555555555555555555555555555555555555555555555555")
@Property(name = "mongo.mongo-txn", value = "false")
class MongoWireMockBaseTest extends Specification {

    static final String PAYLOAD_BASE = "{\"ihrIdentifier\":\"%s\",\"language\":\"EN\",\"taxonomy\":null,\"payload\":\"%s\"}"
    static final String SENZING_BASE = "{\"data\":{\"searchResults\":%s}}"
    public static final String API_DATA_DB = "apidata"
    public static final String API_DATA_SEC_DB = "apidataDev"
    public static final String IHR2_COLLECTION = "external_api_payload_v2"
    public static final String IHR2_COLLECTION_ES = "external_api_payload_v2_es"
    public static final String B50_COLLECTION = "ihr_gold_transcribed_collection"
    public static final String B50_COLLECTION_ES = "ihr_gold_transcribed_collection_es"
    public static final String B50_SECOND_COLLECTION = "ihr_api_disney_data"
    public static final String B50_SECOND_COLLECTION_ES = "ihr_api_disney_data_es"
    public static final String TEST_IHR_ID_07 = "XXXTEST007"
    public static final String TEST_IHR_ID_09 = "XXXTEST009"
    static final String TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJpaHItYXBpIiwiaXNzIjoiaWhyLXNlbnppbmctYXBpLWdhdGV3YXkiLCJhdWQiOiJzZWN1cmUtYXBwIiwiaWF0IjoxNTk2NTAwODExLCJyb2wiOlsicWEiLCJkZXYiXSwiZXhwIjoxNTk2NTAwODIwfQ.AVMLq2RAWdzGkBer5UGri87Gj4Khu3YvuA3zXkdP-Rf05giWvlW8WTAvfSEMwlf0EBmRD9enyzJDeDjVUuAYxA"
    static final String CORRELATION_ID = "test"
    static final String CORRELATION_HEADER = "optum-cid-ext"
    static final String CONSUMER_USER_NAME_HEADER = "X-Consumer-Username"
    static final String COLLECTION_NAME_HEADER = "X-Collection"
    static final String CONSUMER_USER_NAME = "QATEst"
    static final String CONTENT_TYPE = "Content-Type"
    static final String APPLICATION_JSON = "application/json"
    static final String APPLICATION_SCOPE = "scope"
    static final String APPLICATION_READ = "read"
    static final String APPLICATION_ACCEPT = "accept"
    public static final String APPLICATION_CONTENT_TYPE = "application/vnd.uhg.v2+json"
    public static final String SENZING_MATCH = "senzing-response-api.json"
    public static final Set<RecordType> SAMPLE_DATA_CLASS = [RecordType.CARE_TEAM, RecordType.HEALTH_MEDICATION]

    @Inject
    @Client(id = '/', configuration = MongoWireMockHttpClientConfig.class)
    RxHttpClient httpClient

    @ClassRule
    @Shared
    WireMockRule wireMockRule = new WireMockRule(8089)

    @Shared
    static final ObjectMapper MAPPER = new ObjectMapper()

    def setup() {
        wireMockRule.stubFor(post(urlEqualTo("/ihrid/v1.0/nativeQuery/5")).willReturn(notFound()))
    }

    def cleanup() {
        clearMatches()
    }

    def clearMatches() {
        wireMockRule.resetAll()
    }

    static Big5 sampleBig5() {
        return Big5.builder().firstName("TFName").lastName("TLName")
                .policyNumber("TPLCY12345").searchId("TSrch1234")
                .dateOfBirth("2001/01/01").build()
    }

    static Big5 randomChidBig5(String ramdomChid) {
        return Big5.builder().firstName("cinderella").lastName("downtrodden")
                .policyNumber("903033").searchId(ramdomChid)
                .dateOfBirth("1989/05/27").build()
    }

    static MId sampleMid() {
        def memberId = MId.builder().idType("RALLYID").idValue("Mbr1234").big5(sampleBig5()).build()
        memberId
    }

    static MId randomChidMid(String randomChid) {
        def memberId = MId.builder().big5(randomChidBig5(randomChid)).build()
        memberId
    }

    static String randomChid() {
        return RandomStringUtils.randomAlphanumeric(9).toUpperCase()
    }

    static baseRequest(String randomChid, String language) {
        return HttpRequest.POST("/individual-health-records/v1.0/read", sampleIhrApiRequest(randomChid, language))
                .header("JWT", TOKEN)
                .header(CORRELATION_HEADER, CORRELATION_ID)
                .header(CONSUMER_USER_NAME_HEADER, CONSUMER_USER_NAME)
                .header(APPLICATION_SCOPE, APPLICATION_READ)
                .header(APPLICATION_ACCEPT, APPLICATION_CONTENT_TYPE)
                .header(CONTENT_TYPE, APPLICATION_JSON)
    }

    static String buildResponse(String chid, String payload) {
        return String.format(PAYLOAD_BASE, chid, payload)
    }

    static IhrApiRequest sampleIhrApiRequest(String randomChid, String language) {
        IhrApiRequest ihrApiRequest = IhrApiRequest.builder().mbrId(randomChidMid(randomChid)).correlationId(CORRELATION_ID)
                .language(language).requestor(randomChidBig5(randomChid)).dataClasses(SAMPLE_DATA_CLASS).build()
        return ihrApiRequest
    }

    static MongoCollection<Document> getMongoCollection(String database, String collectionName) {
        MongoCollection<Document> collection = MongoTestService.getCollection(database, collectionName)
        //MongoCollection<Document> collection = MongoEmbededProcess.getCollection(database, collectionName)
        return collection
    }

    def matchSenzingToChid(Big5 big5, String chid, String testIhrId) {
        String docStr = Strings.replace(AppUtils.readResource(SENZING_MATCH), "#TESTIHRID#", testIhrId)
        docStr = Strings.replace(docStr, "#CHID#", chid)
        matchSenzing(big5, docStr)
    }

    def matchSenzing(Big5 big5, String response) {
        def request = MAPPER.writeValueAsString(SenzingRequest.buildSenzingRequest(big5))
        wireMockRule.stubFor(post(urlEqualTo("/entities/"))
                .withRequestBody(equalToJson(request))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBody(response)))
    }

    def notMatchSenzing(Big5 big5) {
        def request = MAPPER.writeValueAsString(SenzingRequest.buildSenzingRequest(big5))
        wireMockRule.stubFor(post(urlEqualTo("/entities/"))
                .withRequestBody(equalToJson(request))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader(CONTENT_TYPE, APPLICATION_JSON)
                        .withBody(String.format(SENZING_BASE, "[]"))))
    }

    def errorSenzing(Big5 big5) {
        def request = MAPPER.writeValueAsString(SenzingRequest.buildSenzingRequest(big5))
        wireMockRule.stubFor(post(urlEqualTo("/entities/"))
                .withRequestBody(equalToJson(request))
                .willReturn(serverError()))
    }

    static Document createDocument(String testIhrId, String distinct) {
        String mongoDoc = "en-b50-disney-test-009-local.json"
        String docStr = Strings.replace(AppUtils.readResource(mongoDoc), "#TESTIHRID#", testIhrId)
        docStr = Strings.replace(docStr, "#DISTINCT#", distinct)
        Document document = Document.parse(docStr)
        return document
    }

    static insertValidDocument(String testIhrId, String database, String collectionName, String distinct) {
        Document document = createDocument(testIhrId, distinct)
        log.info("creating-document - id:{}, db:{}, col:{}, distinct:{}", testIhrId, database, collectionName, distinct)
        MongoCollection<Document> collectionB50E = getMongoCollection(database, collectionName)
        MongoTestService.insertOrReplaceDocument(collectionB50E, document)
    }

    static JSONObject convertStringToJson(String value) {
        JSONParser parser = new JSONParser()
        return (JSONObject) parser.parse(value)
    }
}