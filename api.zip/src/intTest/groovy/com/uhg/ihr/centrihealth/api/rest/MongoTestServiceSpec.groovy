package com.uhg.ihr.centrihealth.api.rest

import com.mongodb.client.MongoCollection
import com.uhg.ihr.centrihealth.api.util.MongoDockerProcess
import com.uhg.ihr.centrihealth.api.util.MongoTestService
import com.uhg.ihr.centrihealth.api.util.MongoWireMockBaseTest
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.HttpStatus
import io.micronaut.http.MediaType
import io.micronaut.test.annotation.MicronautTest
import net.minidev.json.JSONObject
import org.bson.Document
import spock.lang.Unroll

@MicronautTest
class MongoTestServiceSpec extends MongoWireMockBaseTest {

    def setupSpec() {
        MongoDockerProcess.startMongoDocker()
    }

    def cleanupSpec() {
        MongoDockerProcess.stopMongoDocker()
        MongoTestService.dropDatabases()
    }

    def "Test mongo upload"() {

        setup:
        Document document = createDocument("1003", "CARE-TEAM-B50-EN")
        MongoCollection<Document> collection = getMongoCollection(API_DATA_DB, IHR2_COLLECTION)

        when:
        boolean success = MongoTestService.insertOrReplaceDocument(collection, document)

        then:
        success
    }

    def "Test mongo download"() {

        setup:
        def testId = "1004"
        def distinct = "CARE-TEAM-B50-EN"
        Document document = createDocument(testId, distinct)
        MongoCollection<Document> collection = getMongoCollection(API_DATA_DB, IHR2_COLLECTION_ES)
        MongoTestService.insertOrReplaceDocument(collection, document)

        when:
        Document downloadedDoc = MongoTestService.filterDocuments(collection, testId)

        then:
        testId == downloadedDoc.get("_id")
        distinct == downloadedDoc.get("dataClasses").get("careTeam").get(0).get("relatedEntityRoleTerm")
    }

    def "Test mongo delete"() {

        setup:
        def testId = "1005"
        Document document = createDocument(testId, "CARE-TEAM-B50-EN")
        MongoCollection<Document> collection = getMongoCollection(API_DATA_DB, B50_COLLECTION)
        MongoTestService.insertOrReplaceDocument(collection, document)

        when:
        boolean isDeleted = MongoTestService.deleteDocuments(collection, testId)
        Document downloadedDoc = MongoTestService.filterDocuments(collection, testId)

        then:
        isDeleted
        downloadedDoc == null
    }

    def "When senzing matched and mongo has no data"() {

        given:
        def chid = randomChid()
        def TEST_IHR_ID = "XXXTEST00D"
        when:
        clearMatches()
        matchSenzingToChid(randomChidBig5(chid), chid, TEST_IHR_ID)
        HttpRequest req = baseRequest(chid, "EN").accept(MediaType.of(APPLICATION_CONTENT_TYPE))

        then:
        def noException = true
        JSONObject responseJson = null
        HttpResponse<String> response = null

        try {
            response = httpClient.toBlocking().exchange(req, String.class)
            responseJson = convertStringToJson(response.body())
        }
        catch (Exception hce) {
            noException = false
        }

        noException
        compareValues( response, responseJson, "EN", chid)
        SAMPLE_DATA_CLASS.size() == responseJson.get("dataClasses").size()
        0 == responseJson.get("dataClasses").get("careTeam").size()
        0 == responseJson.get("dataClasses").get("medications").size()
    }

    @Unroll
    def "Test b50 mongo #desc collection when senzing has no issue"() {

        given:
        def chid = randomChid()

        when:
        clearMatches()
        matchSenzingToChid(randomChidBig5(chid), chid, testIhrId)
        insertValidDocument(testIhrId, database, collectionName, distinct)
        HttpRequest req = baseRequest(chid, language).accept(MediaType.of(APPLICATION_CONTENT_TYPE))

        then:
        def noException = true
        JSONObject responseJson = null
        HttpResponse<String> response = null
        try {
            response =  httpClient.toBlocking().exchange(req, String.class)
            responseJson = convertStringToJson(response.body())
        }
        catch (Exception hce) {
            noException = false
        }

        noException
        compareValues( response, responseJson, language, chid)
        distinct == responseJson.get("dataClasses").get("careTeam").get(0).get("relatedEntityRoleTerm")

        where:
        desc             | language | testIhrId      | database        | collectionName           | distinct
        "English"        | "EN"     | TEST_IHR_ID_07 | API_DATA_DB     | B50_COLLECTION           | "EN B50 Disney TEST007 Local"
        "Spanish"        | "ES"     | TEST_IHR_ID_07 | API_DATA_DB     | B50_COLLECTION_ES        | "ES B50 Disney TEST007 Local"
        "English second" | "EN"     | TEST_IHR_ID_09 | API_DATA_SEC_DB | B50_SECOND_COLLECTION    | "EN B50 Second Disney TEST009 Local"
        "Spanish second" | "ES"     | TEST_IHR_ID_09 | API_DATA_SEC_DB | B50_SECOND_COLLECTION_ES | "ES B50 Second Disney TEST009 Local"
    }

    def compareValues(HttpResponse<String> response, JSONObject responseJson, String language, String chid) {
        response.status() == HttpStatus.OK
        "0.0.1" == responseJson.get("apiVersion")
        "2.0.0" == responseJson.get("dataVersion")
        "2.6.0" == responseJson.get("schemaVersion")
        "test" == responseJson.get("correlationId")
        language == responseJson.get("language")
        "cinderella" == responseJson.get("mbrId").get("big5").get("firstName")
        "downtrodden" == responseJson.get("mbrId").get("big5").get("lastName")
        "1989/05/27" == responseJson.get("mbrId").get("big5").get("dateOfBirth")
        "903033" == responseJson.get("mbrId").get("big5").get("policyNumber")
        chid == responseJson.get("mbrId").get("big5").get("searchId")
    }
}