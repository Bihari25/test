LabResults Framework can read the SDR and Galaxy Lab files and ingest into flatten Tables in Incremental and History Loads.

Framework consists below modules

LabFlatten- it can read the SDR LabFiles and ingesting into Flatten tables

LabGalaxyHistoryFile- It will create Galaxy Data Lab extract file by reading the data from flatten tables with aco roster filter.

LabGalaxyIngestion-It will read the Galaxy LabFiles and ingesting into Flatten tables with aco roster filter.

LabHistoryFiles- It will create SDR Data Lab extract file by reading the data from flatten tables.

LabResults- It will read incremental SDR source files and will parse and filter with aco roster and create the hl7 file.
