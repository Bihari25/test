package com.optum.ihrcentri.LabGalaxyFiles

import java.io.{BufferedReader, File, InputStreamReader}
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.zip.ZipInputStream

import com.optum.ihrcentri.Common._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, FileUtil, Path}
import org.apache.spark.SparkContext
import org.apache.spark.input.PortableDataStream
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}

class CommonFunctions {
  def readAcomembers(spark:SparkSession,tableName:String):DataFrame={
    Logger.log.info("Reading the aco members")
    val acoDf=spark.read.table(s"$tableName").cache()
    Logger.log.info("Aco_member count: "+ acoDf.count)
    acoDf
  }
  def readFile(sc: SparkContext, path: String): RDD[String] = {
    val minPartitions: Int = sc.defaultMinPartitions
    if (path.endsWith(".zip")) {
      sc.binaryFiles(path, minPartitions)
        .flatMap { case (name: String, content: PortableDataStream) =>
          val zis = new ZipInputStream(content.open)
          Stream.continually(zis.getNextEntry)
            .takeWhile {
              case null => zis.close(); false
              case _ => true
            }
            .flatMap { _ =>
              val br = new BufferedReader(new InputStreamReader(zis))
              Stream.continually(br.readLine()).takeWhile(_ != null)
            }
        }
    } else {
      sc.textFile(path, minPartitions)
    }
  }

  def fileRenameToTXT(outputNodeAddress: String, filepath: String, entnm: String): Unit = {
    Logger.log.info("Renaming the outbound file")
    val sourcePath=filepath
    val format = new SimpleDateFormat("MMddyyyyHHmmss")
    val targetPath=filepath + "/" +entnm +"_"+format.format(Calendar.getInstance().getTime())+".txt"
    Logger.log.info("Source Path:"+sourcePath)
    Logger.log.info("target Path:"+targetPath)
    val hadoopConf = new org.apache.hadoop.conf.Configuration()
    val hdfs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI(outputNodeAddress), hadoopConf)
    val source = new org.apache.hadoop.fs.Path(sourcePath)
    val target = new org.apache.hadoop.fs.Path(targetPath)
    val sourceFiles = hdfs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        val spath = sourceFiles.next().getPath()
        if (spath.toString.endsWith(".csv")) {
          hdfs.rename(spath, target)
        }
      }
    }
  }

  def fileRenameToCSV(outputNodeAddress: String, filepath: String, entnm: String): Unit = {
    Logger.log.info("Renaming the outbound file")
    val sourcePath=filepath
    val format = new SimpleDateFormat("MMddyyyyHHmmss")
    val targetPath=filepath + "/" +entnm +"_"+format.format(Calendar.getInstance().getTime())+".csv"
    Logger.log.info("Source Path:"+sourcePath)
    Logger.log.info("target Path:"+targetPath)
    val hadoopConf = new org.apache.hadoop.conf.Configuration()
    val hdfs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI(outputNodeAddress), hadoopConf)
    val source = new org.apache.hadoop.fs.Path(sourcePath)
    val target = new org.apache.hadoop.fs.Path(targetPath)
    val sourceFiles = hdfs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        val spath = sourceFiles.next().getPath()
        if (spath.toString.endsWith(".csv")) {
          hdfs.rename(spath, target)
        }
      }
    }
  }

  def moveTxtFile(srcFilePath: String, destFilePath: String): Unit = {
    val hadoopConf = new Configuration()
    val source = new Path(srcFilePath)
    val target = new Path(destFilePath)
    val fs: FileSystem = source.getFileSystem(hadoopConf)
    val sourceFiles = fs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        val spath = sourceFiles.next().getPath()
        if (spath.toString.endsWith(".txt")) {
          FileUtil.copy(fs, spath, fs, target, true, hadoopConf)
        }
      }
    }
  }

  def moveCSVFile(srcFilePath: String, destFilePath: String): Unit = {
    val hadoopConf = new Configuration()
    val source = new Path(srcFilePath)
    val target = new Path(destFilePath)
    val fs: FileSystem = source.getFileSystem(hadoopConf)
    val sourceFiles = fs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        val spath = sourceFiles.next().getPath()
        if (spath.toString.endsWith(".csv")) {
          FileUtil.copy(fs, spath, fs, target, true, hadoopConf)
        }
      }
    }
  }

  var returnList = List[String]()
  def historyList(directory: String, partdate: String): List[String] = {
    val d = new File(directory)
    for (filelist <- d.listFiles()) {
      if (filelist.isDirectory) {
        if (filelist.getAbsolutePath.contains(partdate)) {
          historyList(filelist.getAbsolutePath, partdate)
        }
      } else {
        returnList = filelist.getAbsolutePath :: returnList
      }
    }
    returnList
  }
  def cleanOutputPath(outputNodeAddress: String, outputFilePath: String): Unit = {
    val hadoopConf = new org.apache.hadoop.conf.Configuration()
    val hdfs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI(outputNodeAddress), hadoopConf)
    val path = new org.apache.hadoop.fs.Path(outputFilePath)
    if (hdfs.exists(path)) {
      Logger.log.info("Overwriting staging outbound directory : " + path)
      try { hdfs.delete(path, true) } catch { case _: Throwable => {} }
    } else { printf("output directory from path %s is empty.... Exiting clean", path) }
    hdfs.mkdirs(path)
  }
}
