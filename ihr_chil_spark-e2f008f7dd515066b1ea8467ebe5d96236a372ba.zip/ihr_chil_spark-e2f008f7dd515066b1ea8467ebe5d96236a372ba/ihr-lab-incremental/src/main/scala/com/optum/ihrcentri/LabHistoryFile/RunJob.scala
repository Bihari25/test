package com.optum.ihrcentri.LabHistoryFile

import com.optum.ihrcentri.Common._
import org.apache.spark.storage.StorageLevel

/**
  * Created by mmallam2 on May,2018
  *
  **/

object RunJob {
  def main(args: Array[String]): Unit = {

    val globalContext = new GlobalContext
    val functions = new CommonFunctions
    val transformations=new Transformations

    import java.text.SimpleDateFormat
    import java.util.Calendar

    val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val starTimeStamp = format.format(Calendar.getInstance().getTime())
    Logger.log.info("=============> Starting IHR Lab Results Framework <=============")
    if (args.length != 2) {
      Logger.log.info("Please Pass RowKey \"PATNRCD-SRCCD-ENTITYNAME\"  and Filter_File for IHR Incremental extract")
      Logger.log.info("===> Since No RowKey and Filter File not Passed ending Ihr LabResults extract <===")
      ReportGeneration.HBaseAuditFailureReport("No-Row-key-LabResults", "No-Row-key-LabResults", "2", "Since No RowKey is Passed ending IHR Incremental extract", "starTimeStamp")
      globalContext.spark.stop()
    } else {
      val rowKey = args(0).toUpperCase().trim
      val FilterFile=args(1).toUpperCase().trim
      val auditRowKey = rowKey + "-" + s"${java.util.UUID.randomUUID.toString}"
      try {
        val rptCfgScan = Lib.getEntityInfo(rowKey)
        val incEndTs = Lib.getCurrentTimeFormat
        rptCfgScan.foreach { case (patnrCd, srcCd, entNm, lastRunSts, outFileNm, outFileExt, isFilter) =>

          Logger.log.info("==============> Extracting the data from Lab Flatten tables and Creating the Hl7 FILE <=============== ")

          val stgLogDir = globalContext.stgdir + entNm + "/stglogdir/"
          val stgLogPath = stgLogDir.replace("/mapr/", "hdfs:///")

          val stgOutpath = globalContext.stgdir + entNm + "/stgoutdir/"
          val stgdistinctPath = globalContext.stgdir + entNm + "/stgDistinct"
          val distinctStg = stgdistinctPath.replace("/mapr/", "hdfs:///")
          val stgPath = stgOutpath.replace("/mapr/", "hdfs:///")
          val outPath = globalContext.outpath.concat(s"/$entNm/").replace("/mapr/", "hdfs:///")


          functions.cleanOutputPath(globalContext.outputNodeAddress, stgLogPath)
          functions.cleanOutputPath(globalContext.outputNodeAddress, stgPath)
          functions.cleanOutputPath(globalContext.outputNodeAddress, distinctStg)

          val logdir = globalContext.logDir.replace("/mapr/", "hdfs:///")
          //val outPath = globalContext.outpath.concat(s"/$entNm/").replace("/mapr/", "hdfs:///")
            val aco_members = "aco_roster"
            val msh_table = globalContext.msh_table
            val db = globalContext.dbName
            val spark = globalContext.sparkS
            val acofile = globalContext.aco_file

            val mshDF = spark.read.table(s"$db.$msh_table")
            val hl7_members = "hl7_member"
            if (entNm.contains("QUESTDIA")) {
              Logger.log.info("Reading the messages from QUESTDIA")
              mshDF.filter("SOURCE_CODE='SDR' and DOMAIN='QUESTDIA'").createOrReplaceTempView(s"$hl7_members")
            } else if (entNm.contains("LABCORPDIA")) {
              Logger.log.info("Reading the messages from LABCORPDIA")
              mshDF.filter("SOURCE_CODE='SDR' and DOMAIN='LABCORPDIA'").createOrReplaceTempView(s"$hl7_members")
            }
            val messages = spark.sql(s"select * from $hl7_members")
            val messagesCount=messages.count
            Logger.log.info(s"Messages received for $entNm : " + messagesCount)
           if(isFilter.equalsIgnoreCase("Yes")) {
             if(FilterFile.equalsIgnoreCase("ACO")) {
               Logger.log.info("Reading the Aco file")
               val acodf = transformations.SDRreadAcoFile(acofile, spark).cache()
               Logger.log.info("Member Count in Aco Roster file:" + acodf.count())
               acodf.createOrReplaceTempView(s"$aco_members")
             }else if(FilterFile.equalsIgnoreCase("EI")){
               Logger.log.info("Reading the EI files")
               val dirPath = globalContext.spark.getConf.get("spark.eiDirectory")
               val UnionDF = transformations.unionDirectoryList(functions.ListDirFiles(dirPath), spark)
               val ei_members = transformations.SDRAcoFields(UnionDF)
               val memCount = ei_members.count()
               Logger.log.info("Member Count from EI Files:" + memCount)
               ei_members.createOrReplaceTempView(s"$aco_members")
             }else{
               Logger.log.info("FilterFile Argument must be either ACO/EI")
               ReportGeneration.HBaseAuditFailureReport(rowKey, auditRowKey, "Invalid argument", s"Invalid Filter File argument: $FilterFile", starTimeStamp)
               globalContext.spark.stop()
             }
             Logger.log.info("Starting the aco filter for:" + entNm)
             val matchedMembers = spark.sql(s"""select match.10_MESSAGE_CNTRL_ID_ST as 10_MESSAGE_CNTRL_ID_ST,match.5_2_PATIENT_NAME_XPN_GIVEN_NM_ST as 5_2_PATIENT_NAME_XPN_GIVEN_NM_ST,match.5_1_PATIENT_NAME_XPN_FAM_NM_FN as 5_1_PATIENT_NAME_XPN_FAM_NM_FN,match.7_DATE_OF_BIRTH_TS as 7_DATE_OF_BIRTH_TS,match.8_ADMINISTRATIVE_SEX_IS as 8_ADMINISTRATIVE_SEX_IS,match.HL7_MESSAGE as HL7_MESSAGE from(select hardmatch.* from (select h.* from $hl7_members h join $aco_members a on trim(lpad(h.DERIVED_PATIENT_IDENTIFIER,15,'0')) = trim(lpad(a.subscriber_id,15,'0')) union select h.* from $hl7_members h join $aco_members a on trim(lpad(h.DERIVED_PATIENT_IDENTIFIER,15,'0')) = trim(lpad(a.alt_id,15,'0')) union select h.* from $hl7_members h join $aco_members a on trim(lpad(h.DERIVED_PATIENT_IDENTIFIER,15,'0')) = trim(lpad(a.card_id,15,'0')))hardmatch union select softmatch.* from (select h.* from $hl7_members h join $aco_members a on trim(substr(h.5_2_PATIENT_NAME_XPN_GIVEN_NM_ST,1,3))=trim(substr(a.member_first_name,1,3)) and trim(substr(h.5_1_PATIENT_NAME_XPN_FAM_NM_FN,1,4))=trim(substr(a.member_last_name,1,4)) and trim(h.7_DATE_OF_BIRTH_TS)=trim(a.member_birth_date) and trim(h.8_ADMINISTRATIVE_SEX_IS)=trim(a.member_gender) union select h.* from $hl7_members h join $aco_members a on trim(substr(h.5_2_PATIENT_NAME_XPN_GIVEN_NM_ST,1,3))=trim(substr(a.member_first_name,1,3)) and trim(substr(h.5_1_PATIENT_NAME_XPN_FAM_NM_FN,1,4))=trim(substr(a.member_last_name,1,4)) and trim(h.7_DATE_OF_BIRTH_TS)=trim(a.member_birth_date) union select h.* from $hl7_members h join $aco_members a on trim(substr(h.5_1_PATIENT_NAME_XPN_FAM_NM_FN,1,4))=trim(substr(a.member_last_name,1,4)) and trim(h.7_DATE_OF_BIRTH_TS)=trim(a.member_birth_date) and trim(h.8_ADMINISTRATIVE_SEX_IS)=trim(a.member_gender) union select h.* from $hl7_members h join $aco_members a on substr(h.5_2_PATIENT_NAME_XPN_GIVEN_NM_ST,1,3)=substr(a.member_first_name,1,3) and h.7_DATE_OF_BIRTH_TS=a.member_birth_date and h.8_ADMINISTRATIVE_SEX_IS=a.member_gender union select h.* from $hl7_members h join $aco_members a on substr(h.5_2_PATIENT_NAME_XPN_GIVEN_NM_ST,1,3)=trim(substr(a.member_first_name,1,3)) and trim(substr(h.5_1_PATIENT_NAME_XPN_FAM_NM_FN,1,4))=trim(substr(a.member_last_name,1,4)) and trim(h.8_ADMINISTRATIVE_SEX_IS)=trim(a.member_gender))softmatch)match""")
             val matchedCount = matchedMembers.count().toString
             Logger.log.info("Aco Match Count:" + matchedCount)
             transformations.SDROutBoundFile(spark, matchedMembers.selectExpr("""split(hl7_message,"BTS\\|\\d+")[0] as hl7_message"""), stgPath + "/file")
             functions.fileRenameToHL7(globalContext.outputNodeAddress, stgPath, auditRowKey)
             transformations.distinctMembers(matchedMembers.select("7_DATE_OF_BIRTH_TS", "8_ADMINISTRATIVE_SEX_IS", "5_2_PATIENT_NAME_XPN_GIVEN_NM_ST", "5_1_PATIENT_NAME_XPN_FAM_NM_FN"), distinctStg + "/Temp")
             val distinctCount = matchedMembers.select("7_DATE_OF_BIRTH_TS", "8_ADMINISTRATIVE_SEX_IS", "5_2_PATIENT_NAME_XPN_GIVEN_NM_ST", "5_1_PATIENT_NAME_XPN_FAM_NM_FN").distinct().count()
             Logger.log.info("Aco Match Count:" + matchedCount)
             matchedMembers.createOrReplaceTempView("MatchedMembers")
             Logger.log.info("Creating log File")
             val logDf = spark.sql(s"select h.10_MESSAGE_CNTRL_ID_ST,h.DERIVED_PATIENT_IDENTIFIER as DERIVED_PATIENT_IDENTIFIER,to_date(cast(unix_timestamp(h.7_DATE_OF_BIRTH_TS,'yyyyMMdd') AS timestamp)) as 7_DATE_OF_BIRTH_TS,h.8_ADMINISTRATIVE_SEX_IS as 8_ADMINISTRATIVE_SEX_IS,h.5_2_PATIENT_NAME_XPN_GIVEN_NM_ST as 5_2_PATIENT_NAME_XPN_GIVEN_NM_ST,h.5_1_PATIENT_NAME_XPN_FAM_NM_FN as 5_1_PATIENT_NAME_XPN_FAM_NM_FN,case when match.HL7_MESSAGE is not null then 'TRUE' else 'FALSE' end as senttoIHR,from_unixtime(unix_timestamp()) as Messagetimestamp from $hl7_members h left outer join matchedmembers match on h.HL7_MESSAGE=match.HL7_MESSAGE")
             val misMatches = logDf.filter("senttoIHR='FALSE'").count
             mshDF.unpersist()
             matchedMembers.unpersist()
             //functions.CreateCSVlogFile(logDf,stgLogPath+"/Temp")
             functions.fileRenameToCSV(globalContext.outputNodeAddress, stgLogPath, auditRowKey)
             Logger.log.info("Moving to actual log dir")
             functions.moveHL7File(stgPath, outPath)
             functions.moveCSVFile(stgLogPath, logdir + entNm)
             Logger.log.info("Generating the Success Audit Report")
             ReportGeneration.HbaseAuditSuccessReport(rowKey, auditRowKey, starTimeStamp, matchedCount, misMatches.toString, "0")

             Logger.log.info("Total Messages: " + matchedCount)
             Logger.log.info("Total UnMatched Messages: " + misMatches)
             Logger.log.info("Total Distinct Messages: " + distinctCount)
             Logger.log.info(s"==============> SDR Lab Results Consumption job for ${entNm} with Filter completed successfully <===============")
             globalContext.spark.stop()
           }else if(isFilter.equalsIgnoreCase("No")){
             Logger.log.info(s"Creating the $entNm Extract")
             transformations.SDROutBoundFile(spark, messages.selectExpr("""split(hl7_message,"BTS\\|\\d+")[0] as hl7_message"""), stgPath + "/file")
             functions.fileRenameToHL7(globalContext.outputNodeAddress, stgPath, auditRowKey)
             Logger.log.info("Moving to  acutal outbound dir")
             functions.moveHL7File(stgPath, outPath)
             Logger.log.info("Generating the Success Audit Report")
             ReportGeneration.HbaseAuditSuccessReport(rowKey, auditRowKey, starTimeStamp, messagesCount.toString, "", "0")
             Logger.log.info("Total Messages: " + messagesCount)
             Logger.log.info(s"==============> SDR Lab Results Consumption job for ${entNm} completed successfully <===============")
             globalContext.spark.stop()
           }
        }
      }
      catch {
          case e: Exception => Logger.log.info("Errored: " + e.getMessage)
            ReportGeneration.HBaseAuditFailureReport(rowKey, auditRowKey, e.getLocalizedMessage, e.getMessage, starTimeStamp)
            globalContext.spark.stop()
      }
    }
  }
}
