package com.optum.ihrcentri.Common

import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.HTable
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession

/**
  * Created by rkodur on 3/6/2018.
  */
class GlobalContext {

  val sparkS:SparkSession=this.createSparkSession("LabResults")
  var spark: SparkContext = sparkS.sparkContext


  def createSparkSession(appName: String): SparkSession = {
    try {
      //val sparkSession = SparkSession.builder().appName(appName).getOrCreate()
      val sparkSession=SparkSession.builder().appName(s"$appName").config("spark.rpc.message.maxSize",2047).config("hive.metastore.uris","thrift://dbslp0567.uhc.com:11016").enableHiveSupport().getOrCreate()
      //val sparkSession=SparkSession.builder().appName(s"$appName").config("spark.rpc.message.maxSize",2047).enableHiveSupport().getOrCreate()
      sparkSession.conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      sparkSession
    }
    catch {
      case e: Exception => Logger.log.info(s"Exception at GlobalContext CreateSparkSession function:" + e.getStackTrace.toString)
        throw e
    }
  }

    val aco_table :String= spark.getConf.get("spark.aco_table")
    val outpath:String = spark.getConf.get("spark.outPath")
    val dbName: String= spark.getConf.get("spark.labDbName")

    val aco_file:String=spark.getConf.get("spark.aco_file")
    val msh_table: String=spark.getConf.get("spark.msh_table")
    val obr_table: String=spark.getConf.get("spark.Obr_table")
    val obx_table: String=spark.getConf.get("spark.obx_table")
    val diag_table: String=spark.getConf.get("spark.ft1_diagcode_table")

    val flatten_outPath: String=spark.getConf.get("spark.externalFlattenTables")
    val startDate: String=spark.getConf.get("spark.startDate")
    //val isEndDate: String=spark.getConf.get("spark.isEndDate")
    //val endDate: String=spark.getConf.get("spark.EndDate")

    val outputNodeAddress:String = spark.getConf.get("spark.node.address")
    val logDir:String = spark.getConf.get("spark.logdir")
    val RuntimColFm:String = spark.getConf.get("spark.RuntimStColFm")
    val RuntimColNm:String = spark.getConf.get("spark.RuntimStConNm")
    val IngRuntimColNm: String=spark.getConf.get("spark.IngRuntimStConNm")

    val errorDir:String = spark.getConf.get("spark.errorDir")
    val stgdir:String=spark.getConf.get("spark.stgdir")

    val threads:String=spark.getConf.get("spark.threads")
    //val isHistory:String=spark.getConf.get("spark.isHistory")
    val partDate:String=spark.getConf.get("spark.partDate")

    //val inboundPath:String=spark.getConf.get("spark.inboundPath")
    val quest_InboundPath: String=spark.getConf.get("spark.QuestInboundPath")
    val LabCorp_InboundPath: String=spark.getConf.get("spark.LabcorpInboundPath")

    val hBaseConf:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
    val hbaseContext = new HBaseContext(spark, hBaseConf)
    val fs: FileSystem = FileSystem.get(spark.hadoopConfiguration)
    val hBaseConf1:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
    hBaseConf1.set(TableInputFormat.INPUT_TABLE, spark.getConf.get("spark.ihrCtlTab"))
    val ihrCtlTab: HTable = new HTable(hBaseConf1, spark.getConf.get("spark.ihrCtlTab"))
    val hBaseConf2:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
    hBaseConf2.set(TableInputFormat.INPUT_TABLE, spark.getConf.get("spark.ihrEitTab"))
    val ihrEitTab: HTable = new HTable(hBaseConf1, spark.getConf.get("spark.ihrEitTab"))
}
