package com.optum.ihrcentri.LabGalaxyIngestion

import java.text.SimpleDateFormat
import java.util.Calendar

import com.optum.ihrcentri.Common._

import scala.collection.parallel.ForkJoinTaskSupport

/**
  * Created by mmallam2 on May,2018
  *
  **/

object RunJob {
  def main(args: Array[String]): Unit = {

    val globalContext = new GlobalContext
    val functions = new CommonFunctions

    val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val starTimeStamp = format.format(Calendar.getInstance().getTime())
    if (args.length != 1) {
      Logger.log.info("Please Pass RowKey \"PATNRCD-SRCCD-ENTITYNAME\"")
      Logger.log.info("===> Since No RowKey is Passed ending Galaxy Lab results extract <===")
      ReportGeneration.HBaseAuditFailureReport("No-Row-key-LabResults", "No-Row-key-LabResults", "2", "Since No RowKey is Passed ending IHR Incremental extract", starTimeStamp)
      globalContext.spark.stop()
    } else {
      val rowKey = args(0).toUpperCase().trim
      val auditRowKey = rowKey + "-" + s"${java.util.UUID.randomUUID.toString}"
      val entNm = rowKey.split('-')(2)
      var failedDate=""
      try {
        Logger.log.info("=================> Lab Results Galaxy Files History load started <==========================")
        val stgOutpath = globalContext.stgdir + entNm + "/stgoutdir/"
        val stgErrorDir = globalContext.stgdir + entNm + "/stgerrordir/"

        val stgPath = stgOutpath.replace("/mapr/", "hdfs:///")

        val out_path = globalContext.flatten_outPath.replace("/mapr/", "hdfs:///")

        functions.cleanOutputPath(globalContext.outputNodeAddress, stgPath)

        val labDb=globalContext.dbName

        Logger.log.info(s"Creating database $labDb if not exists")
        globalContext.sparkS.sql(s"create database if not exists $labDb")
        Logger.log.info("Creating Table for: "+globalContext.msh_table+" if not exits")
        Lib.CreateMSHTable(globalContext.sparkS,globalContext.dbName,globalContext.msh_table,out_path)
        Logger.log.info("Creating Table for: "+globalContext.obr_table+" if not exits")
        Lib.createOBRTable(globalContext.sparkS,globalContext.dbName,globalContext.obr_table,out_path)
        Logger.log.info("Creating Table for: "+globalContext.diag_table+" if not exits")
        Lib.createDIAGTable(globalContext.sparkS,globalContext.dbName,globalContext.diag_table,out_path)
        Logger.log.info("Creating Table for: "+globalContext.obx_table+" if not exits")
        Lib.createOBXTable(globalContext.sparkS,globalContext.dbName,globalContext.obx_table,out_path)

        var endPartDate=""
        var inboundPath = ""
        if (entNm.toUpperCase.contains("QUESTDIA")) {
          inboundPath = globalContext.quest_InboundPath
          endPartDate="2017-04-30"
          Logger.log.info(s"Inbound path for $entNm: $inboundPath and End partition Date:"+endPartDate)
        } else if(entNm.toUpperCase.contains("LABCORPDIA")){
          Logger.log.info("")
          endPartDate="2017-04-23"
          inboundPath = globalContext.LabCorp_InboundPath
          Logger.log.info(s"Inbound path for $entNm: $inboundPath and End partition Date:"+endPartDate)
        }
        val startDate = "2015-10-07"
        val endDate = Lib.getEndDate(rowKey)(0)
        var historyStartDate="2015-10-07"
        val format = new SimpleDateFormat("yyyy-MM-dd")

        if(endDate.split('-')(0).toInt != 0) {
          historyStartDate=endDate
          Logger.log.info(s"Starting date of the history files for $entNm:"+ historyStartDate)
        } else {
          historyStartDate=startDate
          Logger.log.info(s"Starting date of the history files for $entNm:"+ historyStartDate)
        }
        val dateList=functions.genDateRange(format.parse(historyStartDate),format.parse(endPartDate))
        for(folderDate <- dateList){
          val folderFormat = new java.text.SimpleDateFormat("yyyyMMdd")
          failedDate=format.format(folderDate.getTime)
          val partitionDate="date="+folderFormat.format(folderDate)
          History.runHistory(globalContext.createSparkSession(s"LABRESULTS-$entNm"),inboundPath,partitionDate,entNm,rowKey)
        }
        Logger.log.info("Updating the HBase timestamp:" + format.format(Calendar.getInstance().getTime()))
        Lib.hbaseEitPut(rowKey, "is", "intEndDate","0000-00-00" )
        Logger.log.info("==============> Lab Results History files flatten ingestion process completed successfully <===============")
      }catch {
        case e: Exception => Logger.log.info("Errored: " + e.getMessage)
          Logger.log.info("Generating the Error Audit Report")
          ReportGeneration.HBaseAuditFailureReport(rowKey,auditRowKey,e.getLocalizedMessage,e.getMessage,starTimeStamp)
          Logger.log.info("Updating the HBase timestamp" + format.format(Calendar.getInstance().getTime()))
          Lib.hbaseEitPut(rowKey, "is", "intEndDate",failedDate )
          globalContext.spark.stop()
      }
    }
  }
}