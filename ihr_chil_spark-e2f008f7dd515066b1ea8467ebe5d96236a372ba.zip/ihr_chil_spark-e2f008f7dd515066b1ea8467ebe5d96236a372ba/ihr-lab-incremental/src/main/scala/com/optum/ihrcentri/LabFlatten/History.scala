package com.optum.ihrcentri.LabFlatten

import java.text.SimpleDateFormat
import java.util.Calendar

import com.optum.ihrcentri.Common._

import scala.collection.parallel.{ForkJoinTaskSupport, ParSeq}
import org.apache.spark.sql.SparkSession


/**
  * Created by mmallam2 on May,2018
  *
  **/

object History {

  val globalContext = new GlobalContext
  val functions = new CommonFunctions
  val run=new Ingestion

  val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val starTimeStamp = format.format(Calendar.getInstance().getTime())


  val numThreads: Int = globalContext.threads.toInt
  def runHistory(spark: SparkSession,inboundPath: String,partDate: String,entNm: String,rowKey: String):Unit={

    run.totalMessages=0
    run.totalErrorMessages=0

    Logger.log.info(s"==============> Extracting the history files from the partition date: $partDate of $entNm <=================")

    val Audit_RowKey = rowKey + "-" + s"${java.util.UUID.randomUUID.toString}"
    val stgOutpath = globalContext.stgdir + entNm + "/stgoutdir/"
    val stgErrorDir = globalContext.stgdir + entNm + "/stgerrordir/"

    val stgPath = stgOutpath.replace("/mapr/", "hdfs:///")
    val stgrrordir = stgErrorDir.replace("/mapr/", "hdfs:///")

    val errordir = globalContext.errorDir.replace("/mapr/", "hdfs:///")
    val out_path = globalContext.flatten_outPath.replace("/mapr/", "hdfs:///")

    functions.cleanOutputPath(globalContext.outputNodeAddress, stgPath)
    functions.cleanOutputPath(globalContext.outputNodeAddress, stgrrordir)

    val historyList = functions.historyTestList(inboundPath, partDate).par

    historyList.tasksupport = new ForkJoinTaskSupport(new scala.concurrent.forkjoin.ForkJoinPool(numThreads))

      Logger.log.info(s"Total FileList: " + historyList.size)
      Logger.log.info(s"List of Files" + historyList)

      for (file2 <- historyList) {
        Logger.log.info("Current Processing file: " + file2)
        Thread.sleep(1000)
        run.runIngestion(spark,file2,stgPath,globalContext.msh_table,globalContext.obr_table,globalContext.obx_table,globalContext.diag_table,stgErrorDir: String,entNm,rowKey,Audit_RowKey,starTimeStamp.toString)
      }
    val dateFormat = new SimpleDateFormat("yyyy-MM-dd")
    val currentDate=dateFormat.format(Calendar.getInstance().getTime())

    if(historyList.size!=0) {
      Logger.log.info(s"Loading data for: " + globalContext.msh_table + " table into partition: " + currentDate)
      functions.moveParquetFile(stgPath + "/" + globalContext.msh_table, globalContext.outputNodeAddress, globalContext.msh_table, out_path)
      Lib.msckRepairTable(spark, globalContext.dbName, globalContext.msh_table)

      Logger.log.info(s"Loading data for: " + globalContext.obx_table + " table into partition: " + currentDate)
      functions.moveParquetFile(stgPath + "/" + globalContext.obx_table, globalContext.outputNodeAddress, globalContext.obx_table, out_path)
      Lib.msckRepairTable(spark, globalContext.dbName, globalContext.obx_table)

      Logger.log.info(s"Loading data for: " + globalContext.obr_table + " table into partition: " + currentDate)
      functions.moveParquetFile(stgPath + "/" + globalContext.obr_table, globalContext.outputNodeAddress, globalContext.obr_table, out_path)
      Lib.msckRepairTable(spark, globalContext.dbName, globalContext.obr_table)

      Logger.log.info(s"Loading data for: " + globalContext.diag_table + " table into partition: " + currentDate)
      functions.moveParquetFile(stgPath + "/" + globalContext.diag_table, globalContext.outputNodeAddress, globalContext.diag_table, out_path)
      Lib.msckRepairTable(spark, globalContext.dbName, globalContext.diag_table)

      Logger.log.info("Moving files from stg error dir to actual error dir")
      functions.moveFile(stgrrordir, errordir + "/" + entNm + "/")

      Logger.log.info("Generating the Success Audit Report")
      ReportGeneration.HbaseAuditSuccessReport(rowKey, Audit_RowKey, starTimeStamp, run.totalMessages.toString, "0", run.totalErrorMessages.toString)

      Logger.log.info("Total Ingested messages: " + run.totalMessages)
      Logger.log.info("Records Errored messages: " + run.totalErrorMessages)
    }else{
      Logger.log.info("No files for the partiion:" + partDate)
    }
  }
}
