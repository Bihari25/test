package com.optum.ihrcentri.Common

import java.io.{InputStream, _}
import java.text.SimpleDateFormat
import java.util.{Calendar, Date}
import java.util.zip.{ZipEntry, ZipFile, ZipInputStream}
import java.io._
import ca.uhn.hl7v2.DefaultHapiContext
import ca.uhn.hl7v2.HL7Exception
import ca.uhn.hl7v2.parser.CanonicalModelClassFactory
import ca.uhn.hl7v2.util._
import org.apache.spark.sql.SparkSession
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, FileUtil, Path}
import org.apache.spark.SparkContext
import org.apache.spark.input.PortableDataStream
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable


class CommonFunctions {

  def readAcomembers(spark:SparkSession,tableName:String):DataFrame={
    Logger.log.info("Reading the aco members")
    val acoDf=spark.read.table(s"$tableName").cache()
    Logger.log.info("Aco_member count: "+ acoDf.count)
    acoDf
  }

  def noFilterHl7(spark: SparkSession,hl7df:DataFrame):DataFrame={
    hl7df.select("msgblock")
  }
  def csvtoList(spark: SparkSession, csvdf:DataFrame):List[String]={
    csvdf.rdd.coalesce(1).map(x => x.mkString(",")).collect.toList
  }

  def buildH7File(hl7list: List[String],outPath:String): Unit ={
    val file = new File(outPath)
    Logger.log.info(s"Building HL7 file in $outPath")
    val fwrite = new PrintWriter(new FileOutputStream(file, true))
    var count = 0
    fwrite.write("")
    for (hl7msg <- hl7list) {
      count += 1
      fwrite.write(hl7msg)
      fwrite.write("\n")
    }
    Logger.log.info("Created file with " + count + " messsages")
    fwrite.flush()
    fwrite.close()
  }

  def unzip(filePath: String):InputStream={
    Logger.log.info("Opening Zip file")
    var stream: InputStream = new FileInputStream(filePath)
    try {
      val zip = new ZipFile(filePath)
      val entries = zip.entries
      var entry = entries.nextElement()
      while (entries.hasMoreElements()) {
        if (entry.getName.endsWith(".hl7")) {
          Logger.log.info("Hl7 FileName: " + entry.getName)
          stream = zip.getInputStream(entry)
        }
        entry = entries.nextElement()
      }
    }catch{
      case e: IOException => Logger.log.info("exception caught: " + e.getMessage)
    }
    stream
  }
  var hl7FileName=""
  def unzip(spark: SparkSession,filePath: String,rowKey:String,auditRowKey:String,startTime:String):InputStream={
    Logger.log.info("Opening Zip file")
    var stream: InputStream = new FileInputStream(filePath)
    try {
      val zip = new ZipFile(filePath)
      val entries = zip.entries
      var entry = entries.nextElement()
      while (entries.hasMoreElements()) {
        if (entry.getName.endsWith(".hl7")) {
          hl7FileName = entry.getName
          Logger.log.info(s"Hl7 FileName inside source zip file: $filePath : " + hl7FileName)
          stream = zip.getInputStream(entry)
        }
        entry = entries.nextElement()
      }
      if(hl7FileName.isEmpty){
        Logger.log.info(s"========>No HL7 Files inside the source Zip file: ${filePath}<===============")
        ReportGeneration.HBaseAuditFailureReport(rowKey,auditRowKey,s"No HL7 Files inside the source Zip file: ${filePath}","Hl7 File missing",startTime)
        System.exit(1)
        spark.stop()
      }
    }catch{
      case e: IOException => Logger.log.info("exception caught: " + e.getMessage)
    }
    stream
  }

  def unZipIt(zipFile: String, outputFolder: String): Unit = {
    val buffer = new Array[Byte](1024)
    try {
      //output directory
      val folder = new File(outputFolder);
      if (!folder.exists()) {
        folder.mkdir();
      }
      //zip file content
      val zis: ZipInputStream = new ZipInputStream(new FileInputStream(zipFile));
      //get the zipped file list entry
      var ze: ZipEntry = zis.getNextEntry();
      while (ze != null) {
        val fileName = ze.getName();
        val newFile = new File(outputFolder + File.separator + fileName);
        System.out.println("file unzip : " + newFile.getAbsoluteFile());
        //create folders
        new File(newFile.getParent()).mkdirs();
        val fos = new FileOutputStream(newFile);
        var len: Int = zis.read(buffer);
        while (len > 0) {
          fos.write(buffer, 0, len)
          len = zis.read(buffer)
        }
        fos.close()
        ze = zis.getNextEntry()
      }
      zis.closeEntry()
      zis.close()
    } catch {
      case e: IOException => println("exception caught: " + e.getMessage)
    }
  }

  def toList(listDf: DataFrame):List[String]={
    listDf.rdd.map(r=>r(0).toString).collect.toList
  }


  def moveFile(srcFilePath: String,destFilePath: String): Unit= {
    val hadoopConf = new Configuration()
    val source = new Path(srcFilePath)
    val target = new Path(destFilePath)
    val fs: FileSystem = source.getFileSystem(hadoopConf)
    val sourceFiles = fs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        FileUtil.copy(fs, sourceFiles.next().getPath(), fs, target, true, hadoopConf)
      }
    }
  }
  def moveParquetFile(srcFilePath: String,outputNodeAddress: String,tableName: String,destFilePath: String): Unit = {
    var count=0
    val dateformat = new SimpleDateFormat("yyyy-MM-dd")
    val currentDate=dateformat.format(Calendar.getInstance().getTime())
    val hadoopConf = new Configuration()
    val hdfs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI(outputNodeAddress), hadoopConf)
    val source = new Path(srcFilePath)
    val targetPath=destFilePath+"/"+tableName+s"/partition_date=$currentDate"+"/"
    val target = new Path(targetPath)
    if (!hdfs.exists(target)) {
      hdfs.mkdirs(target)
    }
    val fs: FileSystem = source.getFileSystem(hadoopConf)
    val sourceFiles = fs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        val spath = sourceFiles.next().getPath()
        if (spath.toString.endsWith(".parquet")) {
          FileUtil.copy(fs, spath, fs, target, true, hadoopConf)
          count+=1
        }
      }
    }
    Logger.log.info("Files moved: "+count)
  }

  def cleanOutputPath(outputNodeAddress: String, outputFilePath: String): Unit = {
    val hadoopConf = new org.apache.hadoop.conf.Configuration()
    val hdfs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI(outputNodeAddress), hadoopConf)
    val path = new org.apache.hadoop.fs.Path(outputFilePath)
    if (hdfs.exists(path)) {
      Logger.log.info("Overwriting staging directory : " + path)
      try { hdfs.delete(path, true) } catch { case _: Throwable => {} }
    } else { printf("output directory from path %s is empty.... Exiting clean", path) }
    hdfs.mkdirs(path)
  }

  def buildCsvFile(printDF: DataFrame,logPath: String): Unit={
    printDF.coalesce(1).write.csv(logPath)
  }


  def getListOfFiles(dir: String):List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
      d.listFiles.filter(_.isFile).toList
    } else {
      List[File]()
    }
  }
  def CreateCSVlogFile(logDF:DataFrame,outpath:String): Unit ={
    logDF.coalesce(1).write.format("com.databricks.spark.csv").option("delimiter", "|").option("header", "true").save(outpath)
  }

  var returnList=List[String]()
  def historyList(directory: String,partdate: String): List[String] ={
    val d = new File(directory)
    for(filelist <- d.listFiles()){
      if(filelist.isDirectory){
        if(filelist.getAbsolutePath.contains(partdate)){
          historyList(filelist.getAbsolutePath,partdate)
        }
      }else {
        returnList= filelist.getAbsolutePath :: returnList
      }
    }
    returnList
  }

  def historyTestList(directory: String, partDate: String): List[String] = {
    var returnList = List[String]()
    val d = new File(directory)
    for (filelist <- d.listFiles()) {
      if (filelist.isDirectory) {
        if (filelist.getAbsolutePath.contains(partDate)) {
          val partDir = new File(filelist.getAbsolutePath)
          for (curlist <- partDir.listFiles()) {
            returnList = curlist.getAbsolutePath :: returnList
          }
        }
      }
    }
    returnList
  }

  def fileRenameToCSV(outputNodeAddress: String, filepath: String,AuditName: String): Unit = {
    Logger.log.info("Renaming the outbound file")
    val sourcePath=filepath
    val targetPath=filepath+"/"+AuditName+".csv"
    val hadoopConf = new org.apache.hadoop.conf.Configuration()
    val hdfs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI(outputNodeAddress), hadoopConf)
    val source = new org.apache.hadoop.fs.Path(sourcePath)
    val target = new org.apache.hadoop.fs.Path(targetPath)
    val sourceFiles = hdfs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        val spath = sourceFiles.next().getPath()
        if (spath.toString.endsWith(".csv")) {
          hdfs.rename(spath, target)
        }
      }
    }
  }

  def fileRenameToTXT(outputNodeAddress: String, filepath: String, AuditName: String): Unit = {
    Logger.log.info("Renaming the outbound file")
    val sourcePath=filepath
    val format = new SimpleDateFormat("MMddyyyyHHmmss")
    val targetPath=filepath+"/"+AuditName+".txt"
    Logger.log.info("Source Path:"+sourcePath)
    Logger.log.info("target Path:"+targetPath)
    val hadoopConf = new org.apache.hadoop.conf.Configuration()
    val hdfs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI(outputNodeAddress), hadoopConf)
    val source = new org.apache.hadoop.fs.Path(sourcePath)
    val target = new org.apache.hadoop.fs.Path(targetPath)
    val sourceFiles = hdfs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        val spath = sourceFiles.next().getPath()
        if (spath.toString.contains("part-00000")) {
          hdfs.rename(spath, target)
        }
      }
    }
  }

  def fileRenameToHL7(outputNodeAddress: String, filepath: String, AuditName: String): Unit = {
    Logger.log.info("Renaming the outbound file")
    val sourcePath=filepath
    val format = new SimpleDateFormat("MMddyyyyHHmmss")
    val targetPath=filepath+"/"+AuditName+".hl7"
    Logger.log.info("Source Path:"+sourcePath)
    Logger.log.info("target Path:"+targetPath)
    val hadoopConf = new org.apache.hadoop.conf.Configuration()
    val hdfs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI(outputNodeAddress), hadoopConf)
    val source = new org.apache.hadoop.fs.Path(sourcePath)
    val target = new org.apache.hadoop.fs.Path(targetPath)
    val sourceFiles = hdfs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        val spath = sourceFiles.next().getPath()
        if (spath.toString.contains("part-00000")) {
          hdfs.rename(spath, target)
        }
      }
    }
  }

  def moveCSVFile(srcFilePath: String, destFilePath: String): Unit = {
    val hadoopConf = new Configuration()
    val source = new Path(srcFilePath)
    val target = new Path(destFilePath)
    Logger.log.info("Moving to target path:" +target)
    val fs: FileSystem = source.getFileSystem(hadoopConf)
    val sourceFiles = fs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        val spath = sourceFiles.next().getPath()
        if (spath.toString.endsWith(".csv")) {
          FileUtil.copy(fs, spath, fs, target, false, hadoopConf)
        }
      }
    }
  }
  def moveTxtFile(srcFilePath: String, destFilePath: String): Unit = {
    val hadoopConf = new Configuration()
    val source = new Path(srcFilePath)
    val target = new Path(destFilePath)
    val fs: FileSystem = source.getFileSystem(hadoopConf)
    val sourceFiles = fs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        val spath = sourceFiles.next().getPath()
        if (spath.toString.endsWith(".txt")) {
          FileUtil.copy(fs, spath, fs, target, true, hadoopConf)
        }
      }
    }
  }

  def moveHL7File(srcFilePath: String, destFilePath: String): Unit = {
    val hadoopConf = new Configuration()
    val source = new Path(srcFilePath)
    val target = new Path(destFilePath)
    val fs: FileSystem = source.getFileSystem(hadoopConf)
    val sourceFiles = fs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        val spath = sourceFiles.next().getPath()
        if (spath.toString.endsWith(".hl7")) {
          FileUtil.copy(fs, spath, fs, target, true, hadoopConf)
        }
      }
    }
  }

  def readFile(sc: SparkContext, path: String): RDD[String] = {
    val minPartitions: Int = sc.defaultMinPartitions
    if (path.endsWith(".zip")) {
      sc.binaryFiles(path, minPartitions)
        .flatMap { case (name: String, content: PortableDataStream) =>
          val zis = new ZipInputStream(content.open)
          Stream.continually(zis.getNextEntry)
            .takeWhile {
              case null => zis.close(); false
              case _ => true
            }
            .flatMap { _ =>
              val br = new BufferedReader(new InputStreamReader(zis))
              Stream.continually(br.readLine()).takeWhile(_ != null)
            }
        }
    } else {
      sc.textFile(path, minPartitions)
    }
  }
  def genDateRange (startDate: Date, endDate: Date): List[Date] = {
    var dt = startDate
    val res: mutable.MutableList[Date] = new mutable.MutableList[Date]()
    val c = Calendar.getInstance()
    while ( dt.before(endDate) || dt.equals(endDate)) {
      res += dt
      c.setTime(dt)
      c.add(Calendar. DATE, 1)
      dt = c.getTime
    }
    res.toList
  }
  def ListDirFiles(directorypath: String):List[String]={
    var returnList = List[String]()
    val d=new File(directorypath)
    for(fileList <- d.listFiles()){
      returnList= fileList.getAbsolutePath.replace("/mapr/","/") :: returnList
    }
    returnList
  }
}