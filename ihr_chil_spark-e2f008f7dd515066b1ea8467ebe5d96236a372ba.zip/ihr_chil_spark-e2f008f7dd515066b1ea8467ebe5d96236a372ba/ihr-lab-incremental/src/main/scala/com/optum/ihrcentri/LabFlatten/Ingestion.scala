package com.optum.ihrcentri.LabFlatten

import java.text.SimpleDateFormat
import java.util.Calendar

import org.apache.spark.sql.SparkSession
import com.optum.ihrcentri.Common._
import java.io.{InputStream, _}

import org.apache.spark.storage.StorageLevel

/**
  * Created by mmallam2 on Apr,2018
  *
  **/

class Ingestion {

  var totalMessages=0
  var totalErrorMessages=0

    def runIngestion(tempSpark: SparkSession,sourceFilePath: String,outbound_path: String,msh_table: String,obr_table: String,obx_table: String,daig_table: String,errorDir: String,entNm: String,row_key: String,auditRowKey: String,strts: String)={

      val functions=new CommonFunctions
      val parse=new Parser

      parse.msgCount=0
      parse.errorMsgs=0

      val finalErrorDir=errorDir.concat(auditRowKey)
      val hl7Stream=functions.unzip(tempSpark,sourceFilePath,row_key,auditRowKey,strts)
      parse.hl7parser(hl7Stream,sourceFilePath)

      Logger.log.info("Mapping the OBR segment")
      val obrDF=Transformations.createOBRDataFrame(tempSpark,parse.segmentOBR)

      Logger.log.info("Mapping the FT1 segment")
      val ft1DF=Transformations.createFT1DataFrame(tempSpark,parse.segmentFTI)

      Logger.log.info("Mapping the OBX segment")
      val obxDF=Transformations.createOBXDataFrame(tempSpark,parse.segmentOBX)

      Logger.log.info("Mapping the MSH segment")
      val mshDF=Transformations.createMSHDataFrame(tempSpark,parse.segmentMSH)

      Logger.log.info("Creating parquet file for: "+msh_table+" from:" +sourceFilePath)
      Transformations.saveDataFrame(mshDF,msh_table,outbound_path)

      Logger.log.info("Creating parquet file for: "+obr_table+" from:" +sourceFilePath)
      Transformations.saveDataFrame(obrDF,obr_table,outbound_path)

      Logger.log.info("Creating parquet file for: "+obx_table+" from:" +sourceFilePath)
      Transformations.saveDataFrame(obxDF,obx_table,outbound_path)

      Logger.log.info("Creating parquet file for: " +daig_table+" from:" +sourceFilePath)
      Transformations.saveDataFrame(ft1DF,daig_table,outbound_path)

      if(parse.errorMsgs!=0){
        Logger.log.info("Creating Error messages hl7 files")
        Logger.log.info("ErrorMessages:" +parse.errorMsgs)
        functions.buildH7File(parse.errorList,finalErrorDir+".hl7")
      }
      totalMessages += parse.msgCount
      totalErrorMessages += parse.errorMsgs
    }
}
