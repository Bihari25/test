package com.optum.ihrcentri.LabResults

import java.io._
import ca.uhn.hl7v2.DefaultHapiContext
import ca.uhn.hl7v2.HL7Exception
import ca.uhn.hl7v2.parser.CanonicalModelClassFactory
import ca.uhn.hl7v2.util._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql._

case class pschema(msgblock: String,pid: String,lastName: String,firstName: String,dob: String,gender: String,messageId: String)

class HL7Parser extends Serializable {

  var errorMsgs = 0
  var errorList = List[String]()
  var testList = List[List[String]]()


  def Hl7Reader(spark: SparkSession, stream: InputStream): DataFrame = {
      // val file=new FileReader(filepath)
      val iteration = new Hl7InputStreamMessageIterator(stream)
      val context = new DefaultHapiContext
      val version = new CanonicalModelClassFactory("2.5")
      context.setModelClassFactory(version)
      Logger.log.info("Hl7 File Parsing Initiated")
      //context.setValidationContext(DefaultValidation)
      var msgString =""""""
      var msgCount = 0

      while (iteration.hasNext) {
        val next = iteration.next
        val parser: ca.uhn.hl7v2.parser.PipeParser = context.getPipeParser
        try {
          val msg: ca.uhn.hl7v2.model.v25.message.ORU_R01 = parser.parse(next.toString).asInstanceOf[ca.uhn.hl7v2.model.v25.message.ORU_R01]
          msgString = parser.encode(msg).split("BTS\\|")(0)
          val messageId = msg.getMSH.getMessageControlID.getValue
          val pid = msg.getPATIENT_RESULT.getPATIENT.getPID
          val pid1 = pid.getPatientIdentifierList(0).getIDNumber.getValue
          val lastName = pid.getPatientName(0).getFamilyName.getSurname.getValue
          val firstName = pid.getPatientName(0).getGivenName.getValue
          val gender = pid.getAdministrativeSex.getValue
          val dob = pid.getDateTimeOfBirth.getTime
          testList = List(s"$msgString&&$pid1&&$lastName&&$firstName&&$dob&&$gender&&$messageId") :: testList

        } catch {
          case e: HL7Exception =>
            Logger.log.info("Invalid Message Format: " + e.getMessage)
            Logger.log.info("Error Code " + e.getError)
            errorList = next.toString :: errorList
            errorMsgs += 1
        }
        msgCount += 1
      }
      Logger.log.info(msgCount + " messages got parsed")

      if (errorMsgs != 0) {
        Logger.log.info(errorMsgs + " messages got errored")
        //Need to store this messages
      } else {}

    val listRDD = spark.sparkContext.parallelize(testList).flatMap(x => x)
    import spark.implicits._

    val labDF=listRDD.map(_.split("&&").map(_.trim)).map(p => pschema(p(0), p(1), p(2), p(3), p(4), p(5), p(6))).toDF
    labDF.select(col("msgblock"),regexp_replace(col("pid"), "\\,", "").alias("pid"),regexp_replace(col("lastName"), "\\,", "").alias("lastName"),regexp_replace(col("firstName"), "\\,", "").alias("firstName"),regexp_replace(col("dob"), "\\,", "").alias("dob"),regexp_replace(col("gender"), "\\,", "").alias("gender"),regexp_replace(col("messageId"), "\\,", "").alias("messageId"))
  }
}