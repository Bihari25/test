package com.uhg.optum.ihr.provider

import com.uhg.optum.ihr.common.{GlobalContext, Lib, Logger}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql._
import scala.collection.parallel.{ForkJoinTaskSupport, ParSeq}
/**
  * Created by mmallam2 on Aug,2018
  *
  **/

object Incremental_Consumption {
  def main(args: Array[String]): Unit = {
    val globalContext = new GlobalContext
    if (args.length != 1) {
      Logger.log.info("Please Pass RowKey \"PATNRCD-SRCCD-ENTITYNAME\" for IHR Incremental extract")
      Logger.log.info("===> Since No RowKey is Passed ending IHR Incremental extract <===")
      globalContext.spark.stop()
    } else {
      val rowKey = args(0).toUpperCase().trim
      val eitRowKey = s"$rowKey-${java.util.UUID.randomUUID.toString}"
      try {
        val process_Name = rowKey.split('_')(2)
        val spark = globalContext.createSparkSession(process_Name + "_Consumption")
        val prcStTm = Lib.getCurrentTimeFormat
        Lib.hbaseEitPut(eitRowKey, "pi", "prcStTm", prcStTm)
        //val rptCfgScan = Lib.getEntityInfo(rowKey)
        val rptCfgScan=Lib.getConsEntityInfo(rowKey)
        Logger.log.info(s"Entity Config for ${rowKey} from ihr_ent_info Table: " + rptCfgScan.mkString)
        rptCfgScan.foreach { case (patnrCd, srcCd, entNm, lastRunSts,outDelim, outFileNm, outFileExt, nasLoc, quoteCol, isJoin, isNasLoc, endts, extractNm) =>
          if(lastRunSts.length==0){
            Logger.log.info("Please check is:lastRunSts field value in Hbase eit table it should ne either 'null' or TIMESTAMP FORMAT. it can't be empty.")
            Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "Hbase lastRunts is field is empty")
            Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", "Please check is:lastRunSts field value in Hbase eit table it should ne either 'null' or TIMESTAMP FORMAT. it can't be empty.")
            Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
            val prcEndTm = Lib.getCurrentTimeFormat
            Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
            Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
            globalContext.spark.stop()
          }else if(!Lib.timeStampValidation(lastRunSts)){
            Logger.log.info("Please check is:lastRunSts field value in Hbase eit table it should ne either 'null' or TIMESTAMP FORMAT")
            Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "Hbase lastRunts is field is empty")
            Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", "Please check is:lastRunSts field value in Hbase eit table it should ne either 'null' or TIMESTAMP FORMAT. it can't be empty.")
            Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
            val prcEndTm = Lib.getCurrentTimeFormat
            Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
            Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
            globalContext.spark.stop()
          }
          var incEndTs = Lib.getCurrentTimeFormat
          Logger.log.info("Checking the endts value from Hbase")
          if (endts.equalsIgnoreCase("null")) {
            incEndTs = Lib.getCurrentTimeFormat
          }else if(endts.length!=0 && Lib.timeStampValidation(endts)){
            incEndTs = endts
          }else if(endts.length==0){
            Logger.log.info("Please check ei:endTs field value in Hbase eit table it should ne either 'null' or TIMESTAMP FORMAT. it can't be empty.")
            Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "Hbase lastRunts is field is empty")
            Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", "Please check ei:endTs field value in Hbase eit table it should ne either 'null' or TIMESTAMP FORMAT. it can't be empty.")
            Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
            val prcEndTm = Lib.getCurrentTimeFormat
            Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
            Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
            globalContext.spark.stop()
          }
          Logger.log.info(s"=============> Creating Incremental Extract for $outFileNm from $lastRunSts to $incEndTs <===============")
          Logger.log.info(s"Incremental Extract Process Start Time: $prcStTm")
          Logger.log.info(s"EIT Tracking ID for ${entNm.toUpperCase}: $eitRowKey")
          val mountPath = s"${globalContext.spark.getConf.get("spark.mountPath")}"
          val srcDir = s"${mountPath}/${patnrCd.toLowerCase}/raw/standard_access/${srcCd.toLowerCase()}/data/"
          val numThreads = spark.sparkContext.getConf.get("spark.threads")
          if (!isJoin.equalsIgnoreCase("Yes")) {
            val ptnrCd = s"${patnrCd.toUpperCase()}".trim
            val src = s"${srcCd.toUpperCase()}".trim
            val entName = s"${entNm.toUpperCase()}".trim
            Lib.hbaseEitPut(eitRowKey, "pi", "prtnrCd", patnrCd)
            Lib.hbaseEitPut(eitRowKey, "pi", "srcCd", srcCd)
            Lib.hbaseEitPut(eitRowKey, "pi", "prcNm", outFileNm)
            Logger.log.info(s"Source Directory path for Incremental extract: $srcDir")
            Logger.log.info(s"Merging Schema for $entName from $srcDir/$entName")
            val mergeDF = spark.read.option("mergeSchema", true).parquet(s"$srcDir/$entName")
            Logger.log.info(s"Retrieving Primary Keys/CDC_TS Cols from Snapshot Config Table")
            val snapRDD = Lib.getPkTs(patnrCd, srcCd, entName).cache()
            if (!snapRDD.isEmpty()) {
              val cdc_ts = snapRDD.map(_._1).collect.mkString
              Logger.log.info(s"CDC_TS Column for $entName: $cdc_ts")
              val primaryKeys = snapRDD.map(_._2.split(";")).collect.flatten
              val orderByCols = snapRDD.map(_._3.split(",")).collect.flatten
              val descColsList = orderByCols.map(col(_).desc)
              Logger.log.info(s"Primary Key Columns for $entName: ${primaryKeys.mkString}")
              Logger.log.info(s"order by columns for $entName :" + descColsList)
              snapRDD.unpersist()
              val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(descColsList: _*)
              val dedupDF = mergeDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
              val dedupCnt = dedupDF.count()
              Logger.log.info(s"Number of Records Extracted for $entName from 2000-01-22 22:05:08 to $incEndTs with Dedup Logic:" + dedupCnt)
              dedupDF.createOrReplaceTempView(s"${entName}")
              Logger.log.info(s"Created Temp Table for $entName: ${entName} for Select Query")
              val sqlQry = Lib.getSqlQry(s"$rowKey")
              Logger.log.info(s"Sql Query provided for $entName from ihr_entity_info Table: $sqlQry")
              spark.sql(s"$sqlQry").createOrReplaceTempView(s"$outFileNm")
              Logger.log.info(s"Created temp table: $outFileNm for Incremental Query")
              val rawIncQuery = Lib.getIncQry(s"$rowKey").toUpperCase
              val incQuery=rawIncQuery.replace("outFileNm".toUpperCase,s"$outFileNm").replace("startDate".toUpperCase,s"$lastRunSts").replace("endDate",s"$incEndTs")
              Logger.log.info(s"Incremental Query provided for $entName from ihr_entity_info Table: $incQuery")
              val resultDf = spark.sql(s"$incQuery").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
              val incExtCnt = resultDf.count.toString
              if (incExtCnt.toInt != 0) {
                dedupDF.unpersist()
                Logger.log.info(s"Record Count for $outFileNm with provided Sql Query:" + incExtCnt)
                val quoteColFlg: Boolean = s"${quoteCol.toLowerCase}".toBoolean
                Logger.log.info(s"Saving Out File for $entName with Field Delim: $outDelim  Quotes for Fields (true/false): $quoteColFlg")
                val outLoc = globalContext.spark.getConf.get("spark.resultLoc")
                val outBoundLoc = globalContext.spark.getConf.get("spark.outBoundLoc")

                resultDf.coalesce(1).write.mode(SaveMode.Overwrite).format("com.databricks.spark.csv").option("nullValue", "").option("header", "true").option("delimiter", s"$outDelim").option("quoteAll", quoteColFlg).save(s"$outLoc/$entName")

                Logger.log.info("Updating RecordCount in to ihr audit table")
                Lib.hbaseEitPut(eitRowKey, "pi", "prcReccnt", incExtCnt.toString)
                Lib.hbaseEitPut(eitRowKey, "pi", "unprcReccnt", incExtCnt.toString)
                resultDf.unpersist
                val outResFileNm = s"${outFileNm}_${Lib.getCurrentTsFormat}"
                val outFileNmTs = s"$outResFileNm.${outFileExt.toLowerCase()}"
                val outCtlFileNmTs = s"$outResFileNm.ctl"
                Logger.log.info(s"Merge Output Result to OutBound Location with $outFileNmTs: $outFileNmTs")
                Lib.merge(s"$outLoc/$entName", s"$outBoundLoc/$entName/$eitRowKey.dat")
                val nasSrcLoc = s"/mapr$outLoc/$entName"
                if (isNasLoc.equalsIgnoreCase("Yes")) {
                  val nasSrcUnixLoc = s"$nasSrcLoc/$outFileNmTs"
                  val nasSrcEncInfo = globalContext.spark.getConf.get("spark.nasSrcEncUsrInfo")
                  val nasKey = globalContext.spark.getConf.get("spark.encKey")
                  Logger.log.info(s"Provided Encrypted NasUserInfo:$nasSrcEncInfo")
                  Logger.log.info(s"Provided Nas Encryption Key:$nasKey")
                  val nasSrcUsrInfo = Lib.decrypt(nasKey.getBytes, nasSrcEncInfo)
                  val nasDestLoc = s"${nasLoc}/$outFileNmTs"
                  Logger.log.info(s"Transferring $outFileNmTs from $nasSrcUnixLoc to $nasDestLoc")
                  val trnsFlg: Boolean = Lib.maprfsToNas(nasSrcUsrInfo, nasSrcUnixLoc, nasDestLoc, eitRowKey)
                  Logger.log.info("File Transfer Status from MFS to NAS Location:" + trnsFlg)
                  if (trnsFlg) {
                    Logger.log.info("Creating Control File and Transferring to NAS Location")
                    Lib.createCtlFileToNas(nasSrcUsrInfo, eitRowKey, src, entName, incExtCnt, lastRunSts, incEndTs, nasLoc, outFileExt, outDelim, nasSrcLoc, outCtlFileNmTs)
                    Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                    val prcEndTm = Lib.getCurrentTimeFormat
                    Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                    Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                    Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                    Lib.hbasePut(rowKey, "ei", "endTs", "null")
                    Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                    Logger.log.info(s"========> Completed Incremental Extraction for $entName with Success Status <========")
                  } else {
                    Logger.log.info(s"File Transfer Failed for $entName from MFS to CHILL, ending Process")
                    val prcEndTm = Lib.getCurrentTimeFormat
                    Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                    Logger.log.info(s"========> Incremental Extraction for $entName Completed with Failed Status <========")
                  }
                } else {
                  Logger.log.info("File Transfer to NAS Location: No")
                  //Logger.log.info("Creating Control File at HDFS Location")
                  //Lib.createCtlFileToHdfs(src, entName, incExtCnt, lastRunSts, incEndTs, nasLoc, outFileExt, outDelim, nasSrcLoc, outCtlFileNmTs)
                  Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                  val prcEndTm = Lib.getCurrentTimeFormat
                  Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                  Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                  Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                  Lib.hbasePut(rowKey, "ei", "endTs", "null")
                  Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                  Logger.log.info(s"========> Completed Incremental Extraction for $entName with Success Status <========")
                  globalContext.spark.stop()
                }
              } else {
                Logger.log.info(s"Since No Changes reflected for the $entNm from $lastRunSts to Till Date, Updating Record Count as 0")
                Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                Lib.hbaseEitPut(eitRowKey, "pi", "prcReccnt", "0")
                Lib.hbaseEitPut(eitRowKey, "pi", "unprcReccnt", "0")
                Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                Lib.hbasePut(rowKey, "ei", "endTs", "null")
                val prcEndTm = Lib.getCurrentTimeFormat
                Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                globalContext.spark.stop()
              }
            } else {
              Logger.log.info("Snapshot PrimaryKeys / CDC Timestamp not found, Please Check HBase Snapshot_config Table")
              Lib.hbaseEitPut(eitRowKey, "eri", "errCd", " Snapshot Primary / Timestamp")
              Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", "Snapshot PrimaryKeys / CDC Timestamp not found, Please Check HBase Snapshot_config Table")
              Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
              val prcEndTm = Lib.getCurrentTimeFormat
              Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
              Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
              globalContext.spark.stop()
            }
          } else {
            val TabList = entNm.toUpperCase.split('|')
            val TabParList = TabList.par
            TabParList.tasksupport = new ForkJoinTaskSupport(new scala.concurrent.forkjoin.ForkJoinPool(numThreads.toInt))
            val ptnrCd = s"${patnrCd.toUpperCase()}".trim
            val src = s"${srcCd.toUpperCase()}".trim
            val entName = s"${outFileNm.toUpperCase()}"
            Lib.hbaseEitPut(eitRowKey, "pi", "prtnrCd", patnrCd)
            Lib.hbaseEitPut(eitRowKey, "pi", "srcCd", srcCd)
            Lib.hbaseEitPut(eitRowKey, "pi", "entNm", outFileNm)
            TabParList.foreach {
              ent => Lib.createTableView(src, patnrCd, ent.trim, srcDir, eitRowKey, extractNm, spark, incEndTs.toString)
            }
            val sqlQry = Lib.getSqlQry(s"$rowKey")
            Logger.log.info(s"Sql Query provided for $entName from ihr_entity_info Table: $sqlQry")
            spark.sql(s"$sqlQry").createOrReplaceTempView(s"$outFileNm")
            Logger.log.info(s"Created temp table: $outFileNm for Incremental Query")
            val rawIncQuery = Lib.getIncQry(s"$rowKey").toUpperCase
            val incQuery=rawIncQuery.replace("outFileNm".toUpperCase,s"$outFileNm").replace("startDate".toUpperCase,s"$lastRunSts").replace("endDate".toUpperCase(),s"$incEndTs")
            Logger.log.info(s"Incremental Query provided for $entName from ihr_entity_info Table: $incQuery")
            val resultDf = spark.sql(s"$incQuery").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
            val incExtCnt = resultDf.count.toString
            if (incExtCnt.toInt != 0) {
              Logger.log.info(s"Record Count for $outFileNm with provided Sql Query:" + incExtCnt)
              val quoteColFlg: Boolean = s"${quoteCol.toLowerCase}".toBoolean
              Logger.log.info(s"Saving Out File for $entName with Field Delim: $outDelim  Quotes for Fields (true/false): $quoteColFlg")
              val outLoc = globalContext.spark.getConf.get("spark.resultLoc")
              val outBoundLoc = globalContext.spark.getConf.get("spark.outBoundLoc")

              resultDf.coalesce(1).write.mode(SaveMode.Overwrite).format("com.databricks.spark.csv").option("nullValue", "").option("header", "true").option("delimiter", s"$outDelim").option("quoteAll", quoteColFlg).save(s"$outLoc/$entName")

              Logger.log.info("Updating RecordCount in to ihr audit table")
              Lib.hbaseEitPut(eitRowKey, "pi", "prcReccnt", incExtCnt.toString)
              Lib.hbaseEitPut(eitRowKey, "pi", "unprcReccnt", incExtCnt.toString)
              resultDf.unpersist
              val outResFileNm = s"${outFileNm}_${Lib.getCurrentTsFormat}"
              val outFileNmTs = s"$outResFileNm.${outFileExt.toLowerCase()}"
              val outCtlFileNmTs = s"$outResFileNm.ctl"
              Logger.log.info(s"Merge Output Result to OutBound Location with $outFileNmTs: $outFileNmTs")
              Lib.merge(s"$outLoc/$entName", s"$outBoundLoc/$entName/$eitRowKey.dat")
              val nasSrcLoc = s"/mapr$outLoc/$entName"
              if (isNasLoc.equalsIgnoreCase("Yes")) {
                val nasSrcUnixLoc = s"$nasSrcLoc/$outFileNmTs"
                val nasSrcEncInfo = globalContext.spark.getConf.get("spark.nasSrcEncUsrInfo")
                val nasKey = globalContext.spark.getConf.get("spark.encKey")
                Logger.log.info(s"Provided Encrypted NasUserInfo:$nasSrcEncInfo")
                Logger.log.info(s"Provided Nas Encryption Key:$nasKey")
                val nasSrcUsrInfo = Lib.decrypt(nasKey.getBytes, nasSrcEncInfo)
                val nasDestLoc = s"${nasLoc}/$outFileNmTs"
                Logger.log.info(s"Transferring $outFileNmTs from $nasSrcUnixLoc to $nasDestLoc")
                val trnsFlg: Boolean = Lib.maprfsToNas(nasSrcUsrInfo, nasSrcUnixLoc, nasDestLoc, eitRowKey)
                Logger.log.info("File Transfer Status from MFS to NAS Location:" + trnsFlg)
                if (trnsFlg) {
                  Logger.log.info("Creating Control File and Transferring to NAS Location")
                  Lib.createCtlFileToNas(nasSrcUsrInfo, eitRowKey, src, entName, incExtCnt, lastRunSts, incEndTs, nasLoc, outFileExt, outDelim, nasSrcLoc, outCtlFileNmTs)
                  Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                  val prcEndTm = Lib.getCurrentTimeFormat
                  Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                  Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                  Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                  Lib.hbasePut(rowKey, "ei", "endTs", "null")
                  Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                  Logger.log.info(s"========> Completed Incremental Extraction for $entName with Success Status <========")
                  globalContext.spark.stop()
                } else {
                  Logger.log.info(s"File Transfer Failed for $entName from MFS to CHILL, ending Process")
                  val prcEndTm = Lib.getCurrentTimeFormat
                  Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                  Logger.log.info(s"========> Incremental Extraction for $entName Completed with Failed Status <========")
                  globalContext.spark.stop()
                }
              } else {
                Logger.log.info("File Transfer to NAS Location: No")
                //Logger.log.info("Creating Control File at HDFS Location")
                //Lib.createCtlFileToHdfs(src, entName, incExtCnt, lastRunSts, incEndTs, nasLoc, outFileExt, outDelim, nasSrcLoc, outCtlFileNmTs)
                Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                val prcEndTm = Lib.getCurrentTimeFormat
                Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                Lib.hbasePut(rowKey, "ei", "endTs", "null")
                Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                Logger.log.info(s"========> Completed Incremental Extraction for $entName with Success Status <========")
                globalContext.spark.stop()
              }
            } else {
              Logger.log.info(s"Since No Changes reflected for the $entNm from $lastRunSts to Till Date, Updating Record Count as 0")
              Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
              Lib.hbaseEitPut(eitRowKey, "pi", "prcReccnt", "0")
              Lib.hbaseEitPut(eitRowKey, "pi", "unprcReccnt", "0")
              Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
              Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
              Lib.hbasePut(rowKey, "ei", "endTs", "null")
              val prcEndTm = Lib.getCurrentTimeFormat
              Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
              Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
              globalContext.spark.stop()
            }
          }
        }
      } catch {
        case e: Exception => Logger.log.error("Exception at Main Incremental Main Object" :+ e.getMessage)
          Lib.hbaseEitPut(eitRowKey, "eri", "errCd", e.getLocalizedMessage)
          Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", e.getMessage)
          Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
          val prcEndTm = Lib.getCurrentTimeFormat
          Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
          Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
          throw e
      }
    }
  }
}
