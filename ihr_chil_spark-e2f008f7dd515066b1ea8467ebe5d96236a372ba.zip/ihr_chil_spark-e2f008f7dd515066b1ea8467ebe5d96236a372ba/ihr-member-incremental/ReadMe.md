Member Incremental Project Overview:
-------------------------------------------------
HBase Configuration table for Member Incremental:(ihr_entity_info table)
___________________________________________________
-> Update CSV file with columns corresponding values required for Application and load to HBase using Loader Job.

HBase Configuration for Member Incremental Logic:
-------------------------------------------------
Member_MR_Coverage:
-------------------
    hbase(main):003:0* get '/datalake/optum/optuminsight/udw/ihr/prd/developer/sthiagar/ihr_config/ihr_entity_info_temp','OPTUM-GPS-MEMBER_MR_COVERAGE'
    COLUMN                                      CELL
     ei:Columns                                 timestamp=1536104982117, value=
     ei:entNm                                   timestamp=1536104982117, value=INDIVIDUAL;INSURED_PLAN|PLAN_ATTACHABILITY|EMPLOYER_HOUSEHOLD|HOUSEHOLD_PROFILE|INSURED_PLAN|
                                              PLAN|PLAN_TYPE|CONTRACT|REGION_PLAN_PROFILE|REGION_PLAN|REGION|LEGAL_ENTITY|INSURED_PLAN|HOUSEHOLD|line_of_business|househol
                                              d_member|household_address
    ei:extractNm                               timestamp=1536104982117, value=
    ei:isCustDelim                             timestamp=1536104982117, value=yes
    ei:isDrivers                               timestamp=1536104982117, value=No
    ei:isHistory                               timestamp=1536104982117, value=No
    ei:isJoin                                  timestamp=1536104982117, value=Yes
    ei:isNasLoc                                timestamp=1536104982117, value=No
    ei:nasLoc                                  timestamp=1536104982117, value=temp
    ei:outFileDelim                            timestamp=1536104982117, value=|
    ei:outFileExt                              timestamp=1536104982117, value=dat
    ei:outFileNm                               timestamp=1536104982117, value=Member_MR_Coverage
    ei:prtnrCd                                 timestamp=1536104982117, value=OPTUM
    ei:quoteCol                                timestamp=1536104982117, value=FALSE
    ei:sqlQry                                  timestamp=1536104982117, value=<SQL QUERY> 
    ei:srcCd                                   timestamp=1536104982117, value=GPS
    is:lastRnTs                                timestamp=1536106229595, value=2018-08-13 20:00:00
    17 row(s) in 0.1180 seconds



Member_MR_Demographics:
-------------------

    hbase(main):004:0> get '/datalake/optum/optuminsight/udw/ihr/prd/developer/sthiagar/ihr_config/ihr_entity_info_temp','OPTUM-GPS-MEMBER_MR_DEMOGRAPHICS'
    COLUMN                                      CELL
     ei:Columns                                 timestamp=1536104982106, value=
     ei:entNm                                   timestamp=1536104982106, value=INDIVIDUAL;LINE_OF_BUSINESS|HOUSEHOLD|HOUSEHOLD_ADDRESS|household_member|household|insured_pl
                                                an|region_plan_profile|region_plan|plan|plan_type|region|contract|plan_attachability|employer_household|legal_entity|HOUSEHO
                                                LD_PROFILE|
     ei:extractNm                               timestamp=1536104982106, value=
     ei:isCustDelim                             timestamp=1536104982106, value=yes
     ei:isDrivers                               timestamp=1536104982106, value=No
     ei:isHistory                               timestamp=1536104982106, value=No
     ei:isJoin                                  timestamp=1536104982106, value=Yes
     ei:isNasLoc                                timestamp=1536104982106, value=No
     ei:nasLoc                                  timestamp=1536104982106, value=temp
     ei:outFileDelim                            timestamp=1536104982106, value=|
     ei:outFileExt                              timestamp=1536104982106, value=dat
     ei:outFileNm                               timestamp=1536104982106, value=Member_MR_Demographics
     ei:prtnrCd                                 timestamp=1536104982106, value=OPTUM
     ei:quoteCol                                timestamp=1536104982106, value=FALSE
     ei:sqlQry                                  timestamp=1536104982106, value=<SQL QUERTY>
     ei:srcCd                                   timestamp=1536104982106, value=GPS
     is:lastRnTs                                timestamp=1536106229544, value=2018-08-13 20:00:00
    17 row(s) in 0.0540 seconds



Member_CS_Demographics:
-------------------

    hbase(main):005:0> get '/datalake/optum/optuminsight/udw/ihr/prd/developer/sthiagar/ihr_config/ihr_entity_info_temp','UHC-CSF-MEMBER_CS_DEMOGRAPHICS'
    COLUMN                                      CELL
     ei:Columns                                 timestamp=1536104982127, value=
     ei:entNm                                   timestamp=1536104982127, value=FAC_CMC_MEME_MEMBER;FAC_CMC_GRGR_GROUP|FAC_CMC_SBAD_ADDR|FAC_CMC_SBSB_SUBSC|FAC_CMC_MEPE_PRCS
                                                _ELIG|FAC_CMC_PDPD_PRODUCT|FAC_CMC_LOBD_LINE_BUS|FAC_CMC_PYPY_PAYOR|FAC_CMC_MECD_MEDICAID|FAC_CMC_PAGR_PARENT_GR
     ei:extractNm                               timestamp=1536104982127, value=
     ei:isCustDelim                             timestamp=1536104982127, value=Yes
     ei:isDrivers                               timestamp=1536104982127, value=No
     ei:isHistory                               timestamp=1536104982127, value=No
     ei:isJoin                                  timestamp=1536104982127, value=yes
     ei:isNasLoc                                timestamp=1536104982127, value=No
     ei:nasLoc                                  timestamp=1536104982127, value=temp
     ei:outFileDelim                            timestamp=1536104982127, value=|
     ei:outFileExt                              timestamp=1536104982127, value=dat
     ei:outFileNm                               timestamp=1536104982127, value=Member_CS_Demographics
     ei:prtnrCd                                 timestamp=1536104982127, value=UHC
     ei:quoteCol                                timestamp=1536104982127, value=FALSE
     ei:sqlQry                                  timestamp=1536104982127, value=<SQL QUERY>
     ei:srcCd                                   timestamp=1536104982127, value=CSF
     is:lastRnTs                                timestamp=1536106229632, value=2018-08-19 20:00:00
    17 row(s) in 0.0630 seconds



Member_CS_Coverage
-------------------
    hbase(main):006:0> get '/datalake/optum/optuminsight/udw/ihr/prd/developer/sthiagar/ihr_config/ihr_entity_info_temp','UHC-CSF-MEMBER_CS_COVERAGE'
    COLUMN                                      CELL
     ei:Columns                                 timestamp=1536104982122, value=
     ei:entNm                                   timestamp=1536104982122, value=FAC_CMC_MEME_MEMBER;FAC_CMC_GRGR_GROUP|FAC_CMC_MEPE_PRCS_ELIG|FAC_CMC_SBSB_SUBSC|FAC_CMC_PDPD
                                                _PRODUCT|FAC_CMC_LOBD_LINE_BUS|FAC_CMC_PYPY_PAYOR
     ei:extractNm                               timestamp=1536104982122, value=
     ei:isCustDelim                             timestamp=1536104982122, value=Yes
     ei:isDrivers                               timestamp=1536104982122, value=No
     ei:isHistory                               timestamp=1536104982122, value=No
     ei:isJoin                                  timestamp=1536104982122, value=Yes
     ei:isNasLoc                                timestamp=1536104982122, value=No
     ei:nasLoc                                  timestamp=1536104982122, value=temp
     ei:outFileDelim                            timestamp=1536104982122, value=|
     ei:outFileExt                              timestamp=1536104982122, value=dat
     ei:outFileNm                               timestamp=1536104982122, value=Member_CS_Coverage
     ei:prtnrCd                                 timestamp=1536104982122, value=UHC
     ei:quoteCol                                timestamp=1536104982122, value=FALSE
     ei:sqlQry                                  timestamp=1536104982122, value=<SQL QUERY>
     ei:srcCd                                   timestamp=1536104982122, value=CSF
     is:lastRnTs                                timestamp=1536106231576, value=2018-08-19 20:00:00
    17 row(s) in 0.0500 seconds

WorkFlow:
--------
    Datalake Repository --> Extracts (MR/CS/EI Reports using Spark Batch Job) --> Genarate Reports to the RabbitMQ Outbound Folder.
Description:
------------
-> Incremental Framework will create the incremental extracts by scanning the datalake entityInfoTable with lastRnts from the Confirgurations.
Currently Framework tested on GPS,CSF,ADT,BCRT for DF2 and DF3 Framework.

Auditing Info for Member Incremental Job:
----------------------------------------
-> Auditing Information maintain for each Member Increamental reports for every run....

Example:
------- 

        hbase(main):001:0> get '/datalake/optum/optuminsight/p_edh/prd/uhc/ihr/prd/p_mtables/ihr_audit_tracking','UHC-CSF-MEMBER_CS_COVERAGE-ee552191-7d48-4822-9579-122fe144fba3'
    COLUMN                                      CELL
     pi:entNm                                   timestamp=1535659660570, value=Member_CS_Coverage
     pi:incPrcSts                               timestamp=1535660261957, value=Success
     pi:prcEndTm                                timestamp=1535660261960, value=2018-08-30 15:17:41
     pi:prcReccnt                               timestamp=1535660256133, value=0
     pi:prcStTm                                 timestamp=1535659658799, value=2018-08-30 15:07:38
     pi:prtnrCd                                 timestamp=1535659660565, value=UHC
     pi:srcCd                                   timestamp=1535659660568, value=CSF
     pi:unprcReccnt                             timestamp=1535660256136, value=0
    8 row(s) in 0.1740 seconds

           
Logging for Member Incremental:
-------------------------------

-> Logging for Member Incremental App with Spark Driver and Executor instance for every Date wise trigger and maintained folder wise logs..

Properties:
-----------
Member Incremental Spark Job Properties:
-> This Properties file contains all the environment related, which is global to every Member Incremental Report.

Report Level Configuration:
-> Maintained in HBase Table with Specific key for each report.

End to End Workflows with Both DF2 and DF3 Frameworks:
------------------------------------------------------
Tracking Information For DF2:
Entity Instance Tracking:
-> EIT table contains each and every file ingested information on BDPaaS Cluster.
Entity Partner Profile:
-> EPP Table contains Reader Schema versions for all the ingested files.

SourceDB --> IBM CDC --> DF2_Process --> Datalake Ingestion (BDPaaS Env)[FlatFile Ingestion] 
--> Member Incremental Process for FlatFiles --> Genarate Reports to MQOutBound --> IHR RabbitMQ

SourceDB --> IBM CDC --> DF3_Process --> Datalake Ingestion (BDPaaS Env)[Parquet Ingestion] 
--> Member Incremental Process for Parquet Files --> Genarate Reports to MQOutBound --> IHR RabbitMQ



Job Submission via Spark-submit:
-------------------------------

DF3:
---
spark-submit \
--class com.uhg.optum.ihr.provider.ParquetMain \
--master yarn \
--queue ihrgpprd_q1 \
--conf spark.driver.extraClassPath=/opt/mapr/hbase/hbase-1.1.8/lib/metrics-core-2.2.0.jar \
--driver-memory 50g \
--executor-memory 20g \
--num-executors 20 \
--executor-cores 5 \
--properties-file /mapr/datalake/optum/optuminsight/p_edh/prd/uhc/ihr/prd/developer/fixlib/mmallam2/prd/p_conf/ihr_prop_dev.conf \
/mapr/datalake/optum/optuminsight/p_edh/prd/uhc/ihr/prd/p_jars/ihr-member-incremental-latest.jar OPTUM-GPS-MEMBER_MR_DEMOGRAPHICS
 
 
DF2:
---
spark-submit \
--class com.uhg.optum.ihr.provider.IncrementalMain \
--master yarn \
--queue ihrgpbat_q1 \
--driver-memory 10g \
--executor-memory 20g \
--conf spark.driver.extraClassPath=/opt/mapr/hbase/hbase-1.1.8/lib/metrics-core-2.2.0.jar \
--num-executors 15 \
--executor-cores 6 \
--properties-file /mapr/datalake/optum/optuminsight/p_edh/prd/uhc/ihr/prd/developer/fixlib/mmallam2/prd/p_conf/ihr_prop_dev.conf \
/mapr/datalake/optum/optuminsight/p_edh/prd/uhc/ihr/prd/p_jars/ihr-member-incremental-latest.jar UHC-CSF-MEMBER_CS_DEMOGRAPHICS
















