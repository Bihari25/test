SELECT
    Q.GPS_MEMBER_ID,
    Q.LAST_NAME,
    Q.FIRST_NAME,
    Q.MIDDLE_NAME,
    Q.NAME_PREFIX_ID,
    Q.NAME_SUFFIX_ID,
    Q.GENDER_CD,
    Q.DATE_OF_BIRTH,
    Q.DATE_OF_DEATH,
    Q.MEDICARE_CLAIM_NUM,
    Q.SOCIAL_SECURITY_NUMBER,
    Q.MEDICARE_BENEFICIARY_ID,
    Q.LOB_BIT_VALUE,
    Q.BUSINESS_UNIT_ID,
    Q.EMAIL_ADDR,
    Q.LANGUAGE_PREFERENCE_ID,
    'SPOKEN' AS LANGUAGE_MODE,
    Q.SPOKEN_LANGUAGE_ID,
    Q.PART_A_EFFECTIVE_DATE,
    Q.PART_B_EFFECTIVE_DATE,
    Q.PART_D_ELIGIBILITY_EFFT_DATE,
    Q.PART_A_STOP_DATE,
    Q.PART_B_STOP_DATE,
    Q.PART_D_ELIGIBILITY_STOP_DATE,
    Q.DAYTIME_PHONE_NUM,
    Q.DAYTIME_PHONE_NUM_EXTN,
    Q.EVENING_PHONE_NUM,
    Q.EVENING_PHONE_NUM_EXTN,
    Q.MOBILE_PHONE_NUM,
    Q.GPS_HOUSEHOLD_ID,
    Q.GPS_MEMBER_ADDRESS_ID,
    Q.ADDRESS_TYPE_ID,
    Q.ADDRESS_LINE_1,
    Q.ADDRESS_LINE_2,
    Q.CITY,
    Q.STATE,
    Q.COUNTRY,
    Q.ZIP,
    Q.MEMBERSHIP_NUMBER_CARD_ID,
    Q.INDIVIDUAL_CDC_TS,
    Q.LINE_OF_BUSINESS_CDC_TS,
    Q.HOUSEHOLD_MEMBER_CDC_TS,
    Q.HOUSEHOLD_PROFILE_CDC_TS,
    Q.HOUSEHOLD_CDC_TS,
    Q.HOUSEHOLD_ADDRESS_CDC_TS,
    Q.INSURED_PLAN_CDC_TS,
    Q.REGION_PLAN_CDC_TS,
    Q.CONTRACT_CDC_TS,
    Q.REGION_PLAN_PROFILE_CDC_TS
FROM
    (
        SELECT
            I.INDIVIDUAL_ID                              AS GPS_MEMBER_ID,
            TRIM(REGEXP_REPLACE(I.LAST_NAME,'^\\?$',''))                AS LAST_NAME,
            TRIM(REGEXP_REPLACE(I.FIRST_NAME,'^\\?$',''))               AS FIRST_NAME,
            TRIM(REGEXP_REPLACE(I.MIDDLE_NAME,'^\\?$',''))              AS MIDDLE_NAME,
            I.NAME_PREFIX_ID                                           AS NAME_PREFIX_ID,
            I.NAME_SUFFIX_ID                                           AS NAME_SUFFIX_ID,
            TRIM(REGEXP_REPLACE(I.GENDER_CD,'^\\?$',''))                AS GENDER_CD,
            SUBSTR(I.DATE_OF_BIRTH,1,10)                                AS DATE_OF_BIRTH,
            SUBSTR(I.DATE_OF_DEATH,1,10)                                AS DATE_OF_DEATH,
            TRIM(REGEXP_REPLACE(I.MEDICARE_CLAIM_NUM,'^\\?$',''))       AS MEDICARE_CLAIM_NUM,
            TRIM(REGEXP_REPLACE(I.SOCIAL_SECURITY_NUMBER,'^\\?$',''))   AS SOCIAL_SECURITY_NUMBER,
            TRIM(REGEXP_REPLACE (I.MEDICARE_BENEFICIARY_ID,'^\\?$','')) AS MEDICARE_BENEFICIARY_ID,
            I.LOB_BIT_VALUE                                             AS LOB_BIT_VALUE,
            I.CDC_TS                                                    AS INDIVIDUAL_CDC_TS,
            LOB.LINE_OF_BUSINESS_ID                                     AS BUSINESS_UNIT_ID,
            LOB.CDC_TS                                                  AS LINE_OF_BUSINESS_CDC_TS,
            TRIM(REGEXP_REPLACE (I.EMAIL_ADDR,'^\\?$',''))              AS EMAIL_ADDR,
            I.LANGUAGE_PREFERENCE_ID                                    AS LANGUAGE_PREFERENCE_ID,
            I.SPOKEN_LANGUAGE_ID                                        AS SPOKEN_LANGUAGE_ID,
            SUBSTR(I.PART_A_EFFECTIVE_DATE,1,10)                        AS PART_A_EFFECTIVE_DATE,
            SUBSTR(I.PART_B_EFFECTIVE_DATE,1,10)                        AS PART_B_EFFECTIVE_DATE,
            SUBSTR(I.PART_D_ELIGIBILITY_EFFT_DATE,1,10)                 AS
                                               PART_D_ELIGIBILITY_EFFT_DATE,
            SUBSTR(I.PART_A_STOP_DATE,1,10)                        AS PART_A_STOP_DATE,
            SUBSTR(I.PART_B_STOP_DATE,1,10)                        AS PART_B_STOP_DATE,
            SUBSTR(I.PART_D_ELIGIBILITY_STOP_DATE,1,10)            AS PART_D_ELIGIBILITY_STOP_DATE,
            IP.CDC_TS                                              AS INSURED_PLAN_CDC_TS,
            TRIM(REGEXP_REPLACE (HH.DAYTIME_PHONE_NUM,'^\\?$',''))      AS DAYTIME_PHONE_NUM,
            TRIM(REGEXP_REPLACE (HH.DAYTIME_PHONE_NUM_EXTN,'^\\?$','')) AS DAYTIME_PHONE_NUM_EXTN,
            TRIM(REGEXP_REPLACE (HH.EVENING_PHONE_NUM,'^\\?$',''))      AS EVENING_PHONE_NUM,
            TRIM(REGEXP_REPLACE (HH.EVENING_PHONE_NUM_EXTN,'^\\?$','')) AS EVENING_PHONE_NUM_EXTN,
            TRIM(REGEXP_REPLACE (HH.MOBILE_PHONE_NUM,'^\\?$',''))       AS MOBILE_PHONE_NUM,
            HH.HOUSEHOLD_ID                                             AS GPS_HOUSEHOLD_ID,
            HH.CDC_TS                                                   AS HOUSEHOLD_CDC_TS,
            HM.CDC_TS                                                   AS HOUSEHOLD_MEMBER_CDC_TS,
            HA.HOUSEHOLD_ADDRESS_ID                                     AS GPS_MEMBER_ADDRESS_ID,
            HA.ADDRESS_TYPE_ID                                          AS ADDRESS_TYPE_ID,
            HA.CDC_TS                                                   AS HOUSEHOLD_ADDRESS_CDC_TS
            ,
            TRIM(REGEXP_REPLACE (HA.ADDRESS_LINE_1,'^\\?$',''))    AS ADDRESS_LINE_1,
            TRIM(REGEXP_REPLACE (HA.ADDRESS_LINE_2,'^\\?$',''))    AS ADDRESS_LINE_2,
            TRIM(REGEXP_REPLACE (HA.CITY,'^\\?$',''))              AS CITY,
            TRIM(REGEXP_REPLACE (HA.STATE_CD,'^\\?$',''))          AS STATE,
            TRIM(REGEXP_REPLACE (HA.COUNTRY_CD,'^\\?$',''))        AS COUNTRY,
            TRIM(REGEXP_REPLACE (LPAD(HA.ZIP_CD,5,0) ,'^\\?$','')) AS ZIP,
            TRIM(REGEXP_REPLACE (HP.MEMBERSHIP_NUMBER,'^\\?$','')) AS MEMBERSHIP_NUMBER_CARD_ID,
            HP.CDC_TS                                              AS HOUSEHOLD_PROFILE_CDC_TS,
            RP.CDC_TS                                              AS REGION_PLAN_CDC_TS,
            CON.CDC_TS                                             AS CONTRACT_CDC_TS,
            RPP.CDC_TS                                             AS REGION_PLAN_PROFILE_CDC_TS,
            ROW_NUMBER() OVER ( PARTITION BY I.INDIVIDUAL_ID, HA.ADDRESS_TYPE_ID ORDER BY
            I.LAST_MODIFIED_DATE DESC, HA.HHOLD_ADDR_STOP_DATE DESC, HP.LAST_MODIFIED_DATE DESC,
            HA.LAST_MODIFIED_DATE DESC ) AS ROW_NUM
        FROM
            (
                SELECT
                    *
                FROM
                    INDIVIDUAL
                WHERE
                    (
                        INDIVIDUAL_TERMINATION_DATE >= '2015-10-01'
                    OR  TRIM(NVL(INDIVIDUAL_TERMINATION_DATE,'')) = '')
                ORDER BY
                    INDIVIDUAL_ID ) I
        INNER JOIN
            LINE_OF_BUSINESS LOB
        ON
            I.LOB_BIT_VALUE = LOB.BIT_VALUE
        INNER JOIN
            HOUSEHOLD_MEMBER HM
        ON
            I.INDIVIDUAL_ID = HM.INDIVIDUAL_ID
        INNER JOIN
            (
                SELECT
                    *
                FROM
                    (
                        SELECT
                            HOUSEHOLD_ID,
                            MEMBERSHIP_NUMBER,
                            MEMBERSHIP_NUM_SYS_ID,
                            HHOLD_PROFILE_START_DATE,
                            HHOLD_PROFILE_STOP_DATE,
                            LAST_MODIFIED_DATE,
                            CDC_TS,
                            ROW_NUMBER() OVER ( PARTITION BY HOUSEHOLD_ID ORDER BY
                            LAST_MODIFIED_DATE DESC, COALESCE(HHOLD_PROFILE_STOP_DATE,
                            '9999-12-31 00:00:00.000') DESC, HHOLD_PROFILE_START_DATE DESC,
                            MEMBERSHIP_NUMBER DESC ) AS ROW_NUM
                        FROM
                            HOUSEHOLD_PROFILE
                        WHERE
                            COALESCE(DELETE_IND,'N')='N' ) Q
                WHERE
                    ROW_NUM = 1 ) HP
        ON
            HM.HOUSEHOLD_ID=HP.HOUSEHOLD_ID
        INNER JOIN
            HOUSEHOLD HH
        ON
            HM.HOUSEHOLD_ID = HH.HOUSEHOLD_ID
        LEFT JOIN
            HOUSEHOLD_ADDRESS HA
        ON
            HH.HOUSEHOLD_ID = HA.HOUSEHOLD_ID
        AND NVL(HA.DELETE_IND,'N') = 'N'
        AND NVL(HA.INVALID_ADDRESS_IND,'N') = 'N'
        INNER JOIN
            INSURED_PLAN IP
        ON
            I.INDIVIDUAL_ID = IP.INDIVIDUAL_ID
        INNER JOIN
            REGION_PLAN RP
        ON
            RP.REGION_PLAN_ID = IP.REGION_PLAN_ID
        INNER JOIN
            CONTRACT CON
        ON
            CON.CONTRACT_ID = RP.CONTRACT_ID
        INNER JOIN
            REGION_PLAN_PROFILE RPP
        ON
            RPP.REGION_PLAN_ID = RP.REGION_PLAN_ID
        WHERE
            SUBSTR(IP.INSURED_PLAN_EFFECTIVE_DATE,1,10) BETWEEN SUBSTR(HP.HHOLD_PROFILE_START_DATE,
            1,10) AND
            CASE
                WHEN TRIM(NVL(HP.HHOLD_PROFILE_STOP_DATE,''))=''
                THEN '9999-12-31'
                ELSE SUBSTR(HP.HHOLD_PROFILE_STOP_DATE,1,10)
            END
        // AND NOT (
       //        IP.INSURED_PLAN_EFFECTIVE_DATE=NVL(IP.INSURED_PLAN_TERMINATION_DATE, '9999-12-01')
      //    )   -- for incremental query removed this filter. Please refer the JIRA  IHR1-4994 and IHR1-4995
        AND IP.INSURED_PLAN_ID=IP.PARENT_INSURED_PLAN_ID
        AND NOT CONCAT(CONCAT(CON.CONTRACT_NUMBER, '-'), RPP.PBP) IN ( 'H0169-001',
                                                                      'H0169-002',
                                                                      'H0169-003',
                                                                      'H0251-002',
                                                                      'H0251-004',
                                                                      'H0321-002',
                                                                      'H0321-004',
                                                                      'H1045-039',
                                                                      'H1045-040',
                                                                      'H2228-041',
                                                                      'H2228-042',
                                                                      'H2228-043',
                                                                      'H2228-046',
                                                                      'H2247-001',
                                                                      'H3113-005',
                                                                      'H3113-009',
                                                                      'H3113-011',
                                                                      'H3113-012',
                                                                      'H3387-010',
                                                                      'H3794-002',
                                                                      'H4514-001',
                                                                      'H5008-002',
                                                                      'H5008-009',
                                                                      'H5008-010',
                                                                      'H5008-011',
                                                                      'H5008-012',
                                                                      'H5253-024',
                                                                      'H5253-059',
                                                                      'H5322-025',
                                                                      'H5322-028',
                                                                      'H5322-029',
                                                                      'H5322-031',
                                                                      'H7464-001',
                                                                      'R1548-001',
                                                                      'R1548-001',
                                                                      'R3175-003',
                                                                      'R7444-012',
                                                                      'R7444-013') ) Q
WHERE
    Q.ROW_NUM = 1
