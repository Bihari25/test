*******   C&S_Demographics_Coverage_Query_Main.   **********



SELECT DISTINCT
    a.MEME_RECORD_NO              AS member_record_number,
    a.MEME_CK                     AS member_contrived_key,
    a.GRGR_CK                     AS group_contrived_key,
    a.SBSB_CK                     AS subscriber_contrived_key,
    j.PYPY_ID                     AS payor_id,
    a.MEME_REL                    AS relationship,
    a.MEME_LAST_NAME              AS last_name,
    a.MEME_FIRST_NAME             AS first_name,
    a.MEME_MID_INIT               AS middle_initial,
    a.MEME_TITLE                  AS title,
    a.MEME_SSN                    AS social_security_number,
    a.MEME_SEX                    AS gender,
    SUBSTR(a.MEME_BIRTH_DT,1,10)  AS birth_date,
    h.SBSB_ID                     AS subscriber_identifier,
    a.MEME_HICN                   AS medicare_number,
    a.MEME_MEDCD_NO               AS medicaid_number,
    a.MEME_MARITAL_STATUS         AS marital_status,
    a.MEME_MCTR_LANG              AS language,
    a.MEME_FAM_LINK_ID            AS family_link_id,
    a.MEME_HEALTH_ID              AS standard_unique_health_id,
    'H'                           AS subscriber_address_type,
    adr_s.subscriber_address_1    AS subscriber_address_line_1,
    adr_s.subscriber_address_2    AS subscriber_address_line_2,
    adr_s.subscriber_address_3    AS subscriber_address_line_3,
    adr_s.city                    AS city,
    adr_s.state                   AS state,
    adr_s.zip_code                AS zip_code,
    adr_s.county                  AS county,
    adr_S.country                 AS country,
    adr_s.subscriber_phone_number AS subscriber_phone_number,
    adr_s.phone_extension         AS phone_extension,
    CASE
        WHEN adr_s .subscriber_address_type_id= 'H'
        THEN a.MEME_CELL_PHONE
        ELSE ''
    END AS cell_phone_number,
    CASE
        WHEN adr_s .subscriber_address_type_id= 'H'
        THEN a.MEME_WRK_PHONE
        ELSE ''
    END AS work_phone_number,
    CASE
        WHEN adr_s .subscriber_address_type_id= 'H'
        THEN a.MEME_WRK_PHONE_EXT
        ELSE ''
    END                          AS work_phone_number_extension,
    adr_s.subscriber_fax_number  AS subscriber_fax_number,
    adr_s.fax_extension          AS fax_extension,
    adr_s.email                  AS email,
    a.MEME_RECORD_NO             AS member_record_number_s,
    a.MEME_CK                    AS member_contrived_key_s,
    a.GRGR_CK                    AS group_contrived_key_s,
    a.SBSB_CK                    AS subscriber_contrived_key_s,
    a.MEME_REL                   AS relationship_s,
    a.MEME_LAST_NAME             AS last_name_s,
    a.MEME_FIRST_NAME            AS first_name_s,
    a.MEME_MID_INIT              AS middle_initial_s,
    a.MEME_TITLE                 AS title_s,
    a.MEME_SSN                   AS social_security_number_s,
    a.MEME_SEX                   AS gender_s,
    SUBSTR(a.MEME_BIRTH_DT,1,10) AS birth_date_s,
    h.SBSB_ID                    AS subscriber_identifier_s,
    a.MEME_HEALTH_ID             AS standard_unique_health_id_s,
    CASE
        WHEN TRIM(a.meme_HICN) REGEXP
            ('[1-9][a-zA-Z][0-9a-zA-Z][0-9][a-zA-Z][0-9a-zA-Z][0-9][a-zA-Z][a-zA-Z][0-9][0-9]$')
        THEN ''
        ELSE a.meme_HICN
    END                          AS medicare_number_s,
    a.MEME_MEDCD_NO              AS medicaid_number_s,
    a.MEME_MARITAL_STATUS        AS marital_status_s,
    a.MEME_MCTR_LANG             AS language_s,
    a.MEME_FAM_LINK_ID           AS family_link_id_s,
    j.pypy_id                    AS payor_id_s,
    a1.GRGR_ID                   AS group_identifier,
    b1.CSCS_ID                   AS class_identifier,
    b1.CSPI_ID                   AS class_plan_identifier,
    b1.PDPD_ID                   AS product_identifier,
    b1.MEPE_FI                   AS family_indicator,
    SUBSTR(b1.MEPE_EFF_DT,1,10)  AS effective_date,
    SUBSTR(b1.MEPE_TERM_DT,1,10) AS termination_date,
    b1.MEPE_ELIG_IND             AS coverage_indicator,
    CASE
        WHEN TRIM(a.meme_HICN) REGEXP
            ('[1-9][a-zA-Z][0-9a-zA-Z][0-9][a-zA-Z][0-9a-zA-Z][0-9][a-zA-Z][a-zA-Z][0-9][0-9]$')
        THEN a.meme_HICN
        ELSE ''
    END        AS medicare_beneficiary_id,
    pg.CICI_ID AS client_id,
    CASE
        WHEN adr_m .mailing_address_type_id= '9'
        OR  adr_m.mailing_address_type_id = 'M'
        THEN adr_m.mailing_address_type_id
        ELSE ''
    END                         AS mailing_address_type,
    adr_m.mailing_address_1     AS mailing_address_line_1,
    adr_m.mailing_address_2     AS mailing_address_line_2,
    adr_m.mailing_address_3     AS mailing_address_line_3,
    adr_m.mailing_city          AS mailing_city,
    adr_m.mailing_state         AS mailing_state,
    adr_m.mailing_zip_code      AS mailing_zip_code,
    adr_m.mailing_county        AS mailing_county,
    adr_m. mailing_country      AS mailing_country,
    adr_m.mailing_phone_number  AS mailing_phone_number,
    adr_m.mailing_extension     AS mailing_phone_extension,
    adr_m.mailing_fax_number    AS mailing_fax_number,
    adr_m.mailing_fax_extension AS mailing_fax_extension,
    adr_m.mailing_email         AS mailing_email,
    a.cdc_ts                    AS FAC_CMC_MEME_MEMBER_cdc_ts,
    h.cdc_ts                    AS FAC_CMC_SBSB_SUBSC_cdc_ts,
    a1.cdc_ts                   AS FAC_CMC_GRGR_GROUP_cdc_ts,
    b1.cdc_ts                   AS FAC_CMC_MEPE_PRCS_ELIG_cdc_ts,
    i.cdc_ts                    AS FAC_CMC_PDPD_PRODUCT_cdc_ts,
    j.cdc_ts                    AS FAC_CMC_LOBD_LINE_BUS_cdc_ts,
    pg.cdc_ts                   AS FAC_CMC_PAGR_PARENT_GR_cdc_ts,
    c.cdc_ts                    AS FAC_CMC_MECD_MEDICAID_cdc_ts,
    adr_s.cdc_ts                AS fac_cmc_sbad_addr_adr_s_cdc_ts,
    adr_m.cdc_ts                AS fac_cmc_sbad_addr_adr_m_cdc_ts
FROM
    (
        SELECT
            a.*,
            a1.grgr_id
        FROM
            FAC_CMC_MEME_MEMBER a
        JOIN
            FAC_CMC_GRGR_GROUP a1
        ON
            a.GRGR_CK = a1.GRGR_CK
        ORDER BY
            meme_ck ) a
INNER JOIN
    FAC_CMC_GRGR_GROUP a1
ON
    a.GRGR_CK = a1.GRGR_CK
INNER JOIN
    FAC_CMC_SBSB_SUBSC h
ON
    a.SBSB_CK = h.SBSB_CK
AND a.GRGR_CK = h.GRGR_CK
INNER JOIN
    FAC_CMC_MEPE_PRCS_ELIG b1
ON
    a.MEME_CK = b1.MEME_CK
AND a.GRGR_CK = b1.GRGR_CK
AND b1.MEPE_TERM_DT >= '2015-10-01'
INNER JOIN
    FAC_CMC_PDPD_PRODUCT i
ON
    b1.PDPD_ID = i.PDPD_ID
INNER JOIN
    FAC_CMC_LOBD_LINE_BUS j
ON
    i.LOBD_ID = j.LOBD_ID
INNER JOIN
    FAC_CMC_PAGR_PARENT_GR pg
ON
    a1.pagr_ck = pg. pagr_ck
LEFT JOIN
    FAC_CMC_MECD_MEDICAID c
ON
    c.MEME_CK = b1.MEME_CK
LEFT JOIN
    (
        SELECT DISTINCT
            sbsb_ck,
            subscriber_address_1,
            subscriber_address_2,
            subscriber_address_3,
            city,
            state,
            zip_code,
            county,
            country,
            subscriber_phone_number,
            phone_extension,
            subscriber_fax_number,
            fax_extension,
            email,
            subscriber_address_type_id,
            cdc_ts
        FROM
            (
                SELECT DISTINCT
                    ad.SBAD_ADDR1     AS subscriber_address_1,
                    ad.SBAD_ADDR2     AS subscriber_address_2,
                    ad.SBAD_ADDR3     AS subscriber_address_3,
                    ad.SBAD_CITY      AS city,
                    ad.SBAD_STATE     AS state,
                    ad.SBAD_ZIP       AS zip_code,
                    ad.SBAD_COUNTY    AS county,
                    ad.SBAD_CTRY_CD   AS country,
                    ad.SBAD_PHONE     AS subscriber_phone_number,
                    ad.SBAD_PHONE_EXT AS phone_extension,
                    ad.SBAD_FAX       AS subscriber_fax_number,
                    ad.SBAD_FAX_EXT   AS fax_extension,
                    ad.SBAD_EMAIL     AS email,
                    ad.cdc_ts,
                    ad.sbsb_ck,
                    ad.sbad_type                                      AS subscriber_address_type_id,
                    row_number() OVER (PARTITION BY ad.sbsb_ck ORDER BY ad.cdc_ts DESC) AS row_num
                FROM
                    fac_cmc_sbad_addr ad
                WHERE
                    ad.sbad_type = 'H') ad
        WHERE
            row_num = 1 ) adr_s
ON
    a.sbsb_ck = adr_s.sbsb_ck
LEFT JOIN
    (
        SELECT DISTINCT
            sbsb_ck,
            mailing_address_1,
            mailing_address_2,
            mailing_address_3,
            mailing_city,
            mailing_state,
            mailing_zip_code,
            mailing_county,
            mailing_country,
            mailing_phone_number,
            mailing_extension,
            mailing_fax_number,
            mailing_fax_extension,
            mailing_email,
            mailing_address_type_id,
            cdc_ts
        FROM
            (
                SELECT DISTINCT
                    adr.SBAD_ADDR1     AS mailing_address_1,
                    adr.SBAD_ADDR2     AS mailing_address_2,
                    adr.SBAD_ADDR3     AS mailing_address_3,
                    adr.SBAD_CITY      AS mailing_city,
                    adr.SBAD_STATE     AS mailing_state,
                    adr.SBAD_ZIP       AS mailing_zip_code,
                    adr.SBAD_COUNTY    AS mailing_county,
                    adr.SBAD_CTRY_CD   AS mailing_country,
                    adr.SBAD_PHONE     AS mailing_phone_number,
                    adr.SBAD_PHONE_EXT AS mailing_extension,
                    adr.SBAD_FAX       AS mailing_fax_number,
                    adr.SBAD_FAX_EXT   AS mailing_fax_extension,
                    adr.SBAD_EMAIL     AS mailing_email,
                    adr.sbsb_ck,
                    adr.cdc_ts,
                    adr.sbad_type                                        AS mailing_address_type_id,
                    row_number() OVER (PARTITION BY adr.sbsb_ck ORDER BY adr.cdc_ts DESC) AS
                    row_num
                FROM
                    fac_cmc_sbad_addr adr
                WHERE
                    adr.sbad_type = '9'
                OR  adr.sbad_type = 'M') adr
        WHERE
            row_num = 1 ) adr_m
ON
    a.sbsb_ck = adr_m.sbsb_ck
WHERE
    (
        c.MECD_TERM_DT >= '2015-10-01'
    OR  c.MECD_TERM_DT IS NULL
    OR  c.MECD_TERM_DT = '')
AND NOT (
        a.MEME_FIRST_NAME LIKE '%Void%'
    AND a.MEME_LAST_NAME LIKE '%VOID%')
OR  NOT (
        a.MEME_LAST_NAME LIKE '%Void%'
    AND a.MEME_MEDCD_NO LIKE '%VOID%')
OR  NOT(
        a.MEME_MEDCD_NO LIKE '%VOID%')
OR  NOT (
        a.MEME_FAM_LINK_ID LIKE '%VOID%')


*******   C&S_Demographics_Coverage_Query_Where_Clause.   **********

SELECT DISTINCT
    MEMBER_RECORD_NUMBER,
    MEMBER_CONTRIVED_KEY,
    GROUP_CONTRIVED_KEY,
    SUBSCRIBER_CONTRIVED_KEY,
    PAYOR_ID,
    RELATIONSHIP,
    LAST_NAME,
    FIRST_NAME,
    MIDDLE_INITIAL,
    TITLE,
    SOCIAL_SECURITY_NUMBER,
    GENDER,
    BIRTH_DATE,
    SUBSCRIBER_IDENTIFIER,
    MEDICARE_NUMBER,
    MEDICAID_NUMBER,
    MARITAL_STATUS,
    LANGUAGE,
    FAMILY_LINK_ID,
    STANDARD_UNIQUE_HEALTH_ID,
    SUBSCRIBER_ADDRESS_TYPE,
    SUBSCRIBER_ADDRESS_LINE_1,
    SUBSCRIBER_ADDRESS_LINE_2,
    SUBSCRIBER_ADDRESS_LINE_3,
    CITY,
    STATE,
    ZIP_CODE,
    COUNTY,
    COUNTRY,
    SUBSCRIBER_PHONE_NUMBER,
    PHONE_EXTENSION,
    CELL_PHONE_NUMBER,
    WORK_PHONE_NUMBER,
    WORK_PHONE_NUMBER_EXTENSION,
    SUBSCRIBER_FAX_NUMBER,
    FAX_EXTENSION,
    EMAIL,
    MEMBER_RECORD_NUMBER_S,
    MEMBER_CONTRIVED_KEY_S,
    GROUP_CONTRIVED_KEY_S,
    SUBSCRIBER_CONTRIVED_KEY_S,
    RELATIONSHIP_S,
    LAST_NAME_S,
    FIRST_NAME_S,
    MIDDLE_INITIAL_S,
    TITLE_S,
    SOCIAL_SECURITY_NUMBER_S,
    GENDER_S,
    BIRTH_DATE_S,
    SUBSCRIBER_IDENTIFIER_S,
    STANDARD_UNIQUE_HEALTH_ID_S,
    MEDICARE_NUMBER_S,
    MEDICAID_NUMBER_S,
    MARITAL_STATUS_S,
    LANGUAGE_S,
    FAMILY_LINK_ID_S,
    PAYOR_ID_S,
    GROUP_IDENTIFIER,
    CLASS_IDENTIFIER,
    CLASS_PLAN_IDENTIFIER,
    PRODUCT_IDENTIFIER,
    FAMILY_INDICATOR,
    EFFECTIVE_DATE,
    TERMINATION_DATE,
    COVERAGE_INDICATOR,
    MEDICARE_BENEFICIARY_ID,
    CLIENT_ID,
    MAILING_ADDRESS_TYPE,
    MAILING_ADDRESS_LINE_1,
    MAILING_ADDRESS_LINE_2,
    MAILING_ADDRESS_LINE_3,
    MAILING_CITY,
    MAILING_STATE,
    MAILING_ZIP_CODE,
    MAILING_COUNTY,
    MAILING_COUNTRY,
    MAILING_PHONE_NUMBER,
    MAILING_PHONE_EXTENSION,
    MAILING_FAX_NUMBER,
    MAILING_FAX_EXTENSION,
    MAILING_EMAIL
FROM
    OUTFILENM
WHERE
    FAC_CMC_MEME_MEMBER_cdc_ts BETWEEN 'STARTDATE' AND 'ENDDATE'
OR  FAC_CMC_MEPE_PRCS_ELIG_cdc_ts BETWEEN 'STARTDATE' AND 'ENDDATE'
OR  FAC_CMC_MECD_MEDICAID_cdc_ts BETWEEN 'STARTDATE' AND 'ENDDATE'
OR  fac_cmc_sbad_addr_adr_s_cdc_ts BETWEEN 'STARTDATE' AND 'ENDDATE'
OR  fac_cmc_sbad_addr_adr_m_cdc_ts BETWEEN 'STARTDATE' AND 'ENDDATE'
OR  FAC_CMC_SBSB_SUBSC_cdc_ts BETWEEN 'STARTDATE' AND 'ENDDATE'
