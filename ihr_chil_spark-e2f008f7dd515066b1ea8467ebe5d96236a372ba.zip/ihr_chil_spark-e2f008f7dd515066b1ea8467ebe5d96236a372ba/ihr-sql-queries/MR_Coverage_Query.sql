USE df2_gps_lakeprd;
SELECT  DISTINCT 
	   q.gps_member_coverage_id, 
	   q.gps_member_id, 
	   q.medicare_claim_num, 
	   q.medicare_beneficiary_id, 
	   q.coverage_effective_date, 
	   q.coverage_termination_date, 
	   q.master_group_number, 
	   q.group_number, 
	   q.gps_employer_id, 
	   q.membership_number_card_id, 
	   q.membership_num_sys_id, 
	   q.plan_code, q.plan_description, 
	   q.plan_type_name, 
	   q.plan_category_cd, 
	   q.contract_number, 
	   q.plan_benefit_package, 
	   q.service_area_id, 
	   q.service_area_name, 
	   q.legal_entity_id, 
	   q.legal_entity_name, 
	   q.rx_ind, 
	   q.site, 
	   q.pcp_required_ind, 
	   q.gps_plan_id, 
	   q.gps_consumer_id 
FROM    ( 
	SELECT   
		ip.insured_plan_id AS gps_member_coverage_id,            
		ip.individual_id AS gps_member_id,           
		TRIM(REGEXP_REPLACE(i.medicare_claim_num, '^\\?$', '')) AS medicare_claim_num,
		TRIM(REGEXP_REPLACE(i.medicare_beneficiary_id, '^\\?$', '')) AS medicare_beneficiary_id,
		SUBSTR(ip.insured_plan_effective_date,1,10) AS coverage_effective_date,
		CASE 
			WHEN SUBSTR(ip.insured_plan_termination_date,1,10) IS NULL THEN '9999-12-31' 
			WHEN LENGTH(Trim(ip.insured_plan_termination_date)) = 0 THEN '9999-12-31' 
			ELSE SUBSTR(ip.insured_plan_termination_date,1,10) 
		END AS coverage_termination_date,
		TRIM(REGEXP_REPLACE(COALESCE(pa.mastergroup, ''),'^\\?$', '')) AS master_group_number,
		TRIM(REGEXP_REPLACE(COALESCE(pa.group_number, ''),'^\\?$', '')) AS group_number,
        COALESCE(CAST(eh.employer_id AS string), '') AS gps_employer_id,
        hp.membership_number AS membership_number_card_id, 		
		hp.membership_num_sys_id, 
		TRIM(REGEXP_REPLACE(ip.plan_cd,'^\\?$', '')) AS plan_code,
        TRIM(REGEXP_REPLACE(PL.plan_desc, '^\\?$', '')) AS plan_description,
		TRIM(REGEXP_REPLACE(pt.plan_type_name, '^\\?$', '')) AS plan_type_name,
		pt.plan_category_id AS plan_category_cd,
		TRIM(REGEXP_REPLACE(con.contract_number, '^\\?$', '')) AS contract_number,
		TRIM(REGEXP_REPLACE(rpp.pbp, '^\\?$', '')) AS plan_benefit_package,
		rp.region_id AS service_area_id,
		TRIM(REGEXP_REPLACE(rg.region_name, '^\\?$', '')) AS service_area_name, 
		rp.legal_entity_id,
		TRIM(REGEXP_REPLACE(le.legal_entity_desc, '^\\?$', '')) AS legal_entity_name,
		NVL(rp.rx_ind, 'N') AS rx_ind,
		TRIM(REGEXP_REPLACE(COALESCE(rpp.site, ''),'^\\?$', '')) AS site,
		COALESCE(rpp.pcp_required_ind, 'N') AS pcp_required_ind,
		ip.region_plan_id AS gps_plan_id,
		Concat(Concat(con.contract_number, '-'), rpp.pbp) AS filter_val,
		CONCAT(CONCAT(hp.household_id, '~'), CONCAT(hp.membership_number, '~'), hp.membership_num_sys_id) AS gps_consumer_id, -- Changed by Pamela, 2018-07-26	- see new membnum sub-query below		 
		row_number() OVER (
					PARTITION BY i.individual_id, ip.insured_plan_id, ha.address_type_id
					ORDER BY ip.last_modified_date DESC, ha.hhold_addr_stop_date DESC, hp.last_modified_date DESC, ha.LAST_MODIFIED_DATE DESC
					)													 AS row_num
		FROM (
			    SELECT *
				FROM  individual_snapshot 
				WHERE (individual_termination_date >= '2015-10-01' OR Trim(NVL(individual_termination_date,'')) = '')
				ORDER BY individual_id
		) i
		INNER JOIN line_of_business_snapshot lob
			ON i.lob_bit_value = lob.bit_value
		INNER JOIN household_member_snapshot hm
			ON  i.individual_id = hm.individual_id
		INNER JOIN ( 
			SELECT * FROM (
				SELECT household_id, membership_number, membership_num_sys_id, hhold_profile_start_date, hhold_profile_stop_date, last_modified_date, 
					row_number() OVER (
							PARTITION BY household_id 
							ORDER BY last_modified_date DESC, Coalesce(hhold_profile_stop_date,'9999-12-31 00:00:00.000') DESC, hhold_profile_start_date DESC, membership_number DESC
						) AS row_num
				FROM household_profile_snapshot
				WHERE Coalesce(delete_ind,'N')='N'
			) q
			WHERE row_num = 1
		) hp ON hm.household_id=hp.household_id
		INNER JOIN household_snapshot hh
			ON hm.household_id = hh.household_id
		LEFT JOIN household_address_snapshot ha 
			ON hh.household_id = ha.household_id
			AND NVL(ha.DELETE_IND,'N') = 'N'
			AND NVL(ha.INVALID_ADDRESS_IND,'N') = 'N'
		INNER JOIN insured_plan_snapshot ip
			ON i.individual_id = ip.individual_id
		INNER JOIN region_plan_profile_snapshot rpp 
			ON ip.region_plan_id=rpp.region_plan_id 
		INNER JOIN region_plan_snapshot rp 
			ON ip.region_plan_id=rp.region_plan_id 
		INNER JOIN plan_snapshot PL 
			ON ip.plan_cd=PL.PLAN_CD 
		INNER JOIN plan_type_snapshot pt 
			ON pl.Plan_Type_Id=pt.plan_type_id 
		INNER JOIN region_snapshot rg 
			ON rp.region_id=rg.region_id 
		INNER JOIN contract_snapshot con 
			ON rp.contract_id=con.contract_id 
		LEFT JOIN plan_attachability_snapshot pa 
			ON ip.plan_attachability_id=pa.plan_attachability_id 
			AND pa.rider_bit_value=0 
		LEFT JOIN employer_household_snapshot eh 
			ON hm.household_id=eh.household_id 
			AND NVL(eh.delete_ind, 'N')='N' 
		INNER JOIN legal_entity_snapshot le 
			ON rp.legal_entity_id=le.legal_entity_id 
		WHERE ( ip.insured_plan_termination_date >= '2015-10-01'  OR  Trim(NVL(ip.insured_plan_termination_date,''))='' )
			AND substr(ip.insured_plan_effective_date,1,10) BETWEEN 
				substr(rp.region_plan_start_date,1,10) AND 
				CASE WHEN Trim(Nvl(rp.region_plan_stop_date,''))='' THEN '9999-12-31' ELSE substr(rp.region_plan_stop_date,1,10) END
			AND substr(ip.insured_plan_effective_date,1,10) BETWEEN 
				substr(rpp.region_plan_profile_start_date,1,10) AND
				CASE WHEN Trim(Nvl(rpp.region_plan_profile_stop_date,''))='' THEN '9999-12-31' ELSE substr(rpp.region_plan_profile_stop_date,1,10) END
			AND substr(ip.insured_plan_effective_date,1,10) BETWEEN 
				substr(hp.hhold_profile_start_date,1,10) AND 
				CASE WHEN Trim(Nvl(rpp.region_plan_profile_stop_date,''))='' THEN '9999-12-31' ELSE substr(rpp.region_plan_profile_stop_date,1,10) END
			AND ( 
				 pa.plan_attachability_id IS NULL
				 OR
				 SUBSTR(ip.insured_plan_effective_date,1,10) BETWEEN 
					SUBSTR (pa.plan_attachability_start_date,1,10) AND
					CASE WHEN Trim(Nvl(pa.plan_attachability_stop_date,''))='' THEN '9999-12-31' ELSE substr(pa.plan_attachability_stop_date,1,10) END
				)
			AND ( 
				 eh.household_id IS NULL
				 OR
				 substr(ip.insured_plan_effective_date,1,10) BETWEEN 
					substr(eh.emp_hhold_start_date,1,10) AND
					CASE WHEN Trim(Nvl(eh.emp_hhold_stop_date,''))='' THEN '9999-12-31' ELSE substr(eh.emp_hhold_stop_date,1,10) END
				)

			AND NOT ( ip.insured_plan_effective_date=NVL(ip.insured_plan_termination_date, '9999-12-01') ) 
			AND ip.insured_plan_id=ip.parent_insured_plan_id 
			AND rpp.membership_num_sys_id=hp.membership_num_sys_id 
	

			AND NOT Concat(Concat(con.contract_number, '-'), rpp.pbp) IN (
			'H0169-001',
			'H0169-002',
			'H0169-003',
			'H0251-002',
			'H0251-004',
			'H0321-002',
			'H0321-004',
			'H1045-039',
			'H1045-040',
			'H2228-041',
			'H2228-042',
			'H2228-043',
			'H2228-046',
			'H2247-001',
			'H3113-005',
			'H3113-009',
			'H3113-011',
			'H3113-012',
			'H3387-010',
			'H3794-002',
			'H4514-001',
			'H5008-002',
			'H5008-009',
			'H5008-010',
			'H5008-011',
			'H5008-012',
			'H5253-024',
			'H5253-059',
			'H5322-025',
			'H5322-028',
			'H5322-029',
			'H5322-031',
			'H7464-001',
			'R1548-001',
			'R1548-001',
			'R3175-003',
			'R7444-012',
			'R7444-013')
) q 	
WHERE q.row_num = 1;