*******   M&R_Demographics_Coverage_Query_Main.   **********

SELECT DISTINCT
    i.individual_id                                 AS gps_member_id,
    Trim(Regexp_Replace(i.last_name,'^\\?$',''))                AS last_name,
    Trim(Regexp_Replace(i.first_name,'^\\?$',''))               AS first_name,
    Trim(Regexp_Replace(i.middle_name,'^\\?$',''))              AS middle_name,
    i.name_prefix_id                                            AS name_prefix_id,
    i.name_suffix_id                                            AS name_suffix_id,
    Trim(Regexp_Replace(i.gender_cd,'^\\?$',''))                AS gender_cd,
    SUBSTR(i.date_of_birth,1,10)                                AS date_of_birth,
    SUBSTR(i.date_of_death,1,10)                                AS date_of_death,
    Trim(Regexp_Replace(i.medicare_claim_num,'^\\?$',''))       AS medicare_claim_num,
    Trim(Regexp_Replace(i.social_security_number,'^\\?$',''))   AS social_security_number,
    Trim(Regexp_Replace (i.medicare_beneficiary_id,'^\\?$','')) AS medicare_beneficiary_id,
    i.lob_bit_value                                             AS lob_bit_value,
    lob.line_of_business_id                                     AS business_unit_id,
    Trim(Regexp_Replace (i.email_addr,'^\\?$',''))              AS email_addr,
    i.language_preference_id                                    AS language_preference_id,
    'Spoken'                                                    AS language_mode,
    i.spoken_language_id                                        AS spoken_language_id,
    SUBSTR(i.part_a_effective_date,1,10)                        AS part_a_effective_date,
    SUBSTR(i.part_b_effective_date,1,10)                        AS part_b_effective_date,
    SUBSTR(i.part_d_eligibility_efft_date,1,10)                 AS part_d_eligibility_efft_date,
    SUBSTR(i.part_a_stop_date,1,10)                             AS part_a_stop_date,
    SUBSTR(i.part_b_stop_date,1,10)                             AS part_b_stop_date,
    SUBSTR(i.part_d_eligibility_stop_date,1,10)                 AS part_d_eligibility_stop_date,
    Trim(Regexp_Replace(hh.daytime_phone_num,'^\\?$',''))       AS daytime_phone_num,
    Trim(Regexp_Replace(hh.daytime_phone_num_extn,'^\\?$',''))  AS daytime_phone_num_extn,
    Trim(Regexp_Replace(hh.evening_phone_num,'^\\?$',''))       AS evening_phone_num,
    Trim(Regexp_Replace(hh.evening_phone_num_extn,'^\\?$',''))  AS evening_phone_num_extn,
    Trim(Regexp_Replace(hh.mobile_phone_num,'^\\?$',''))        AS mobile_phone_num,
    hh.household_id                                             AS gps_household_id,
    ha_pAddr.gps_member_address_id                              AS gps_member_address_id,
    '1'                                                         AS address_type_id,
    ha_pAddr.address_line_1                                     AS address_line_1,
    ha_pAddr.address_line_2                                     AS address_line_2,
    ha_pAddr.city                                               AS city,
    ha_pAddr.state                                              AS state,
    ha_pAddr.country                                            AS country,
    ha_pAddr.zip                                                AS zip,
    ip.insured_plan_id                                          AS gps_member_coverage_id,
    ip.individual_id                                            AS gps_member_id_s,
    CASE
        WHEN NOT is_MBI
        THEN Trim(i.medicare_claim_num)
        ELSE ''
    END AS medicare_claim_num_s,
    CASE
        WHEN is_MBI
        THEN Trim(i.medicare_claim_num)
        ELSE ''
    END                                         AS medicare_beneficiary_id_s,
    SUBSTR(ip.insured_plan_effective_date,1,10) AS coverage_effective_date,
    CASE
        WHEN Trim(NVL(ip.insured_plan_termination_date,'')) = ''
        THEN '9999-12-31'
        ELSE SUBSTR(ip.insured_plan_termination_date,1,10)
    END                                                       AS coverage_termination_date,
    Trim(REGEXP_REPLACE(NVL(pa.mastergroup, ''),'^\\?$', ''))  AS master_group_number,
    Trim(REGEXP_REPLACE(NVL(pa.group_number, ''),'^\\?$', '')) AS group_number,
    NVL(CAST(eh.employer_id AS string), '')                    AS gps_employer_id,
    hp.membership_number                                       AS membership_number_card_id,
    hp.membership_num_sys_id                                   AS membership_num_sys_id,
    Trim(REGEXP_REPLACE(ip.plan_cd,'^\\?$', ''))               AS plan_code,
    Trim(REGEXP_REPLACE(PL.plan_desc, '^\\?$', ''))            AS plan_description,
    Trim(REGEXP_REPLACE(pt.plan_type_name, '^\\?$', ''))       AS plan_type_name,
    pt.plan_category_id                                        AS plan_category_cd,
    Trim(REGEXP_REPLACE(con.contract_number, '^\\?$', ''))     AS contract_number,
    Trim(REGEXP_REPLACE(rpp.pbp, '^\\?$', ''))                 AS plan_benefit_package,
    rp.region_id                                               AS service_area_id,
    Trim(REGEXP_REPLACE(rg.region_name, '^\\?$', ''))          AS service_area_name,
    rp.legal_entity_id                                         AS legal_entity_id,
    Trim(REGEXP_REPLACE(le.legal_entity_desc, '^\\?$', ''))    AS legal_entity_name,
    NVL(rp.rx_ind, 'N')                                        AS rx_ind,
    Trim(REGEXP_REPLACE(NVL(rpp.site, ''),'^\\?$', ''))        AS site,
    NVL(rpp.pcp_required_ind, 'N')                             AS pcp_required_ind,
    ip.region_plan_id                                          AS gps_plan_id,
    CONCAT(CONCAT(hp.household_id, '~'), CONCAT(hp.membership_number, '~'),hp.membership_num_sys_id
    )                                      AS gps_consumer_id,
    ha_mAddr.gps_member_mailing_address_id AS gps_member_mailing_address_id,
    '3'                                    AS mailing_address_type_id,
    ha_mAddr.mailing_address_line_1        AS mailing_address_line_1,
    ha_mAddr.mailing_address_line_2        AS mailing_address_line_2,
    ha_mAddr.mailing_city                  AS mailing_city,
    ha_mAddr.mailing_state                 AS mailing_state,
    ha_mAddr.mailing_country               AS mailing_country,
    ha_mAddr.mailing_zip                   AS mailing_zip,
    CASE
        WHEN rpp.membership_num_sys_id = 2
        THEN pa.group_number
        WHEN rpp.membership_num_sys_id = 3
        THEN pa.mastergroup
        WHEN rpp.membership_num_sys_id = 6
        THEN pa.mastergroup
        ELSE ''
    END AS insured_group_id,
    CASE
        WHEN rpp.membership_num_sys_id = 2
        THEN 'UHS'
        WHEN rpp.membership_num_sys_id = 3
        THEN 'PLHIC'
        ELSE ''
    END AS insured_group_assigning_authority_gps,
    CASE
        WHEN rpp.membership_num_sys_id = 6
        THEN ha_pAddr.state
        WHEN rpp.membership_num_sys_id = 6
        THEN ha_mAddr.mailing_state
        ELSE ''
    END                                                    AS insured_group_assigning_authority_csp,
    Concat(Concat(con.contract_number, '-'), Trim(rpp.pbp)) AS plan_id,
    rpp.membership_num_sys_id                               AS plan_id_assigning_authority,
    Hp.Household_id                                         AS subscriber_id,
    ip.cdc_ts                                               AS insured_plan_cdc_ts,
    i.cdc_ts                                                AS individual_cdc_ts,
    lob.cdc_ts                                              AS line_of_business_cdc_ts,
    hm.cdc_ts                                               AS household_member_cdc_ts,
    hp.cdc_ts                                               AS household_profile_cdc_ts,
    hh.cdc_ts                                               AS household_cdc_ts,
    ha_pAddr.cdc_ts                                         AS household_address_cdc_ts,
    rpp.cdc_ts                                              AS region_plan_profile_cdc_ts,
    rp.cdc_ts                                               AS region_plan_cdc_ts,
    pl.cdc_ts                                               AS plan_cdc_ts,
    pt.cdc_ts                                               AS plan_type_cdc_ts,
    rg.cdc_ts                                               AS region_cdc_ts,
    con.cdc_ts                                              AS contract_cdc_ts,
    pa.cdc_ts                                               AS plan_attachability_cdc_ts,
    eh.cdc_ts                                               AS employer_household_cdc_ts,
    le.cdc_ts                                               AS legal_entity_cdc_ts
FROM
    insured_plan ip
INNER JOIN
    (
        SELECT
            *,
            (medicare_claim_num NOT RegExp '[B,I,L,O,S,Z]'
        AND Trim(medicare_claim_num) RegExp
            '^[1-9][A-Z][A-Z0-9][0-9][A-Z][A-Z0-9][0-9][A-Z][A-Z][0-9][0-9]$' ) AS is_MBI
        FROM
            individual
        WHERE
            ( (
                    individual_termination_date >= '2015-10-01')
            OR  (
                    Trim(NVL(individual_termination_date,'')) = '') )
        ORDER BY
            individual_id ) i
ON
    ip.individual_id = i.individual_id
INNER JOIN
    line_of_business lob
ON
    i.lob_bit_value = lob.bit_value
INNER JOIN
    household_member hm
ON
    i.individual_id = hm.individual_id
INNER JOIN
    (
        SELECT
            *
        FROM
            (
                SELECT
                    household_id,
                    membership_number,
                    membership_num_sys_id,
                    hhold_profile_start_date,
                    hhold_profile_stop_date,
                    last_modified_date,
                    cdc_ts,
                    row_number() OVER ( PARTITION BY household_id ORDER BY last_modified_date DESC,
                    NVL(hhold_profile_stop_date,'9999-12-31 00:00:00.000') DESC,
                    hhold_profile_start_date DESC, membership_number DESC ) AS row_num
                FROM
                    household_profile ) q
        WHERE
            row_num = 1 ) hp
ON
    hm.household_id=hp.household_id
INNER JOIN
    household hh
ON
    hm.household_id = hh.household_id
LEFT JOIN
    (
        SELECT
            household_id,
            gps_member_address_id,
            address_line_1,
            address_line_2,
            city,
            state,
            country,
            zip,
            cdc_ts,
            address_type_id
        FROM
            (
                SELECT
                    ha.household_id,
                    ha.hhold_addr_start_date,
                    ha.hhold_addr_stop_date,
                    ha.last_modified_date,
                    ha.cdc_ts,
                    ha.address_type_id,
                    ha.household_address_id                             AS gps_member_address_id,
                    Trim(Regexp_Replace (ha.address_line_1,'^\\?$',''))    AS address_line_1,
                    Trim(Regexp_Replace (ha.address_line_2,'^\\?$',''))    AS address_line_2,
                    Trim(Regexp_Replace (ha.city,'^\\?$',''))              AS city,
                    Trim(Regexp_Replace (ha.state_cd,'^\\?$',''))          AS state,
                    Trim(Regexp_Replace (ha.country_cd,'^\\?$',''))        AS country,
                    Trim(Regexp_Replace (LPad(ha.zip_cd,5,0) ,'^\\?$','')) AS zip,
                    row_number() OVER ( PARTITION BY ha.household_id ORDER BY ha.last_modified_date
                    DESC, ha.hhold_addr_start_date DESC, ha.hhold_addr_stop_date DESC,
                    ha.household_address_id DESC ) AS row_num
                FROM
                    household_address ha
                WHERE
                    ha.address_type_id = '1' ) ha
        WHERE
            row_num = 1 ) ha_pAddr
ON
    hh.household_id = ha_pAddr.household_id
LEFT JOIN
    (
        SELECT
            household_id,
            gps_member_mailing_address_id,
            mailing_address_line_1,
            mailing_address_line_2,
            mailing_city,
            mailing_state,
            mailing_country,
            mailing_zip,
            address_type_id
        FROM
            (
                SELECT
                    ha.household_id,
                    ha.hhold_addr_start_date,
                    ha.hhold_addr_stop_date,
                    ha.last_modified_date,
                    ha.address_type_id,
                    ha.household_address_id                        AS gps_member_mailing_address_id,
                    Trim(Regexp_Replace (ha.address_line_1,'^\\?$',''))   AS mailing_address_line_1,
                    Trim(Regexp_Replace (ha.address_line_2,'^\\?$',''))   AS mailing_address_line_2,
                    Trim(Regexp_Replace (ha.city,'^\\?$',''))              AS mailing_city,
                    Trim(Regexp_Replace (ha.state_cd,'^\\?$',''))          AS mailing_state,
                    Trim(Regexp_Replace (ha.country_cd,'^\\?$',''))        AS mailing_country,
                    Trim(Regexp_Replace (LPad(ha.zip_cd,5,0) ,'^\\?$','')) AS mailing_zip,
                    row_number() OVER ( PARTITION BY ha.household_id ORDER BY ha.last_modified_date
                    DESC, ha.hhold_addr_start_date DESC, ha.hhold_addr_stop_date DESC,
                    ha.household_address_id DESC ) AS row_num
                FROM
                    household_address ha
                WHERE
                    ha.address_type_id = '3' ) ha
        WHERE
            row_num = 1 ) ha_mAddr
ON
    hh.household_id = ha_mAddr.household_id
INNER JOIN
    region_plan_profile rpp
ON
    ip.region_plan_id=rpp.region_plan_id
INNER JOIN
    region_plan rp
ON
    ip.region_plan_id=rp.region_plan_id
INNER JOIN
    plan PL
ON
    ip.plan_cd=PL.PLAN_CD
INNER JOIN
    plan_type pt
ON
    pl.Plan_Type_Id=pt.plan_type_id
INNER JOIN
    region rg
ON
    rp.region_id=rg.region_id
INNER JOIN
    contract con
ON
    rp.contract_id=con.contract_id
LEFT JOIN
    plan_attachability pa
ON
    ip.plan_attachability_id=pa.plan_attachability_id
AND pa.rider_bit_value=0
LEFT JOIN
    employer_household eh
ON
    hm.household_id=eh.household_id
AND NVL(eh.delete_ind, 'N')='N'
INNER JOIN
    legal_entity le
ON
    rp.legal_entity_id=le.legal_entity_id
WHERE
    ( (
            ip.insured_plan_termination_date >= '2015-10-01')
    OR  (
            Trim(NVL(ip.insured_plan_termination_date,''))='') )
AND SUBSTR(ip.insured_plan_effective_date,1,10) BETWEEN SUBSTR(rp.region_plan_start_date,1,10) AND
    CASE
        WHEN Trim(NVL(rp.region_plan_stop_date,''))=''
        THEN '9999-12-31'
        ELSE SUBSTR(rp.region_plan_stop_date,1,10)
    END
AND SUBSTR(ip.insured_plan_effective_date,1,10) BETWEEN SUBSTR(rpp.region_plan_profile_start_date,1
    ,10) AND
    CASE
        WHEN Trim(NVL(rpp.region_plan_profile_stop_date,''))=''
        THEN '9999-12-31'
        ELSE SUBSTR(rpp.region_plan_profile_stop_date,1,10)
    END
AND SUBSTR(ip.insured_plan_effective_date,1,10) BETWEEN SUBSTR(hp.hhold_profile_start_date,1,10)
AND
    CASE
        WHEN Trim(NVL(hp.hhold_profile_stop_date,''))=''
        THEN '9999-12-31'
        ELSE SUBSTR(hp.hhold_profile_stop_date,1,10)
    END
AND (
        pa.plan_attachability_id IS NULL
    OR  SUBSTR(ip.insured_plan_effective_date,1,10) BETWEEN SUBSTR
        (pa.plan_attachability_start_date,1,10) AND
        CASE
            WHEN Trim(NVL(pa.plan_attachability_stop_date,''))=''
            THEN '9999-12-31'
            ELSE SUBSTR(pa.plan_attachability_stop_date,1,10)
        END )
AND (
        eh.household_id IS NULL
    OR  SUBSTR(ip.insured_plan_effective_date,1,10) BETWEEN SUBSTR(eh.emp_hhold_start_date,1,10)
    AND
        CASE
            WHEN Trim(NVL(eh.emp_hhold_stop_date,''))=''
            THEN '9999-12-31'
            ELSE SUBSTR(eh.emp_hhold_stop_date,1,10)
        END )
AND ip.insured_plan_id=ip.parent_insured_plan_id
AND rpp.membership_num_sys_id=hp.membership_num_sys_id



*******   M&R_Demographics_Coverage_Query_Where_Clause.   **********


SELECT DISTINCT
    gps_member_id,
    last_name,
    first_name,
    middle_name,
    name_prefix_id,
    name_suffix_id,
    gender_cd,
    date_of_birth,
    date_of_death,
    medicare_claim_num,
    social_security_number,
    medicare_beneficiary_id,
    lob_bit_value,
    business_unit_id,
    email_addr,
    language_preference_id,
    language_mode,
    spoken_language_id,
    part_a_effective_date,
    part_b_effective_date,
    part_d_eligibility_efft_date,
    part_a_stop_date,
    part_b_stop_date,
    part_d_eligibility_stop_date,
    daytime_phone_num,
    daytime_phone_num_extn,
    evening_phone_num,
    evening_phone_num_extn,
    mobile_phone_num,
    gps_household_id,
    gps_member_address_id,
    address_type_id,
    address_line_1,
    address_line_2,
    city,
    state,
    country,
    zip,
    gps_member_coverage_id,
    gps_member_id_s,
    medicare_claim_num_s,
    medicare_beneficiary_id_s,
    coverage_effective_date,
    coverage_termination_date,
    master_group_number,
    group_number,
    gps_employer_id,
    membership_number_card_id,
    membership_num_sys_id,
    plan_code,
    plan_description,
    plan_type_name,
    plan_category_cd,
    contract_number,
    plan_benefit_package,
    service_area_id,
    service_area_name,
    legal_entity_id,
    legal_entity_name,
    rx_ind,
    site,
    pcp_required_ind,
    gps_plan_id,
    gps_consumer_id,
    gps_member_mailing_address_id,
    mailing_address_type_id,
    mailing_address_line_1,
    mailing_address_line_2,
    mailing_city,
    mailing_state,
    mailing_country,
    mailing_zip,
    insured_group_id,
    insured_group_assigning_authority_gps,
    insured_group_assigning_authority_csp,
    plan_id,
    plan_id_assigning_authority,
    subscriber_id
FROM
    OUTFILENM
WHERE
    individual_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  insured_plan_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  employer_household_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  household_profile_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  plan_type_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  contract_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  region_plan_profile_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  region_plan_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  line_of_business_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  household_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  household_member_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  region_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  legal_entity_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  plan_attachability_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  household_address_cdc_ts BETWEEN 'startDate' AND 'endDate'
OR  plan_cdc_ts BETWEEN 'startDate' AND 'endDate'
