SELECT
    Q.GPS_MEMBER_COVERAGE_ID,
    Q.GPS_MEMBER_ID,
    Q.MEDICARE_CLAIM_NUM,
    Q.MEDICARE_BENEFICIARY_ID,
    Q.COVERAGE_EFFECTIVE_DATE,
    Q.COVERAGE_TERMINATION_DATE,
    Q.MASTER_GROUP_NUMBER,
    Q.GROUP_NUMBER,
    Q.GPS_EMPLOYER_ID,
    Q.MEMBERSHIP_NUMBER_CARD_ID,
    Q.MEMBERSHIP_NUM_SYS_ID,
    Q.PLAN_CODE,
    Q.PLAN_DESCRIPTION,
    Q.PLAN_TYPE_NAME,
    Q.PLAN_CATEGORY_CD,
    Q.CONTRACT_NUMBER,
    Q.PLAN_BENEFIT_PACKAGE,
    Q.SERVICE_AREA_ID,
    Q.SERVICE_AREA_NAME,
    Q.LEGAL_ENTITY_ID,
    Q.LEGAL_ENTITY_NAME,
    Q.RX_IND,
    Q.SITE,
    Q.PCP_REQUIRED_IND,
    Q.GPS_PLAN_ID,
    Q.GPS_CONSUMER_ID,
    Q.INDIVIDUAL_CDC_TS,
    Q.INSURED_PLAN_CDC_TS,
    Q.PLAN_ATTACHABILITY_CDC_TS,
    Q.EMPLOYER_HOUSEHOLD_CDC_TS,
    Q.HOUSEHOLD_PROFILE_CDC_TS,
    Q.PLAN_CDC_TS,
    Q.PLAN_TYPE_CDC_TS,
    Q.CONTRACT_CDC_TS,
    Q.REGION_PLAN_PROFILE_CDC_TS,
    Q.REGION_PLAN_CDC_TS,
    Q.LINE_OF_BUSINESS_CDC_TS,
    Q.HOUSEHOLD_CDC_TS,
    Q.HOUSEHOLD_MEMBER_CDC_TS,
    Q.REGION_CDC_TS,
    Q.LEGAL_ENTITY_CDC_TS,
    Q.HOUSEHOLD_ADDRESS_CDC_TS
FROM
    (
        SELECT
            IP.INSURED_PLAN_ID                                      AS GPS_MEMBER_COVERAGE_ID,
           IP.INDIVIDUAL_ID                                        AS GPS_MEMBER_ID,
            IP.CDC_TS                                               AS INSURED_PLAN_CDC_TS,
            TRIM(REGEXP_REPLACE(I.MEDICARE_CLAIM_NUM, '^\\?$', ''))      AS MEDICARE_CLAIM_NUM,
            TRIM(REGEXP_REPLACE(I.MEDICARE_BENEFICIARY_ID, '^\\?$', '')) AS MEDICARE_BENEFICIARY_ID
            ,
            I.CDC_TS                                    AS INDIVIDUAL_CDC_TS,
            SUBSTR(IP.INSURED_PLAN_EFFECTIVE_DATE,1,10) AS COVERAGE_EFFECTIVE_DATE,
            CASE
                WHEN SUBSTR(IP.INSURED_PLAN_TERMINATION_DATE,1,10) IS NULL
                THEN '9999-12-31'
                WHEN LENGTH(TRIM(IP.INSURED_PLAN_TERMINATION_DATE)) = 0
                THEN '9999-12-31'
                ELSE SUBSTR(IP.INSURED_PLAN_TERMINATION_DATE,1,10)
            END                                                        AS COVERAGE_TERMINATION_DATE,
            TRIM(REGEXP_REPLACE(COALESCE(PA.MASTERGROUP, ''),'^\\?$', ''))  AS MASTER_GROUP_NUMBER,
            TRIM(REGEXP_REPLACE(COALESCE(PA.GROUP_NUMBER, ''),'^\\?$', '')) AS GROUP_NUMBER,
            PA.CDC_TS                                                       AS
                                                            PLAN_ATTACHABILITY_CDC_TS,
            COALESCE(CAST(EH.EMPLOYER_ID AS STRING), '') AS GPS_EMPLOYER_ID,
            EH.CDC_TS                                    AS EMPLOYER_HOUSEHOLD_CDC_TS,
            HP.MEMBERSHIP_NUMBER                         AS MEMBERSHIP_NUMBER_CARD_ID,
            HP.CDC_TS                                    AS HOUSEHOLD_PROFILE_CDC_TS,
            HP.MEMBERSHIP_NUM_SYS_ID,
            TRIM(REGEXP_REPLACE(IP.PLAN_CD,'^\\?$', ''))           AS PLAN_CODE,
            TRIM(REGEXP_REPLACE(PL.PLAN_DESC, '^\\?$', ''))        AS PLAN_DESCRIPTION,
            PL.CDC_TS                                              AS PLAN_CDC_TS,
            TRIM(REGEXP_REPLACE(PT.PLAN_TYPE_NAME, '^\\?$', ''))   AS PLAN_TYPE_NAME,
            PT.PLAN_CATEGORY_ID                                    AS PLAN_CATEGORY_CD,
            PT.CDC_TS                                              AS PLAN_TYPE_CDC_TS,
            TRIM(REGEXP_REPLACE(CON.CONTRACT_NUMBER, '^\\?$', '')) AS CONTRACT_NUMBER,
            CON.CDC_TS                                             AS CONTRACT_CDC_TS,
            TRIM(REGEXP_REPLACE(RPP.PBP, '^\\?$', ''))             AS PLAN_BENEFIT_PACKAGE,
            RPP.CDC_TS                                             AS REGION_PLAN_PROFILE_CDC_TS,
            RP.REGION_ID                                           AS SERVICE_AREA_ID,
            TRIM(REGEXP_REPLACE(RG.REGION_NAME, '^\\?$', ''))      AS SERVICE_AREA_NAME,
            RP.LEGAL_ENTITY_ID,
            RP.CDC_TS                                               AS REGION_PLAN_CDC_TS,
            TRIM(REGEXP_REPLACE(LE.LEGAL_ENTITY_DESC, '^\\?$', ''))  AS LEGAL_ENTITY_NAME,
            NVL(RP.RX_IND, 'N')                                      AS RX_IND,
            TRIM(REGEXP_REPLACE(COALESCE(RPP.SITE, ''),'^\\?$', '')) AS SITE,
            COALESCE(RPP.PCP_REQUIRED_IND, 'N')                      AS PCP_REQUIRED_IND,
            IP.REGION_PLAN_ID                                        AS GPS_PLAN_ID,
            CONCAT(CONCAT(CON.CONTRACT_NUMBER, '-'), RPP.PBP)        AS FILTER_VAL,
            CONCAT(CONCAT(HP.HOUSEHOLD_ID, '~'), CONCAT(HP.MEMBERSHIP_NUMBER, '~'),
            HP.MEMBERSHIP_NUM_SYS_ID) AS GPS_CONSUMER_ID,
            ROW_NUMBER() OVER ( PARTITION BY I.INDIVIDUAL_ID, IP.INSURED_PLAN_ID,
            HA.ADDRESS_TYPE_ID ORDER BY IP.LAST_MODIFIED_DATE DESC, HA.HHOLD_ADDR_STOP_DATE DESC,
            HP.LAST_MODIFIED_DATE DESC, HA.LAST_MODIFIED_DATE DESC ) AS ROW_NUM,
            HA.CDC_TS                                                AS HOUSEHOLD_ADDRESS_CDC_TS,
            LOB.CDC_TS                                               AS LINE_OF_BUSINESS_CDC_TS,
            HH.CDC_TS                                                AS HOUSEHOLD_CDC_TS,
            HM.CDC_TS                                                AS HOUSEHOLD_MEMBER_CDC_TS,
            RG.CDC_TS                                                AS REGION_CDC_TS,
            LE.CDC_TS                                                AS LEGAL_ENTITY_CDC_TS
        FROM
            (
                SELECT
                    *
                FROM
                    INDIVIDUAL
                WHERE
                    (
                        INDIVIDUAL_TERMINATION_DATE >= '2015-10-01'
                    OR  TRIM(NVL(INDIVIDUAL_TERMINATION_DATE,'')) = '')
                ORDER BY
                    INDIVIDUAL_ID ) I
        INNER JOIN
            LINE_OF_BUSINESS LOB
        ON
            I.LOB_BIT_VALUE = LOB.BIT_VALUE
        INNER JOIN
            HOUSEHOLD_MEMBER HM
        ON
            I.INDIVIDUAL_ID = HM.INDIVIDUAL_ID
        INNER JOIN
            (
                SELECT
                    *
                FROM
                    (
                        SELECT
                            HOUSEHOLD_ID,
                            MEMBERSHIP_NUMBER,
                            MEMBERSHIP_NUM_SYS_ID,
                            HHOLD_PROFILE_START_DATE,
                            HHOLD_PROFILE_STOP_DATE,
                            LAST_MODIFIED_DATE,
                            CDC_TS,
                            ROW_NUMBER() OVER ( PARTITION BY HOUSEHOLD_ID ORDER BY
                            LAST_MODIFIED_DATE DESC, COALESCE(HHOLD_PROFILE_STOP_DATE,
                            '9999-12-31 00:00:00.000') DESC, HHOLD_PROFILE_START_DATE DESC,
                            MEMBERSHIP_NUMBER DESC ) AS ROW_NUM
                        FROM
                            HOUSEHOLD_PROFILE
                        WHERE
                            COALESCE(DELETE_IND,'N')='N' ) Q
                WHERE
                    ROW_NUM = 1 ) HP
        ON
            HM.HOUSEHOLD_ID=HP.HOUSEHOLD_ID
        INNER JOIN
            HOUSEHOLD HH
        ON
            HM.HOUSEHOLD_ID = HH.HOUSEHOLD_ID
        LEFT JOIN
            HOUSEHOLD_ADDRESS HA
        ON
            HH.HOUSEHOLD_ID = HA.HOUSEHOLD_ID
        AND NVL(HA.DELETE_IND,'N') = 'N'
        AND NVL(HA.INVALID_ADDRESS_IND,'N') = 'N'
        INNER JOIN
            INSURED_PLAN IP
        ON
            I.INDIVIDUAL_ID = IP.INDIVIDUAL_ID
        INNER JOIN
            REGION_PLAN_PROFILE RPP
        ON
            IP.REGION_PLAN_ID=RPP.REGION_PLAN_ID
        INNER JOIN
            REGION_PLAN RP
       ON
            IP.REGION_PLAN_ID=RP.REGION_PLAN_ID
        INNER JOIN
            PLAN PL
        ON
            IP.PLAN_CD=PL.PLAN_CD
        INNER JOIN
            PLAN_TYPE PT
        ON
            PL.PLAN_TYPE_ID=PT.PLAN_TYPE_ID
        INNER JOIN
            REGION RG
        ON
            RP.REGION_ID=RG.REGION_ID
        INNER JOIN
            CONTRACT CON
        ON
            RP.CONTRACT_ID=CON.CONTRACT_ID
        LEFT JOIN
            PLAN_ATTACHABILITY PA
        ON
            IP.PLAN_ATTACHABILITY_ID=PA.PLAN_ATTACHABILITY_ID
        AND PA.RIDER_BIT_VALUE=0
        LEFT JOIN
            EMPLOYER_HOUSEHOLD EH
        ON
            HM.HOUSEHOLD_ID=EH.HOUSEHOLD_ID
        AND NVL(EH.DELETE_IND, 'N')='N'
        INNER JOIN
            LEGAL_ENTITY LE
        ON
            RP.LEGAL_ENTITY_ID=LE.LEGAL_ENTITY_ID
        WHERE
            (
                SUBSTR(IP.INSURED_PLAN_TERMINATION_DATE,1,10) >= '2015-10-01'
            OR  TRIM(NVL(IP.INSURED_PLAN_TERMINATION_DATE,''))='' )
        AND SUBSTR(IP.INSURED_PLAN_EFFECTIVE_DATE,1,10) BETWEEN SUBSTR(RP.REGION_PLAN_START_DATE,1,
            10) AND
            CASE
                WHEN TRIM(NVL(RP.REGION_PLAN_STOP_DATE,''))=''
                THEN '9999-12-31'
                ELSE SUBSTR(RP.REGION_PLAN_STOP_DATE,1,10)
            END
        AND SUBSTR(IP.INSURED_PLAN_EFFECTIVE_DATE,1,10) BETWEEN SUBSTR
            (RPP.REGION_PLAN_PROFILE_START_DATE,1,10) AND
            CASE
                WHEN TRIM(NVL(RPP.REGION_PLAN_PROFILE_STOP_DATE,''))=''
                THEN '9999-12-31'
                ELSE SUBSTR(RPP.REGION_PLAN_PROFILE_STOP_DATE,1,10)
            END
        AND SUBSTR(IP.INSURED_PLAN_EFFECTIVE_DATE,1,10) BETWEEN SUBSTR(HP.HHOLD_PROFILE_START_DATE,
           1,10) AND
            CASE
                WHEN TRIM(NVL(RPP.REGION_PLAN_PROFILE_STOP_DATE,''))=''
                THEN '9999-12-31'
                ELSE SUBSTR(RPP.REGION_PLAN_PROFILE_STOP_DATE,1,10)
            END
        AND (
                PA.PLAN_ATTACHABILITY_ID IS NULL
            OR  SUBSTR(IP.INSURED_PLAN_EFFECTIVE_DATE,1,10) BETWEEN SUBSTR
                (PA.PLAN_ATTACHABILITY_START_DATE,1,10) AND
                CASE
                    WHEN TRIM(NVL(PA.PLAN_ATTACHABILITY_STOP_DATE,''))=''
                    THEN '9999-12-31'
                    ELSE SUBSTR(PA.PLAN_ATTACHABILITY_STOP_DATE,1,10)
                END )
        AND (
                EH.HOUSEHOLD_ID IS NULL
            OR  SUBSTR(IP.INSURED_PLAN_EFFECTIVE_DATE,1,10) BETWEEN SUBSTR(EH.EMP_HHOLD_START_DATE,
                1,10) AND
                CASE
                    WHEN TRIM(NVL(EH.EMP_HHOLD_STOP_DATE,''))=''
                    THEN '9999-12-31'
                    ELSE SUBSTR(EH.EMP_HHOLD_STOP_DATE,1,10)
                END )
       // AND NOT (
       //        IP.INSURED_PLAN_EFFECTIVE_DATE=NVL(IP.INSURED_PLAN_TERMINATION_DATE, '9999-12-01')
      //    )   -- for incremental query removed this filter. Please refer the JIRA  IHR1-4994 and IHR1-4995
        AND IP.INSURED_PLAN_ID=IP.PARENT_INSURED_PLAN_ID
        AND RPP.MEMBERSHIP_NUM_SYS_ID=HP.MEMBERSHIP_NUM_SYS_ID
        AND NOT CONCAT(CONCAT(CON.CONTRACT_NUMBER, '-'), RPP.PBP) IN ( 'H0169-001',
                                                                      'H0169-002',
                                                                      'H0169-003',
                                                                      'H0251-002',
                                                                      'H0251-004',
                                                                      'H0321-002',
                                                                      'H0321-004',
                                                                      'H1045-039',
                                                                      'H1045-040',
                                                                      'H2228-041',
                                                                      'H2228-042',
                                                                      'H2228-043',
                                                                      'H2228-046',
                                                                      'H2247-001',
                                                                      'H3113-005',
                                                                      'H3113-009',
                                                                      'H3113-011',
                                                                      'H3113-012',
                                                                      'H3387-010',
                                                                      'H3794-002',
                                                                      'H4514-001',
                                                                      'H5008-002',
                                                                      'H5008-009',
                                                                      'H5008-010',
                                                                      'H5008-011',
                                                                      'H5008-012',
                                                                      'H5253-024',
                                                                      'H5253-059',
                                                                      'H5322-025',
                                                                      'H5322-028',
                                                                      'H5322-029',
                                                                      'H5322-031',
                                                                      'H7464-001',
                                                                      'R1548-001',
                                                                      'R1548-001',
                                                                      'R3175-003',
                                                                      'R7444-012',
                                                                      'R7444-013') ) Q
WHERE
    Q.ROW_NUM = 1
