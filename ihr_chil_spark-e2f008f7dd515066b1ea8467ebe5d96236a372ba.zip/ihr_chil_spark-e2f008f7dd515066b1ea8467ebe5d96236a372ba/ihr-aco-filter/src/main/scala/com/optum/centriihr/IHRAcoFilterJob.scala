package com.optum.centriihr

import java.io.{PrintWriter, StringWriter}

import com.optum.centriihr.IHRUtils._
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col


object IHRAcoFilterJob {

  def main(args: Array[String]): Unit = {


    if (args.length != 1) {
      Logger.log.info("Please provide provide file name for filter Member_CS_Coverage / Member_MR_Coverage")
      return;
    }

    val processStartTime = getCurrentTime
    var processEndTime = ""
    var processDate = getDate
    val spark = SparkSession
      .builder()
      .appName("ihr-aco-filter")
      .master("yarn")
      .getOrCreate()

    val sparkContext = spark.sparkContext
    val sparkConf = sparkContext.getConf

    val hbaseAuditTable = sparkConf.get("spark.ihr.audit.table")

    val fileType = args(0);

    // UHG-CSF-Member_MR_Coverage_2018060115013140.dat

    val fs = FileSystem.get(sparkContext.hadoopConfiguration)
    val member_fullfile = sparkConf.get("spark.ihr."+fileType+"_input")
    val inputFileName = fs.globStatus(new org.apache.hadoop.fs.Path(member_fullfile+"/*"))(0).getPath.getName();
    var hbaseRowKey = inputFileName.split("\\.")(0);
    Logger.log.info("hbaseRowKey=" + hbaseRowKey + ", fileType=" + fileType+", inputFileName="+inputFileName)
    hbaseRowKey = if (!hbaseRowKey.contains("-") || hbaseRowKey.split("-").length < 2) s"NO-ROWKEY-DEFINED_$hbaseRowKey" else hbaseRowKey
    var processName = hbaseRowKey.split("-")(2)

    try {
      val acoFilterFile = sparkConf.get("spark.ihr.ACO_filter_file")

      val acoFilterDF = spark.read.option("delimiter", "|").option("header", "true").csv(acoFilterFile)
      //acoFilterDF.show(3)

      acoFilterDF.createOrReplaceTempView("aco_filter_table")

      val df2 = spark.read.option("delimiter", "|").option("header", "true").csv(member_fullfile)
      //df2.show(3)

      Logger.log.info("read the file from coverage fullfile folder")

      df2.createOrReplaceTempView("member_table")
      var dffwithdateformat = df2
      if ("Member_CS_Coverage".equalsIgnoreCase(fileType)) {
        Logger.log.info("in Member_CS_Coverage")
        val finalResult = spark.sql("SELECT member_table.* FROM aco_filter_table, member_table where aco_filter_table.CARD_ID = member_table.medicaid_number" +
          " union " +
          " SELECT member_table.* FROM aco_filter_table, member_table where aco_filter_table.SUBSCRIBER_ID = member_table.subscriber_identifier ")

        dffwithdateformat = finalResult.withColumn("birth_date", col("birth_date").cast("date")).withColumn("effective_date", col("effective_date").cast("date")).withColumn("termination_date", col("termination_date").cast("date"))
      } else if ("Member_CS_Demographics".equalsIgnoreCase(fileType)) {
        Logger.log.info("in Member_CS_Demographics")
        val finalResult = spark.sql("SELECT member_table.* FROM aco_filter_table, member_table where aco_filter_table.CARD_ID = member_table.medicaid_number" +
          " union " +
          " SELECT member_table.* FROM aco_filter_table, member_table where aco_filter_table.SUBSCRIBER_ID = member_table.subscriber_identifier ")
        dffwithdateformat = finalResult.withColumn("birth_date", col("birth_date").cast("date"))
      } else if ("Member_MR_Coverage".equalsIgnoreCase(fileType)) {
        Logger.log.info("in Member_MR_Coverage")
        dffwithdateformat = spark.sql("SELECT member_table.* FROM aco_filter_table, member_table where aco_filter_table.CARD_ID = member_table.membership_number_card_id union SELECT member_table.* FROM aco_filter_table, member_table where aco_filter_table.SUBSCRIBER_ID = member_table.membership_number_card_id")
      } else if ("Member_MR_Demographics".equalsIgnoreCase(fileType)) {
        Logger.log.info("in Member_MR_Demographics")
        val predffwithdateformat = spark.sql("SELECT member_table.* FROM aco_filter_table, member_table where aco_filter_table.CARD_ID = member_table.membership_number_card_id union SELECT member_table.* FROM aco_filter_table, member_table where aco_filter_table.SUBSCRIBER_ID = member_table.membership_number_card_id")
        dffwithdateformat = predffwithdateformat.drop("membership_number_card_id")

      }
      else {
        Logger.log.info("Please Pass valid load-type (parquet/text) for IHR Incremental extract")
      }

      val member_coverage_output = sparkConf.get("spark.ihr."+fileType+"_output")
      val conf = sparkContext.hadoopConfiguration

      val fs = FileSystem.get(sparkContext.hadoopConfiguration)
      val exists = fs.exists(new org.apache.hadoop.fs.Path(member_coverage_output+"/"+fileType+"_temp"))
      if(exists) {
        fs.delete(new org.apache.hadoop.fs.Path(member_coverage_output+"/"+fileType+"_temp"), true)
      }
      val totalRowsAfterFilter = dffwithdateformat.count()
      dffwithdateformat.repartition(1).write.option("mapreduce.fileoutputcommitter.marksuccessfuljobs","false").option("delimiter", "|").option("header","false").csv(member_coverage_output+"/"+fileType+"_temp")

      val outputPartFileName = fs.globStatus(new org.apache.hadoop.fs.Path(member_coverage_output+"/"+fileType+"_temp/part-*"))(0).getPath.getName();

      val filetransfer = fs.rename(new org.apache.hadoop.fs.Path (member_coverage_output+"/"+fileType+"_temp/"+outputPartFileName), new org.apache.hadoop.fs.Path(member_coverage_output + "/"+inputFileName))
      if(filetransfer) {
        fs.delete(new org.apache.hadoop.fs.Path(member_coverage_output+"/"+fileType+"_temp"), true)
      }

      processEndTime = getCurrentTime

      val duration = (getCurrentTimeInLong(processEndTime) - getCurrentTimeInLong(processStartTime)) / 1000

      val iHRAuditTracking = new IHRAuditTracking(hbaseRowKey, processName, "Success", processDate, processEndTime, processStartTime, hbaseRowKey.split("-")(0), hbaseRowKey.split("-")(1), ""+totalRowsAfterFilter, "","")
      updateAudit(spark, hbaseAuditTable, iHRAuditTracking)

    } catch {

      case ex: Exception => {

        val stringWriter = new StringWriter
        ex.printStackTrace(new PrintWriter(stringWriter))

        Logger.log.info("got exception and stackTrace: " + ex.getMessage)
        Logger.log.info("got exception and stackTrace: ", ex)
        processEndTime = getCurrentTime


       // var soFarProcessed = ex.getMessage.split("")(1) + ""
        var soFarProcessed = "0"

        val duration = (getCurrentTimeInLong(processEndTime) - getCurrentTimeInLong(processStartTime)) / 1000

        val iHRAuditTracking = new IHRAuditTracking(hbaseRowKey, processName, "Failure", processDate, processEndTime, processStartTime, hbaseRowKey.split("-")(0), hbaseRowKey.split("-")(1), soFarProcessed, ex.getMessage, stringWriter.toString)
        updateAudit(spark, hbaseAuditTable, iHRAuditTracking)
      }

    }
  }

  def updateAudit(sparkSession: SparkSession, hbaseTableName: String, ihrAuditTracking: IHRAuditTracking): Unit = {
    val hbaseUtil = new HBaseUtil(sparkSession)
    hbaseUtil.writeToHBase(hbaseTableName, ihrAuditTracking)
  }

}

