--address

hive> desc centri_professional_latestrecord_address;
OK
entity_id           	string              	                    
addr_mtch_hcproleid 	string              	                    
addr_mtch_hcprolename	string              	                    
location_name       	string              	                    
street_name         	string              	                    
city                	string              	                    
zip                 	string              	                    
state               	string              	                    
county              	string              	                    
country             	string              	                    
latitude            	string              	                    
longitude           	string              	                    
location_effstartdate	string              	                    
location_type       	string              	                    
Time taken: 0.075 seconds, Fetched: 14 row(s)
 
VIEW Creation:
--------------
create VIEW bdapps_ihr_centri.centri_professional_latestrecord_address as select * from ( SELECT 
entity_id,
inserttimestamp,
temp.addr_mtch_hcproleid as addr_mtch_hcproleid,
temp.addr_mtch_hcprolename as addr_mtch_hcprolename,
temp.location_name as location_name,
temp.street_name as street_name,
temp.city as city,
temp.zip as zip,
temp.state as state,
temp.county as county,
temp.country as country,
temp.latitude as latitude,
temp.longitude as longitude,
temp.location_effstartdate as location_effstartdate,
temp.location_type as location_type
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.address) exploded VIEW as temp) K


--affiliation_info

hive> desc centri_professional_latestrecord_affiliation_info;
OK
entity_id           	string              	                    
affiliation_providerid	string              	                    
affiliation_typecode	string              	                    
affiliation_strtdt  	string              	                    
affiliation_stpdt   	string              	                    
affiliation_admsnprevlgtypecode	string              	                    
affiliation_stustypecode	string              	                    
affiliation_primhospaffliind	string              	                    
Time taken: 0.077 seconds, Fetched: 8 row(s)

-- Query:

create VIEW bdapps_ihr_centri.centri_professional_latestrecord_affiliation_info as select * from ( SELECT 
entity_id,
inserttimestamp,
temp.affiliation_providerid as affiliation_providerid,
temp.affiliation_typecode as affiliation_typecode,
temp.affiliation_strtdt as affiliation_strtdt,
temp.affiliation_stpdt as affiliation_stpdt,
temp.affiliation_admsnprevlgtypecode as affiliation_admsnprevlgtypecode,
temp.affiliation_stustypecode as affiliation_stustypecode,
temp.affiliation_primhospaffliind as affiliation_primhospaffliind
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.affiliation_info) exploded VIEW as temp) K


-- credsts_info:

hive> desc centri_professional_latestrecord_credsts_info;
OK
entity_id           	string              	                    
credsts_statustypecode	string              	                    
credsts_crendtltypecode	string              	                    
credsts_crendtltypedesc	string              	                    
credsts_effstrtdt   	string              	                    
credsts_effenddt    	string              	                    
credsts_recrendtldt 	string              	                    
credsts_credresponcode	string              	                    
credsts_corpbusnssegcode	string              	                    
Time taken: 0.069 seconds, Fetched: 9 row(s)

--Query:

create VIEW bdapps_ihr_centri.centri_professional_latestrecord_credsts_info as select * from ( SELECT 
entity_id,
inserttimestamp,
temp.credsts_statustypecode as credsts_statustypecode,
temp.credsts_crendtltypecode as credsts_crendtltypecode,
temp.credsts_crendtltypedesc as credsts_crendtltypedesc,
temp.credsts_effstrtdt as credsts_effstrtdt,
temp.credsts_effenddt as credsts_effenddt,
temp.credsts_recrendtldt as credsts_recrendtldt,
temp.credsts_credresponcode as credsts_credresponcode,
temp.credsts_corpbusnssegcode as credsts_corpbusnssegcode
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.credsts_info) exploded VIEW as temp) K


-- druglic_info

hive> desc centri_professional_latestrecord_druglic_info;
OK
entity_id           	string              	                    
druglic_typecode    	string              	                    
druglic_numberid    	string              	                    
durglic_geoareaid   	string              	                    
druglic_effcncldt   	string              	                    
druglic_statustypcd 	string              	                    
Time taken: 0.063 seconds, Fetched: 6 row(s)

-- Query:

create VIEW bdapps_ihr_centri.centri_professional_latestrecord_druglic_info as select * from ( SELECT 
entity_id,
inserttimestamp,
temp.druglic_typecode as druglic_typecode,
temp.druglic_numberid as druglic_numberid,
temp.durglic_geoareaid as durglic_geoareaid,
temp.druglic_effcncldt as druglic_effcncldt,
temp.druglic_statustypcd as druglic_statustypcd
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.druglic_info) exploded VIEW as temp) K

-- elecommu_info:

hive> desc centri_professional_latestrecord_eleccommu_info;
OK
entity_id           	string              	                    
eleccommu_addrtypecode	string              	                    
eleccommu_addrtext  	string              	                    
eleccommu_statscode 	string              	                    
Time taken: 0.068 seconds, Fetched: 4 row(s)

-- Query:

create VIEW bdapps_ihr_centri.centri_professional_latestrecord_eleccommu_info as select * from ( SELECT 
entity_id,
inserttimestamp,
temp.eleccommu_addrtypecode as eleccommu_addrtypecode,
temp.eleccommu_addrtext as eleccommu_addrtext,
temp.eleccommu_statscode as eleccommu_statscode
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.eleccommu_info) exploded VIEW as temp) K


-- hcpdegree_info:

hive> desc centri_professional_latestrecord_hcpdegree_info;
OK
entity_id           	string              	                    
hcp_degree_code     	string            	                    
hcp_primaryind      	string              	                    
hcp_school_name     	string              	                    
hcp_school_compldt  	string              	                    
hcp_school_statuscd 	string              	                    
Time taken: 0.056 seconds, Fetched: 6 row(s)

-- Query:

create VIEW bdapps_ihr_centri.centri_professional_latestrecord_hcpdegree_info as select * from ( SELECT 
entity_id,
inserttimestamp,
temp.hcp_degree_code as hcp_degree_code,
temp.hcp_primaryind as hcp_primaryind,
temp.hcp_school_name as hcp_school_name,
temp.hcp_school_compldt as hcp_school_compldt,
temp.hcp_school_statuscd as hcp_school_statuscd
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.hcpdegree_info) exploded VIEW as temp) K


-- hcpidobjmpin

hive> desc centri_professional_latestrecord_hcpidobjmpin;
OK
entity_id           	string              	                    
hcpidobj_mpin_name  	string              	                    
hcpidobj_mpin_value 	string              	                    
hcpidobj_mpin_effstrtdt	string              	                    
hcpidobj_mpin_effenddt	string              	                    
Time taken: 0.094 seconds, Fetched: 5 row(s)

-- Query

create VIEW bdapps_ihr_centri.centri_professional_latestrecord_mpin as select * from (SELECT 
entity_id,
inserttimestamp,
prod_and_ts.hcpidobj_mpin_name as hcpidobj_mpin_name,
prod_and_ts.hcpidobj_mpin_value as hcpidobj_mpin_value,
prod_and_ts.hcpidobj_mpin_effstrtdt as hcpidobj_mpin_effstrtdt,
prod_and_ts.hcpidobj_mpin_effenddt as hcpidobj_mpin_effenddt
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.hcpidobjmpin) exploded VIEW as prod_and_ts) K

-- hcpidobjothrid

hive> desc centri_professional_latestrecord_hcpidobjothrid;
OK
entity_id           	string              	                    
hcpidobj_otherid_name	string              	                    
hcpidobj_otherid_value	string              	                    
hcpidobj_otherid_effstrtdt	string              	                    
hcpidobj_otherid_effenddt	string              	                    
Time taken: 0.06 seconds, Fetched: 5 row(s)

-- Query

create VIEW bdapps_ihr_centri.centri_professional_latestrecord_hcpidobjothrid as select * from (SELECT 
entity_id,
inserttimestamp,
prod_and_ts.hcpidobj_otherid_name as hcpidobj_otherid_name,
prod_and_ts.hcpidobj_otherid_value as hcpidobj_otherid_value,
prod_and_ts.hcpidobj_otherid_effstrtdt as hcpidobj_otherid_effstrtdt,
prod_and_ts.hcpidobj_otherid_effenddt as hcpidobj_otherid_effenddt
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.hcpidobjothrid) exploded VIEW as prod_and_ts) K


-- hcprole_info

hive> desc centri_professional_latestrecord_hcprole_info;
OK
entity_id           	string              	                    
hcprole_id          	string              	                    
hcprole_name        	string              	                    
hcprole_effstrtdt   	string              	                    
hcprole_taxid_name  	string              	                    
hcprole_taxid_value 	string              	                    
hcprole_entityid_name	string              	                    
hcprole_entityid_value	string              	                    
hcprole_taxid_effstrtdt	string              	                    
hcprole_taxid_ownername	string              	                    
hcprole_taxid_owner_org_id	string              	                    
hcprole_tieredproviderservcmodltypcd	string              	                    
hcprole_tieredproviderservcmodleffstrtdt	string              	                    
hcprole_taxid_number_effstrtdt	string              	                    
hcprole_hcotinowner_enterpriseid	string              	                    
hcprole_spowner_organization_name	string              	                    
hcprole_spowner_organization_nametypcd	string              	                    
hcprole_spowner_organization_effstrtdt	string              	                    
hcprole_spowner_organization_id	string              	                    
hcprole_servcprov_otheridname	string              	                    
hcprole_servcprov_otheridvalue	string              	                    
hcprole_servcprov_otherideffstrtdt	string              	                    
Time taken: 0.06 seconds, Fetched: 22 row(s)


-- Query
create VIEW bdapps_ihr_centri.centri_professional_latestrecord_hcprole_info as select * from ( SELECT 
entity_id,
inserttimestamp,
temp.hcprole_id as hcprole_id,
temp.hcprole_name as hcprole_name,
temp.hcprole_effstrtdt as hcprole_effstrtdt,
temp.hcprole_taxid_name as hcprole_taxid_name,
temp.hcprole_taxid_value as hcprole_taxid_value,
temp.hcprole_entityid_name as hcprole_entityid_name,
temp.hcprole_entityid_value as hcprole_entityid_value,
temp.hcprole_taxid_effstrtdt as hcprole_taxid_effstrtdt,
temp.hcprole_taxid_ownername as hcprole_taxid_ownername,
temp.hcprole_taxid_owner_org_id as hcprole_taxid_owner_org_id,
temp.hcprole_tieredproviderservcmodltypcd as hcprole_tieredproviderservcmodltypcd,
temp.hcprole_tieredproviderservcmodleffstrtdt as hcprole_tieredproviderservcmodleffstrtdt,
temp.hcprole_taxid_number_effstrtdt,             	                    
temp.hcprole_hcotinowner_enterpriseid,             	                    
temp.hcprole_spowner_organization_name,             	                    
temp.hcprole_spowner_organization_nametypcd,              	                    
temp.hcprole_spowner_organization_effstrtdt,             	                    
temp.hcprole_spowner_organization_id,
temp.hcprole_servcprov_otheridname as hcprole_servcprov_otheridname,
temp.hcprole_servcprov_otheridvalue as hcprole_servcprov_otheridvalue,
temp.hcprole_servcprov_otherideffstrtdt as hcprole_servcprov_otherideffstrtdt
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.hcprole_info) exploded VIEW as temp) K


-- malpracticecarrier_info

hive> desc centri_professional_latestrecord_malpracticecarrier_info;
OK
entity_id           	string              	                    
malpracticecarrier_id	string              	                    
malpracticecarrier_code	string              	                    
malpracticecarrier_name	string              	                    
malpracticecarrier_effstrtdt	string              	                    
malpracticecarrier_effcncldt	string              	                    
malpracticecarrier_totlanulcovamt	string              	                    
malpracticecarrier_sngloccurcovamt	string              	                    
malpracticecarrier_statuscode	string              	                    
Time taken: 0.058 seconds, Fetched: 9 row(s)

-- Query

create VIEW bdapps_ihr_centri.centri_professional_latestrecord_malpracticecarrier_info as select * from ( SELECT 
entity_id,
inserttimestamp,
temp.malpracticecarrier_id as malpracticecarrier_id,
temp.malpracticecarrier_code as malpracticecarrier_code,
temp.malpracticecarrier_name as malpracticecarrier_name,
temp.malpracticecarrier_effstrtdt as malpracticecarrier_effstrtdt,
temp.malpracticecarrier_effcncldt as malpracticecarrier_effcncldt,
temp.malpracticecarrier_totlanulcovamt as malpracticecarrier_totlanulcovamt,
temp.malpracticecarrier_sngloccurcovamt as malpracticecarrier_sngloccurcovamt,
temp.malpracticecarrier_statuscode as malpracticecarrier_statuscode
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.malpracticecarrier_info) exploded VIEW as temp) K

-- medicare_info

hive> desc centri_professional_latestrecord_medicare_info;
OK
entity_id           	string              	                    
medicare_name       	string              	                    
medicare_id         	string              	                    
medicare_effstarttdate	string              	                    
medicare_effenddate 	string              	                    
Time taken: 0.061 seconds, Fetched: 5 row(s)

-- Query

create VIEW bdapps_ihr_centri.centri_professional_latestrecord_medicare_info as select * from ( SELECT 
entity_id,
inserttimestamp,
temp.medicare_name as medicare_name,
temp.medicare_id as medicare_id,
temp.medicare_effstarttdate as medicare_effstarttdate,
temp.medicare_effenddate as medicare_effenddate
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.medicare_info) exploded VIEW as temp) K


-- othernm_info

hive> desc centri_professional_latestrecord_othernm_info;
OK
entity_id           	string              	                    
othernm_firstname   	string              	                    
othernm_middlename  	string              	                    
othernm_lastname    	string              	                    
othernm_nametypcd   	string              	                    
othernm_statuscd    	string              	                    
Time taken: 0.06 seconds, Fetched: 6 row(s)

-- Query:

create VIEW bdapps_ihr_centri.centri_professional_latestrecord_othernm_info as select * from ( SELECT 
entity_id,
inserttimestamp,
temp_othernm.othernm_firstname as othernm_firstname,
temp_othernm.othernm_middlename as othernm_middlename,
temp_othernm.othernm_lastname as othernm_lastname,
temp_othernm.othernm_nametypcd as othernm_nametypcd,
temp_othernm.othernm_statuscd as othernm_statuscd
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.othernm_info) exploded VIEW as temp_othernm) K


-- premium_designation

hive> desc centri_professional_latestrecord_premium_designation;
OK
entity_id           	string              	                    
premiumdisease_grouptypecode	string              	                    
premiumdisease_conditionfocustypecode	string              	                    
premium_efficiencytypecode	string              	                    
premiumquality_typecode	string              	                    
premiumquality_efficiencytypecode	string              	                    
premiumdesignation_effstart_date	string              	                    
premiumdesignation_effend_date	string              	                    
premiumdesignation_prioritynumber	string              	                    
premiumdesignation_prioritygroupnumber	string              	                    
Time taken: 0.066 seconds, Fetched: 10 row(s)


-- Query:

create VIEW bdapps_ihr_centri.centri_professional_latestrecord_premium_designation as select * from ( SELECT 
entity_id,
inserttimestamp,
temp.premiumdisease_grouptypecode as premiumdisease_grouptypecode,
temp.premiumdisease_conditionfocustypecode as premiumdisease_conditionfocustypecode,
temp.premium_efficiencytypecode as premium_efficiencytypecode,
temp.premiumquality_typecode as premiumquality_typecode,
temp.premiumquality_efficiencytypecode as premiumquality_efficiencytypecode,
temp.premiumdesignation_effstart_date as premiumdesignation_effstart_date,
temp.premiumdesignation_effend_date as premiumdesignation_effend_date,
temp.premiumdesignation_prioritynumber as premiumdesignation_prioritynumber,
temp.premiumdesignation_prioritygroupnumber as premiumdesignation_prioritygroupnumber
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.premium_designation) exploded VIEW as temp) K


-- taxonomyclass_info

hive> desc centri_professional_latestrecord_taxonomyclass_info;
OK
entity_id           	string              	                    
taxonomy_classicode 	string              	                    
taxonomy_classieffstrtdt	string              	                    
taxonomy_classiprimclassind	string              	                    
taxonomy_classisrctype	string              	                    
taxonomy_classisrctypecode	string              	                    
taxonomy_classipracspclind	string              	                    
taxonomy_classispclbrdcertcode	string              	                    
taxonomy_classispclbrdcertdate	string              	                    
taxonomy_classispclbrdexamdate	string              	                    
taxonomy_classispclbrdexpdate	string              	                    
taxonomy_classirecerteffdate	string              	                    
Time taken: 0.055 seconds, Fetched: 12 row(s)

-- Query:

create VIEW bdapps_ihr_centri.centri_professional_latestrecord_taxonomyclass_info as select * from ( SELECT 
entity_id,
inserttimestamp,
temp.taxonomy_classicode as taxonomy_classicode,
temp.taxonomy_classieffstrtdt as taxonomy_classieffstrtdt,
temp.taxonomy_classiprimclassind as taxonomy_classiprimclassind,
temp.taxonomy_classisrctype as taxonomy_classisrctype,
temp.taxonomy_classisrctypecode as taxonomy_classisrctypecode,
temp.taxonomy_classipracspclind as taxonomy_classipracspclind,
temp.taxonomy_classispclbrdcertcode as taxonomy_classispclbrdcertcode,
temp.taxonomy_classispclbrdcertdate as taxonomy_classispclbrdcertdate,
temp.taxonomy_classispclbrdexamdate as taxonomy_classispclbrdexamdate,
temp.taxonomy_classispclbrdexpdate as taxonomy_classispclbrdexpdate,
temp.taxonomy_classirecerteffdate as taxonomy_classirecerteffdate
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.taxonomyclass_info) exploded VIEW as temp) K


-- training_info

hive> desc centri_professional_latestrecord_training_info;
OK
entity_id           	string              	                    
training_typecode   	string              	                    
training_strtdt     	string              	                    
training_compdt     	string              	                    
training_schooltypecode	string              	                    
training_edutypecode	string              	                    
training_statuscode 	string              	                    
Time taken: 0.09 seconds, Fetched: 7 row(s)

-- Query

create VIEW bdapps_ihr_centri.centri_professional_latestrecord_training_info as select * from ( SELECT 
entity_id,
inserttimestamp,
temp.training_typecode as training_typecode,
temp.training_strtdt as training_strtdt,
temp.training_compdt as training_compdt,
temp.training_schooltypecode as training_schooltypecode,
temp.training_edutypecode as training_edutypecode,
temp.training_statuscode as training_statuscode
FROM
bdapps_ihr_centri.practitionerflat as p
LATERAL VIEW explode(p.training_info) exploded VIEW as temp) K

-- noarrayofstructs

hive> desc centri_professional_noarrayofstructs;
OK
inserttimestamp     	string              	                    
entity_id           	string              	                    
provider_prtytypcd  	string              	                    
provider_effstrtdt  	string              	                    
practitioner_effstrtdt	string              	                    
first_name          	string              	                    
middle_name         	string              	                    
last_name           	string              	                    
birth_date          	string              	                    
gender              	string              	                    
ssn                 	string              	                    
npi_id              	string              	                    
npi_id_effstrtdt    	string              	                    
npi_id_effenddt     	string              	                    
taxonomy_providertypecode	string              	                    
taxonomy_effdates   	string              	                    
Time taken: 0.093 seconds, Fetched: 16 row(s)

-- Query:

create VIEW bdapps_ihr_centri.centri_professional_noarrayofstructs as select 
entity_id,
inserttimestamp,
provider_prtytypcd,
provider_effstrtdt,
practitioner_effstrtdt,
first_name,
middle_name,
last_name,
birth_date,
gender,
ssn,
npi_id,
npi_id_effstrtdt,
npi_id_effenddt,
taxonomy_providertypecode,
taxonomy_effdates
FROM
bdapps_ihr_centri.practitionerflat;

