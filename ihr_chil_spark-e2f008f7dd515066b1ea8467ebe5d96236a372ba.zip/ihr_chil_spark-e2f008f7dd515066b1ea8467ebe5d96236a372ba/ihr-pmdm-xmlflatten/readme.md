Job Overview:
-------------
-> Extracts PMDM professional and Organization xmls from Datalake HBase Table with Timerange scan and perform flattening to create HIVE Tables on top of Flattened xml data. 
The watermark Timestamp called lastRnLdTs column maintains last run time status to pull xmls with in the time range.

Below is the ihr_entity_info HBase table for Professional and Organization domains:

Professional:
-------------

hbase(main):002:0> get '/datalake/optum/optuminsight/p_edh/prd/uhc/ihr/prd/p_mtables/ihr_entity_info','UHG-PMD-PRACTITIONERFLAT'
COLUMN                                                       CELL                                                                                                                                                                             
 ei:lastRnLdTs                                               timestamp=1534430314785, value=2018-08-16 08:55:34.205                                                                                                                           
 ei:outFileNm                                                timestamp=1527798777138, value=PRACTITIONERFLAT                                                                                                                                  
 ei:prtnrCd                                                  timestamp=1527798777138, value=UHG                                                                                                                                               
 ei:srcCd                                                    timestamp=1527798777138, value=PMD                                                                                                                                               
4 row(s) in 0.0100 seconds

Organization:
-------------

hbase(main):003:0> get '/datalake/optum/optuminsight/p_edh/prd/uhc/ihr/prd/p_mtables/ihr_entity_info','UHG-PMD-PROVORGFLAT'
COLUMN                                                       CELL                                                                                                                                                                             
 ei:lastRnLdTs                                               timestamp=1534435336064, value=2018-08-16 08:52:54.127                                                                                                                           
 ei:outFileNm                                                timestamp=1527798777092, value=PROVORGFLAT                                                                                                                                       
 ei:prtnrCd                                                  timestamp=1527798777092, value=UHG                                                                                                                                               
 ei:srcCd                                                    timestamp=1527798777092, value=PMD                                                                                                                                               
4 row(s) in 0.0030 seconds

-> PMDM-XML-Flattened job croned using Oozie workflow on daily basis to trigger everyday 8:50AM CST.

Job WorkFlow:
-------------
Job --> Triggers Parallel Fashion --> 1) ProvOrgXmlFlatInc       -->Updates Audit Tracking     ---> Success/Failure Sends a Mail 
                                      2) PractitionerXmlFlatInc  -->Updates Audit Tracking     ---> Success/Failure Sends a Mail

Runnable command to submit via Oozie:
-------------------------------------
/opt/mapr/oozie/oozie-4.3.0/bin/oozie job -oozie="https://apsrp05219.uhc.com:11443/oozie/" -config /mapr/datalake/optum/optuminsight/p_edh/prd/uhc/ihr/prd/p_conf/oozie/pmdoozie/IHROozieJob.properties -run


Table Info:
===========

scala> spark.sql("use bdapps_ihr_centri")
res2: org.apache.spark.sql.DataFrame = []

scala> spark.sql("use bdapps_ihr_centri").show(false)
++
||
++
++


scala> spark.sql("show tables").show(false)
+-----------------+----------------------------------------+-----------+
|database         |tableName                               |isTemporary|
+-----------------+----------------------------------------+-----------+
|bdapps_ihr_centri|6435dbp_ml_cnsm_xref_snapshot_20180926  |false      |
|bdapps_ihr_centri|cdb_aco_rallyroster                     |false      |
|bdapps_ihr_centri|cdb_ei_julydat                          |false      |
|bdapps_ihr_centri|cdb_finalqry_20180730                   |false      |
|bdapps_ihr_centri|cdb_finalqry_updated_20180720           |false      |
|bdapps_ihr_centri|centri_adoc_xml_extract                 |false      |
|bdapps_ihr_centri|centri_adoc_xml_extract_latestrecord    |false      |
|bdapps_ihr_centri|centri_adoc_xml_extract_org             |false      |
|bdapps_ihr_centri|centri_adoc_xml_extract_org_latestrecord|false      |
|bdapps_ihr_centri|centri_organization_alternatenms        |false      |
|bdapps_ihr_centri|centri_organization_correspondence_info |false      |
|bdapps_ihr_centri|centri_organization_eleccommu_info      |false      |
|bdapps_ihr_centri|centri_organization_hcotinownercorr_info|false      |
|bdapps_ihr_centri|centri_organization_hlthcarecredsts     |false      |
|bdapps_ihr_centri|centri_organization_hlthcareeleccomm    |false      |
|bdapps_ihr_centri|centri_organization_locidobj_info       |false      |
|bdapps_ihr_centri|centri_organization_noarrayofstructs    |false      |
|bdapps_ihr_centri|centri_organization_nonvalidnpi         |false      |
|bdapps_ihr_centri|centri_organization_nonvalidnpitax_info |false      |
|bdapps_ihr_centri|centri_organization_orgidobjmpin        |false      |
+-----------------+----------------------------------------+-----------+
only showing top 20 rows


scala> spark.sql("select inserttimestamp from provorgflat").show(false)
18/10/29 10:03:19 WARN Utils: Truncated the string representation of a plan since it was too large. This behavior can be adjusted by setting 'spark.debug.maxToStringFields' in SparkEnv.conf.
+--------------------------+
|inserttimestamp           |
+--------------------------+
|2018-07-02T03:41:44.000000|
|2018-07-02T03:41:44.000000|
|2018-10-24T17:33:28.000000|
|2018-07-02T03:41:44.000000|
|2018-07-02T03:41:44.000000|
|2018-07-31T03:00:51.000000|
|2018-07-31T03:00:51.000000|
|2018-07-02T03:41:44.000000|
|2018-07-02T03:41:44.000000|
|2018-08-12T18:20:27.000000|
|2018-07-13T05:44:19.000000|
|2018-07-02T03:41:44.000000|
|2018-07-02T03:41:44.000000|
|2018-09-11T14:56:37.000000|
|2018-07-02T03:41:44.000000|
|2018-07-02T03:41:44.000000|
|2018-10-29T01:19:26.000000|
|2018-07-02T03:41:44.000000|
|2018-07-02T03:41:44.000000|
|2018-07-02T03:41:44.000000|
+--------------------------+
only showing top 20 rows


scala> spark.sql("select inserttimestamp from practitionerflat").show(false)
2018-10-29 10:03:16,7269 ERROR Cidcache fs/client/fileclient/cc/cidcache.cc:2154 Thread: 24565 Lookup of volume datalake failed, error Read-only file system(30), CLDB: 10.106.33.32:7222 backing off ...
2018-10-29 10:03:16,7299 ERROR Cidcache fs/client/fileclient/cc/cidcache.cc:2154 Thread: 24565 Lookup of volume p_edh failed, error Read-only file system(30), CLDB: 10.106.33.32:7222 backing off ...
2018-10-29 10:03:16,7319 ERROR Cidcache fs/client/fileclient/cc/cidcache.cc:2154 Thread: 24565 Lookup of volume edh_ihr_prd failed, error Read-only file system(30), CLDB: 10.106.33.32:7222 backing off ...
+--------------------------+
|inserttimestamp           |
+--------------------------+
|2018-10-20T11:36:51.000000|
|2018-07-05T03:00:55.000000|
|2018-10-26T22:03:55.000000|
|2018-10-24T17:33:28.000000|
|2018-10-26T22:03:55.000000|
|2018-10-18T15:32:00.000000|
|2018-10-04T16:10:51.000000|
|2018-10-23T11:44:00.000000|
|2018-10-24T17:33:28.000000|
|2018-07-02T03:41:44.000000|
|2018-03-23T09:59:17.000000|
|2018-07-02T03:41:44.000000|
|2018-08-03T03:00:51.000000|
|2018-10-26T22:03:55.000000|
|2018-10-26T22:03:55.000000|
|2018-08-28T07:02:53.000000|
|2018-07-02T03:41:44.000000|
|2018-10-04T16:10:51.000000|
|2018-07-27T03:00:55.000000|
|2018-07-02T03:41:44.000000|
+--------------------------+
only showing top 20 rows

