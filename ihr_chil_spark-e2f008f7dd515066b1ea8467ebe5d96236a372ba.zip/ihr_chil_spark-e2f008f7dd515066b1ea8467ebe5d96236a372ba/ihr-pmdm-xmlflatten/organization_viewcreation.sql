-- centri_organization_alternatenms

hive> desc centri_organization_alternatenms;
OK
providobj_enterprise_id	string              	                    
alternatenms_servprov_match_nm	string              	                    
alternatenms_name   	string              	                    
alternatenms_nametypcd	string              	                    
alternatenms_stscd  	string              	                    
Time taken: 0.327 seconds, Fetched: 5 row(s)


Query:
-----
create view bdapps_ihr_centri.centri_organization_alternatenms as select * from ( SELECT
providobj_enterprise_id,
inserttimestamp,
temp_alternatenms.alternatenms_servprov_match_nm as alternatenms_servprov_match_nm,
temp_alternatenms.alternatenms_name as  alternatenms_name,
temp_alternatenms.alternatenms_nametypcd as alternatenms_nametypcd,
temp_alternatenms.alternatenms_stscd as alternatenms_stscd
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.alternatenms) exploded_view as temp_alternatenms) K;



-- centri_organization_correspondence_info

hive> desc centri_organization_correspondence_info;
OK
providobj_enterprise_id	string              	                    
correpndnce_matchaddr_othrprovloc	string              	                    
correpndnce_effstrtdtmatch_otherprovloc	string              	                    
correpndnce_othrprov_identifier	string              	                    
correpndnce_othrprov_addtypcode	string              	                    
correpndnce_othrprov_effstrtdt	string              	                    
Time taken: 0.074 seconds, Fetched: 6 row(s)


Query:
------
create view bdapps_ihr_centri.centri_organization_correspondence_info as select * from ( SELECT 
providobj_enterprise_id,
inserttimestamp,
temp_correspondence.correpndnce_matchaddr_othrprovloc as correpndnce_matchaddr_othrprovloc,
temp_correspondence.correpndnce_effstrtdtmatch_otherprovloc as correpndnce_effstrtdtmatch_otherprovloc,
temp_correspondence.correpndnce_othrprov_identifier as correpndnce_othrprov_identifier,
temp_correspondence.correpndnce_othrprov_addtypcode as correpndnce_othrprov_addtypcode,
temp_correspondence.correpndnce_othrprov_effstrtdt as correpndnce_othrprov_effstrtdt
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.correspondence) exploded_view as temp_correspondence) K



-- centri_organization_eleccommu_info

hive> desc centri_organization_eleccommu_info;
OK
providobj_enterprise_id	string              	                    
eleccommu_addrtypecode	string              	                    
eleccommu_addrtext  	string              	                    
eleccommu_statscode 	string              	                    
Time taken: 0.218 seconds, Fetched: 4 row(s)

Query:
-----
create view bdapps_ihr_centri.centri_organization_eleccommu_info as select * from ( SELECT 
providobj_enterprise_id,
inserttimestamp,
temp_eleccommu_info.eleccommu_addrtypecode as eleccommu_addrtypecode,
temp_eleccommu_info.eleccommu_addrtext as eleccommu_addrtext,
temp_eleccommu_info.eleccommu_statscode as eleccommu_statscode
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.eleccommu_info) exploded_view as temp_eleccommu_info) K


-- centri_organization_hcotinownercorr_info

hive> desc centri_organization_hcotinownercorr_info;
OK
providobj_enterprise_id	string              	                    
tinowner_match_taxid	string              	                    
tinowner_address_line1	string              	                    
tinowner_city       	string              	                    
tinowner_county_code	string              	                    
tinowner_state      	string              	                    
tinowner_postalcode_part1	string              	                    
tinowner_postalcode_part2	string              	                    
tinowner_type       	string              	                    
tinowner_latitude   	string              	                    
tinowner_longitude  	string              	                    
tinowner_country    	string              	                    
tinowner_locationidobj_identifier	string              	                    
tinowner_locationidobj_addrtypcode	string              	                    
tinowner_corrspeffstrtdt	string              	                    
tinowner_effectivedtrange_strtdt	string              	                    
Time taken: 0.083 seconds, Fetched: 16 row(s)


Query:
------

create view bdapps_ihr_centri.centri_organization_hcotinownercorr_info as select * from ( SELECT 
providobj_enterprise_id,
inserttimestamp,
temp_hcotinownercorr_info.tinowner_match_taxid as tinowner_match_taxid,
temp_hcotinownercorr_info.tinowner_address_line1 as tinowner_address_line1,
temp_hcotinownercorr_info.tinowner_city as tinowner_city,
temp_hcotinownercorr_info.tinowner_county_code as tinowner_county_code,
temp_hcotinownercorr_info.tinowner_state as tinowner_state,
temp_hcotinownercorr_info.tinowner_postalcode_part1 as tinowner_postalcode_part1,
temp_hcotinownercorr_info.tinowner_postalcode_part2 as tinowner_postalcode_part2,
temp_hcotinownercorr_info.tinowner_type as tinowner_type,
temp_hcotinownercorr_info.tinowner_latitude as tinowner_latitude,
temp_hcotinownercorr_info.tinowner_longitude as tinowner_longitude,
temp_hcotinownercorr_info.tinowner_country as tinowner_country,
temp_hcotinownercorr_info.tinowner_locationidobj_identifier as tinowner_locationidobj_identifier,
temp_hcotinownercorr_info.tinowner_locationidobj_addrtypcode as tinowner_locationidobj_addrtypcode,
temp_hcotinownercorr_info.tinowner_corrspeffstrtdt as tinowner_corrspeffstrtdt,
temp_hcotinownercorr_info.tinowner_effectivedtrange_strtdt as tinowner_effectivedtrange_strtdt
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.hcotinownercorr_info) exploded_view as temp_hcotinownercorr_info) K



--- centri_organization_hlthcarecredsts

hive> desc centri_organization_hlthcarecredsts;
OK
providobj_enterprise_id	string              	                    
hlthcarecredsts_ststypcd	string              	                    
hlthcarecredsts_credtypcd	string              	                    
hlthcarecredsts_credtypcd_desc	string              	                    
hlthcarecredsts_effstrtdt	string              	                    
hlthcarecredsts_effcancldt	string              	                    
hlthcarecredsts_credrespcd	string              	                    
hlthcarecredsts_corpbussegcd	string              	                    
hlthcarecredsts_org_id	string              	                    
Time taken: 0.147 seconds, Fetched: 9 row(s)

Query:
------

create view bdapps_ihr_centri.centri_organization_hlthcarecredsts as select * from ( SELECT
providobj_enterprise_id,
inserttimestamp,
temp_hlthcarecredsts.hlthcarecredsts_ststypcd as hlthcarecredsts_ststypcd,
temp_hlthcarecredsts.hlthcarecredsts_credtypcd as hlthcarecredsts_credtypcd,
temp_hlthcarecredsts.hlthcarecredsts_credtypcd_desc as hlthcarecredsts_credtypcd_desc,
temp_hlthcarecredsts.hlthcarecredsts_effstrtdt hlthcarecredsts_effstrtdt,
temp_hlthcarecredsts.hlthcarecredsts_effcancldt as hlthcarecredsts_effcancldt,
temp_hlthcarecredsts.hlthcarecredsts_credrespcd as hlthcarecredsts_credrespcd,
temp_hlthcarecredsts.hlthcarecredsts_corpbussegcd as hlthcarecredsts_corpbussegcd,
temp_hlthcarecredsts.hlthcarecredsts_org_id as hlthcarecredsts_org_id
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.hlthcarecredsts) exploded_view as temp_hlthcarecredsts) K;



-- centri_organization_hlthcareeleccomm

hive> desc centri_organization_hlthcareeleccomm;
OK
providobj_enterprise_id	string              	                    
hlthcareeleccommu_addrtypecode	string              	                    
hlthcareeleccommu_addrtext	string              	                    
hlthcareeleccommu_statscode	string              	                    
Time taken: 0.069 seconds, Fetched: 4 row(s)


Query:
------
create view bdapps_ihr_centri.centri_organization_hlthcareeleccomm as select * from ( SELECT 
providobj_enterprise_id,
inserttimestamp,
temp_hlthcareeleccomm.hlthcareeleccommu_addrtypecode as hlthcareeleccommu_addrtypecode,
temp_hlthcareeleccomm.hlthcareeleccommu_addrtext as hlthcareeleccommu_addrtext,
temp_hlthcareeleccomm.hlthcareeleccommu_statscode as hlthcareeleccommu_statscode
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.hlthcareeleccomm) exploded_view as temp_hlthcareeleccomm) K




-- centri_organization_locidobj_info

hive> desc centri_organization_locidobj_info;
OK
providobj_enterprise_id	string              	                    
locidobj_identifier 	string              	                    
locidobj_addtypcode 	string              	                    
locidobj_effstrtdt  	string              	                    
Time taken: 0.064 seconds, Fetched: 4 row(s)


Query:
-----
create view bdapps_ihr_centri.centri_organization_locidobj_info as select * from ( SELECT 
providobj_enterprise_id,
inserttimestamp,
temp_locidobj.locidobj_identifier as locidobj_identifier,
temp_locidobj.locidobj_addtypcode as locidobj_addtypcode,
temp_locidobj.locidobj_effstrtdt as locidobj_effstrtdt
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.locidobj) exploded_view as temp_locidobj) K


-- centri_organization_nonvalidnpi

hive> desc centri_organization_nonvalidnpi;
OK
providobj_enterprise_id	string              	                    
organization_orgid  	string              	                    
nonvalidnpi_name    	string              	                    
nonvalidnpi_value   	string              	                    
nonvalidnpi_sourcesystm	string              	                    
nonvalidnpi_effstrtdt	string              	                    
nonvalidnpi_effcncldt	string              	                    
nonvalidnpi_adddt   	string              	                    
Time taken: 0.071 seconds, Fetched: 8 row(s)

Query:
------
create view bdapps_ihr_centri.centri_organization_nonvalidnpi as select * from ( SELECT 
providobj_enterprise_id,
inserttimestamp,
temp_nonvalidnpi.organization_orgid  as organization_orgid,
temp_nonvalidnpi.nonvalidnpi_name   as nonvalidnpi_name,
temp_nonvalidnpi.nonvalidnpi_value  as nonvalidnpi_value,
temp_nonvalidnpi.nonvalidnpi_sourcesystm as nonvalidnpi_sourcesystm,
temp_nonvalidnpi.nonvalidnpi_effstrtdt  as nonvalidnpi_effstrtdt,
temp_nonvalidnpi.nonvalidnpi_effcncldt as nonvalidnpi_effcncldt,
temp_nonvalidnpi.nonvalidnpi_adddt as nonvalidnpi_adddt
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.nonvalidnpi) exploded_view as temp_nonvalidnpi) K


-- centri_organization_nonvalidnpitax_info

hive> desc centri_organization_nonvalidnpitax_info;
OK
providobj_enterprise_id	string              	                    
nonvalid_npiid_match_taxnmy	string              	                    
nonvalid_npi_taxnmy_effstrtdt	string              	                    
nonvalid_npi_taxnmy_adddt	string              	                    
nonvalid_npi_taxnmy_srctypcd	string              	                    
nonvalid_npi_taxnmy_code	string              	                    
Time taken: 0.056 seconds, Fetched: 6 row(s)

Query:
-----

create view bdapps_ihr_centri.centri_organization_nonvalidnpitax_info as select * from ( SELECT 
providobj_enterprise_id,
inserttimestamp,
temp_nonvalidnpitax.nonvalid_npiid_match_taxnmy as nonvalid_npiid_match_taxnmy,
temp_nonvalidnpitax.nonvalid_npi_taxnmy_effstrtdt as nonvalid_npi_taxnmy_effstrtdt,
temp_nonvalidnpitax.nonvalid_npi_taxnmy_adddt as  nonvalid_npi_taxnmy_adddt,
temp_nonvalidnpitax.nonvalid_npi_taxnmy_srctypcd as nonvalid_npi_taxnmy_srctypcd,
temp_nonvalidnpitax.nonvalid_npi_taxnmy_code as nonvalid_npi_taxnmy_code
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.nonvalidnpitax) exploded_view as temp_nonvalidnpitax)K


-- centri_organization_orgidobjotherid_info

hive> desc centri_organization_orgidobjotherid_info;
OK
providobj_enterprise_id	string              	                    
orgidobj_otherid_name	string              	                    
orgidobj_otherid_value	string              	                    
orgidobj_otherid_effstartdt	string              	                    
Time taken: 0.072 seconds, Fetched: 4 row(s)

Query:
-----
create view bdapps_ihr_centri.centri_organization_orgidobjotherid_info as select * from ( SELECT
providobj_enterprise_id,
inserttimestamp,
temp_orgidobjotherid.organization_orgid as organization_orgid,
temp_orgidobjotherid.orgidobj_otherid_name  as orgidobj_otherid_name ,
temp_orgidobjotherid.orgidobj_otherid_value  as orgidobj_otherid_value,
temp_orgidobjotherid.orgidobj_otherid_effstartdt as orgidobj_otherid_effstartdt
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.orgidobjotherid) exploded_view as temp_orgidobjotherid) K;


-- centri_organization_orgidobjmpin

hive> desc centri_organization_orgidobjmpin;
OK
providobj_enterprise_id	string              	                    
organization_orgid  	string              	                    
orgidobjmpin_name   	string              	                    
orgidobjmpin_value  	string              	                    
orgidobjmpin_effstrtdt	string              	                    
orgidobjmpin_effenddt	string              	                    
Time taken: 0.072 seconds, Fetched: 6 row(s)

Query:
------
create view bdapps_ihr_centri.centri_organization_orgidobjmpin as select * from ( SELECT 
providobj_enterprise_id,
inserttimestamp,
temp_orgidobjmpin.organization_orgid as organization_orgid,
temp_orgidobjmpin.orgidobjmpin_name  as orgidobjmpin_name ,
temp_orgidobjmpin.orgidobjmpin_value  as orgidobjmpin_value ,
temp_orgidobjmpin.orgidobjmpin_effstrtdt as orgidobjmpin_effstrtdt,
temp_orgidobjmpin.orgidobjmpin_effenddt as orgidobjmpin_effenddt
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.orgidobjmpin) exploded_view as temp_orgidobjmpin) K


-- centri_organization_orgnames

hive> desc centri_organization_orgnames;
OK
providobj_enterprise_id	string              	                    
org_name            	string              	                    
org_effstrtdt       	string              	                    
org_effenddt        	string              	                    
Time taken: 0.053 seconds, Fetched: 4 row(s)

Query:
------
create view bdapps_ihr_centri.centri_organization_orgnames as select * from ( SELECT 
providobj_enterprise_id,
inserttimestamp,
temp_orgnames.org_name  as org_name,
temp_orgnames.org_effstrtdt  as org_effstrtdt,
temp_orgnames.org_effenddt  as org_effenddt
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.orgnames) exploded_view as temp_orgnames) K


-- centri_organization_orgtxnmy

hive> desc centri_organization_orgtxnmy;
OK
providobj_enterprise_id	string              	                    
orgtxnmy_providertypcode	string              	                    
orgtxnmy_effstrtdt  	string              	                    
orgtxnmy_effenddt   	string              	                    
Time taken: 0.064 seconds, Fetched: 4 row(s)

Query:
------
create view bdapps_ihr_centri.centri_organization_orgtxnmy as select * from ( SELECT 
providobj_enterprise_id,
inserttimestamp,
temp_orgtxnmy.orgtxnmy_providertypcode  as orgtxnmy_providertypcode,
temp_orgtxnmy.orgtxnmy_effstrtdt  as orgtxnmy_effstrtdt,
temp_orgtxnmy.orgtxnmy_effenddt  as orgtxnmy_effenddt
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.orgtxnmy) exploded_view as temp_orgtxnmy) K


-- centri_organization_pracloc_teleinfo

hive> desc centri_organization_pracloc_teleinfo;
OK
providobj_enterprise_id	string              	                    
praclocaddline_matchtelephone	string              	                    
pracloc_telephone_typecode	string              	                    
pracloc_telephone_countrycode	string              	                    
pracloc_telephone_areacode	string              	                    
pracloc_telephone_subscriber	string              	                    
pracloc_telephone_telephonenbr	string              	                    
pracloc_telephone_primind	string              	                    
Time taken: 0.065 seconds, Fetched: 8 row(s)

Query:
-----
create view bdapps_ihr_centri.centri_organization_pracloc_teleinfo as select * from ( SELECT 
providobj_enterprise_id,
inserttimestamp,
temp_pracloctele.praclocaddline_matchtelephone as praclocaddline_matchtelephone,
temp_pracloctele.pracloc_telephone_typecode as pracloc_telephone_typecode,
temp_pracloctele.pracloc_telephone_countrycode as pracloc_telephone_countrycode,
temp_pracloctele.pracloc_telephone_areacode as pracloc_telephone_areacode,
temp_pracloctele.pracloc_telephone_subscriber as pracloc_telephone_subscriber,
temp_pracloctele.pracloc_telephone_telephonenbr as pracloc_telephone_telephonenbr,
temp_pracloctele.pracloc_telephone_primind as pracloc_telephone_primind
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.pracloctele) exploded_view as temp_pracloctele)K

-- centri_organization_praclocschedule_info

hive> desc centri_organization_praclocschedule_info;
OK
providobj_enterprise_id	string              	                    
praclocadd_matchschedule	string              	                    
praclocschedule_dayofweek	string              	                    
praclocschedule_starttime	string              	                    
praclocschedule_endtime	string              	                    
Time taken: 0.106 seconds, Fetched: 5 row(s)

Query:
------
create view bdapps_ihr_centri.centri_organization_praclocschedule_info as select * from ( SELECT
providobj_enterprise_id,
inserttimestamp,
temp_praclocschedule_info.praclocadd_matchschedule as praclocadd_matchschedule,
temp_praclocschedule_info.praclocschedule_dayofweek as praclocschedule_dayofweek,
temp_praclocschedule_info.praclocschedule_starttime as praclocschedule_starttime,
temp_praclocschedule_info.praclocschedule_endtime as praclocschedule_endtime
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.praclocschedule_info) exploded_view as temp_praclocschedule_info) K;


-- centri_organization_serprovpracloc

hive> desc centri_organization_serprovpracloc;
OK
providobj_enterprise_id	string              	                    
pracloc_address_line1	string              	                    
pracloc_city        	string              	                    
pracloc_countycode  	string              	                    
pracloc_state       	string              	                    
pracloc_postalcode_part1	string              	                    
pracloc_postalcode_part2	string              	                    
pracloc_type        	string              	                    
pracloc_primaryind  	string              	                    
pracloc_latitude    	string              	                    
pracloc_longitude   	string              	                    
pracloc_country     	string              	                    
pracloc_location_effstrtdt	string              	                    
pracloc_locationname	string              	                    
Time taken: 0.063 seconds, Fetched: 14 row(s)

Query:
------
create view bdapps_ihr_centri.centri_organization_serprovpracloc as select * from ( SELECT
providobj_enterprise_id,
inserttimestamp,
temp_serprovpracloc.pracloc_address_line1 as pracloc_address_line1,
temp_serprovpracloc.pracloc_city as pracloc_city,
temp_serprovpracloc.pracloc_countycode as pracloc_countycode,
temp_serprovpracloc.pracloc_state as pracloc_state,
temp_serprovpracloc.pracloc_postalcode_part1 as pracloc_postalcode_part1,
temp_serprovpracloc.pracloc_postalcode_part2 as pracloc_postalcode_part2,
temp_serprovpracloc.pracloc_type   as pracloc_type, 
temp_serprovpracloc.pracloc_primaryind as pracloc_primaryind,
temp_serprovpracloc.pracloc_latitude   as pracloc_latitude,
temp_serprovpracloc.pracloc_longitude as pracloc_longitude,
temp_serprovpracloc.pracloc_country as pracloc_country,
temp_serprovpracloc.pracloc_location_effstrtdt as pracloc_location_effstrtdt,
temp_serprovpracloc.pracloc_locationname as pracloc_locationname
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.serprovpracloc) exploded_view as temp_serprovpracloc) K;


-- centri_organization_taxonomyclass_info

hive> desc centri_organization_taxonomyclass_info;
OK
providobj_enterprise_id	string              	                    
taxonomy_provtypcd_match_class	string              	                    
taxonomy_classicode 	string              	                    
taxonomy_classieffstrtdt	string              	                    
taxonomy_classieffcancldt	string              	                    
taxonomy_classiprimclassind	string              	                    
taxonomy_classisrctype	string              	                    
taxonomy_classisrctypecode	string              	                    
taxonomy_classipracspclind	string              	                    
taxonomy_classispclbrdcertcode	string              	                    
taxonomy_classispclbrdcertdate	string              	                    
taxonomy_classispclbrdexamdate	string              	                    
taxonomy_classispclbrdexpdate	string              	                    
taxonomy_classirecerteffdate	string              	                    
Time taken: 0.067 seconds, Fetched: 14 row(s)

Query:
-----
create view bdapps_ihr_centri.centri_organization_taxonomyclass_info as select * from ( SELECT 
providobj_enterprise_id,
inserttimestamp,
temp_taxonomyclass.taxonomy_provtypcd_match_class as taxonomy_provtypcd_match_class,
temp_taxonomyclass.taxonomy_classicode  as taxonomy_classicode,
temp_taxonomyclass.taxonomy_classieffstrtdt as taxonomy_classieffstrtdt,
temp_taxonomyclass.taxonomy_classieffcancldt as taxonomy_classieffcancldt,
temp_taxonomyclass.taxonomy_classiprimclassind as taxonomy_classiprimclassind,
temp_taxonomyclass.taxonomy_classisrctype as taxonomy_classisrctype,
temp_taxonomyclass.taxonomy_classisrctypecode as taxonomy_classisrctypecode,
temp_taxonomyclass.taxonomy_classipracspclind as taxonomy_classipracspclind,
temp_taxonomyclass.taxonomy_classispclbrdcertcode as taxonomy_classispclbrdcertcode,
temp_taxonomyclass.taxonomy_classispclbrdcertdate as taxonomy_classispclbrdcertdate,
temp_taxonomyclass.taxonomy_classispclbrdexamdate as taxonomy_classispclbrdexamdate,
temp_taxonomyclass.taxonomy_classispclbrdexpdate as taxonomy_classispclbrdexpdate,
temp_taxonomyclass.taxonomy_classirecerteffdate as taxonomy_classirecerteffdate
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.taxonomyclass_info) exploded_view as temp_taxonomyclass) K


-- centri_organization_txnmyclsspclty_info

array<struct<txnmy_clss_match_code:string,txnmyclsspclty_code:string,txnmyclsspclty_effstrtdt:string,txnmyclsspclty_effcancldt:string,txnmyclsspclty_datasrctypcd:string,txnmyclsspclty_pracspclind:string,
txnmyclsspclty_primspclind:string,txnmyclsspclty_srctypecode:string>>

create view bdapps_ihr_centri.centri_organization_txnmyclsspclty_info as select * from ( SELECT 
providobj_enterprise_id,
inserttimestamp,
temp_txnmyclsspclty.txnmy_clss_match_code as txnmy_clss_match_code,
temp_txnmyclsspclty.txnmyclsspclty_code as txnmyclsspclty_code,
temp_txnmyclsspclty.txnmyclsspclty_effstrtdt as txnmyclsspclty_effstrtdt,
temp_txnmyclsspclty.txnmyclsspclty_effcancldt as txnmyclsspclty_effcancldt,
temp_txnmyclsspclty.txnmyclsspclty_datasrctypcd as txnmyclsspclty_datasrctypcd,
temp_txnmyclsspclty.txnmyclsspclty_pracspclind as txnmyclsspclty_pracspclind,
temp_txnmyclsspclty.txnmyclsspclty_primspclind as txnmyclsspclty_primspclind,
temp_txnmyclsspclty.txnmyclsspclty_srctypecode as txnmyclsspclty_srctypecode
FROM bdapps_ihr_centri.provorgflat as p
LATERAL VIEW explode(p.txnmyclsspclty_info) exploded_view as temp_txnmyclsspclty)K



-- centri_organization_noarrayofstructs

hive> desc centri_organization_noarrayofstructs;
OK
inserttimestamp     	string              	                    
organization_code   	string              	                    
proveff_startdate   	string              	                    
partytype_codetype  	string              	                    
providobj_enterprise_id	string              	                    
organization_id     	string              	                    
source_name         	string              	                    
source_id           	string              	                    
source_effstartdate 	string              	                    
source_effenddate   	string              	                    
tax_id              	string              	                    
tax_code            	string              	                    
tax_effstartdate    	string              	                    
legal_ownername     	string              	                    
legal_ownereffstartdate	string              	                    
legal_ownereffenddate	string              	                    
provider_servicemodeltype_code	string              	                    
provider_servicemodel_effstartdate	string              	                    
provider_servicemodel_effenddate	string              	                    
hcotinowner_enterpriseid	string              	                    
tinowner_effdate_startdt	string              	                    
tinowner_remittance_typecode	string              	                    
tinowner_pymtmthd_typecode	string              	                    
tinowner_elecpymnt_prefind	string              	                    
orgidobj_otherid_name	string              	                    
orgidobj_otherid_value	string              	                    
orgidobj_otherid_effstartdt	string              	                    
healthcaresolopractice_name	string              	                    
healthcaresolopractice_code	string              	                    
servcprov_name      	string              	                    
servcprov_effstrtdt 	string              	                    
servcprov_hosptlind 	string              	                    
servcprov_taxidnbr  	string              	                    
servcprov_typecode  	string              	                    
servcprov_entityidentifier	string              	                    
servcprov_source_name	string              	                    
servcprov_source_value	string              	                    
servcprov_source_effstartdate	string              	                    
servcprov_mdcareid_name	string              	                    
servcprov_mdcareid_value	string              	                    
servcprov_mdcareid_effstartdate	string              	                    
servcprov_mdcareid_statuscd	string              	                    
servcprov_otherid_name	string              	                    
servcprov_otherid_value	string              	                    
servcprov_otherid_effstartdate	string              	                    
servcprov_lic_nbr   	string              	                    
servcprov_lic_add_state	string              	                    
servcprov_lic_add_countrycd	string              	                    
servcprov_lic_effstrtdt	string              	                    
servcprov_lic_typecd	string              	                    
servcprov_lic_statuscd	string              	                    
correpndnce_address_line1	string              	                    
correpndnce_city    	string              	                    
correpndnce_countycode	string              	                    
correpndnce_state   	string              	                    
correpndnce_postalcode_part1	string              	                    
correpndnce_postalcode_part2	string              	                    
correpndnce_type    	string              	                    
correpndnce_latitude	string              	                    
correpndnce_longitude	string              	                    
correpndnce_country 	string              	                    
correpndnce_effstrtdt	string              	                    
correpndnce_telephone_typecode	string              	                    
correpndnce_telephone_countrycode	string              	                    
correpndnce_telephone_areacode	string              	                    
correpndnce_telephone_subscriber	string              	                    
correpndnce_telephone_telephonenbr	string              	                    
correpndnce_telephone_primind	string              	                    
pracloc_survey_code 	string              	                    
pracloc_survey_hndcpaccessind	string              	                    
rltdorgid_taxidnbr  	string              	                    
rltdorgid_taxid_typecode	string              	                    
rltdorgid_taxid_numbreffstrtdt	string              	                    
rltdorgid_taxid_ownername	string              	                    
rltdorgid_tieredproviderservcmodltypcd	string              	                    
rltdorgid_tieredproviderservcmodleffstrtdt	string              	                    
rltdorgid_taxid_enterpriseid	string              	                    
rltdorgid_hcotinowner_enterpriseid	string              	                    
healthcarecorporation_name	string              	                    
healthcarecorporation_code	string              	                    
taxonomy_providertypecode	string              	                    
taxonomy_effstartdate	string              	                    
healthcarefacility_name	string              	                    
healthcarefacility_code	string              	                    
Time taken: 0.329 seconds, Fetched: 84 row(s

Query:
-----
create view bdapps_ihr_centri.centri_organization_noarrayofstructs as select 
inserttimestamp,            	                    
organization_code,              	                    
proveff_startdate,             	                    
partytype_codetype,           	                    
providobj_enterprise_id,            	                    
organization_id,             	                    
source_name,             	                    
source_id,             	                    
source_effstartdate,             	                    
source_effenddate,            	                    
tax_id,           	                    
tax_code,            	                    
tax_effstartdate,             	                    
legal_ownername,             	                    
legal_ownereffstartdate,            	                    
legal_ownereffenddate,            	                    
provider_servicemodeltype_code,           	                    
provider_servicemodel_effstartdate,            	                    
provider_servicemodel_effenddate,              	                    
hcotinowner_enterpriseid,             	                    
tinowner_effdate_startdt,            	                    
tinowner_remittance_typecode,              	                    
tinowner_pymtmthd_typecode,             	                    
tinowner_elecpymnt_prefind,             	                    
orgidobj_otherid_name,             	                    
orgidobj_otherid_value,             	                    
orgidobj_otherid_effstartdt,             	                    
healthcaresolopractice_name,             	                    
healthcaresolopractice_code,              	                    
servcprov_name,             	                    
servcprov_effstrtdt,            	                    
servcprov_hosptlind,             	                    
servcprov_taxidnbr,            	                    
servcprov_typecode,             	                    
servcprov_entityidentifier,             	                    
servcprov_source_name,            	                    
servcprov_source_value,             	                    
servcprov_source_effstartdate,            	                    
servcprov_mdcareid_name,            	                    
servcprov_mdcareid_value,             	                    
servcprov_mdcareid_effstartdate,             	                    
servcprov_mdcareid_statuscd,            	                    
servcprov_otherid_name,             	                    
servcprov_otherid_value,            	                    
servcprov_otherid_effstartdate,             	                    
servcprov_lic_nbr,            	                    
servcprov_lic_add_state,             	                    
servcprov_lic_add_countrycd,             	                    
servcprov_lic_effstrtdt,            	                    
servcprov_lic_typecd,            	                    
servcprov_lic_statuscd,             	                    
correpndnce_address_line1,             	                    
correpndnce_city,             	                    
correpndnce_countycode,             	                    
correpndnce_state,            	                    
correpndnce_postalcode_part1,             	                    
correpndnce_postalcode_part2,            	                    
correpndnce_type,          	                    
correpndnce_latitude,           	                    
correpndnce_longitude,            	                    
correpndnce_country,          	                    
correpndnce_effstrtdt,        	                    
correpndnce_telephone_typecode,           	                    
correpndnce_telephone_countrycode,            	                    
correpndnce_telephone_areacode,           	                    
correpndnce_telephone_subscriber,            	                    
correpndnce_telephone_telephonenbr,            	                    
correpndnce_telephone_primind,             	                    
pracloc_survey_code,           	                    
pracloc_survey_hndcpaccessind,              	                    
rltdorgid_taxidnbr,          	                    
rltdorgid_taxid_typecode,            	                    
rltdorgid_taxid_numbreffstrtdt,             	                    
rltdorgid_taxid_ownername,             	                    
rltdorgid_tieredproviderservcmodltypcd,             	                    
rltdorgid_tieredproviderservcmodleffstrtdt,           	                    
rltdorgid_taxid_enterpriseid,           	                    
rltdorgid_hcotinowner_enterpriseid,            	                    
healthcarecorporation_name,            	                    
healthcarecorporation_code,             	                    
taxonomy_providertypecode,             	                    
taxonomy_effstartdate,             	                    
healthcarefacility_name,             	                    
healthcarefacility_code        
from bdapps_ihr_centri.provorgflat;