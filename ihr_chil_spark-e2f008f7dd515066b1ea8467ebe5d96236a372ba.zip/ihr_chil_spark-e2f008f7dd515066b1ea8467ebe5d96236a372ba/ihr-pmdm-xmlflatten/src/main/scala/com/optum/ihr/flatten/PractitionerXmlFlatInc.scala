package com.optum.ihr.flatten

import java.text.SimpleDateFormat

import com.optum.ihr.common.{Lib, Logger}
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.hadoop.hbase.client.{HTable, Put, Scan}
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter.{BinaryComparator, RowFilter}
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.protobuf.ProtobufUtil
import org.apache.hadoop.hbase.protobuf.generated.ClientProtos
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.hadoop.hbase.util.{Base64, Bytes}
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, lit, row_number}
import org.apache.hadoop.fs._

object PractitionerXmlFlatInc {
  def main(args: Array[String]) {

    //  val sparkConf = new SparkConf().setAppName("CENTRI PROFESSIONAL RECORD PARSER")

    val sc = SparkSession.builder()
      .appName("CENTRI PROFESSIONAL RECORD PARSER")
      .config("hive.metastore.uris", "thrift://dbslp0567.uhc.com:11016")
      .enableHiveSupport()
      .getOrCreate().sparkContext

    //  val sc = new SparkContext(sparkConf)
    val rowKey = args(0)
    if (args.length != 1) {
      println("Please enter RowKey for PMDM Flattening:")
      sc.stop()
    }
    /* val propFilePath = args(0)
     val propFile = sc.textFile(propFilePath)
     properties = propFile.map(x => (x.split("=")(0), x.split("=")(1))).collect().toMap*/
    processPMDMGoldenSnapshot(sc, rowKey)
  }

  case class Othernm(othernm_firstname: String, othernm_middlename: String, othernm_lastname: String, othernm_nametypcd: String, othernm_statuscd: String)

  case class Address(/*hcprole_effsatrtdate: String, tinowner_organization_id : String, spowner_organization_name : String, spowner_organization_nametypcd : String, spowner_organization_effstrtdt : String, spowner_organization_id : String,*/
                     addr_mtch_hcproleid: String, addr_mtch_hcprolename: String, location_name: String, street_name: String, city: String, zip: String, state: String,
                     county: String, country: String, latitude: String, longitude: String,
                     /*tax_type : String, tax_id : String,*/ location_effstartdate: String, location_type: String)

  case class Keychain(hcpidobj_otherid_name: String, hcpidobj_otherid_value: String, hcpidobj_otherid_effstrtdt: String, hcpidobj_otherid_effenddt: String, hcpidobj_mpin_name: String, hcpidobj_mpin_value: String,
                      hcpidobj_mpin_effstrtdt: String, hcpidobj_mpin_effenddt: String)

  case class Medicare(medicare_name: String, medicare_id: String, medicare_effstarttdate: String,
                      medicare_effenddate: String)

  case class Premiumdesignation(premiumdisease_grouptypecode: String, premiumdisease_conditionfocustypecode: String,
                                premium_efficiencytypecode: String, premiumquality_typecode: String,
                                premiumquality_efficiencytypecode: String, premiumdesignation_effstart_date: String,
                                premiumdesignation_effend_date: String, premiumdesignation_prioritynumber: String,
                                premiumdesignation_prioritygroupnumber: String)

  case class Hcpdegree(hcp_degree_code: String, hcp_primaryind: String, hcp_school_name: String,
                       hcp_school_compldt: String, hcp_school_statuscd: String)

  case class Malpracticecarrier(malpracticecarrier_id: String, malpracticecarrier_code: String,
                                malpracticecarrier_name: String, malpracticecarrier_effstrtdt: String,
                                malpracticecarrier_effcncldt: String, malpracticecarrier_totlanulcovamt: String,
                                malpracticecarrier_sngloccurcovamt: String, malpracticecarrier_statuscode: String)

  case class Training(training_typecode: String, training_strtdt: String, training_compdt: String,
                      training_schooltypecode: String, training_edutypecode: String, training_statuscode: String)

  case class Affiliation(affiliation_providerid: String, affiliation_typecode: String,
                         affiliation_strtdt: String, affiliation_stpdt: String, affiliation_admsnprevlgtypecode: String,
                         affiliation_stustypecode: String, affiliation_primhospaffliind: String)

  case class Druglic(druglic_typecode: String, druglic_numberid: String, durglic_geoareaid: String, druglic_effcncldt: String, druglic_statustypcd: String)

  case class Eleccommu(eleccommu_addrtypecode: String, eleccommu_addrtext: String, eleccommu_statscode: String)

  case class Credsts(credsts_statustypecode: String, credsts_crendtltypecode: String, credsts_crendtltypedesc: String, credsts_effstrtdt: String, credsts_effenddt: String, credsts_recrendtldt: String, credsts_credresponcode: String, credsts_corpbusnssegcode: String)

  case class Hcprole(hcprole_id: String, hcprole_name: String, hcprole_effstrtdt: String, hcprole_taxid_name: String, hcprole_taxid_value: String, hcprole_entityid_name: String, hcprole_entityid_value: String, hcprole_taxid_effstrtdt: String, hcprole_taxid_ownername: String, hcprole_taxid_owner_org_id: String, hcprole_tieredproviderservcmodltypcd: String, hcprole_tieredproviderservcmodleffstrtdt: String,
                     hcprole_taxid_number_effstrtdt: String, hcprole_hcotinowner_enterpriseid: String, hcprole_spowner_organization_name: String, hcprole_spowner_organization_nametypcd: String, hcprole_spowner_organization_effstrtdt: String, hcprole_spowner_organization_id: String,
                     hcprole_servcprov_otheridname: String, hcprole_servcprov_otheridvalue: String, hcprole_servcprov_otherideffstrtdt: String)


  case class Taxonomyclass(taxonomy_classicode: String, taxonomy_classieffstrtdt: String, taxonomy_classiprimclassind: String,
                           taxonomy_classisrctype: String, taxonomy_classisrctypecode: String, taxonomy_classipracspclind: String, taxonomy_classispclbrdcertcode: String, taxonomy_classispclbrdcertdate: String,
                           taxonomy_classispclbrdexamdate: String, taxonomy_classispclbrdexpdate: String, taxonomy_classirecerteffdate: String)

  case class Hcpidobjothrid(hcpidobj_otherid_name: String, hcpidobj_otherid_value: String, hcpidobj_otherid_effstrtdt: String, hcpidobj_otherid_effenddt: String)

  case class Hcpidobjmpin(hcpidobj_mpin_name: String, hcpidobj_mpin_value: String, hcpidobj_mpin_effstrtdt: String, hcpidobj_mpin_effenddt: String)

  case class PMdmCol(inserttimestamp: String, entity_id: String, provider_prtytypcd: String, provider_effstrtdt: String, practitioner_effstrtdt: String, first_name: String, middle_name: String, last_name: String, birth_date: String, gender: String,
                     ssn: String, npi_id: String, npi_id_effstrtdt: String, npi_id_effenddt: String, taxonomy_providertypecode: String, taxonomy_effdates: String, othernm_info: List[Othernm],
                     address: List[Address], /*key_chain : List[Keychain],*/ medicare_info: List[Medicare], premium_designation: List[Premiumdesignation],
                     hcpdegree_info: List[Hcpdegree], malpracticecarrier_info: List[Malpracticecarrier], training_info: List[Training], affiliation_info: List[Affiliation],
                     druglic_info: List[Druglic], eleccommu_info: List[Eleccommu], credsts_info: List[Credsts], taxonomyclass_info: List[Taxonomyclass], hcprole_info: List[Hcprole], hcpidobjothrid: List[Hcpidobjothrid], hcpidobjmpin: List[Hcpidobjmpin])

  def processPMDMGoldenSnapshot(sc: SparkContext, rowKey: String) = {

    @transient val hBaseConf: org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
    val hbaseContext = new HBaseContext(sc, hBaseConf)

    Logger.log.info("============> Starting Extract for Professional Flattening <===========")

    val ihrCtlTab = sc.getConf.get("spark.ihrCtlTab")

    Logger.log.info("IHR PMDM Flattening Configuration Table: " + ihrCtlTab)

    def getEntityInfo(rowKey: String): String = {
      try {
        println(s"ihrCtlTab ihr_ent_cfg for PMDM Flattening: $ihrCtlTab")
        val scanner = new Scan()
        scanner.setCaching(1000)
        scanner.setCacheBlocks(false)
        val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKey")))
        scanner.setFilter(filter1)
        val ihrInfo = hbaseContext.hbaseRDD(TableName.valueOf(ihrCtlTab), scanner).cache()
        val ihrEntRDD = ihrInfo.map(tuple => {
          val result = tuple._2
          (Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("srcCd"))),
            Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("prtnrCd"))),
            Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("outFileNm"))),
            Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("lastRnLdTs")))
          )
        })
        if (ihrEntRDD.isEmpty()) {
          println(s"Please Provide Appropriate RowKey / Check ihr_ent_cfg table Properties for $rowKey properly")
          ihrEntRDD.collect().map(x => x.productIterator.mkString("|")).mkString
        }
        else {
          ihrEntRDD.collect().map(x => x.productIterator.mkString("|")).mkString
        }
      } catch {
        case e: Exception => println(s"Exception while getting Configuration from ihr_entity_info Tab" :+ e.getMessage)
          throw e
      }
    }


    val configInfo = getEntityInfo(rowKey)
    Logger.log.info("Configurations for Professional extract: " + configInfo)

    val fs: FileSystem = FileSystem.get(sc.hadoopConfiguration)

    def rmDirIfExist(dir: String): Unit = {
      try {
        if (fs.exists(new Path(s"$dir"))) {
          fs.delete(new Path(dir), true)
        }
        else {
          Logger.log.info(s"Working Dir: $dir doesn't exist, Please check for Errors.")
        }
      } catch {
        case e: Exception => Logger.log.error("Exception at HBase Put Commands at IHR_enttiy_info" :+ e.getStackTrace.toString)
          throw e
      }
    }

    val ihrEitTab: HTable = new HTable(hBaseConf, sc.getConf.get("spark.ihrEitTab"))

    def hbaseEitPut(eitRowKey: String, colFm: String, colNm: String, value: String): Unit = {
      try {
        val p = new Put(s"$eitRowKey".getBytes())
        p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
        ihrEitTab.put(p)
      } catch {
        case e: Exception => Logger.log.error("Exception at HBase EIT Put Commands at IHR_enttiy_info IHR_ADT_DTL" :+ e.getMessage)
          throw e
      }
    }

    val Array(srcCd, prtnrCd, outFileNm, lastRnLdTs) = configInfo.split("\\|")
    val endTs = Lib.getMilliSecCurrentTimeFormat
    val currDt = Lib.getCurrentDate
    Logger.log.info("Current Date: " + currDt)
    val prevDt = Lib.dateAddDay(s"$currDt", -1, "yyyyMMdd", "yyyyMMdd")
    Logger.log.info("Previous Run Date: " + prevDt)
    val bkpDelDt = Lib.dateAddDay(s"$currDt", -2, "yyyyMMdd", "yyyyMMdd")
    Logger.log.info("1 Day Before Run Date: " + bkpDelDt)

    def getTimestamp(DateFormat: String): Long = {
      val timestampformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
      timestampformat.parse(DateFormat).getTime()
    }

    val eitRowKey = s"${rowKey.toUpperCase()}-${java.util.UUID.randomUUID()}"
    Logger.log.info("HBase EIT Row Key for Professional Flattening: " + eitRowKey)
    hbaseEitPut(eitRowKey, "pi", "prtnrCd", s"$prtnrCd")
    hbaseEitPut(eitRowKey, "pi", "srcCd", srcCd)
    hbaseEitPut(eitRowKey, "pi", "prcNm", outFileNm)
    hbaseEitPut(eitRowKey, "pi", "prcDt", currDt)

    @transient val conf: org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
    @transient val scan = new Scan()

    val dLProfTab = sc.getConf.get("spark.dlProfTab")

    Logger.log.info("Datalake Professional Table Path: " + dLProfTab)

    conf.set(TableInputFormat.INPUT_TABLE, dLProfTab)

    scan.setCaching(10000)
    scan.setCacheBlocks(false)
    scan.setTimeRange(getTimestamp(s"$lastRnLdTs"), getTimestamp(s"$endTs"))

    def convertScanToString(scan: Scan): String = {
      val proto: ClientProtos.Scan = ProtobufUtil.toScan(scan)
      return Base64.encodeBytes(proto.toByteArray)
    }

    conf.set(TableInputFormat.SCAN, convertScanToString(scan))

    val hbaseRDD = sc.newAPIHadoopRDD(conf, classOf[TableInputFormat],
      classOf[org.apache.hadoop.hbase.io.ImmutableBytesWritable],
      classOf[org.apache.hadoop.hbase.client.Result])


    val keyValueRDD: RDD[(String)] = hbaseRDD.map(tuple => {
      val result = tuple._2
      (Bytes.toString(result.getValue(Bytes.toBytes("ri"), Bytes.toBytes("rawMsg"))))
    })

    val keyCntRDD: RDD[(String)] = hbaseRDD.map(tuple => {
      val result = tuple._2
      (Bytes.toString(result.getRow()))
    })

    Logger.log.info(s"Extracting Professional Records from $lastRnLdTs to $endTs=====>")
    val extractCnt = keyCntRDD.count()
    Logger.log.info(s"Total Professional records from $lastRnLdTs to $endTs: " + extractCnt)

    try {
      val flattenedMDMRecords = keyValueRDD.map(mdmRec => parsePMDMGoldenXml(mdmRec.toString))
      val sqlContext = new org.apache.spark.sql.SQLContext(sc)
      import sqlContext.implicits._
      val parsedDF = flattenedMDMRecords.toDF.repartition(2000)
      val userWindow = Window.partitionBy("entity_id").orderBy(col("inserttimestamp").desc)
      val profOutFilePth = sc.getConf.get("spark.profOutPath")

      val dedupParseDF = parsedDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
      dedupParseDF.printSchema()
      val resPath = s"$profOutFilePth/professional/$currDt"

      Logger.log.info("Saving Extract to the professional OutPath Loc =>: " + profOutFilePth)
      dedupParseDF.write.save(s"$resPath")

      val dedupCnt = dedupParseDF.select("entity_id").count()

      Logger.log.info("Deduped Messages from Professional from Datalake: " + dedupCnt)

      val prevResPath = s"$profOutFilePth/professional/${prevDt}"

      Logger.log.info(s"Previous Day Location: $prevResPath")

      if (fs.exists(new Path(s"$resPath")) && fs.exists(new Path(s"$prevResPath"))) {
        Logger.log.info("Previous Day location and current Day locations exists, saving result to temp for Dedup")
        val mergeDf = sqlContext.read.parquet(s"$resPath", s"$prevResPath")
        //Save Data to the Temp Location:
        val tempLoc = s"$profOutFilePth/professional/${outFileNm}_temp"
        mergeDf.write.mode(SaveMode.Overwrite).save(s"$tempLoc")
        val combineDF = sqlContext.read.parquet(s"$tempLoc")
        val combineDFCnt = combineDF.select("entity_id").count()
        Logger.log.info(s"$currDt and ${prevDt} Combined Count: " + combineDFCnt)
        val dedupMergeDF = combineDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
        val dedupMergeDFCnt = dedupMergeDF.select("entity_id").count()
        Logger.log.info(s"$currDt and ${prevDt} Combined Dedup Count: " + dedupMergeDFCnt)

        //Drop Table Before saving to Actual location:

        Logger.log.info(s"Droping Table bdapps_ihr_centri.$outFileNm before refreshing Data")

        sqlContext.sql(s"drop table bdapps_ihr_centri.$outFileNm")

        dedupMergeDF.write.mode(SaveMode.Overwrite).option("path", s"$resPath").saveAsTable(s"bdapps_ihr_centri.$outFileNm")

        Logger.log.info(s"Refresh Done, Hence Updating ${endTs} TS to IHR Configuration table")

        Logger.log.info(s"Deleting 1 day before backup Data with $bkpDelDt date")

        val bkpDir = s"$profOutFilePth/professional/$bkpDelDt"

        Logger.log.info(s"Backup Directory Path: $bkpDir")

        rmDirIfExist(s"$bkpDir")

        Logger.log.info(s"Deletion Done for the day before Day with Date: $bkpDelDt")

        Logger.log.info("====>Hence Updating Audit Tracking table with Entries<=====")

        hbaseEitPut(eitRowKey, "pi", "RecCnt", s"$extractCnt")
        hbaseEitPut(eitRowKey, "pi", "dedupRecCnt", s"$dedupCnt")
        hbaseEitPut(eitRowKey, "pi", "prcSts", s"Success")


        @transient val hBaseCtlConf: org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
        hBaseCtlConf.set(TableInputFormat.INPUT_TABLE, ihrCtlTab)
        val ihrCtlTabPut: HTable = new HTable(hBaseCtlConf, ihrCtlTab)
        val p = new Put(s"$rowKey".getBytes())
        p.addColumn(s"ei".getBytes(), "lastRnLdTs".getBytes(), s"$endTs".getBytes())
        ihrCtlTabPut.put(p)
        Logger.log.info("==================> Job Completed Successfully <==================")
      } else {
        Logger.log.info(s"Folder Paths Does not exists Please check Once $prevResPath & $resPath")
        hbaseEitPut(eitRowKey, "eri", "errCd", "Exception folder does not exist, please check the Directory Path")
        hbaseEitPut(eitRowKey, "eri", "errDesc", s"Please check the prevDt and Currect Date Direcory Path")
        hbaseEitPut(eitRowKey, "pi", "prcSts", s"Failure")
      }
    } catch {
      case e: Exception =>
        hbaseEitPut(eitRowKey, "eri", "errCd", "Exception at Provider Organization, Please check")
        hbaseEitPut(eitRowKey, "eri", "errDesc", s"${e.getMessage}")
        hbaseEitPut(eitRowKey, "pi", "prcSts", s"Failure")
    }
  }

  def parsePMDMGoldenXml(in: String): PMdmCol = {
    var record_gen_dt = ""
    var record_gen_ts = ""
    var entity_id = "NA"
    var first_name = ""
    var middle_name = ""
    var last_name = ""
    var birth_date = ""
    var gender = ""
    var ssn = ""
    var othernm_firstname = ""
    var othernm_middlename = ""
    var othernm_lastname = ""
    var othernm_nametypcd = ""
    var othernm_statuscd = ""
    var addr_mtch_hcproleid = ""
    var addr_mtch_hcprolename = ""
    var location_name = ""
    var street_name = ""
    var address_line_2 = ""
    var city = ""
    var zip = ""
    var state = ""
    var county = ""
    var country = ""
    var latitude = ""
    var longitude = ""
    var key_chain_temp = ""
    var postalcode_part1 = ""
    var postalcode_part2 = ""
    var hcpidobj_otherid_name = ""
    var hcpidobj_otherid_value = ""
    var hcpidobj_otherid_effstrtdt = ""
    var hcpidobj_otherid_effenddt = ""
    var hcpidobj_mpin_name = ""
    var hcpidobj_mpin_value = ""
    var hcpidobj_mpin_effstrtdt = ""
    var hcpidobj_mpin_effenddt = ""
    var MPINsourcecode = ""
    var MPINeffdate = ""
    var PULSEsourcecode = ""
    var PULSEeffdate = ""
    var spowner_organization_name = ""
    var tinowner_organization_id = ""
    var spowner_organization_id = ""
    var spowner_organization_nametypcd = ""
    var spowner_organization_effstrtdt = ""
    var npi_id = ""
    var tax_id = ""
    var tax_type = ""
    var key_chain = ""
    var npi_id_effstrtdt = ""
    var npi_id_effenddt = ""
    var hcprole_effsatrtdate = ""
    var medicare_name = ""
    var medicare_id = ""
    var medicare_effstarttdate = ""
    var medicare_effenddate = ""
    var location_effstartdate = ""
    var location_type = ""
    var premiumdisease_grouptypecode = ""
    var premiumdisease_conditionfocustypecode = ""
    var premium_efficiencytypecode = ""
    var premiumquality_typecode = ""
    var premiumquality_efficiencytypecode = ""
    var premiumdesignation_effstart_date = ""
    var premiumdesignation_prioritynumber = ""
    var premiumdesignation_prioritygroupnumber = ""
    var premiumdesignation_effend_date = ""
    var hcp_degree_code = ""
    var hcp_primaryind = ""
    var hcp_school_name = ""
    var hcp_school_compldt = ""
    var hcp_school_statuscd = ""
    var malpracticecarrier_id = ""
    var malpracticecarrier_code = ""
    var malpracticecarrier_name = ""
    var malpracticecarrier_effstrtdt = ""
    var malpracticecarrier_effcncldt = ""
    var malpracticecarrier_totlanulcovamt = ""
    var malpracticecarrier_sngloccurcovamt = ""
    var malpracticecarrier_statuscode = ""
    var training_typecode = ""
    var training_strtdt = ""
    var training_compdt = ""
    var training_schooltypecode = ""
    var training_edutypecode = ""
    var training_statuscode = ""
    var credsts_statustypecode = ""
    var credsts_crendtltypecode = ""
    var credsts_crendtltypedesc = ""
    var credsts_effstrtdt = ""
    var credsts_effenddt = ""
    var credsts_recrendtldt = ""
    var credsts_credresponcode = ""
    var credsts_corpbusnssegcode = ""
    var eleccommu_addrtypecode = ""
    var eleccommu_addrtext = ""
    var eleccommu_statscode = ""
    var affiliation_providerid = ""
    var affiliation_typecode = ""
    var affiliation_strtdt = ""
    var affiliation_stpdt = ""
    var affiliation_admsnprevlgtypecode = ""
    var affiliation_stustypecode = ""
    var affiliation_primhospaffliind = ""
    var druglic_typecode = ""
    var druglic_numberid = ""
    var durglic_geoareaid = ""
    var druglic_effcncldt = ""
    var druglic_statustypcd = ""
    var taxonomy_providertypecode = ""
    var taxonomy_effdates = ""
    var taxonomy_classicode = ""
    var taxonomy_classieffstrtdt = ""
    var taxonomy_classiprimclassind = ""
    var taxonomy_classisrctype = ""
    var taxonomy_classisrctypecode = ""
    var taxonomy_classipracspclind = ""
    var taxonomy_classispclbrdcertcode = ""
    var taxonomy_classispclbrdcertdate = ""
    var taxonomy_classispclbrdexamdate = ""
    var taxonomy_classispclbrdexpdate = ""
    var taxonomy_classirecerteffdate = ""
    var hcprole_id = ""
    var hcprole_name = ""
    var hcprole_effstrtdt = ""
    var hcprole_taxid_name = ""
    var hcprole_taxid_value = ""
    var hcprole_entityid_name = ""
    var hcprole_entityid_value = ""
    var hcprole_taxid_effstrtdt = ""
    var hcprole_taxid_ownername = ""
    var hcprole_taxid_owner_org_id = ""
    var hcprole_tieredproviderservcmodltypcd = ""
    var hcprole_tieredproviderservcmodleffstrtdt = ""
    var hcprole_servcprov_otheridname = ""
    var hcprole_servcprov_otheridvalue = ""
    var hcprole_servcprov_otherideffstrtdt = ""
    var hcprole_taxid_number_effstrtdt = ""
    var hcprole_hcotinowner_enterpriseid = ""
    var hcprole_spowner_organization_name = ""
    var hcprole_spowner_organization_nametypcd = ""
    var hcprole_spowner_organization_effstrtdt = ""
    var hcprole_spowner_organization_id = ""
    var provider_effstrtdt = ""
    var provider_prtytypcd = ""
    var practitioner_effstrtdt = ""
    var effstrtdt1 = ""


    val xml = scala.xml.XML.loadString(in)

    val timestamp = xml \\ "ProvMasterMsg" \\ "headerObj" \\ "timeStamp"

    val oprovider_prtytypcd = xml \\ "ProvMasterMsg" \\ "body" \\ "provider" \\ "partyTypeCodeType" \\ "code"
    if (oprovider_prtytypcd != null && oprovider_prtytypcd.length > 0) {
      provider_prtytypcd = oprovider_prtytypcd(0).text
    }

    val oprovider_effstrtdt = xml \\ "ProvMasterMsg" \\ "body" \\ "provider" \\ "provEffDate" \\ "effStartDate"
    if (oprovider_effstrtdt != null && oprovider_effstrtdt.length > 0) {
      provider_effstrtdt = oprovider_effstrtdt(0).text
    }

    val professionalxml = xml \\ "ProvMasterMsg" \\ "body" \\ "provider" \\ "professional"

    val orecord_gen_ts = xml \\ "ProvMasterMsg" \\ "headerObj" \\ "timeStamp"
    if (orecord_gen_ts != null && orecord_gen_ts.length > 0) {
      record_gen_ts = orecord_gen_ts(0).text
      record_gen_dt = record_gen_ts.split("T").array(0)
    }

    val opractitioner_effstrtdt = xml \\ "ProvMasterMsg" \\ "body" \\ "provider" \\ "professional" \\ "effectiveDateRange" \\ "startDate"
    if (opractitioner_effstrtdt != null && opractitioner_effstrtdt.length > 0) {
      practitioner_effstrtdt = opractitioner_effstrtdt(0).text
    }

    //populate enterprise ID
    val oEntity = xml \\ "ProvMasterMsg" \\ "body" \\ "provider" \\ "providerIDObj" \\ "enterpriseID" \\ "value"
    if (oEntity != null && oEntity.length > 0) {
      println("1.......")
      entity_id = oEntity(0).text
    }

    //populate first name
    val oFirstName = professionalxml \\ "name" \\ "firstName"
    if (oFirstName != null && oFirstName.length > 0) {
      println("2.......")
      first_name = oFirstName(0).text
    }

    //populate middle name
    val oMiddleName = professionalxml \\ "name" \\ "middleName"
    if (oMiddleName != null && oMiddleName.length > 0) {
      println("3.......")
      middle_name = oMiddleName(0).text
    }

    //populate last name
    val oLastName = professionalxml \\ "name" \\ "lastName"
    if (oLastName != null && oLastName.length > 0) {
      println("4.......")
      last_name = oLastName(0).text
    }

    //populate birth date
    val oBirthDate = professionalxml \\ "dateOfBirth"
    if (oBirthDate != null && oBirthDate.length > 0) {
      println("5.......")
      birth_date = oBirthDate(0).text
    }
    //populate gender
    val oGender = professionalxml \\ "gender"
    if (oGender != null && oGender.length > 0) {
      println("5.......")
      gender = oGender(0).text
    }


    //populate ssnr
    val oSSN = professionalxml \\ "hCPIDObj" \\ "ssn" \\ "value"
    if (oSSN != null && oSSN.length > 0) {

      ssn = oSSN(0).text
    }

    val oNPIN = professionalxml \\ "hCPIDObj" \\ "nonValidatedNPI" \\ "value"
    if (oNPIN != null && oNPIN.length > 0) {

      npi_id = oNPIN(0).text
    }

    val oNPINEffStrtDate = professionalxml \\ "hCPIDObj" \\ "nonValidatedNPI" \\ "effectiveDates" \\ "effStartDate"
    if (oNPINEffStrtDate != null && oNPINEffStrtDate.length > 0) {

      npi_id_effstrtdt = oNPINEffStrtDate(0).text
    }

    val oNPINEffEndDate = professionalxml \\ "hCPIDObj" \\ "nonValidatedNPI" \\ "effectiveDates" \\ "effEndDate"
    if (oNPINEffEndDate != null && oNPINEffEndDate.length > 0) {

      npi_id_effenddt = oNPINEffEndDate(0).text
    }


    val otaxonomy_providertypecode = professionalxml \\ "hcpTaxonomy" \\ "providerType" \\ "code"
    if (otaxonomy_providertypecode != null && otaxonomy_providertypecode.length > 0) {
      taxonomy_providertypecode = otaxonomy_providertypecode(0).text
    }

    val otaxonomy_effdates = professionalxml \\ "hcpTaxonomy" \\ "taxonomyEffDates" \\ "effStartDate"
    if (otaxonomy_effdates != null && otaxonomy_effdates.length > 0) {
      taxonomy_effdates = otaxonomy_effdates(0).text
    }


    /*
     for (name0 <- (professionalxml \\ "name" )){
       for(name1 <- name0.child){
         var fname = ""
         var mname = ""
         var newstartdate = ""
         if(name1.label == "firstName"){
           fname = name1.text
           println(fname)
         }
          if(name1.label == "middleName"){
           mname = name1.text
           println(mname)
       }
           if(name1.label == "effectiveDateRange"){
             for (name2 <- name1.child){
               if( name2.label == "startDate"){
             newstartdate = name2.text
               }
             }
           }
           if(name1.label == "effectiveDateRange"){
             if ( effstrtdt1 == "" || newstartdate > effstrtdt1){
               effstrtdt1 = newstartdate
               first_name = fname
               middle_name = mname

             }
           }
         }
     }
     */
    /*var keyList:List[Keychain] = List()
    for ( keyc0 <- (professionalxml\\"hCPRole")){
      val keyc1 = keyc0.child
      for ( curAdr <- keyc1) {
      if(curAdr.label == "hCPRoleIDObj")
       {
        val othroles = curAdr.child
        for(othrole <- othroles){
             if(othrole.label=="OtherID"){
               var newcode = ""
               var neweffdate = ""
               for(othchild <- othrole.child){
                 if(othchild.label == "name" ){
                 sourcename = othchild.child.text
                 }
                   if(othchild.label == "value" ){
                     newcode = othchild.child.text
                     }
                     if(othchild.label == "EffDate" ){
                       for(effdates <- othchild.child){
                         if(effdates.label=="effStartDate"){
                           neweffdate=effdates.child.text
                           }
                          }
                         }
                     if(othchild.label == "EffDate" ){
                       if(sourcename=="MPIN") {
                         if (MPINeffdate == "" || neweffdate > MPINeffdate) {
                           MPINsourcecode = newcode
                           MPINeffdate = neweffdate
                           }
                           }else if (sourcename=="PULSE PROV CODE"){
                           if (PULSEeffdate == "" || neweffdate > PULSEeffdate) {
                             PULSEsourcecode = newcode
                             PULSEeffdate = neweffdate
                   }
                 }
               }
             }
           }
         }
        }
       }
    }*/


    var othernmList: List[Othernm] = List()

    for (other0 <- (professionalxml \\ "otherNames")) {
      othernm_firstname = ""
      othernm_middlename = ""
      othernm_lastname = ""
      othernm_nametypcd = ""
      othernm_statuscd = ""
      for (other1 <- other0.child) {
        if (other1.label == "Name") {
          for (other2 <- other1.child) {
            if (other2.label == "firstName") {
              othernm_firstname = other2.text
            }
            if (other2.label == "middleName") {
              othernm_middlename = other2.text
            }
            if (other2.label == "lastName") {
              othernm_lastname = other2.text
            }
          }
        }
        if (other1.label == "NameTypeCode") {
          for (other2 <- other1.child) {
            if (other2.label == "code") {
              othernm_nametypcd = other2.text
            }
          }
        }
        if (other1.label == "statusCode") {
          for (other2 <- other1.child) {
            if (other2.label == "code") {
              othernm_statuscd = other2.text
            }
          }
        }
      }
      val othernm = Othernm(othernm_firstname, othernm_middlename, othernm_lastname, othernm_nametypcd, othernm_statuscd)
      othernmList = othernm :: othernmList
    }


    var addrList: List[Address] = List()

    for (addr0 <- (professionalxml \\ "hCPRole")) {
      addr_mtch_hcproleid = ""
      addr_mtch_hcprolename = ""
      for (curAdr <- addr0.child) {
        if (curAdr.label == "id" || curAdr.label == "name") {
          if (curAdr.label == "name") {
            addr_mtch_hcprolename = curAdr.text
          } else {
            addr_mtch_hcproleid = curAdr.text
          }
        }
      }

      for (curAdr1 <- addr0 \\ "serviceProviderPracticeLocation") {

        location_effstartdate = ""
        location_type = ""
        location_name = ""
        street_name = ""
        city = ""
        state = ""
        country = ""
        county = ""
        postalcode_part1 = ""
        postalcode_part2 = ""
        zip = ""
        latitude = ""
        longitude = ""
        if (curAdr1.label == "serviceProviderPracticeLocation") {
          for (c <- curAdr1.child) {
            c.label match {
              case "locationName" => location_name = c.text
              case "city" => city = c.text
              case "state" => state = c.text
              case "countyCode" => county = c.text
              case "type" => location_type = c.text
              case _ =>
            }
            for (b <- c) {
              if (b.label == "postalCode") {
                for (a <- b.child)
                  a.label match {
                    case "part1" => postalcode_part1 = a.text
                    case "part2" => postalcode_part2 = a.text
                    case _ =>
                  }
                zip = postalcode_part1 + '-' + postalcode_part2
              }
              if (b.label == "streetName") {
                street_name = b.text
              }
              if (b.label == "latLong") {
                for (a <- b.child)
                  a.label match {
                    case "lat" => latitude = a.text
                    case "long" => longitude = a.text
                    case _ =>
                  }
              }
              if (b.label == "country") {
                for (a <- b.child)
                  a.label match {
                    case "code" => country = a.text
                    case _ =>
                  }
              }
              if (b.label == "locationEffDate") {
                for (a <- b.child) {
                  if (a.label == "effStartDate") {
                    location_effstartdate = a.text
                  }
                }
              }
            }
          }


          val addr = Address(/*hcprole_effsatrtdate, tinowner_organization_id, spowner_organization_name, spowner_organization_nametypcd, spowner_organization_effstrtdt, spowner_organization_id, */ addr_mtch_hcproleid, addr_mtch_hcprolename, location_name, street_name, city, zip, state, county, country, latitude, longitude, /*tax_type, tax_id,*/ location_effstartdate, location_type)
          addrList = addr :: addrList
        }
      }
    }

    /*var serprovpraclocList:List[Serprovpracloc] = List()

   for (serprovpracloc0 <- (organizationxml \\ "serviceProvider"\\ "practiceLocations")){
         pracloc_address_line1 = ""
         pracloc_city = ""
         pracloc_countycode = ""
         pracloc_state = ""
         pracloc_postalcode_part1 = ""
         pracloc_postalcode_part2 = ""
         pracloc_type = ""
         pracloc_primaryind =""
         pracloc_latitude = ""
         pracloc_longitude = ""
         pracloc_country = ""
         pracloc_location_effstrtdt = ""
         pracloc_locationname = ""
    if(serprovpracloc0.label == "practiceLocations"){
             for (curLoc4 <- serprovpracloc0.child){
               if(curLoc4.label == "line1"){
               pracloc_address_line1 = curLoc4.text
               }
               if(curLoc4.label == "city"){
                 pracloc_city = curLoc4.text
               }
               if(curLoc4.label == "countyCode"){
                 pracloc_countycode = curLoc4.text
               }
               if(curLoc4.label == "state"){
                 pracloc_state = curLoc4.text
               }
               if (curLoc4.label == "postalCode"){
                  for(curLoc5 <- curLoc4.child){
                     if ( curLoc5.label == "part1"){
                        pracloc_postalcode_part1 = curLoc5.text
                         }
                       if ( curLoc5.label == "part2"){
                      pracloc_postalcode_part2 = curLoc5.text
                    }
                  }
                }
               if (curLoc4.label == "type"){
                 pracloc_type = curLoc4.text
               }
               if (curLoc4.label == "primaryInd"){
                 pracloc_primaryind = curLoc4.text
               }
               if (curLoc4.label == "latLong"){
                   for(curLoc5 <- curLoc4.child){
                      if ( curLoc5.label == "lat"){
                      pracloc_latitude = curLoc5.text
                       }
                     if ( curLoc5.label == "long"){
                     pracloc_longitude = curLoc5.text
                   }
                 }
                }
                if (curLoc4.label == "country"){
                  for(curLoc5 <- curLoc4.child){
                    if(curLoc5.label == "code"){
                      pracloc_country = curLoc5.text
                    }
                  }
                }
                if (curLoc4.label == "locationEffDate"){
                  for(curLoc5 <- curLoc4.child){
                    if(curLoc5.label == "effStartDate"){
                      pracloc_location_effstrtdt = curLoc5.text
                    }
                  }
                }
                if (curLoc4.label == "locationName"){
                  pracloc_locationname = curLoc4.text
                }
             }
           }
   val serprovpracloc = Serprovpracloc(pracloc_address_line1,pracloc_city,pracloc_countycode,pracloc_state, pracloc_postalcode_part1, pracloc_postalcode_part2,
       pracloc_type, pracloc_primaryind, pracloc_latitude, pracloc_longitude, pracloc_country, pracloc_location_effstrtdt, pracloc_locationname)
   serprovpraclocList = serprovpracloc :: serprovpraclocList
 }
    */

    /*var keyList:List[Keychain] = List()


    for(keyc <-(professionalxml\\"hCPIDObj")){
      hcpidobj_otherid_name =""
    hcpidobj_otherid_value = ""
    hcpidobj_otherid_effstrtdt = ""
    hcpidobj_otherid_effenddt = ""
    hcpidobj_mpin_name = ""
    hcpidobj_mpin_value = ""
    hcpidobj_mpin_effstrtdt = ""
    hcpidobj_mpin_effenddt = ""
    for ( keyc0 <- keyc.child){
      if(keyc0.label == "mpin"){
       for ( curAdr <- keyc0.child ){
       if (curAdr.label == "name"){
         hcpidobj_mpin_name = curAdr.text
       }
       if (curAdr.label == "value"){
         hcpidobj_mpin_value = curAdr.text
       }
       if (curAdr.label == "effDateRange"){
         for (curAdr1 <- curAdr.child){
           if ( curAdr1.label == "startDate"){
         hcpidobj_mpin_effstrtdt = curAdr1.text
           }
           if ( curAdr1.label == "endDate"){
         hcpidobj_mpin_effenddt = curAdr1.text
           }
         }
       }
      }
     }
      if(keyc0.label == "otherID"){
      for ( curAdr <- keyc0.child ){
       if (curAdr.label == "name"){
         hcpidobj_otherid_name = curAdr.child.text
         }
      if(curAdr.label == "value" ){
         hcpidobj_otherid_value = curAdr.child.text
        }
      if(curAdr.label == "EffDate" ){
        for(effdates <- curAdr.child){
          if(effdates.label=="effStartDate"){
             hcpidobj_otherid_effstrtdt=effdates.child.text
              }
           if(effdates.label == "effCancelDate"){
              hcpidobj_otherid_effenddt=effdates.child.text
              }
           }
       }
      }
    }
   }
      val key_chain = Keychain(hcpidobj_otherid_name, hcpidobj_otherid_value, hcpidobj_otherid_effstrtdt, hcpidobj_otherid_effenddt, hcpidobj_mpin_name, hcpidobj_mpin_value,
     hcpidobj_mpin_effstrtdt, hcpidobj_mpin_effenddt)
       keyList = key_chain :: keyList
    }
    */

    var hcpidobjothridList: List[Hcpidobjothrid] = List()
    for (hcpidobjothrid0 <- professionalxml \\ "hCPIDObj" \\ "otherID") {
      hcpidobj_otherid_name = ""
      hcpidobj_otherid_value = ""
      hcpidobj_otherid_effstrtdt = ""
      hcpidobj_otherid_effenddt = ""

      for (hcpidobjothrid1 <- hcpidobjothrid0.child) {
        if (hcpidobjothrid1.label == "name") {
          hcpidobj_otherid_name = hcpidobjothrid1.child.text
        }
        if (hcpidobjothrid1.label == "value") {
          hcpidobj_otherid_value = hcpidobjothrid1.child.text
        }
        if (hcpidobjothrid1.label == "EffDate") {
          for (hcpidobjothrid2 <- hcpidobjothrid1.child) {
            if (hcpidobjothrid2.label == "effStartDate") {
              hcpidobj_otherid_effstrtdt = hcpidobjothrid2.child.text
            }
            if (hcpidobjothrid2.label == "effCancelDate") {
              hcpidobj_otherid_effenddt = hcpidobjothrid2.child.text
            }
          }
        }
      }
      val hcpidobjothrid = Hcpidobjothrid(hcpidobj_otherid_name, hcpidobj_otherid_value, hcpidobj_otherid_effstrtdt, hcpidobj_otherid_effenddt)
      hcpidobjothridList = hcpidobjothrid :: hcpidobjothridList
    }

    var hcpidobjmpinList: List[Hcpidobjmpin] = List()
    for (hcpidobjmpin0 <- professionalxml \\ "hCPIDObj" \\ "mpin") {
      hcpidobj_mpin_name = ""
      hcpidobj_mpin_value = ""
      hcpidobj_mpin_effstrtdt = ""
      hcpidobj_mpin_effenddt = ""
      if (hcpidobjmpin0.label == "mpin") {
        for (hcpidobjmpin1 <- hcpidobjmpin0.child) {
          if (hcpidobjmpin1.label == "name") {
            hcpidobj_mpin_name = hcpidobjmpin1.text
          }
          if (hcpidobjmpin1.label == "value") {
            hcpidobj_mpin_value = hcpidobjmpin1.text
          }
          if (hcpidobjmpin1.label == "effDateRange") {
            for (hcpidobjmpin2 <- hcpidobjmpin1.child) {
              if (hcpidobjmpin2.label == "startDate") {
                hcpidobj_mpin_effstrtdt = hcpidobjmpin2.text
              }
              if (hcpidobjmpin2.label == "endDate") {
                hcpidobj_mpin_effenddt = hcpidobjmpin2.text
              }
            }
          }
        }


        val hcpidobjmpin = Hcpidobjmpin(hcpidobj_mpin_name, hcpidobj_mpin_value, hcpidobj_mpin_effstrtdt, hcpidobj_mpin_effenddt)
        hcpidobjmpinList = hcpidobjmpin :: hcpidobjmpinList
      }
    }

    var medicareList: List[Medicare] = List()

    for (keyc0 <- (professionalxml \\ "hCPIDObj" \\ "medicareID")) {
      medicare_name = ""
      medicare_id = ""
      medicare_effstarttdate = ""
      medicare_effenddate = ""
      for (curAdr <- keyc0.child) {
        if (curAdr.label == "name") {
          medicare_name = curAdr.child.text
        }
        if (curAdr.label == "value") {
          medicare_id = curAdr.child.text
        }
        if (curAdr.label == "effDate") {
          for (effdates <- curAdr.child) {
            if (effdates.label == "effStartDate") {
              medicare_effstarttdate = effdates.child.text
            }
            if (effdates.label == "effEndDate") {
              medicare_effenddate = effdates.child.text
            }
          }
        }
      }
      val medicare_info = Medicare(medicare_name, medicare_id, medicare_effstarttdate, medicare_effenddate)
      medicareList = medicare_info :: medicareList
    }


    var premiumdesignationList: List[Premiumdesignation] = List()

    for (keyc0 <- xml \\ "ProvMasterMsg" \\ "body" \\ "provider" \\ "professional") {
      premiumdisease_grouptypecode = ""
      premiumdisease_conditionfocustypecode = ""
      premium_efficiencytypecode = ""
      premiumquality_typecode = ""
      premiumquality_efficiencytypecode = ""
      premiumdesignation_effstart_date = ""
      premiumdesignation_effend_date = ""
      premiumdesignation_prioritynumber = ""
      premiumdesignation_prioritygroupnumber = ""
      for (keyc1 <- keyc0.child) {
        if (keyc1.label == "premiumDesignation") {
          for (curAdr <- keyc1.child) {
            if (curAdr.label == "premiumDiseaseGroupTypeCode") {
              for (curAdr1 <- curAdr.child) {
                if (curAdr1.label == "code") {
                  premiumdisease_grouptypecode = curAdr1.text
                }
              }
            }
            if (curAdr.label == "premiumDiseaseConditionFocusTypeCode") {
              for (curAdr1 <- curAdr.child) {
                if (curAdr1.label == "code") {
                  premiumdisease_conditionfocustypecode = curAdr1.text
                }
              }
            }
            if (curAdr.label == "premiumEfficiencyTypeCode") {
              for (curAdr1 <- curAdr.child) {
                if (curAdr1.label == "code") {
                  premium_efficiencytypecode = curAdr1.text
                }
              }
            }
            if (curAdr.label == "premiumQualityTypeCode") {
              for (curAdr1 <- curAdr.child) {
                if (curAdr1.label == "code") {
                  premiumquality_typecode = curAdr1.text
                }
              }
            }
            if (curAdr.label == "premiumQualityEfficiencyTypeCode") {
              for (curAdr1 <- curAdr.child) {
                if (curAdr1.label == "code") {
                  premiumquality_efficiencytypecode = curAdr1.text
                }
              }
            }
            if (curAdr.label == "effDateRange") {
              for (curAdr1 <- curAdr.child) {
                if (curAdr1.label == "effStartDate") {
                  premiumdesignation_effstart_date = curAdr1.text
                }
              }
            }
            if (curAdr.label == "effDateRange") {
              for (curAdr1 <- curAdr.child) {
                if (curAdr1.label == "effEndDate") {
                  premiumdesignation_effend_date = curAdr1.text
                }
              }
            }
            if (curAdr.label == "premiumDesignationPriorityType") {
              for (curAdr1 <- curAdr.child) {
                if (curAdr1.label == "priorityNumber") {
                  premiumdesignation_prioritynumber = curAdr1.text
                }

                if (curAdr1.label == "priorityGroupingNumber") {
                  premiumdesignation_prioritygroupnumber = curAdr1.text
                }
              }
            }
          }
          val premium_designation = Premiumdesignation(premiumdisease_grouptypecode, premiumdisease_conditionfocustypecode, premium_efficiencytypecode, premiumquality_typecode, premiumquality_efficiencytypecode, premiumdesignation_effstart_date, premiumdesignation_effend_date, premiumdesignation_prioritynumber, premiumdesignation_prioritygroupnumber)
          premiumdesignationList = premium_designation :: premiumdesignationList
        }

      }

    }

    var hcpdegreeList: List[Hcpdegree] = List()
    for (hcpdgr0 <- (professionalxml \\ "hcpDegree")) {
      hcp_degree_code = ""
      hcp_primaryind = ""
      hcp_school_name = ""
      hcp_school_compldt = ""
      hcp_school_statuscd = ""

      for (hcpdgr1 <- hcpdgr0.child) {
        if (hcpdgr1.label == "degree") {
          for (hcpdgr2 <- hcpdgr1.child) {
            if (hcpdgr2.label == "code") {
              hcp_degree_code = hcpdgr2.text
            }
          }
        }
        if (hcpdgr1.label == "primaryInd") {
          hcp_primaryind = hcpdgr1.text
        }
        if (hcpdgr1.label == "school") {
          for (hcpdgr2 <- hcpdgr1.child) {
            if (hcpdgr2.label == "name") {
              hcp_school_name = hcpdgr2.text
            }
          }
        }
        if (hcpdgr1.label == "complDate") {
          hcp_school_compldt = hcpdgr1.text
        }
        if (hcpdgr1.label == "statusCode") {
          for (hcpdgr2 <- hcpdgr1.child) {
            if (hcpdgr2.label == "code") {
              hcp_school_statuscd = hcpdgr2.text
            }
          }
        }
      }

      val hcpdegree_info = Hcpdegree(hcp_degree_code, hcp_primaryind, hcp_school_name, hcp_school_compldt, hcp_school_statuscd)
      hcpdegreeList = hcpdegree_info :: hcpdegreeList
    }

    var malpracticecarrierList: List[Malpracticecarrier] = List()
    for (malcar0 <- (professionalxml \\ "hcpMalpracticeCarrier")) {
      malpracticecarrier_id = ""
      malpracticecarrier_code = ""
      malpracticecarrier_name = ""
      malpracticecarrier_effstrtdt = ""
      malpracticecarrier_effcncldt = ""
      malpracticecarrier_totlanulcovamt = ""
      malpracticecarrier_sngloccurcovamt = ""
      malpracticecarrier_statuscode = ""

      for (malcar1 <- malcar0.child) {
        if (malcar1.label == "policy") {
          for (malcar2 <- malcar1.child) {
            if (malcar2.label == "id") {
              malpracticecarrier_id = malcar2.text
            }
            if (malcar2.label == "code") {
              malpracticecarrier_code = malcar2.text
            }
            if (malcar2.label == "name") {
              malpracticecarrier_name = malcar2.text
            }
            if (malcar2.label == "effDateRange") {
              for (malcar3 <- malcar2.child) {
                if (malcar3.label == "effStartDate") {
                  malpracticecarrier_effstrtdt = malcar3.text
                }
                if (malcar3.label == "effCancelDate") {
                  malpracticecarrier_effcncldt = malcar3.text
                }
              }
            }
          }
        }
        if (malcar1.label == "totAnnualCovAmt") {
          malpracticecarrier_totlanulcovamt = malcar1.text
        }
        if (malcar1.label == "singleOccurCovAmt") {
          malpracticecarrier_sngloccurcovamt = malcar1.text
        }
        if (malcar1.label == "statusCode") {
          for (malcar2 <- malcar1.child) {
            if (malcar2.label == "desc") {
              malpracticecarrier_statuscode = malcar2.text
            }
          }
        }
      }

      val malpracticecarrier_info = Malpracticecarrier(malpracticecarrier_id, malpracticecarrier_code, malpracticecarrier_name, malpracticecarrier_effstrtdt, malpracticecarrier_effcncldt, malpracticecarrier_totlanulcovamt, malpracticecarrier_sngloccurcovamt, malpracticecarrier_statuscode)
      malpracticecarrierList = malpracticecarrier_info :: malpracticecarrierList
    }


    var trainingList: List[Training] = List()

    for (training0 <- (professionalxml \\ "hcpTraining")) {
      training_typecode = ""
      training_strtdt = ""
      training_compdt = ""
      training_schooltypecode = ""
      training_edutypecode = ""
      training_statuscode = ""

      for (training1 <- training0.child) {
        if (training1.label == "trainingTypeCode") {
          for (training2 <- training1.child) {
            if (training2.label == "code") {
              training_typecode = training2.text
            }
          }
        }
        if (training1.label == "trainingStrtDate") {
          training_strtdt = training1.text
        }
        if (training1.label == "trainingCompDate") {
          training_compdt = training1.text
        }
        if (training1.label == "schoolTypeCode") {
          for (training2 <- training1.child) {
            if (training2.label == "code") {
              training_schooltypecode = training2.text
            }
          }
        }
        if (training1.label == "eduTypeCode") {
          for (training2 <- training1.child) {
            if (training2.label == "code") {
              training_edutypecode = training2.text
            }
          }
        }
        if (training1.label == "statusCode") {
          for (training2 <- training1.child) {
            if (training2.label == "code") {
              training_statuscode = training2.text
            }
          }
        }
      }

      val training_info = Training(training_typecode, training_strtdt, training_compdt, training_schooltypecode, training_edutypecode, training_statuscode)
      trainingList = training_info :: trainingList
    }

    var affiliationList: List[Affiliation] = List()
    for (affiliation0 <- (professionalxml \\ "hcpAffiliation")) {
      affiliation_providerid = ""
      affiliation_typecode = ""
      affiliation_strtdt = ""
      affiliation_stpdt = ""
      affiliation_admsnprevlgtypecode = ""
      affiliation_stustypecode = ""
      affiliation_primhospaffliind = ""

      for (affiliation1 <- affiliation0.child) {
        if (affiliation1.label == "affiliatedProviderId") {
          for (affiliation2 <- affiliation1.child) {
            if (affiliation2.label == "id") {
              affiliation_providerid = affiliation2.text
            }
          }
        }
        if (affiliation1.label == "affiliatedTypeCode") {
          for (affiliation2 <- affiliation1.child) {
            if (affiliation2.label == "code") {
              affiliation_typecode = affiliation2.text
            }
          }
        }
        if (affiliation1.label == "effectiveDateRange") {
          for (affiliation2 <- affiliation1.child) {
            if (affiliation2.label == "startDate") {
              affiliation_strtdt = affiliation2.text
            }
            if (affiliation2.label == "stopDate") {
              affiliation_stpdt = affiliation2.text
            }
          }
        }
        if (affiliation1.label == "addmissionPrivilegeTypeCode") {
          for (affiliation2 <- affiliation1.child) {
            if (affiliation2.label == "code") {
              affiliation_admsnprevlgtypecode = affiliation2.text
            }
          }
        }
        if (affiliation1.label == "statusTypeCode") {
          for (affiliation2 <- affiliation1.child) {
            if (affiliation2.label == "code") {
              affiliation_stustypecode = affiliation2.text
            }
          }
        }
        if (affiliation1.label == "primaryHospitalAffiliationIndicator") {
          affiliation_primhospaffliind = affiliation1.text
        }
      }
      val affiliation_info = Affiliation(affiliation_providerid, affiliation_typecode, affiliation_strtdt, affiliation_stpdt, affiliation_admsnprevlgtypecode, affiliation_stustypecode, affiliation_primhospaffliind)
      affiliationList = affiliation_info :: affiliationList
    }

    var druglicList: List[Druglic] = List()

    for (drug0 <- (professionalxml \\ "hcpDrugLicense")) {

      druglic_typecode = ""
      druglic_numberid = ""
      durglic_geoareaid = ""
      druglic_effcncldt = ""
      druglic_statustypcd = ""

      for (drug1 <- drug0.child) {
        if (drug1.label == "drugLicenseTypeCode") {
          for (drug2 <- drug1.child) {
            if (drug2.label == "code") {
              druglic_typecode = drug2.text
            }
          }
        }
        if (drug1.label == "drugLicenseNumberId") {
          for (drug2 <- drug1.child) {
            if (drug2.label == "id") {
              druglic_numberid = drug2.text
            }
          }
        }
        if (drug1.label == "geographicAreaId") {
          for (drug2 <- drug1.child) {
            if (drug2.label == "id") {
              durglic_geoareaid = drug2.text
            }
          }
        }
        if (drug1.label == "drugLicenseEffDates") {
          for (drug2 <- drug1.child) {
            if (drug2.label == "effCancelDate") {
              druglic_effcncldt = drug2.text
            }
          }
        }
        if (drug1.label == "statusTypeCode") {
          for (drug2 <- drug1.child) {
            if (drug2.label == "code") {
              druglic_statustypcd = drug2.text
            }
          }
        }

      }

      val durglic_info = Druglic(druglic_typecode, druglic_numberid, durglic_geoareaid, druglic_effcncldt, druglic_statustypcd)
      druglicList = durglic_info :: druglicList
    }

    var eleccommuList: List[Eleccommu] = List()

    for (eleccomm <- (professionalxml \\ "hcpElecCommunications")) {
      eleccommu_addrtypecode = ""
      eleccommu_addrtext = ""
      eleccommu_statscode = ""
      for (eleccomm0 <- eleccomm.child) {
        if (eleccomm0.label == "elecCommType") {
          for (eleccomm1 <- eleccomm0.child) {
            if (eleccomm1.label == "elecAddrTypeCode") {
              for (eleccomm2 <- eleccomm1.child) {
                if (eleccomm2.label == "code") {
                  eleccommu_addrtypecode = eleccomm1.text
                }
              }
            }
            if (eleccomm1.label == "elecAddrText") {
              eleccommu_addrtext = eleccomm1.text
            }
            if (eleccomm1.label == "statusCode") {
              for (eleccomm2 <- eleccomm1.child) {
                if (eleccomm2.label == "code") {
                  eleccommu_statscode = eleccomm2.text
                }
              }
            }
          }
        }
      }
      val eleccommu_info = Eleccommu(eleccommu_addrtypecode, eleccommu_addrtext, eleccommu_statscode)
      eleccommuList = eleccommu_info :: eleccommuList
    }


    var credstsList: List[Credsts] = List()
    for (credntl <- (professionalxml \\ "hcpCredentialStatuses")) {
      credsts_statustypecode = ""
      credsts_crendtltypecode = ""
      credsts_crendtltypedesc = ""
      credsts_effstrtdt = ""
      credsts_effenddt = ""
      credsts_recrendtldt = ""
      credsts_credresponcode = ""
      credsts_corpbusnssegcode = ""
      for (credntl0 <- credntl.child) {
        if (credntl0.label == "statusTypeCode") {
          for (credntl1 <- credntl0.child) {
            if (credntl1.label == "code") {
              credsts_statustypecode = credntl1.text
            }
          }
        }
        if (credntl0.label == "credentialTypeCode") {
          for (credntl1 <- credntl0.child) {
            if (credntl1.label == "code") {
              credsts_crendtltypecode = credntl1.text
            }
            if (credntl1.label == "desc") {
              credsts_crendtltypedesc = credntl1.text
            }
          }
        }
        if (credntl0.label == "effectiveDateRange") {
          for (credntl1 <- credntl0.child) {
            if (credntl1.label == "effStartDate") {
              credsts_effstrtdt = credntl1.text
            }
            if (credntl1.label == "effCancelDate") {
              credsts_effenddt = credntl1.text
            }
          }
        }
        if (credntl0.label == "recredentialDate") {
          credsts_recrendtldt = credntl0.text
        }
        if (credntl0.label == "credResponsibilityCode") {
          for (credntl1 <- credntl0.child) {
            if (credntl1.label == "code") {
              credsts_credresponcode = credntl1.text
            }
          }
        }
        if (credntl0.label == "corpBusinessSegmentCode") {
          for (credntl1 <- credntl0.child) {
            if (credntl1.label == "code") {
              credsts_corpbusnssegcode = credntl1.text
            }
          }
        }
      }
      val credsts_info = Credsts(credsts_statustypecode, credsts_crendtltypecode, credsts_crendtltypedesc, credsts_effstrtdt, credsts_effenddt, credsts_recrendtldt, credsts_credresponcode, credsts_corpbusnssegcode)
      credstsList = credsts_info :: credstsList
    }


    var taxonomyclassList: List[Taxonomyclass] = List()
    for (taxonomyclassi0 <- (professionalxml \\ "hcpTaxonomy" \\ "classification")) {
      taxonomy_classicode = ""
      taxonomy_classieffstrtdt = ""
      taxonomy_classiprimclassind = ""
      taxonomy_classisrctype = ""
      taxonomy_classisrctypecode = ""
      taxonomy_classipracspclind = ""
      taxonomy_classispclbrdcertcode = ""
      taxonomy_classispclbrdcertdate = ""
      taxonomy_classispclbrdexamdate = ""
      taxonomy_classispclbrdexpdate = ""
      taxonomy_classirecerteffdate = ""

      for (taxonomyclassi1 <- taxonomyclassi0.child) {
        if (taxonomyclassi1.label == "code") {
          taxonomy_classicode = taxonomyclassi1.text
        }
        if (taxonomyclassi1.label == "effDateRange") {
          for (taxonomyclassi2 <- taxonomyclassi1.child) {
            if (taxonomyclassi2.label == "effStartDate") {
              taxonomy_classieffstrtdt = taxonomyclassi2.text
            }
          }
        }
        if (taxonomyclassi1.label == "primClassInd") {
          taxonomy_classiprimclassind = taxonomyclassi1.text
        }
        if (taxonomyclassi1.label == "dataSourceType") {
          for (taxonomyclassi2 <- taxonomyclassi1.child) {
            if (taxonomyclassi2.label == "code") {
              taxonomy_classisrctype = taxonomyclassi2.text
            }
          }
        }
        if (taxonomyclassi1.label == "taxonomyVerificationSourceTypeCode") {
          for (taxonomyclassi2 <- taxonomyclassi1.child) {
            if (taxonomyclassi2.label == "code") {
              taxonomy_classisrctypecode = taxonomyclassi2.text
            }
          }
        }
        if (taxonomyclassi1.label == "practicingSpecialtyInd") {
          taxonomy_classipracspclind = taxonomyclassi1.text
        }
        if (taxonomyclassi1.label == "specialtyBoardCertificationCode") {
          for (taxonomyclassi2 <- taxonomyclassi1.child) {
            if (taxonomyclassi2.label == "code") {
              taxonomy_classispclbrdcertcode = taxonomyclassi2.text
            }
          }
        }
        if (taxonomyclassi1.label == "spclBrdCertDate") {
          taxonomy_classispclbrdcertdate = taxonomyclassi1.text
        }
        if (taxonomyclassi1.label == "spclBrdExamDate") {
          taxonomy_classispclbrdexamdate = taxonomyclassi1.text
        }
        if (taxonomyclassi1.label == "spclBrdExpDate") {
          taxonomy_classispclbrdexpdate = taxonomyclassi1.text
        }
        if (taxonomyclassi1.label == "recertEffDate") {
          for (taxonomyclassi2 <- taxonomyclassi1.child) {
            if (taxonomyclassi2.label == "EffStartDate") {
              taxonomy_classirecerteffdate = taxonomyclassi2.text
            }
          }
        }
      }
      val taxonomyclass_info = Taxonomyclass(taxonomy_classicode, taxonomy_classieffstrtdt, taxonomy_classiprimclassind, taxonomy_classisrctype, taxonomy_classisrctypecode, taxonomy_classipracspclind, taxonomy_classispclbrdcertcode, taxonomy_classispclbrdcertdate, taxonomy_classispclbrdexamdate, taxonomy_classispclbrdexpdate, taxonomy_classirecerteffdate)
      taxonomyclassList = taxonomyclass_info :: taxonomyclassList
    }


    var hcproleList: List[Hcprole] = List()

    for (role0 <- (professionalxml \\ "hCPRole")) {
      hcprole_id = ""
      hcprole_name = ""
      hcprole_effstrtdt = ""
      hcprole_taxid_name = ""
      hcprole_taxid_value = ""
      hcprole_entityid_name = ""
      hcprole_entityid_value = ""
      hcprole_taxid_effstrtdt = ""
      hcprole_taxid_ownername = ""
      hcprole_taxid_owner_org_id = ""
      hcprole_tieredproviderservcmodltypcd = ""
      hcprole_tieredproviderservcmodleffstrtdt = ""
      hcprole_servcprov_otheridname = ""
      hcprole_servcprov_otheridvalue = ""
      hcprole_servcprov_otherideffstrtdt = ""
      hcprole_taxid_number_effstrtdt = ""
      hcprole_hcotinowner_enterpriseid = ""
      hcprole_spowner_organization_name = ""
      hcprole_spowner_organization_nametypcd = ""
      hcprole_spowner_organization_effstrtdt = ""
      hcprole_spowner_organization_id = ""

      for (role1 <- role0.child) {
        if (role1.label == "id") {
          hcprole_id = role1.text
        }
        if (role1.label == "name") {
          hcprole_name = role1.text
        }
        if (role1.label == "effDateRange") {
          for (role2 <- role1.child) {
            if (role2.label == "effStartDate") {
              hcprole_effstrtdt = role2.text
            }
          }
        }
        if (role1.label == "ServiceProviderIDObj") {
          for (role2 <- role1.child) {
            if (role2.label == "taxID") {
              for (role3 <- role2.child) {
                if (role3.label == "name") {
                  hcprole_taxid_name = role3.text
                }
                if (role3.label == "value") {
                  hcprole_taxid_value = role3.text
                }
              }
            }
            if (role2.label == "entityIdentifier") {
              for (role3 <- role2.child) {
                if (role3.label == "name") {
                  hcprole_entityid_name = role3.text
                }
                if (role3.label == "value") {
                  hcprole_entityid_value = role3.text
                }
              }
            }
            if (role2.label == "relationshipOwner") {
              for (role3 <- role2.child) {
                if (role3.label == "relatedTINOwner") {
                  for (role4 <- role3.child) {
                    if (role4.label == "organizationId") {
                      for (role5 <- role4.child) {
                        if (role5.label == "value") {
                          hcprole_taxid_owner_org_id = role5.text
                        }
                      }
                    }
                    if (role4.label == "hcoTINOwner") {
                      for (role5 <- role4.child) {
                        if (role5.label == "taxID") {
                          for (role6 <- role5.child) {
                            if (role6.label == "numberEffDate") {
                              for (role7 <- role6.child) {
                                if (role7.label == "effStartDate") {
                                  hcprole_taxid_number_effstrtdt = role7.text
                                }
                              }
                            }
                            if (role6.label == "legalOwnerName") {
                              for (role7 <- role6.child) {
                                if (role7.label == "name") {
                                  hcprole_taxid_ownername = role7.text
                                }
                              }
                            }
                            if (role6.label == "tieredProviderServiceModel") {
                              for (role7 <- role6.child) {
                                if (role7.label == "tieredProviderServiceModelTypeCode") {
                                  for (role8 <- role7.child) {
                                    if (role8.label == "code") {
                                      hcprole_tieredproviderservcmodltypcd = role8.text
                                    }
                                  }
                                }
                                if (role7.label == "tieredProviderServiceModelEffDate") {
                                  for (role8 <- role7.child) {
                                    if (role8.label == "effStartDate") {
                                      hcprole_tieredproviderservcmodleffstrtdt = role8.text
                                    }
                                  }
                                }
                              }
                            }
                            if (role6.label == "enterpriseId") {
                              hcprole_hcotinowner_enterpriseid = role6.text
                            }
                          }
                        }
                        if (role5.label == "effDate") {
                          for (role6 <- role5.child) {
                            if (role6.label == "effStartDate") {
                              hcprole_taxid_effstrtdt = role6.text
                            }
                          }
                        }
                      }
                    }
                  }
                }

                if (role3.label == "relatedSPOwner") {
                  for (k2 <- role3.child) {
                    if (k2.label == "organizationNames") {
                      for (k3 <- k2.child) {
                        if (k3.label == "name") {
                          hcprole_spowner_organization_name = k3.text
                        }
                        if (k3.label == "nameTypeCode") {
                          for (k4 <- k3.child) {
                            if (k4.label == "code") {
                              hcprole_spowner_organization_nametypcd = k4.text
                            }
                          }
                        }
                        if (k3.label == "effectiveDate") {
                          for (k4 <- k3.child) {
                            if (k4.label == "effStartDate") {
                              hcprole_spowner_organization_effstrtdt = k4.text
                            }
                          }
                        }
                      }
                    }
                    if (k2.label == "organizationId") {
                      for (k3 <- k2.child) {
                        if (k3.label == "value") {
                          hcprole_spowner_organization_id = k3.text
                        }
                      }
                    }
                  }
                }
              }
            }

            if (role2.label == "OtherID") {
              for (role3 <- role2.child) {
                if (role3.label == "name") {
                  hcprole_servcprov_otheridname = role3.text
                }
                if (role3.label == "value") {
                  hcprole_servcprov_otheridvalue = role3.text
                }
                if (role3.label == "EffDate") {
                  for (role4 <- role3.child) {
                    if (role4.label == "effStartDate") {
                      hcprole_servcprov_otherideffstrtdt = role3.text
                    }
                  }
                }
              }
            }
          }
        }
      }


      val hcprole_info = Hcprole(hcprole_id, hcprole_name, hcprole_effstrtdt, hcprole_taxid_name, hcprole_taxid_value, hcprole_entityid_name, hcprole_entityid_value, hcprole_taxid_effstrtdt, hcprole_taxid_ownername, hcprole_taxid_owner_org_id, hcprole_tieredproviderservcmodltypcd, hcprole_tieredproviderservcmodleffstrtdt,
        hcprole_taxid_number_effstrtdt, hcprole_hcotinowner_enterpriseid, hcprole_spowner_organization_name, hcprole_spowner_organization_nametypcd, hcprole_spowner_organization_effstrtdt, hcprole_spowner_organization_id,
        hcprole_servcprov_otheridname, hcprole_servcprov_otheridvalue, hcprole_servcprov_otherideffstrtdt)
      hcproleList = hcprole_info :: hcproleList
    }


    return PMdmCol(timestamp.text, entity_id, provider_prtytypcd, provider_effstrtdt, practitioner_effstrtdt, first_name, middle_name, last_name, birth_date, gender, ssn, npi_id, npi_id_effstrtdt, npi_id_effenddt, taxonomy_providertypecode, taxonomy_effdates, othernmList, addrList, /*keyList,*/ medicareList, premiumdesignationList, hcpdegreeList,
      malpracticecarrierList, trainingList, affiliationList, druglicList, eleccommuList, credstsList, taxonomyclassList, hcproleList, hcpidobjothridList, hcpidobjmpinList)


  }
}
