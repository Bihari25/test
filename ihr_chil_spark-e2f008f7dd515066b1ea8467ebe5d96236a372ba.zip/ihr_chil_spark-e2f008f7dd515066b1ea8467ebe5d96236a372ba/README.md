# ihr_chil_spark
This repository is used to store Spark code used for CHIL data ingestion process
