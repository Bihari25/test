package com.optum.centriihr;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;


/**
 *
 * @author fsiddiq3
 */
public class WebServiceCall {


    public String callReceivedBatch(String wsdl, String batchId, String translatorId) throws Exception{
        // Create a StringEntity for the SOAP XML.
        String body ="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:connectivity\"><soapenv:Header/><soapenv:Body><urn:receivedBatch><translatorId xmlns=\"\">"+translatorId+"</translatorId><batchId xmlns=\"\">"+batchId+"</batchId></urn:receivedBatch></soapenv:Body></soapenv:Envelope>";
//        String body = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:connectivity\">\n" +
//                "   <soapenv:Header/>\n" +
//                "   <soapenv:Body>\n" +
//                "      <urn:enqueuedBatch>\n" +
//                "       <translatorId xmlns=\"\">MSC_TEST</translatorId>\n" +
//                "         <batchId>Member_MR_Demographics_20180414221557</batchId>\n" +
//                "         <recordCount>87499</recordCount>\n" +
//                "      </urn:enqueuedBatch>\n" +
//                "   </soapenv:Body>\n" +
//                "</soapenv:Envelope>";
        System.out.println("body="+body);
        requestBody = body;
        StringEntity stringEntity = new StringEntity(body, "UTF-8");
        stringEntity.setChunked(true);

        // Request parameters and other properties.
        System.out.println("wsdl="+wsdl);
        HttpPost httpPost = new HttpPost(wsdl);
        httpPost.setEntity(stringEntity);
        httpPost.addHeader("Accept", "text/xml");
        httpPost.addHeader(HttpHeaders.CONTENT_TYPE, "text/xml");


        // Execute and get the response.
        HttpClient httpClient = new DefaultHttpClient();
        HttpResponse response = httpClient.execute(httpPost);
        HttpEntity entity = response.getEntity();

        String strResponse = null;
        if (entity != null) {
            strResponse = EntityUtils.toString(entity);
        }
        return strResponse;
    }

    public String requestBody = "";

    public String callEnqueuedBatch(String wsdl, String batchId, String recordCount) throws Exception{
        // Create a StringEntity for the SOAP XML.
        String body ="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:connectivity\"><soapenv:Header/><soapenv:Body><urn:enqueuedBatch><batchId xmlns=\"\">"+batchId+"</batchId><recordCount xmlns=\"\">"+recordCount+"</recordCount></urn:enqueuedBatch></soapenv:Body></soapenv:Envelope>";
//        String body = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:connectivity\">\n" +
//                "   <soapenv:Header/>\n" +
//                "   <soapenv:Body>\n" +
//                "      <urn:enqueuedBatch>\n" +
//                "       <translatorId xmlns=\"\">MSC_TEST</translatorId>\n" +
//                "         <batchId>Member_MR_Demographics_20180414221557</batchId>\n" +
//                "         <recordCount>87499</recordCount>\n" +
//                "      </urn:enqueuedBatch>\n" +
//                "   </soapenv:Body>\n" +
//                "</soapenv:Envelope>";
        System.out.println("body="+body);
        requestBody = body;
        StringEntity stringEntity = new StringEntity(body, "UTF-8");
        stringEntity.setChunked(true);
        System.out.println("wsdl="+wsdl);

        // Request parameters and other properties.
        HttpPost httpPost = new HttpPost(wsdl);
        httpPost.setEntity(stringEntity);
        httpPost.addHeader("Accept", "text/xml");
        httpPost.addHeader(HttpHeaders.CONTENT_TYPE, "text/xml");


        // Execute and get the response.
        HttpClient httpClient = new DefaultHttpClient();
        HttpResponse response = httpClient.execute(httpPost);
        HttpEntity entity = response.getEntity();

        String strResponse = null;
        if (entity != null) {
            strResponse = EntityUtils.toString(entity);
        }
        return strResponse;
    }

}
