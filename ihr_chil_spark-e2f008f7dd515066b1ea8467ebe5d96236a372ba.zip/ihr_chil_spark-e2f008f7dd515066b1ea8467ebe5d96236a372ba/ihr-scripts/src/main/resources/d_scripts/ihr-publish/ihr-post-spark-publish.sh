#!/bin/sh


process_file=$1
inbound_path=$2
archive_path=$3
domain=$4

#cp ${inbound_path}/${domain}/*.hl7 ${archive_path}/${domain}/ 


sed -i 's/\f/\r/g' ${inbound_path}/${domain}/*.hl7

if [ $? -ne 0 ];
then
  echo hl7 files not found
fi

mkdir -p ${archive_path}/${domain}
chmod -R ug+rw ${archive_path}/${domain}
mv ${inbound_path}/${domain}/* ${archive_path}/${domain}/


#cat ${ihr_hdfs}/${domain}.process
cat ${process_file}
echo chmod ug+rw ${archive_path}/../d_hdfs/${domain}*.process
chmod ug+rw ${archive_path}/../d_hdfs/${domain}*.process
echo hi
