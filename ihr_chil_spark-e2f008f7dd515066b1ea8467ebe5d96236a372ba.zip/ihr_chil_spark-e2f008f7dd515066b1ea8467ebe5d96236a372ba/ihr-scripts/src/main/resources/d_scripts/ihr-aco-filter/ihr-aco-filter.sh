#!bin/sh


spark-submit --class com.optum.centriihr.IHRAcoFilterJob  --properties-file /mapr/datalake/optum/optuminsight/udw/ihr/dev/d_scripts/ihr-aco-filter/ihr-aco-filter-dev.properties --master yarn --queue fabbddev_q1  /mapr/datalake/optum/optuminsight/udw/ihr/dev/d_jars/ihr-ACO-Filter-1.0.0-SNAPSHOT.jar Member_MR_Coverage
