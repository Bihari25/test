package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.PractitionerRole;

import java.util.List;

@Slf4j
@Getter
@RequiredArgsConstructor(staticName = "of")
public class PractitionerRoleResource implements IhrResource<PractitionerRole> {

    final PractitionerRole practitionerRole;

    @Override
    public PractitionerRole getDomainResource() {
        return practitionerRole;
    }

    @Override
    public List<Annotation> getNote() {
        return null;
    }

    @Override
    public PractitionerRole setNote(List<Annotation> notes) {
        return null;
    }

    @Override
    public List<Identifier> getIdentifiers() {
        return practitionerRole.getIdentifier();
    }

    @Override
    public PractitionerRole addIdentifier(Identifier identifier) {
        return practitionerRole.addIdentifier(identifier);
    }

}