package com.uhg.ihr.centrihealth.api.validator;

import lombok.Getter;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

@Getter
public enum PractitionerIdentifierEnum {

    NPI("NPI"),
    EMPLOYEE_ID("employeeId");
    private String identifier;

    PractitionerIdentifierEnum(String code){
        this.identifier = code;
    }

    protected static final Set<String> PRACTITIONER_IDENTIFIERS = Arrays.stream(PractitionerIdentifierEnum.values())
            .map(PractitionerIdentifierEnum::getIdentifier).collect(Collectors.toSet());
}
