package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Value;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Condition;

@Value(staticConstructor = "of")
public class ConditionResourceMapper implements IhrResourceMapper<Condition> {

    public IhrResource createDomainResource(final Bundle.BundleEntryComponent entity) {

        if (!(entity.getResource() instanceof Condition)) {
            return ConditionResource.of(null);
        }
        ConditionResource newResource = ConditionResource.of(new Condition());
        ConditionResource oldResource = ConditionResource.of((Condition) entity.getResource());
        return IhrResourceMapper.buildIhrResource(oldResource, newResource);
    }
}
