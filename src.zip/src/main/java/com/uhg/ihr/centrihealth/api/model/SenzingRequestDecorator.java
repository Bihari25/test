package com.uhg.ihr.centrihealth.api.model;

import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Resource;

public interface SenzingRequestDecorator<T extends Resource> {
    SenzingRequest buildSenzingRequest(Bundle.BundleEntryComponent entity, SenzingRequest senzingRequest);
}
