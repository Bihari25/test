package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.util.Constant;
import com.uhg.ihr.centrihealth.api.util.Z85;
import io.micronaut.core.util.CollectionUtils;
import io.micronaut.core.util.StringUtils;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;
import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.DateTimeType;
import org.hl7.fhir.r4.model.DateType;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.InstantType;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.Type;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

@Slf4j
@NoArgsConstructor
public class ValidationUtils {

    private static final int PATIENT_NOTE_LIMIT = 1000;
    private static final String INVALID_RECORD_KEY = "Invalid record key";
    private static final String INVALID_EMPLOYEE_ID = "Invalid employee Id";
    public static final String INVALID_IDENTIFIER_KEY = "Invalid identifier";
    public static final String DATE_PATTERNS = "yyyy-MM-dd";
    public static final String REQUIRED_IDENTIFIER = "Identifier is required";
    private static final String REQUIRED_RECORD_KEY = "Recordkey is required as note is available";
    private static final String INVALID_ACTION_FLAG = "Invalid Action flag";
    private static final String INVALID_ACTION_FLAG_ITEMS = "Can't process more than one actionflag";
    private static final String INVALID_LAST_UPDATED_DATE_FORMAT = "Invalid last updated date format";
    private static final String CODE_OR_SYSTEM_MISSING = "Code or System missing in Coding";
    private static final String MISSING_CODEABLECONCEPT = "Missing CodeableConcept";
    private static final String INVALID_NOTE_TEXT = "Invalid note text";
    private static final String INVALID_NOTE_COUNT = "Multiple notes not allowed";
    private static final String INVALID_CLINICAL_NOTE = "Invalid clinical or patient note extension";
    private static final String NOTE_TYPE_URL = "https://new-wiki.optum.com/display/IHRI/ihrNoteType";
    private static final String INVALID_AUTHOR_REFERENCE = "Invalid author reference";
    private static final String CLINICAL_NOTE = "Clinical Note";
    private static final String INVALID_PRACTITIONER = "Invalid practitioner reference or identifier in note";
    private static final String INVALID_PATIENT = "Invalid patient or related person reference in note";
    private static final String INVALID_NOTE_TIME = "Invalid note time";
    private static final String EMPLOYEE_IDS_MISMATCH = "EmployeeId mismatch in resource";
    private static final String DISPLAY_OR_SYSTEM_MISSING = "Display or System missing in Coding";
    private static final String UNABLE_TO_DECODE_RECORD_MSG = "Unable to decode record key value ";

    private static int DATE_TIME_LENGTH = 10;
    private static String DATE_REGEX_SLASH = "((?:19|20)\\d\\d)/(0?[1-9]|1[012])/([12][0-9]|3[01]|0?[1-9])";
    private static String DATE_REGEX_HYPHEN = "^20[0-2][0-9]-((0[1-9])|(1[0-2]))-(0[1-9]|[1-2][0-9]|3[0-1])$";
    private static Pattern DATE_PATTERN_SLASH = Pattern.compile(DATE_REGEX_SLASH);
    private static Pattern DATE_PATTERN_HYPHEN = Pattern.compile(DATE_REGEX_HYPHEN);
    private static DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy/MM/dd", Locale.US);
    private static DateTimeFormatter FORMATTER_HYPHEN = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US);

    protected static boolean hasNoTimestamp(Type type) {
        boolean hasNoTimestamp = false;
        if (type == null) {
            return true;
        }
        try {
            if (type instanceof InstantType) {
                InstantType instantType = (InstantType) type;
                if (instantType.getTimeZone() == null && !instantType.isTimeZoneZulu()) {
                    hasNoTimestamp = true;
                }
            } else if (type instanceof DateTimeType) {
                DateTimeType dateTimeType = (DateTimeType) type;
                if (dateTimeType.getTimeZone() == null && !dateTimeType.isTimeZoneZulu()) {
                    hasNoTimestamp = true;
                }
            } else {
                DateType dateTimeType = (DateType) type;
                if (dateTimeType.getTimeZone() == null && !dateTimeType.isTimeZoneZulu()) {
                    hasNoTimestamp = true;
                }
            }
        } catch (Exception ex) {
            log.warn(ex.getMessage());
            return true;
        }
        return hasNoTimestamp;
    }

    protected static boolean isDateOnly(DateType dateType) {
        if (dateType == null) {
            return false;
        }
        try {
            DateUtils.parseDateStrictly(dateType.asStringValue(), DATE_PATTERNS);
        } catch (Exception ex) {
            log.warn(ex.getMessage());
            return false;
        }
        return true;
    }

    protected static void validateIdentifier(List<Identifier> identifiers, boolean noteExists) {
        boolean recordKeyExists = false;
        if (CollectionUtils.isEmpty(identifiers)) {
            throw new IhrBadRequestException(REQUIRED_IDENTIFIER);
        }
        for (Identifier identifier : identifiers) {
            if (!IdentifierEnum.ENUM_VALUES.contains(identifier.getType().getText())) {
                throw new IhrBadRequestException(INVALID_IDENTIFIER_KEY);
            }
            if (IdentifierEnum.RECORD_KEY.getValue().equals(identifier.getType().getText())) {
                recordKeyExists = true;
                if (!isIdentifierValid(identifier)) {
                    throw new IhrBadRequestException(INVALID_RECORD_KEY);
                }
                //decode record key
                decodeRecordKey(identifier);
                }

        }
        if (noteExists && !recordKeyExists) {
            throw new IhrBadRequestException(REQUIRED_RECORD_KEY);
        }
    }

    private static void decodeRecordKey(Identifier identifier) {
        try {
            byte[] decode = Z85.decode(identifier.getValue());
            identifier.setValue(new String(decode));
        } catch(Exception e) {
            throw new IhrBadRequestException(UNABLE_TO_DECODE_RECORD_MSG);
        }
    }

    public static boolean isIdentifierValid(Identifier identifier) {
        return (identifier.getType().getText() != null
                && !StringUtils.isEmpty(identifier.getValue()));
    }

    protected static void isValidNote(List<Annotation> notes) {
        if (CollectionUtils.isEmpty(notes)) {
            return;
        }
        if (notes.size() > 1) {
            throw new IhrBadRequestException(INVALID_NOTE_COUNT);
        }
        if (!isValidNoteText(notes.get(0))) {
            throw new IhrBadRequestException(INVALID_NOTE_TEXT);
        }
        if (!isValidAuthorReference(notes.get(0))) {
            throw new IhrBadRequestException(INVALID_AUTHOR_REFERENCE);
        }
        if (!hasValidateDateTimeType(notes.get(0).getTimeElement())) {
            throw new IhrBadRequestException(INVALID_NOTE_TIME);
        }
        if (!(isValidClinicalNote(notes.get(0)) || isValidPatientNote(notes.get(0)))) {
            throw new IhrBadRequestException(INVALID_CLINICAL_NOTE);
        }
    }

    protected static boolean isValidNoteText(Annotation annotation) {
        return StringUtils.isNotEmpty(annotation.getText())
                && annotation.getText().length() <= PATIENT_NOTE_LIMIT;
    }

    private static boolean isValidAuthorReference(Annotation annotation) {
        return annotation.getAuthorReference().getResource() != null
                && annotation.getAuthorReference().getResource().getIdElement() != null
                && StringUtils.isNotEmpty(annotation.getAuthorReference().getReferenceElement().getResourceType());
    }

    protected static boolean isValidClinicalNote(Annotation annotation) {
        return hasValidClinicalExtension(annotation)
                && hasValidPractitionerIdentifier(annotation);
    }

    protected static boolean hasValidClinicalExtension(Annotation annotation) {
        return annotation.getExtension().size() == 1
                && hasExtension(annotation)
                && NOTE_TYPE_URL.equals(annotation.getExtension().get(0).getUrl())
                && CLINICAL_NOTE.equals(annotation.getExtension().get(0).getValue().toString());
    }

    protected static boolean hasExtension(Annotation annotation) {
        return annotation.getExtension().get(0).hasUrl()
                && annotation.getExtension().get(0).hasValue();
    }

    protected static boolean isValidPatientNote(Annotation annotation) {
        return hasValidPatientExtension(annotation)
                && hasValidPatientReference(annotation);
    }

    protected static boolean hasValidPatientExtension(Annotation annotation) {
        return annotation.getExtension().size() == 1
                && hasExtension(annotation)
                && NOTE_TYPE_URL.equals(annotation.getExtension().get(0).getUrl())
                && !CLINICAL_NOTE.equals(annotation.getExtension().get(0).getValue().toString());
    }

    public static boolean hasValidateDateTimeType(DateTimeType dateAsserted) {
        return dateAsserted != null && !hasNoTimestamp(dateAsserted);
    }

    protected static boolean hasValidPractitionerIdentifier(Annotation annotation) {
        if (annotation.getAuthorReference().getResource() instanceof Practitioner
                && ((Practitioner) annotation.getAuthorReference().getResource())
                .getIdentifier().stream().anyMatch(identifier -> isIdentifierValid(identifier)
                        && PractitionerIdentifierEnum.PRACTITIONER_IDENTIFIERS.contains(identifier.getType().getText()))) {
            return true;
        } else {
            throw new IhrBadRequestException(INVALID_PRACTITIONER);
        }
    }

    protected static boolean hasValidPatientReference(Annotation annotation) {
        if ((annotation.getAuthorReference().getResource() instanceof Patient
                || annotation.getAuthorReference().getResource() instanceof RelatedPerson)) {
            return true;
        } else {
            throw new IhrBadRequestException(INVALID_PATIENT);
        }
    }

    protected static void validateActionFlag(List<Coding> tag) {
        if (tag.isEmpty() || !tag.stream().allMatch(e -> ActionFlag.ENUM_VALUES.contains(e.getDisplay()) && Constant.ACTION_FLAG.equals(e.getCode()))) {
            throw new IhrBadRequestException(INVALID_ACTION_FLAG);
        }
        if (tag.size() > 1) {
            throw new IhrBadRequestException(INVALID_ACTION_FLAG_ITEMS);
        }
    }

    protected static void validateLastUpdatedDate(InstantType lastUpdated) {
        if (lastUpdated == null || hasNoTimestamp(lastUpdated)) {
            throw new IhrBadRequestException(INVALID_LAST_UPDATED_DATE_FORMAT);
        }
    }

    public static boolean isRequiredIdentifierExists(List<Identifier> identifiers, String text) {
        for (Identifier identifier : identifiers) {
            if (null != identifier.getType().getText()
                    && identifier.getType().getText().equals(text)
                    && null != identifier.getValue()
                    && StringUtils.isNotEmpty(identifier.getValue().trim())) {
                return true;
            }
        }
        return false;
    }

    public static void validateCoding(CodeableConcept concept) {
        if (null == concept || CollectionUtils.isEmpty(concept.getCoding())) {
            throw new IhrBadRequestException(MISSING_CODEABLECONCEPT);
        } else {
            for (Coding coding : concept.getCoding()) {
                if (StringUtils.isEmpty(coding.getSystem()) || StringUtils.isEmpty(coding.getCode())) {
                    throw new IhrBadRequestException(CODE_OR_SYSTEM_MISSING);
                }
            }
        }
    }

    public static void validateCodableDisplayCoding(CodeableConcept concept) {
        if (null != concept) {
            for (Coding coding : concept.getCoding()) {
                if (null == coding.getSystem() || null == coding.getDisplay()) {
                    throw new IhrBadRequestException(DISPLAY_OR_SYSTEM_MISSING);
                }
            }
        } else {
            throw new IhrBadRequestException(MISSING_CODEABLECONCEPT);
        }
    }

    public static String getEmployeeId(List<Identifier> identifiers) {

        for (Identifier identifier : identifiers) {
            if (identifier.getType().getText().equals(IdentifierEnum.EMPLOYEE_ID.getValue())) {
                return identifier.getValue();
            }
        }
        return null;
    }
    public static String getNpiId(List<Identifier> identifiers) {
        for (Identifier identifier : identifiers) {
            if (identifier.getType().getText().equals("NPI")) {
                return identifier.getValue();
            }
        }
        return null;
    }

    public static void validateEmployeeId(List<Identifier> identifiers, FhirAttributesWrapper fhirAttributesWrapper) {
        boolean employeeIdExists = ValidationUtils.isRequiredIdentifierExists(identifiers,
                IdentifierEnum.EMPLOYEE_ID.getValue());
        if (employeeIdExists) {
            String msId = ValidationUtils.getEmployeeId(identifiers);
            if (fhirAttributesWrapper.getEmployeeId().isEmpty()) {
                fhirAttributesWrapper.getEmployeeId().add(msId);
            } else if (!fhirAttributesWrapper.getEmployeeId().contains(msId)) {
                throw new IhrBadRequestException(EMPLOYEE_IDS_MISMATCH);
            }
        }
    }

    public static boolean validateLoneIdentifier(List<Identifier> identifiers, String text) {
        boolean isValid = false;
        if (CollectionUtils.isNotEmpty(identifiers) && identifiers.size() == 1) {
            isValid = isRequiredIdentifierExists(identifiers, text);
        }
        return isValid;
    }

    protected static void validateRecordKey(List<Identifier> identifiers) {
        for (Identifier identifier : identifiers) {
            if (!IdentifierEnum.ENUM_VALUES.contains(identifier.getType().getText())) {
                throw new IhrBadRequestException(INVALID_IDENTIFIER_KEY);
            }
            if (IdentifierEnum.RECORD_KEY.getValue().equals(identifier.getType().getText())) {
                if (!isIdentifierValid(identifier)) {
                    throw new IhrBadRequestException(INVALID_RECORD_KEY);
                }
            }
        }
    }

    static Date toDate(String date) {
        try {
            if (isDateTime(date)) {
                return Date.from(ZonedDateTime.parse(date).toInstant());
            } else if (isDatePatternSlash(date)) {
                LocalDate ld = LocalDate.parse(date, FORMATTER);
                return Date.from(ld.atStartOfDay(ZoneOffset.UTC).toInstant());
            } else if (isDatePatternHyphen(date)) {
                LocalDate ld = LocalDate.parse(date, FORMATTER_HYPHEN);
                return Date.from(ld.atStartOfDay(ZoneOffset.UTC).toInstant());
            } else {
                return null;
            }
        } catch (DateTimeParseException de) {
            return null;
        }
    }

    public static boolean isDatePatternSlash(String date) {
        return date != null && DATE_PATTERN_SLASH.matcher(date).matches();
    }

    public static boolean isDatePatternHyphen(String date) {
        return date != null && DATE_PATTERN_HYPHEN.matcher(date).matches();
    }

    public static boolean isDateTime(String dateTime) {
        return dateTime != null && dateTime.length() > DATE_TIME_LENGTH;
    }
}
