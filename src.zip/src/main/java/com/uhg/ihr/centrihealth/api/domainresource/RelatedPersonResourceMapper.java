package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Value;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.RelatedPerson;

@Value(staticConstructor = "of")
public class RelatedPersonResourceMapper implements IhrResourceMapper<RelatedPerson> {

    public IhrResource<?> createDomainResource(final Bundle.BundleEntryComponent entity) {

        if (!(entity.getResource() instanceof RelatedPerson)) {
            return RelatedPersonResource.of(null);
        }
        RelatedPersonResource newResource = RelatedPersonResource.of(new RelatedPerson());
        RelatedPersonResource oldResource = RelatedPersonResource.of((RelatedPerson) entity.getResource());
        newResource.getDomainResource().setRelationship(oldResource.getDomainResource().getRelationship());
        newResource.getDomainResource().setId(oldResource.getDomainResource().getId());
        return newResource;
    }
}
