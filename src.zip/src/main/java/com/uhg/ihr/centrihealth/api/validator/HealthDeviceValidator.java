package com.uhg.ihr.centrihealth.api.validator;


import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Device;
import org.hl7.fhir.r4.model.Resource;

@NoArgsConstructor(staticName = "of")
public class HealthDeviceValidator implements IhrResourceValidator {

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Device) {
            validate((Device) resource, null);
        }
    }


    private void validate(final Device device, final FhirAttributesWrapper fhirAttributesWrapper) {

        //validate action flag
        ValidationUtils.validateActionFlag(device.getMeta().getTag());
        //validate last updated date
        ValidationUtils.validateLastUpdatedDate(device.getMeta().getLastUpdatedElement());
        // validate Identifiers (record key and RefId)
        boolean noteExists = device.getNote().size() > 0;
        ValidationUtils.validateIdentifier(device.getIdentifier(), noteExists);
        // validate Note
        ValidationUtils.isValidNote(device.getNote());
    }
}