package com.uhg.ihr.centrihealth.api.model;

public enum ActorIdType {

    PATIENT("PATIENT"),
    AUTHOR("AUTHOR");

    private String value;

    ActorIdType(String value) {
            this.value = value;
    }

    public String getValue() {
        return value;
    }
}
