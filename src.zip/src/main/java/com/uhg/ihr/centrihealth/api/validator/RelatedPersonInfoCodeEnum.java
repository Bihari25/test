package com.uhg.ihr.centrihealth.api.validator;

import lombok.Getter;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

@Getter
public enum RelatedPersonInfoCodeEnum {

    //Caregiver, Family Member, Guardian, Health Care Proxy, Other, Power of Attorney:
    CAREGIVER("Caregiver"),
    FAMILY_MEMBER("Family Member"),
    GUARDIAN("Guardian"),
    HEATLTH_CARE_PROXY("Health Care Proxy"),
    OTHER("Other"),
    POWER_OF_ATTORNEY("Power of Attorney");

    private String code;

    RelatedPersonInfoCodeEnum(String code){
        this.code = code;
    }

    protected static final Set<String> RELATED_PERSON_CODES = Arrays.stream(RelatedPersonInfoCodeEnum.values())
            .map(RelatedPersonInfoCodeEnum::getCode).collect(Collectors.toSet());


}
