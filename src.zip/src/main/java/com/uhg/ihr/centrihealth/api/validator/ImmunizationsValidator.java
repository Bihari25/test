package com.uhg.ihr.centrihealth.api.validator;


import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Immunization;
import org.hl7.fhir.r4.model.Resource;

@NoArgsConstructor(staticName = "of")
public class ImmunizationsValidator implements IhrResourceValidator {

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Immunization) {
            validate((Immunization) resource, null);
        }
    }

    private void validate(final Immunization immunization, final FhirAttributesWrapper fhirAttributesWrapper) {

        //validate action flag
        ValidationUtils.validateActionFlag(immunization.getMeta().getTag());
        //validate last updated date
        ValidationUtils.validateLastUpdatedDate(immunization.getMeta().getLastUpdatedElement());

        // validate patient Note
        boolean noteExists = immunization.getNote().size() > 0;
        // validate Identifiers (record key and RefId)
        ValidationUtils.validateIdentifier(immunization.getIdentifier(), noteExists);
        //validate notes
        ValidationUtils.isValidNote(immunization.getNote());
    }
}