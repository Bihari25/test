package com.uhg.ihr.centrihealth.api.validator;
import com.google.common.collect.ImmutableMap;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.util.Constant;
import io.micronaut.core.util.CollectionUtils;
import io.micronaut.core.util.StringUtils;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Dosage;
import org.hl7.fhir.r4.model.Extension;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Medication;
import org.hl7.fhir.r4.model.MedicationStatement;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Quantity;
import org.hl7.fhir.r4.model.Resource;
import org.hl7.fhir.r4.model.ResourceType;

import java.util.List;
import java.util.Map;
import java.util.Set;

@NoArgsConstructor(staticName = "of")
@Slf4j
public class MedicationStatementValidator implements IhrReferenceValidator {

    public static final String INVALID_MEDICATION_REQUEST = "Can't process medication request";
    public static final String INVALID_MEDICATION_DISPENSE = "Can't process medication dispense";
    private static final String REQUIRED_DATA_AUTHOR_IDENTIFIER = "dataAuthorIdentifier is required as date asserted is present";
    public static final String MEDICATION_REQUIRED = "Medication is required as record key does not exists";
    public static final String CONCEPT_CODE_REQUIRED = "Medication conceptChid or source vocabulary/source vocabulary code are required if no record key is present.";
    private static final String MEDICATION_CODE_SYSTEM = "http://hl7.org/fhir/sid/ndc";
    private static final String MISSING_MEDICATION_CODE = "Missing/Incorrect medication code system";
    public static final String MISSING_EXTENSION_INFO = "Missing or Incorrect information in extension";
    private static final String UPSERT_ACTION_FLAG_ERROR = "No other action flag is allowed other than Upsert";
    public static final String IHR_HOLD_DATE_URL = "https://new-wiki.optum.com/display/IHRI/ihrHoldDate";
    public static final String IHR_RESTART_DATE_URL = "https://new-wiki.optum.com/display/IHRI/ihrRestartDate";
    public static final String IHR_ADHERENCE_STOP_DATE_URL = "https://new-wiki.optum.com/display/IHRI/ihrAdherenceStopDate";
    public static final String TAKEN_AS_ORDERED_URL = "https://new-wiki.optum.com/display/IHRI/takenAsOrdered";
    public static final String RECORD_KEY_MISSING_ERROR = "For a date to be received, a record key must be present";
    public static final String STATUS_RECORD_KEY_ERROR = "recordKey is requrired, as status exists";
    public static final String STATUS_AND_REASON_ERROR = "Status is requrired, as status reason exists";
    public static final String MISSING_STATUS_REASON_SYSTEM = "Missing system for status reason";
    public static final String STATUS_REASON_CODING_ERROR = "No more than one coding is allowed for status reason";
    private static final String INVALID_IDENTIFIER = "Invalid Identifier";
    private static final String INVALID_MEDICATION_REFERENCE = "Invalid Medication Reference";
    private static final String INVALID_INFORMATIONSOURCE_REFERENCE = "Invalid InformationSource Reference";
    public static final String MISSING_MEDICATION_DOSAGE_TEXT = "Medication Dosage text is missing";
    public static final String MISSING_MED_DOSAGE_QU = "Missing or Incorrect  DoseQuantity unit";
    public static final String MISSING_MED_DOSAGE_QV = "Missing or Incorrect  DoseQuantity value";
    private static final String DOSE_QUANTITY_VALUE_REQUIRED = "DoseQuantity value is required as DoseQuantity unit is present";

    private static final Map<ResourceType, IhrResourceValidator> informationSourceMap = ImmutableMap.<ResourceType, IhrResourceValidator>builder()
            .put(ResourceType.Patient, PatientValidator.of())
            .put(ResourceType.RelatedPerson, RelatedPersonValidator.of())
            .put(ResourceType.PractitionerRole, PractitionerRoleValidator.of())
            .build();

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof MedicationStatement) {
            validate((MedicationStatement) resource, fhirAttributesWrapper);
        }
    }

    private void validate(final MedicationStatement medicationStatement, final FhirAttributesWrapper fhirAttributesWrapper) {

       // ValidationUtils.validateEmployeeId(medicationStatement.getIdentifier(), fhirAttributesWrapper);//need to look

        //action flag
        ValidationUtils.validateActionFlag(medicationStatement.getMeta().getTag());
        //last updated date
        ValidationUtils.validateLastUpdatedDate(medicationStatement.getMeta().getLastUpdatedElement());

        boolean noteExists = medicationStatement.getNote().size() > 0;
        // validate identifiers
        ValidationUtils.validateIdentifier(medicationStatement.getIdentifier(), noteExists);

        //Asserted Date
        boolean assertedDateExists = ValidationUtils.hasValidateDateTimeType(medicationStatement.getDateAssertedElement());

        //Check for record key
        boolean recordKeyExists = ValidationUtils.isRequiredIdentifierExists(medicationStatement.getIdentifier(),
                IdentifierEnum.RECORD_KEY.getValue());

        //Check for dataAuthorIdentifier
        /*boolean empolyeeIdExists = ValidationUtils.isRequiredIdentifierExists(medicationStatement.getIdentifier(),
                IdentifierEnum.EMPLOYEE_ID.getValue());
        isDataAuthorIdentifierRequired(assertedDateExists, empolyeeIdExists);*/
        //validate information source
        validateInformationSource(medicationStatement, fhirAttributesWrapper);

        validateMedicationReference(medicationStatement, recordKeyExists);
        if (null != medicationStatement.getMedicationReference() &&
                null != medicationStatement.getMedicationReference().getResource()) {
            Medication medication = (Medication) medicationStatement.getMedicationReference().getResource();
            validateMedication(medication, recordKeyExists);
        }

        if (null != medicationStatement.getSubject() && null != medicationStatement.getSubject().getResource()) {
            Patient patient = (Patient) medicationStatement.getSubject().getResource();
            PatientValidator.of().validate(patient, fhirAttributesWrapper);
        }
        // validate notes
        ValidationUtils.isValidNote(medicationStatement.getNote());
        //Validate Extension
        if (CollectionUtils.isNotEmpty(medicationStatement.getExtension())
                && !isUrlValidForMedicationExtension(medicationStatement.getExtension())) {
            throw new IhrBadRequestException(MISSING_EXTENSION_INFO);
        }
        boolean statusExists = (null != medicationStatement.getStatus() && null != medicationStatement.getStatus().toCode());

        if (statusExists && !recordKeyExists) {
            throw new IhrBadRequestException(STATUS_RECORD_KEY_ERROR);
        }
        boolean statusReasonExists = false;
        if (CollectionUtils.isNotEmpty(medicationStatement.getStatusReason())
                && CollectionUtils.isNotEmpty(medicationStatement.getStatusReason().get(0).getCoding())) {
            medicationStatusReason(medicationStatement.getStatusReason().get(0));
            statusReasonExists = true;
        }
        if (statusReasonExists && !statusExists) {
            throw new IhrBadRequestException(STATUS_AND_REASON_ERROR);
        }
        boolean editableFieldAvailable = isMedicationEditableFieldAvailable(medicationStatement);
        if (editableFieldAvailable && !isActionFlagUpsert(medicationStatement.getMeta().getTag())) {
            throw new IhrBadRequestException(UPSERT_ACTION_FLAG_ERROR);
        }
        if (editableFieldAvailable && !recordKeyExists) {
            throw new IhrBadRequestException(RECORD_KEY_MISSING_ERROR);
        }
        if (CollectionUtils.isNotEmpty(medicationStatement.getBasedOn())) {
            throw new IhrBadRequestException(INVALID_MEDICATION_REQUEST);
        }
        if (CollectionUtils.isNotEmpty(medicationStatement.getPartOf())) {
            throw new IhrBadRequestException(INVALID_MEDICATION_DISPENSE);
        }
        // reasonCode
        if (CollectionUtils.isNotEmpty(medicationStatement.getReasonCode())) {
            for (CodeableConcept codeableConcept : medicationStatement.getReasonCode()) {
                ValidationUtils.validateCoding(codeableConcept);
            }
        }
        // dosage
        validateDosage(medicationStatement.getDosage());

    }

    public static void validateDosage(List<Dosage> dosages) {
        if (CollectionUtils.isNotEmpty(dosages)) {
            for (Dosage dosage : dosages) {
                if (null != dosage.getText() && !dosage.hasText()) {
                    throw new IhrBadRequestException(MISSING_MEDICATION_DOSAGE_TEXT);
                }
                if (null != dosage.getRoute() && CollectionUtils.isNotEmpty(dosage.getRoute().getCoding())) {
                    ValidationUtils.validateCoding(dosage.getRoute());
                }
                if (CollectionUtils.isNotEmpty(dosage.getDoseAndRate())) {
                    validateDoseAndRateQuantity(dosage.getDoseAndRate());
                }
                if (null != dosage.getTiming() && null != dosage.getTiming().getCode()) {
                    ValidationUtils.validateCoding(dosage.getTiming().getCode());
                }
            }
        }
    }

    private static void validateDoseAndRateQuantity(List<Dosage.DosageDoseAndRateComponent> doseAndRate) {
        for (Dosage.DosageDoseAndRateComponent doseAndRateComponent : doseAndRate) {
            if (null != doseAndRateComponent.getDoseQuantity().getUnit() && !doseAndRateComponent.getDoseQuantity().hasUnit()) {
                throw new IhrBadRequestException(MISSING_MED_DOSAGE_QU);
            }
            if (null != doseAndRateComponent.getDoseQuantity().getValue()
                    && !StringUtils.isDigits(String.valueOf(doseAndRateComponent.getDoseQuantity().getValue()))) {
                throw new IhrBadRequestException(MISSING_MED_DOSAGE_QV);
            }
            if (null == doseAndRateComponent.getDoseQuantity().getValue() && doseAndRateComponent.getDoseQuantity().hasUnit()) {
                throw new IhrBadRequestException(DOSE_QUANTITY_VALUE_REQUIRED);
            }
        }
    }

    private static void validateInformationSource(final MedicationStatement medicationStatement, FhirAttributesWrapper fhirAttributesWrapper) {
        validateInformationSourceReference(medicationStatement, fhirAttributesWrapper);
    }

    private static void validateInformationSourceReference(final MedicationStatement statement, final FhirAttributesWrapper fhirAttributesWrapper) {
        if (!(null != statement.getInformationSource()
                && null != statement.getInformationSource().getResource()
                && null != statement.getInformationSource().getIdElement()
                && StringUtils.isNotEmpty(statement.getInformationSource().getReferenceElement().getResourceType()))) {
            throw new IhrBadRequestException(INVALID_INFORMATIONSOURCE_REFERENCE);
        } else {
            IhrResourceValidator validator = informationSourceMap.get(ResourceType.valueOf
                    (statement.getInformationSource().getReferenceElement().getResourceType()));
            if (validator == null) {
                throw new IhrBadRequestException(INVALID_INFORMATIONSOURCE_REFERENCE);
            } else {
                validator.validate((Resource) statement.getInformationSource().getResource(), fhirAttributesWrapper);
            }
        }
    }

    private static boolean isMedicationEditableFieldAvailable(MedicationStatement medicationStatement) {
        //All editable dates , status code and status reason
        if (CollectionUtils.isNotEmpty(medicationStatement.getExtension()) &&
                isUrlValidForMedicationExtension(medicationStatement.getExtension())) {
            return true;
        }

        if (medicationStatement.hasEffectivePeriod()) {
            return true;
        }
        if (CollectionUtils.isNotEmpty(medicationStatement.getStatusReason()) &&
                CollectionUtils.isNotEmpty(medicationStatement.getStatusReason().get(0).getCoding()) &&
                null != medicationStatement.getStatusReason().get(0).getCoding().get(0)) {
            return true;
        }
        if (null != medicationStatement.getStatus() && null != medicationStatement.getStatus().toCode()) {
            return true;
        }
        return false;
    }

    public static void isDataAuthorIdentifierRequired(boolean assertedDateExists, boolean dataAuthorIdentifierExists) {
        if (assertedDateExists && !dataAuthorIdentifierExists) {
            throw new IhrBadRequestException(REQUIRED_DATA_AUTHOR_IDENTIFIER);
        }
    }

    public static void validateMedication(final Medication medication, final boolean recordKeyExists) {
        if (!recordKeyExists && !medication.hasCode() && !medication.hasIdentifier()) {
            throw new IhrBadRequestException(CONCEPT_CODE_REQUIRED);
        }
        if (medication.hasCode()) {
            CodeableConcept concept = medication.getCode();
            ValidationUtils.validateCoding(concept);
            validateSystemForMedication(concept);
        }
        if (medication.hasIdentifier()) {
            List<Identifier> identifiers = medication.getIdentifier();
            if (!(CollectionUtils.isNotEmpty(identifiers) && (identifiers.stream().allMatch(identifier ->
                    ValidationUtils.isIdentifierValid(identifier) &&
                            identifier.getType().getText().equals(Constant.CONCEPT_CHID))))) {
                throw new IhrBadRequestException(INVALID_IDENTIFIER);
            }
        }
    }

    private static void validateSystemForMedication(CodeableConcept concept) {
        List<Coding> codings = concept.getCoding();
        if (!(CollectionUtils.isNotEmpty(codings) && (codings.stream().allMatch(coding ->
                coding.getSystem().equals(MEDICATION_CODE_SYSTEM))))) {
            throw new IhrBadRequestException(MISSING_MEDICATION_CODE);
        }
    }

    public static boolean isUrlValidForMedicationExtension(List<Extension> extensions) {
        return extensions.stream().allMatch(extension ->
                extension.hasUrl() && (IHR_ADHERENCE_STOP_DATE_URL.equals(extension.getUrl())
                        || IHR_HOLD_DATE_URL.equals(extension.getUrl()) || TAKEN_AS_ORDERED_URL.equals(extension.getUrl())
                        || IHR_RESTART_DATE_URL.equals(extension.getUrl())) && null != extension.getValue());
    }

    public static boolean isActionFlagUpsert(List<Coding> tag) {
        if (CollectionUtils.isNotEmpty(tag) && tag.stream().allMatch(e -> ActionFlag.UPSERT.getValue().equals(e.getDisplay())
                && Constant.ACTION_FLAG.equals(e.getCode()))) {
            return true;
        }
        return false;
    }

    public static void medicationStatusReason(CodeableConcept concept) {
        ValidationUtils.validateCoding(concept);
        List<Coding> codings = concept.getCoding();
        if (codings.size() > 1) {
            throw new IhrBadRequestException(STATUS_REASON_CODING_ERROR);
        } else if (!codings.get(0).hasSystem()) {
            throw new IhrBadRequestException(MISSING_STATUS_REASON_SYSTEM);
        }
    }

    public static void validateMedicationReference(MedicationStatement medicationStatement, boolean recordKeyExists) {
        if (StringUtils.isNotEmpty(medicationStatement.getMedicationReference().getReference())){
            if(null == medicationStatement.getMedicationReference().getResource()) {
                throw new IhrBadRequestException(INVALID_MEDICATION_REFERENCE);
            }
        }
        if(!recordKeyExists && null == medicationStatement.getMedicationReference().getResource() ){
            throw new IhrBadRequestException(MEDICATION_REQUIRED);
        }
        if (null != medicationStatement.getMedicationReference().getResource() ){
            Medication medication = (Medication) medicationStatement.getMedicationReference().getResource();
            validateMedication(medication, recordKeyExists);
        }
    }

    @Override
    public void setReferenceIds(Set<String> resourceIds, Resource resource) {
        MedicationStatement statement = (MedicationStatement) resource;
        resourceIds.add(statement.getId());
        if (null != statement.getSubject().getResource()) {
            resourceIds.add(statement.getSubject().getReference());
        }
        if (null != statement.getMedicationReference().getResource()) {
            resourceIds.add(statement.getMedicationReference().getReference());
        }
        if (null != statement.getInformationSource().getResource()) {
            resourceIds.add(statement.getInformationSource().getReference());
        }
        if (CollectionUtils.isNotEmpty(statement.getNote())
                && null != statement.getNote().get(0).getAuthorReference().getResource()) {
            resourceIds.add(statement.getNote().get(0).getAuthorReference().getReference());
        }
    }
}
