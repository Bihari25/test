package com.uhg.ihr.centrihealth.api.model;

import com.uhg.ihr.centrihealth.api.util.AppUtils;
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Patient;

@NoArgsConstructor(staticName = "of")
public class PatientDecorator implements SenzingRequestDecorator<Patient> {

    @Override
    public SenzingRequest buildSenzingRequest(final Bundle.BundleEntryComponent entity, final SenzingRequest senzingRequest) {
        if (entity.getResource() instanceof Patient) {
            Patient patient = ((Patient) entity.getResource());
            SenzingRequest.buildRequestWithPatientData(AppUtils.toDateString(patient.getBirthDate()),
                    patient.getName().get(0).getGivenAsSingleString(), patient.getName().get(0).getFamily(), senzingRequest);
        }
        return senzingRequest;
    }
}
