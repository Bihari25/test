package com.uhg.ihr.centrihealth.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class KafkaPayload {

    @JsonProperty
    private String uuid;

    @JsonProperty
    private String interfaceType;

    @JsonProperty
    private String payload;

    @JsonProperty
    private String createTimestamp;

    @JsonProperty
    private String updateTimestamp;
}