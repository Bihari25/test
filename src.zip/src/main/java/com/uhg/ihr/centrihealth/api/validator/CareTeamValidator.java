package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.CareTeam;
import org.hl7.fhir.r4.model.Resource;

@NoArgsConstructor(staticName = "of")
public class CareTeamValidator implements IhrResourceValidator {
    private static final String INVALID_SUBJECT = "Can't process subject";
    private static final String INVALID_PARTICIPANT = "Can't process participant";
    private static final String INVALID_PATIENT_NOTE = "Can't process patient note";

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof CareTeam) {
            CareTeam careTeam = (CareTeam) resource;
            boolean isSfp = false;
            if (careTeam.getParticipant().size() > 0) {
                isSfp = ServiceFacilityProviderValidator.isServiceFacilityProvider(careTeam);
            }
            if (!isSfp) {
                validate(careTeam, null);
            }
        }
    }

    private void validate(final CareTeam careTeam, final FhirAttributesWrapper fhirAttributesWrapper) {
        //action flag
        ValidationUtils.validateActionFlag(careTeam.getMeta().getTag());
        //last updated date
        ValidationUtils.validateLastUpdatedDate(careTeam.getMeta().getLastUpdatedElement());
        //patient note
        if (!careTeam.getNote().isEmpty()) {
            throw new IhrBadRequestException(INVALID_PATIENT_NOTE);
        }
        boolean noteExists = careTeam.getNote().size() > 0;
        // Identifiers
        ValidationUtils.validateIdentifier(careTeam.getIdentifier(), noteExists);
        //subject
        if (!(careTeam.getSubject().isEmpty())) {
            throw new IhrBadRequestException(INVALID_SUBJECT);
        }
        //participant
        if (!(careTeam.getParticipant().isEmpty())) {
            throw new IhrBadRequestException(INVALID_PARTICIPANT);
        }
    }
}
