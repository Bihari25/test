package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.CareTeam;

@NoArgsConstructor
public class CareGiverValidator {
    private static final String INVALID_PATIENT_NOTE = "Can't process patient note";


    public static void validate(final CareTeam caregiver) {

        //validate action flag
        ValidationUtils.validateActionFlag(caregiver.getMeta().getTag());
        //validate last updated date
        ValidationUtils.validateLastUpdatedDate(caregiver.getMeta().getLastUpdatedElement());
        // validate patient note
        if (!caregiver.getNote().isEmpty() || caregiver.getNote() != null && caregiver.getNote().size() > 0) {
            throw new IhrBadRequestException(INVALID_PATIENT_NOTE);
        }

        // validate Identifiers (record key and RefId)
        boolean noteExists = caregiver.getNote().size() > 0;
        ValidationUtils.validateIdentifier(caregiver.getIdentifier(), noteExists);
    }
}