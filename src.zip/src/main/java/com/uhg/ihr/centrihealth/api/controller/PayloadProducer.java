package com.uhg.ihr.centrihealth.api.controller;

import io.micronaut.configuration.kafka.annotation.KafkaClient;
import io.micronaut.configuration.kafka.annotation.Topic;
import io.micronaut.context.annotation.Property;
import org.apache.kafka.clients.producer.ProducerConfig;

@KafkaClient(properties = {
        @Property(name = ProducerConfig.COMPRESSION_TYPE_CONFIG, value = "gzip"),
        @Property(name = ProducerConfig.MAX_REQUEST_SIZE_CONFIG, value = "150000000")
})
public interface PayloadProducer {
    @Topic("${topic.payload}")
    void sendPayload(String payload);
}