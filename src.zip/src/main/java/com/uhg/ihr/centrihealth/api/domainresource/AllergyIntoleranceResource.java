package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.AllergyIntolerance;
import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.Identifier;

import java.util.List;

@Slf4j
@Getter
@RequiredArgsConstructor(staticName = "of")
public class AllergyIntoleranceResource implements IhrResource<AllergyIntolerance> {

    final AllergyIntolerance allergyIntolerance;

    @Override
    public AllergyIntolerance getDomainResource() {
        return allergyIntolerance;
    }

    @Override
    public List<Annotation> getNote() {
        return allergyIntolerance.getNote();
    }

    @Override
    public AllergyIntolerance setNote(List<Annotation> notes) {
        return allergyIntolerance.setNote(notes);
    }

    @Override
    public List<Identifier> getIdentifiers() {
        return allergyIntolerance.getIdentifier();
    }

    @Override
    public AllergyIntolerance addIdentifier(Identifier identifier) {
        return allergyIntolerance.addIdentifier(identifier);
    }
}