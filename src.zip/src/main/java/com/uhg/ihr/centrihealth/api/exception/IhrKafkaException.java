package com.uhg.ihr.centrihealth.api.exception;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class IhrKafkaException extends RuntimeException {
    public IhrKafkaException(String message) {
        super(message);
    }
}