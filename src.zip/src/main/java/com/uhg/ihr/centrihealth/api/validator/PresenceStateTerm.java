package com.uhg.ihr.centrihealth.api.validator;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

public enum PresenceStateTerm {

    PRESENT("Present"),
    NOT_PRESENT("Not Present"),
    PAST_OCCURRENCE("Past Occurrence"),
    PLANNED_OCCURRENCE("Planned Occurrence");

    PresenceStateTerm(String value) {
        this.value = value;
    }

    private String value;
    public String getValue() {
        return value;
    }

    protected static final Set<String> ENUM_VALUES = Arrays.stream(PresenceStateTerm.values())
            .map(PresenceStateTerm::getValue)
            .collect(Collectors.toSet());
}
