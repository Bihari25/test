package com.uhg.ihr.centrihealth.api.exception;

import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.server.exceptions.ExceptionHandler;

import javax.inject.Singleton;

@Produces
@Singleton
@Requires(classes = {HttpResponseException.class, ExceptionHandler.class})
public class HttpResponseExceptionHandler implements ExceptionHandler<HttpResponseException, HttpResponse> {

    @Override
    public HttpResponse handle(HttpRequest request, HttpResponseException exception) {
        if (HttpStatus.UNPROCESSABLE_ENTITY.getCode() == exception.getStatusCode()) {
            return HttpResponse.status(HttpStatus.UNPROCESSABLE_ENTITY, exception.getMessage());
        }
        return HttpResponse.status(HttpStatus.BAD_REQUEST, exception.getMessage());
    }

}
