package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Value;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.PractitionerRole;

@Value(staticConstructor = "of")
public class PractitionerRoleResourceMapper implements IhrResourceMapper<PractitionerRole> {

    public IhrResource<?> createDomainResource(final Bundle.BundleEntryComponent entity) {

        if (!(entity.getResource() instanceof PractitionerRole)) {
            return PractitionerRoleResource.of(null);
        }
        PractitionerRoleResource newResource = PractitionerRoleResource.of(new PractitionerRole());
        PractitionerRoleResource oldResource = PractitionerRoleResource.of((PractitionerRole) entity.getResource());
        newResource.getDomainResource().setCode(oldResource.getDomainResource().getCode());
        newResource.getDomainResource().setId(oldResource.getDomainResource().getId());
        return newResource;
    }
}
