package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import io.micronaut.core.util.CollectionUtils;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Coverage;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Resource;

import java.util.List;
import java.util.Set;

@NoArgsConstructor(staticName = "of")
public class CoverageValidator implements IhrReferenceValidator {
    private static final String MISSING_IDENTIFIER_VALUE = "Missing value for Identifier";
    private static final String MISSING_SEARCH_ID = "Missing Search Id";

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Coverage) {
            validate((Coverage) resource, null);
        }
    }

    private static void validate(final Coverage coverage, final FhirAttributesWrapper fhirAttributesWrapper) {
        List<Identifier> identifiers = coverage.getIdentifier();
        if (CollectionUtils.isEmpty(identifiers)) {
            throw new IhrBadRequestException(ValidationUtils.REQUIRED_IDENTIFIER);
        }
        boolean searchIdAvailable = false;
        for (Identifier identifier : identifiers) {
            if (!CoverageEnum.COVERAGE_ENUMS.contains(identifier.getType().getText())) {
                throw new IhrBadRequestException(ValidationUtils.INVALID_IDENTIFIER_KEY);
            }
            if (!ValidationUtils.isIdentifierValid(identifier)) {
                throw new IhrBadRequestException(MISSING_IDENTIFIER_VALUE);
            }
            if (identifier.getType().getText().equalsIgnoreCase(CoverageEnum.SEARCH_ID.getValue())) {
                searchIdAvailable = true;
            }
        }
        if (!searchIdAvailable) {
            throw new IhrBadRequestException(MISSING_SEARCH_ID);
        }
    }

    @Override
    public void setReferenceIds(Set<String> resourceIds, Resource resource) {
        if (resource instanceof Coverage) {
            resourceIds.add(resource.getId());
        }
    }
}
