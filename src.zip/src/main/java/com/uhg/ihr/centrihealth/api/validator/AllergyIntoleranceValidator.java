package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.util.Constant;
import io.micronaut.core.util.CollectionUtils;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.AllergyIntolerance;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.Resource;
import org.hl7.fhir.r4.model.ResourceType;
import org.hl7.fhir.r4.model.codesystems.AllergyIntoleranceType;

import java.util.List;
import java.util.Set;

@NoArgsConstructor(staticName = "of")
public class AllergyIntoleranceValidator implements IhrReferenceValidator {

    private static final String INVALID_PRACTITIONER_REFERENCE_ID = "Invalid practitioner employeeId found";
    private static final String INVALID_PATIENT_REFERENCE = "Invalid patient reference found";
    private static final String INVALID_PRACTITIONER_REFERENCE = "Invalid practitioner reference found";
    private static final String INVALID_PERIOD = "Invalid start date or end date format ";
    private static final String RECORDED_DATE_ERROR = "Recorded date to be required as  lastupdated is  present";
    private static final String ALLERGY_CODE_REQUIRED = "Allergy code is required as record key does not exists";
    private static final String ALLERGY_REACTION_REQUIRED = "Allergy reaction is required as allergy code does not exists";
    private static final String MISSING_INFORMATION_SOURCE = "Missing information source";
    private static final String MISSING_INFORMATION_TEXT = "Missing/Incorrect information source text";
    private static final String UPSERT_ACTION_FLAG_ERROR = "No other action flag is allowed other than Upsert";
    private static final String ALLERGY_REACTION_IS_REQUIRED = "Allergy reaction is required with recordKey";
    private static final String MANIFESTATION_CODE_MISSSING = "Manifestation code is missing";
    private static final String INVALID_RECORDED_DATE = "Invalid recorded date found";

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof AllergyIntolerance) {
            validate((AllergyIntolerance) resource, null);
        }
    }

    public void validate(final AllergyIntolerance allergyIntolerance, final FhirAttributesWrapper fhirAttributesWrapper) {

        //action flag
        ValidationUtils.validateActionFlag(allergyIntolerance.getMeta().getTag());

        //validate meta
        ValidationUtils.validateLastUpdatedDate(allergyIntolerance.getMeta().getLastUpdatedElement());

        //Identifiers
        ValidationUtils.validateRecordKey(allergyIntolerance.getIdentifier());

        //Is record key exist
        boolean recordKeyExists = ValidationUtils.isRequiredIdentifierExists(allergyIntolerance.getIdentifier(),
                IdentifierEnum.RECORD_KEY.getValue());

        //Allergy code validation
        ValidationUtils.validateCoding(allergyIntolerance.getCode());

        //recorded date
        if (allergyIntolerance.getRecordedDate() != null
                && null == ValidationUtils.toDate(allergyIntolerance.getRecordedDateElement().asStringValue())) {
            throw new IhrBadRequestException(INVALID_RECORDED_DATE);
        }

        if (null != allergyIntolerance.getAsserter()
                && null != allergyIntolerance.getAsserter().getReference()) {
            validateAsserter((Resource) allergyIntolerance.getAsserter().getResource(), fhirAttributesWrapper);
        }

        //patient
        if (allergyIntolerance.getPatient() != null) {
            if (allergyIntolerance.getPatient().getResource() instanceof Patient) {
                Patient patient = (Patient) allergyIntolerance.getPatient().getResource();
                PatientValidator.of().validate(patient, fhirAttributesWrapper);
            } else {
                throw new IhrBadRequestException(INVALID_PATIENT_REFERENCE);
            }
        }

        //recorder
        if (allergyIntolerance.getRecorder() != null) {
            if (allergyIntolerance.getRecorder().getResource() instanceof Practitioner) {
                Practitioner practitioner = (Practitioner) allergyIntolerance.getRecorder().getResource();
                boolean isEmployeeIdExists = ValidationUtils.isRequiredIdentifierExists(practitioner.getIdentifier(), IdentifierEnum.EMPLOYEE_ID.getValue());
                if (!isEmployeeIdExists) {
                    throw new IhrBadRequestException(INVALID_PRACTITIONER_REFERENCE_ID);
                }
            } else {
                throw new IhrBadRequestException(INVALID_PRACTITIONER_REFERENCE);
            }
        }

        //recorded date
        boolean recordedDateExists = allergyIntolerance.getRecordedDateElement().hasValue();
        boolean lastUpdateDateExist = allergyIntolerance.getMeta().getLastUpdatedElement().hasValue();

        if (lastUpdateDateExist && !recordedDateExists) {
            throw new IhrBadRequestException(RECORDED_DATE_ERROR);
        }

        //related Allergy type
        if (null != allergyIntolerance.getType()) {
            AllergyIntoleranceType.fromCode(allergyIntolerance.getType().toString().toLowerCase());
        }

        if (!isActionFlagUpsert(allergyIntolerance.getMeta().getTag())) {
            throw new IhrBadRequestException(UPSERT_ACTION_FLAG_ERROR);
        }

        //allergy code is required if no recordKey
        validateAllergyCode(allergyIntolerance, recordKeyExists);

        //allergyIntolerance has code then reaction is required
        validateAllergyReaction(allergyIntolerance);

        //recordkey exist reaction is validated
        validateReactionManifestation(allergyIntolerance, recordKeyExists);

        //onsetPeriod date
        if (null != allergyIntolerance.getOnsetPeriod()
                && ((allergyIntolerance.getOnsetPeriod().getStart() == null ? false
                : null == ValidationUtils.toDate(allergyIntolerance.getOnsetPeriod().getStartElement().asStringValue()))
                || (allergyIntolerance.getOnsetPeriod().getEnd() == null ? false
                : null == ValidationUtils.toDate(allergyIntolerance.getOnsetPeriod().getEndElement().asStringValue())))) {
            throw new IhrBadRequestException(INVALID_PERIOD);
        }

        //asserter validation
        if (null != allergyIntolerance.getAsserter()
                && null != allergyIntolerance.getAsserter().getReference()) {
            validateAsserter((Resource) allergyIntolerance.getAsserter().getResource(), fhirAttributesWrapper);
        }
    }

    public static boolean isActionFlagUpsert(List<Coding> tag) {
        return CollectionUtils.isNotEmpty(tag)
                && tag.stream().allMatch(e -> ActionFlag.UPSERT.getValue().equals(e.getDisplay())
                && Constant.ACTION_FLAG.equals(e.getCode()));
    }

    //if no record key is present, this field is required
    public static void validateAllergyCode(AllergyIntolerance allergyIntolerance, boolean recordKeyExists) {
        if (!recordKeyExists) {
            if (!allergyIntolerance.hasCode()) {
                throw new IhrBadRequestException(ALLERGY_CODE_REQUIRED);
            }
            ValidationUtils.validateCoding(allergyIntolerance.getCode());
        }
    }

    public static void validateReactionManifestation(AllergyIntolerance allergyIntolerance, boolean recordKeyExists) {
        if (recordKeyExists) {
            if (allergyIntolerance.hasReaction()) {
                validateAllergyManifestation(allergyIntolerance);
            } else {
                throw new IhrBadRequestException(ALLERGY_REACTION_IS_REQUIRED);
            }
        }
    }

    //If an allergyIntolerance Code is received, reaction is required
    //while parsing in begining this severity validation done
    public static void validateAllergyReaction(AllergyIntolerance allergyIntolerance) {
        if (allergyIntolerance.hasCode()) {
            if (allergyIntolerance.hasReaction()) {
                validateAllergyManifestation(allergyIntolerance);
            } else {
                throw new IhrBadRequestException(ALLERGY_REACTION_REQUIRED);
            }
        }
    }

    //manifestation validation
    public static void validateAllergyManifestation(AllergyIntolerance allergyIntolerance) {
        for (AllergyIntolerance.AllergyIntoleranceReactionComponent reactionComponent : allergyIntolerance.getReaction()) {
            if (CollectionUtils.isEmpty(reactionComponent.getManifestation())) {
                throw new IhrBadRequestException(MANIFESTATION_CODE_MISSSING);
            }
            for (CodeableConcept manifestation : reactionComponent.getManifestation()) {
                ValidationUtils.validateCoding(manifestation);
            }
        }
    }

    public static void validateAsserter(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (!(resource.getResourceType().toString().equals(ResourceType.RelatedPerson.toString())
                && CollectionUtils.isNotEmpty(((RelatedPerson) resource).getRelationship()) ||
                (resource.getResourceType().toString().equals(ResourceType.PractitionerRole.toString())
                        && CollectionUtils.isNotEmpty(((PractitionerRole) resource).getCode()))
                || resource.getResourceType().toString().equals(ResourceType.Patient.toString()))) {
            throw new IhrBadRequestException(MISSING_INFORMATION_SOURCE);
        } else {
            validateAsserterResource(resource, fhirAttributesWrapper);
        }
    }

    private static void validateAsserterResource(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource.getResourceType().toString().equals(ResourceType.RelatedPerson.toString())) {
            validateAsserterCode(((RelatedPerson) resource).getRelationship(),
                    RelatedPersonInfoCodeEnum.RELATED_PERSON_CODES);
        } else if (resource.getResourceType().toString().equals(ResourceType.PractitionerRole.toString())) {
            validateAsserterCode(((PractitionerRole) resource).getCode(), PractitionerRoleInfoCodeEnum.PRACTITIONER_ROLE_CODES);
        } else {
            PatientValidator.of().validate(resource, fhirAttributesWrapper);
        }
    }

    private static void validateAsserterCode(List<CodeableConcept> concepts,
                                             Set<String> codes) {
        if (!(CollectionUtils.isNotEmpty(concepts) && (concepts.stream().allMatch(concept ->
                codes.contains(concept.getText()))))) {
            throw new IhrBadRequestException(MISSING_INFORMATION_TEXT);
        }
    }

    @Override
    public void setReferenceIds(Set<String> resourceIds, Resource resource) {
        AllergyIntolerance statement = (AllergyIntolerance) resource;
        resourceIds.add(statement.getId());
        if (null != statement.getPatient().getResource()) {
            resourceIds.add(statement.getPatient().getReference());
        }
        if (null != statement.getRecorder().getResource()) {
            resourceIds.add(statement.getRecorder().getReference());
        }
    }
}