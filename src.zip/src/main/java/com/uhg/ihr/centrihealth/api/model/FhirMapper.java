package com.uhg.ihr.centrihealth.api.model;

import ca.uhn.fhir.context.FhirContext;
import com.google.common.collect.ImmutableMap;
import com.uhg.ihr.centrihealth.api.domainresource.AllergyIntoleranceResourceMapper;
import com.uhg.ihr.centrihealth.api.domainresource.ConditionResourceMapper;
import com.uhg.ihr.centrihealth.api.domainresource.CoverageResourceMapper;
import com.uhg.ihr.centrihealth.api.domainresource.IhrResource;
import com.uhg.ihr.centrihealth.api.domainresource.IhrResourceMapper;
import com.uhg.ihr.centrihealth.api.domainresource.MedicationResourceMapper;
import com.uhg.ihr.centrihealth.api.domainresource.MedicationStatementResourceMapper;
import com.uhg.ihr.centrihealth.api.domainresource.PatientResourceMapper;
import com.uhg.ihr.centrihealth.api.domainresource.PractitionerResourceMapper;
import com.uhg.ihr.centrihealth.api.domainresource.PractitionerRoleResourceMapper;
import com.uhg.ihr.centrihealth.api.domainresource.ProvenanceResourceMapper;
import com.uhg.ihr.centrihealth.api.domainresource.RelatedPersonResourceMapper;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.validator.AllergyIntoleranceValidator;
import com.uhg.ihr.centrihealth.api.validator.CoverageEnum;
import com.uhg.ihr.centrihealth.api.validator.CoverageValidator;
import com.uhg.ihr.centrihealth.api.validator.IhrReferenceValidator;
import com.uhg.ihr.centrihealth.api.validator.MedicationStatementValidator;
import com.uhg.ihr.centrihealth.api.validator.PatientValidator;
import com.uhg.ihr.centrihealth.api.validator.ProvenanceValidator;
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coverage;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Resource;
import org.hl7.fhir.r4.model.ResourceType;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@NoArgsConstructor
public class FhirMapper {

    public static final FhirContext FHIR_CONTEXT = FhirContext.forR4();

    public static final Map<ResourceType, IhrResourceMapper<?>> RESOURCE_MAPPERS =
            ImmutableMap.<ResourceType, IhrResourceMapper<?>>builder()
                    .put(ResourceType.AllergyIntolerance, AllergyIntoleranceResourceMapper.of())
                    .put(ResourceType.Condition, ConditionResourceMapper.of())
                    .put(ResourceType.MedicationStatement, MedicationStatementResourceMapper.of())
                    .put(ResourceType.Medication, MedicationResourceMapper.of())
                    .put(ResourceType.Patient, PatientResourceMapper.of())
                    .put(ResourceType.PractitionerRole, PractitionerRoleResourceMapper.of())
                    .put(ResourceType.RelatedPerson, RelatedPersonResourceMapper.of())
                    .put(ResourceType.Practitioner, PractitionerResourceMapper.of())
                    .put(ResourceType.Coverage, CoverageResourceMapper.of())
                    .put(ResourceType.Provenance, ProvenanceResourceMapper.of())
                    .build();

    public static final Map<ResourceType, IhrReferenceValidator> referenceValidatorMap = ImmutableMap.<ResourceType, IhrReferenceValidator>builder()
            .put(ResourceType.Patient, PatientValidator.of())
            .put(ResourceType.Coverage, CoverageValidator.of())
            .put(ResourceType.MedicationStatement, MedicationStatementValidator.of())
            .put(ResourceType.AllergyIntolerance, AllergyIntoleranceValidator.of())
            .put(ResourceType.Provenance, ProvenanceValidator.of())
            .build();

    public static final Set<ResourceType> MAPPABLE_TYPES = RESOURCE_MAPPERS.keySet();

    public static final Set<ResourceType> ALLOWED_RESOURCE_TYPES = Stream.of(ResourceType.AllergyIntolerance, ResourceType.Condition, ResourceType.MedicationStatement).collect(Collectors.toSet());

    public static final Set<ResourceType> REQUIRED_RESOURCE_TYPES = Stream.of(ResourceType.Patient, ResourceType.Coverage,
            ResourceType.Provenance).collect(Collectors.toSet());

    public static final Map<ResourceType, SenzingRequestDecorator<?>> SENZING_RESOURCE_MAPPERS =
            ImmutableMap.<ResourceType, SenzingRequestDecorator<?>>builder()
                    .put(ResourceType.Patient, PatientDecorator.of())
                    .put(ResourceType.Coverage, CoverageDecorator.of())
                    .put(ResourceType.Practitioner, PractitionerDecorator.of())
                    .build();

    public static String bundleToString(Bundle bundle) {
        return FHIR_CONTEXT.newJsonParser().encodeResourceToString(bundle);
    }

    public static final Set<ResourceType> SENZING_MAPPABLE_TYPES = SENZING_RESOURCE_MAPPERS.keySet();

    public static SenzingRequest buildSenzingRequest(Bundle bundle) {
        SenzingRequest senzingRequest = new SenzingRequest();
        for (Bundle.BundleEntryComponent entity : bundle.getEntry()) {
            if (SENZING_MAPPABLE_TYPES.contains(entity.getResource().getResourceType())) {
                SenzingRequestDecorator senzingRequestDecorator = SENZING_RESOURCE_MAPPERS.get(entity.getResource().getResourceType());

                if (senzingRequestDecorator == null) {
                    log.debug("no decorator for resource type {}", entity.getResource().getResourceType());
                } else {
                    senzingRequest = senzingRequestDecorator.buildSenzingRequest(entity, senzingRequest);
                }
            }
        }
        return senzingRequest;
    }

    public static String createIngestBundleJson(Bundle fhirBundle, List<ActorIds> actorIdsList) {
        //This set contains only valid references and not resource without any references
        Set<String> statementReferenceIds = getReferenceIdsForResources(fhirBundle, actorIdsList);
        List<Bundle.BundleEntryComponent> resourceList = fhirBundle.getEntry().stream()
                .filter(entity -> MAPPABLE_TYPES.contains(entity.getResource().getResourceType())
                        && statementReferenceIds.contains(entity.getResource().getId()))
                .map(FhirMapper::convertResourceToIhrBundleEntry)
                .collect(Collectors.toList());
        Bundle ingestBundle = new Bundle();
        ingestBundle.setEntry(resourceList);
        return FhirMapper.bundleToString(ingestBundle);
    }

    public static Bundle.BundleEntryComponent convertResourceToIhrBundleEntry(Bundle.BundleEntryComponent entity) {
        IhrResourceMapper<?> mapper = RESOURCE_MAPPERS.get(entity.getResource().getResourceType());
        if (mapper != null) {
            IhrResource<?> resource = mapper.createIhrResource(entity);
            Bundle.BundleEntryComponent entry = new Bundle.BundleEntryComponent();
            entry.setResource(resource.getDomainResource());
            return entry;
        }
        throw new IhrBadRequestException("unable to map resource" + entity.getResource().getResourceType());
    }

    public static Set<String> getReferenceIdsForResources(Bundle bundle, List<ActorIds> actorIdsList) {
        Set<String> resourceIds = new HashSet<>();
        for (Bundle.BundleEntryComponent entity : bundle.getEntry()) {
            Resource resource = entity.getResource();
            IhrReferenceValidator referenceValidator = referenceValidatorMap.get(resource.getResourceType());

            if (referenceValidator == null) {
                log.debug("no reference validator for resource type {}", resource.getResourceType());
            } else {
                referenceValidator.setReferenceIds(resourceIds, resource);
            }
            if (entity.getResource() instanceof Coverage) {
                processCoverage((Coverage) entity.getResource(), actorIdsList);
            }
        }
        return resourceIds;
    }

    public static void processCoverage(Coverage coverage, List<ActorIds> actorIdsList) {
        Optional<ActorIds> actorId = actorIdsList.stream().
                filter(e -> ResourceType.Patient.toString().equalsIgnoreCase(e.getActorIdType())).findFirst();
        coverage.getIdentifier().add(new Identifier()
                .setType(new CodeableConcept().setText(CoverageEnum.ACTOR_ID.getValue()))
                .setValue(actorId.isPresent() ? actorId.get().getActorId() : ""));
    }
}
