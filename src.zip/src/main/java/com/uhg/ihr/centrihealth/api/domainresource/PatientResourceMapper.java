package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Value;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Patient;

@Value(staticConstructor = "of")
public class PatientResourceMapper implements IhrResourceMapper<Patient> {

    public IhrResource<?> createDomainResource(final Bundle.BundleEntryComponent entity) {

        if (!(entity.getResource() instanceof Patient)) {
            return PatientResource.of(null);
        }
        PatientResource newResource = PatientResource.of(new Patient());
        PatientResource oldResource = PatientResource.of((Patient) entity.getResource());
        newResource.getDomainResource().setBirthDate(oldResource.getDomainResource().getBirthDate());
        newResource.getDomainResource().setName(oldResource.getDomainResource().getName());
        newResource.getDomainResource().setId(oldResource.getDomainResource().getId());
        return newResource;
    }
}
