package com.uhg.ihr.centrihealth.api.model;

import com.uhg.ihr.centrihealth.api.util.Constant;
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Coverage;
import org.hl7.fhir.r4.model.Identifier;

@Slf4j
@NoArgsConstructor(staticName = "of")
public class CoverageDecorator implements SenzingRequestDecorator<Coverage> {
    @Override
    public SenzingRequest buildSenzingRequest(final Bundle.BundleEntryComponent entity, final SenzingRequest senzingRequest) {
        if (entity.getResource() instanceof Coverage) {
            Coverage coverage = (Coverage) entity.getResource();
            for (Identifier identifier : coverage.getIdentifier()) {
                if (identifier.getType() != null) {
                    if (Constant.SEARCH_ID.equals(identifier.getType().getText())) {
                        senzingRequest.setSearchId(identifier.getValue());
                    }
                    else if (Constant.CORRELATION_ID.equals(identifier.getType().getText())) {
                        log.info(Constant.CORRELATION_ID + ": {}", identifier.getValue());
                    }
                }
            }
        }
        return senzingRequest;
    }
}
