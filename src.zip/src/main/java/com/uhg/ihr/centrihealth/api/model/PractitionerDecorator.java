package com.uhg.ihr.centrihealth.api.model;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils;
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest;
import io.micronaut.core.util.StringUtils;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Practitioner;


@Slf4j
@NoArgsConstructor(staticName = "of")
public class PractitionerDecorator implements SenzingRequestDecorator<Practitioner> {
    private static final String EMPLOYEE_ID_LENGTH_MISMATCH = "EmployeeId  must be 9 digit Characters";

    @Override
    public SenzingRequest buildSenzingRequest(final Bundle.BundleEntryComponent entity, final SenzingRequest senzingRequest) {
        if (entity.getResource() instanceof Practitioner) {
            Practitioner practitioner = (Practitioner) entity.getResource();
            String employeeId = ValidationUtils.getEmployeeId(practitioner.getIdentifier());

            if (StringUtils.isNotEmpty(employeeId)) {
                validateEmployeeIdLength(employeeId);
                senzingRequest.setEmpId(employeeId);
            }
            if (StringUtils.isEmpty(employeeId)) {
                String npi = ValidationUtils.getNpiId(practitioner.getIdentifier());
                senzingRequest.setEmpId(npi);
            }
        }
        return senzingRequest;
    }

    private void validateEmployeeIdLength(String employeeId) {
        if (!(employeeId.trim().length() == 9)) {
            throw new IhrBadRequestException(EMPLOYEE_ID_LENGTH_MISMATCH);
        }
    }
}