package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import io.micronaut.core.util.CollectionUtils;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Observation;
import org.hl7.fhir.r4.model.Resource;

@NoArgsConstructor(staticName = "of")
public class ObservationValidator implements IhrResourceValidator {

    private static final String INVALID_OBSERVATION_EXTENSION = "Can't process observation extension";
    private static final String INVALID_OBSERVATION_CODE = "Can't process observation code";
    private static final String INVALID_EFFECTIVE_DATE = "Can't process effective date time";
    private static final String INVALID_VALUE_STRING = "Can't process value string";
    private static final String INVALID_REFERENCE_RANGE = "Can't process reference range";
    private static final String INVALID_COMPONENT = "Can't process component";

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Observation) {
            validate((Observation) resource, null);
        }
    }

    private void validate(final Observation observation, final FhirAttributesWrapper fhirAttributesWrapper) {

        //action flag
        ValidationUtils.validateActionFlag(observation.getMeta().getTag());
        //last updated date
        ValidationUtils.validateLastUpdatedDate(observation.getMeta().getLastUpdatedElement());
        boolean noteExists = observation.getNote().size() > 0;
        // Identifiers
        ValidationUtils.validateIdentifier(observation.getIdentifier(), noteExists);
        // validate Note
        ValidationUtils.isValidNote(observation.getNote());

        //Extension
        if (CollectionUtils.isNotEmpty(observation.getExtension())) {
            throw new IhrBadRequestException(INVALID_OBSERVATION_EXTENSION);
        }
        //observation code
        if (!(observation.getCode()).isEmpty()) {
            throw new IhrBadRequestException(INVALID_OBSERVATION_CODE);
        }
        // effective date time
        if (observation.getEffective() != null) {
            throw new IhrBadRequestException(INVALID_EFFECTIVE_DATE);
        }
        // value string
        if (observation.getValue() != null) {
            throw new IhrBadRequestException(INVALID_VALUE_STRING);
        }
        // reference range
        if (!(observation.getReferenceRange().isEmpty())) {
            throw new IhrBadRequestException(INVALID_REFERENCE_RANGE);
        }
        // component
        if (!(observation.getComponent().isEmpty())) {
            throw new IhrBadRequestException(INVALID_COMPONENT);
        }
    }
}
