package com.uhg.ihr.centrihealth.senzing.model;

import io.micronaut.context.annotation.Property;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * SenzingProperties class used to map senzing properties from yml/yaml file.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
@Data
@NoArgsConstructor
public class SenzingProperties {

    @Property(name = "senzing.subject")
    private String subject;

    @Property(name = "senzing.duration")
    private Long duration;

    @Property(name = "senzing.secretKey")
    private String secretKey;

    @Property(name = "senzing.roles")
    private List<String> roles;

    @Property(name = "senzing.audience")
    private String audience;

}