package com.uhg.ihr.centrihealth.api.domainresource;

import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.DomainResource;
import org.hl7.fhir.r4.model.Identifier;

import java.util.List;

public interface IhrResource<T extends DomainResource> {

    /**
     * @return Provides extra information about the specific domain resource that is not conveyed by the other attributes.
     */
    List<Annotation> getNote();

    /**
     * Sets the extra information about the specific domain resource that is not conveyed by the other attributes.
     */
    T setNote(List<Annotation> notes);

    /**
     * @return Identifiers associated with a specific domain resource that are defined by business processes and/or used to refer to it when a direct URL reference to the resource itself is not appropriate. They are business identifiers assigned to this resource by the performer or other systems and remain constant as the resource is updated and propagates from server to server.
     */
    List<Identifier> getIdentifiers();

    /**
     * Add an identifiers associated with a specific domain resource that are defined by business processes and/or used to refer to it when a direct URL reference to the resource itself is not appropriate. They are business identifiers assigned to this resource by the performer or other systems and remain constant as the resource is updated and propagates from server to server.
     */
    T addIdentifier(Identifier identifier);

    /**
     * @return A specific resource that includes narrative, extensions, and contained resources.
     */
    T getDomainResource();
}
