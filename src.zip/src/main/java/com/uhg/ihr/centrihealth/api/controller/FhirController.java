package com.uhg.ihr.centrihealth.api.controller;

import com.uhg.ihr.centrihealth.api.exception.HttpResponseException;
import com.uhg.ihr.centrihealth.api.exception.IhrFhirParseException;
import com.uhg.ihr.centrihealth.api.exception.IhrKafkaException;
import com.uhg.ihr.centrihealth.api.exception.IhrNotFoundException;
import com.uhg.ihr.centrihealth.api.logging.LoggingFilter;
import com.uhg.ihr.centrihealth.api.model.ActorIdType;
import com.uhg.ihr.centrihealth.api.model.FhirMapper;
import com.uhg.ihr.centrihealth.api.security.SenzingTokenHelper;
import com.uhg.ihr.centrihealth.api.service.SenzingService;
import com.uhg.ihr.centrihealth.api.util.KafkaPayloadUtils;
import com.uhg.ihr.centrihealth.api.validator.FhirValidator;
import com.uhg.ihr.centrihealth.senzing.model.SenzingProperties;
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest;
import io.micronaut.context.annotation.Context;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Put;
import io.micronaut.security.annotation.Secured;
import io.micronaut.security.rules.SecurityRule;
import io.micronaut.validation.Validated;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Bundle;

import javax.inject.Inject;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Validated
@Context
@Controller("/bundles/v1")
@Secured(SecurityRule.IS_ANONYMOUS) //TODO: figure how how to move stargateJwtFilter to the new auth model
public class FhirController {
    private static final String CONTENT_MEDIA_TYPE = MediaType.APPLICATION_JSON + ";charset=utf-8";
    private static final String RESPONSE_HEADER = "X-UHG-Media-Type";
    private static final String SENZING = "senzing";
    private static final String SENZING_MSID = "senzingMsid";
    public static final String OPTUM_CID_EXT = "optum-cid-ext";
    private final SenzingProperties senzingProperties;

    @Inject
    private SenzingService senzingService;

    @Inject
    private PayloadProducer producer;

    public FhirController(final SenzingProperties senzingProperties) {

        this.senzingProperties = senzingProperties;

        log.info("initialized the API controller with SENZING_SUBJECT set to {}", senzingProperties.getSubject());

        if ("FIXME".equals(senzingProperties.getSecretKey())) {
            log.error("senzing secret key is not set");
        }
    }

    @Put(produces = CONTENT_MEDIA_TYPE, consumes = CONTENT_MEDIA_TYPE)
    public Maybe<MutableHttpResponse<?>> readBundle(final HttpRequest<String> request, @Body String bundleJsonString) {

        try {
            Bundle fhirBundle = FhirValidator.parseAndValidateBundle(bundleJsonString);

            SenzingRequest senzingRequest = FhirMapper.buildSenzingRequest(fhirBundle);
            LoggingFilter.logSenzingRequest(request, senzingRequest);
            String senzingToken = SenzingTokenHelper.generateToken(senzingProperties.getSubject(), null, senzingProperties.getAudience(),
                    new Date(), senzingProperties.getDuration(), senzingProperties.getRoles(), senzingProperties.getSecretKey());

            return getEmpIDAndSenzingMatch(request, senzingRequest, senzingToken)
                    .flatMap(ids -> buildKafkaRequest(ids, fhirBundle))
                    .flatMap(i -> Maybe.just(HttpResponse.accepted()
                            .header(RESPONSE_HEADER, CONTENT_MEDIA_TYPE)
                            .header(HttpHeaders.CONTENT_TYPE, CONTENT_MEDIA_TYPE)));

        } catch (Exception e) {
            LoggingFilter.logFail(request, "bundles", e.getMessage());

            if (e instanceof HttpResponseException) {
                HttpResponseException hrp = (HttpResponseException) e;
                throw new HttpResponseException(hrp.getStatusCode(), hrp.getMessage());
            }

            throw new IhrFhirParseException("unable to parse bundle " + bundleJsonString, e.getMessage());
        }
    }

    public Maybe<Map<ActorIdType, String>> getSenzingMatch(final HttpRequest<String> request, final SenzingRequest senzingRequest, final String token, final Map<ActorIdType, String> actorIdMap) {
        return senzingService.b50filterIhrId(token, senzingRequest, request.getHeaders().get(OPTUM_CID_EXT))
                .doOnSubscribe(sub -> LoggingFilter.logStart(request, SENZING))
                .flatMap(ihrIdResponse -> {
                    actorIdMap.put(ActorIdType.PATIENT, ihrIdResponse);
                    LoggingFilter.logSuccess(request, SENZING);
                    return Maybe.just(actorIdMap);
                })
                .onErrorResumeNext(e -> {
                    LoggingFilter.logFail(request, SENZING, e.getMessage());
                    return Maybe.error(new IhrNotFoundException("unable to match user: " + e.getMessage()));
                });
    }

    public Maybe<Map<ActorIdType, String>> getEmpIDAndSenzingMatch(final HttpRequest<String> request, final SenzingRequest senzingRequest, final String token) {
        Map<ActorIdType, String> actorIdMap = new HashMap<>();

        if (null == senzingRequest.getEmpId()) {
            return getSenzingMatch(request, SenzingRequest.buildRequestWithSearchId(senzingRequest), token, actorIdMap);
        }

        return senzingService.b50filterIhrId(token, SenzingRequest.buildRequestWithEmpId(senzingRequest), request.getHeaders().get(OPTUM_CID_EXT))
                .doOnSubscribe(sub -> LoggingFilter.logStart(request, SENZING_MSID))
                .onErrorResumeNext(e -> {
                    LoggingFilter.logFail(request, SENZING_MSID, e.getMessage());
                    return Maybe.error(new IhrNotFoundException("unable to match EmployeeId user: " + e.getMessage()));
                })
                .flatMap(ihrIdResponse -> {
                    actorIdMap.put(ActorIdType.AUTHOR, ihrIdResponse);
                    LoggingFilter.logSuccess(request, SENZING_MSID);
                    return getSenzingMatch(request, SenzingRequest.buildRequestWithSearchId(senzingRequest), token, actorIdMap);
                });
    }

    private void postMessage(String bundle) {
        try {
            producer.sendPayload(bundle);
        } catch (Exception ex) {
            log.error("Kafka processing exception : {}", ex.getMessage());
            throw new IhrKafkaException(ex.getMessage());
        }
    }

    private Maybe<Boolean> buildKafkaRequest(Map<ActorIdType, String> map, Bundle fhirBundle) {
        try {
            String jsonMessage = KafkaPayloadUtils.getBundleJsonString(map, fhirBundle);
            postMessage(jsonMessage);
            return Maybe.just(true);
        } catch (Exception jpe) {
            throw new IhrKafkaException(jpe.getMessage());
        }
    }
}
