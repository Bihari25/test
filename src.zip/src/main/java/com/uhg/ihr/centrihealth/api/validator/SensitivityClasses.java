package com.uhg.ihr.centrihealth.api.validator;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

public enum SensitivityClasses {

    ABANDONMENT("Abandonment"),
    ABUSEACTIVITY("Abuse Activity"),
    BODY_IMAGE("Body Image"),
    BRAIN_DISORDER("Brain Disorder"),
    CD("Communicable Diseases"),
    CONTRACEPTION("Contraception"),
    COUNSELING("Counseling"),
    GENETIC("Genetic"),
    HIVAIDS("HIV/AIDS"),
    MBH("Mental/Behavioral Health"),
    NEGLECT("Neglect"),
    PMA("Paid Monetary Amount"),
    PATHOLOGY("Pathology"),
    PHYSICAL_ABUSE("Physical Abuse"),
    PAN("Physical Abuse or Neglect"),
    PC("Pregnancy/Childbirth"),
    PF("Psychological Function"),
    RH("Reproductive Health"),
    SH("Self Harm"),
    SGD("Sex and Gender Disorder"),
    STD("STD (Sexually Transmitted Disease)"),
    SA("Substance Abuse");

    SensitivityClasses(String value) {
        this.value = value;
    }

    private String value;
    public String getValue() {
        return value;
    }

    protected static final Set<String> ENUM_VALUES = Arrays.stream(SensitivityClasses.values())
            .map(SensitivityClasses::getValue)
            .collect(Collectors.toSet());
}
