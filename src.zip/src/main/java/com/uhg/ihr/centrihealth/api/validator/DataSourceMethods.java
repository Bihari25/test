package com.uhg.ihr.centrihealth.api.validator;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

public enum DataSourceMethods {

    DEAM("Direct Entry Acquisition method"),
    DDFOD("Data Derived from Other Data"),
    PDE("Provider Direct Entry"),
    IDE("Individual Direct Entry"),
    RDM("Reported Data Method"),
    RSDM("Repurposed Data Method"),
    REDAM("Rule Evaluation Data Acquisition Method"),
    SEDAM("Staff Entry Data Acquisition Method"),
    SM("Stated Method"),
    SIDAM("System Interface Data Acquisition Method");

    DataSourceMethods(String value) {
        this.value = value;
    }
    private String value;
    public String getValue() {
        return value;
    }

    protected static final Set<String> ENUM_VALUES = Arrays.stream(DataSourceMethods.values())
            .map(DataSourceMethods::getValue)
            .collect(Collectors.toSet());
}
