package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Value;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Provenance;

@Value(staticConstructor = "of")
public class ProvenanceResourceMapper implements IhrResourceMapper<Provenance> {
    @Override
    public IhrResource<?> createDomainResource(final Bundle.BundleEntryComponent entity) {

        if (!(entity.getResource() instanceof Provenance)) {
            return ProvenanceResource.of(null);
        }

        ProvenanceResource newProvenanceResource = ProvenanceResource.of(new Provenance());
        ProvenanceResource oldProvenanceResource = ProvenanceResource.of((Provenance) entity.getResource());
        newProvenanceResource.getDomainResource().setId(oldProvenanceResource.getDomainResource().getId());
        newProvenanceResource.getDomainResource().setTarget(oldProvenanceResource.getDomainResource().getTarget());
        newProvenanceResource.getDomainResource().setAgent(oldProvenanceResource.getDomainResource().getAgent());
        newProvenanceResource.getDomainResource().setRecorded(oldProvenanceResource.getDomainResource().getRecorded());
        return newProvenanceResource;
    }
}
