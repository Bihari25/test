package com.uhg.ihr.centrihealth.api.exception;

import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.server.exceptions.ExceptionHandler;
import io.micronaut.security.authentication.AuthenticationException;

import javax.inject.Singleton;

//TODO: after upgrading to micronaut 2.0.+, use their base handler instead
@Singleton
public class HttpStatusAuthorizationExceptionHandler implements ExceptionHandler<AuthenticationException, HttpResponse<?>> {
    @Override
    public HttpResponse<?> handle(HttpRequest request, AuthenticationException exception) {
        return HttpResponse.status(HttpStatus.UNAUTHORIZED).body(ErrorHelper.handleError(request, "unable to validate JWT token"));
    }
}