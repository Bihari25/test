package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Value;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Practitioner;

@Value(staticConstructor = "of")
public class PractitionerResourceMapper implements IhrResourceMapper<Practitioner> {

    public IhrResource<?> createDomainResource(final Bundle.BundleEntryComponent entity) {

        if (!(entity.getResource() instanceof Practitioner)) {
            return PractitionerResource.of(null);
        }
        PractitionerResource newResource = PractitionerResource.of(new Practitioner());
        PractitionerResource oldResource = PractitionerResource.of((Practitioner) entity.getResource());
        newResource.getDomainResource().setId(oldResource.getDomainResource().getId());
        newResource.getDomainResource().setName(oldResource.getDomainResource().getName());
        newResource.getDomainResource().setIdentifier(oldResource.getDomainResource().getIdentifier());
        return newResource;
    }
}
