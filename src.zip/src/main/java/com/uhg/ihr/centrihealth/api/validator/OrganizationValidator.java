package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.util.Constant;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Resource;

import java.util.List;

@NoArgsConstructor(staticName = "of")
public class OrganizationValidator implements IhrResourceValidator {

    public static final String INVALID_ORGANIZATION_IDENTIFIER = "Invalid Identifier for Organization for Provenance";

    @Override
    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Organization) {
            validateNpiIdentifier((Organization) resource);
        }
    }

    private void validateNpiIdentifier(final Organization organization) {
        List<Identifier> identifiers = organization.getIdentifier();
        if (!ValidationUtils.validateLoneIdentifier(identifiers, Constant.NPI)) {
            throw new IhrBadRequestException(INVALID_ORGANIZATION_IDENTIFIER);
        }
    }
}
