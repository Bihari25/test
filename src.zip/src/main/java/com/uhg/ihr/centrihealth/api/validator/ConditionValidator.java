package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import io.micronaut.core.util.CollectionUtils;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Condition;
import org.hl7.fhir.r4.model.Resource;

@NoArgsConstructor(staticName = "of")
public class ConditionValidator implements IhrResourceValidator {
    private static final String INVALID_ONSET_DATE_TIME = "Can't process onset date time";
    private static final String INVALID_RECORDED_DATE = "Can't process recorded date time";
    private static final String INVALID_CONDITION_CODE = "Can't process condition code";
    private static final String INVALID_EXTENSION = "Can't process extension";

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Condition) {
            validate((Condition) resource, null);
        }
    }

    private void validate(final Condition condition, final FhirAttributesWrapper fhirAttributesWrapper) {

        //action flag
        ValidationUtils.validateActionFlag(condition.getMeta().getTag());
        //last updated date
        ValidationUtils.validateLastUpdatedDate(condition.getMeta().getLastUpdatedElement());
        boolean noteExists = condition.getNote().size() > 0;
        // Identifiers
        ValidationUtils.validateIdentifier(condition.getIdentifier(), noteExists);
        //code
        if (!(condition.getCode().isEmpty())) {
            throw new IhrBadRequestException(INVALID_CONDITION_CODE);
        }
        //onsetdatetime
        if (condition.getOnset() != null) {
            throw new IhrBadRequestException(INVALID_ONSET_DATE_TIME);
        }
        //recordeddate
        if (condition.getRecordedDate() != null) {
            throw new IhrBadRequestException(INVALID_RECORDED_DATE);
        }
        //extension
        if (CollectionUtils.isNotEmpty(condition.getExtension())) {
            throw new IhrBadRequestException(INVALID_EXTENSION);
        }
        //validate notes lenth
        ValidationUtils.isValidNote(condition.getNote());
    }
}
