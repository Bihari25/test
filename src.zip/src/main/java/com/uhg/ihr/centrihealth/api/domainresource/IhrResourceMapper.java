package com.uhg.ihr.centrihealth.api.domainresource;

import org.apache.commons.collections4.CollectionUtils;
import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.DomainResource;
import org.hl7.fhir.r4.model.Identifier;

import java.util.List;

public interface IhrResourceMapper<T extends DomainResource> {

    default IhrResource<?> createIhrResource(Bundle.BundleEntryComponent entity) {
        if (entity == null) {
            return null;
        }
        return createDomainResource(entity);
    }

    IhrResource<?> createDomainResource(Bundle.BundleEntryComponent entity);

    static IhrResource<?> buildIhrResource(IhrResource<? extends DomainResource> oldResource,
                                           IhrResource<? extends DomainResource> newResource) {
        setNoteText(oldResource, newResource);
        buildBaseFields(oldResource.getDomainResource(), newResource.getDomainResource());
        addIdentifiers(oldResource.getIdentifiers(), newResource);
        return newResource;
    }

    static void buildBaseFields(DomainResource oldResource, DomainResource newResource) {
        newResource.setMeta(oldResource.getMeta());
    }

    static void setNoteText(IhrResource<?> resource, IhrResource<?> newResource) {
        if (!CollectionUtils.isEmpty(resource.getNote())) {
            for (Annotation annotation : resource.getNote()) {
                annotation.setText(annotation.getText().trim());
            }
            newResource.setNote(resource.getNote());
        }
    }

    static void addIdentifiers(List<Identifier> identifiers, IhrResource<?> newResource) {
        for (Identifier identifier : identifiers) {
            if (identifier.getType() != null) {
                    newResource.addIdentifier(identifier);
            }
        }
    }
}
