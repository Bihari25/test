package com.uhg.ihr.centrihealth.api.exception;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class IhrNotAcceptableException extends RuntimeException {
    public IhrNotAcceptableException(String message) {
        super(message);
    }
}