package com.uhg.ihr.centrihealth.senzing.model

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import spock.lang.Unroll

@Unroll
class SenzingRequestSpec extends BaseFhirSpecification {

    def "Test buildIdentifiers #desc"() {

        given:
        List<Map<String, String>> mapList

        when:
        mapList = SenzingRequest.buildIdentifiers(search_id)

        then:
        mapList.size() == size

        where:
        desc         | search_id   | size
        "Happy Path" | "471180426" | 2
    }

    def "Test computePaddedIds #desc"() {

        given:
        Map<String, String> map

        when:
        map = SenzingRequest.computePaddedIds(search_id)

        then:
        map.get("paddedId") == paddedKey
        map.get("unpaddedId") == unPaddedKey

        where:
        desc         | search_id   | paddedKey     | unPaddedKey
        "Happy Path" | "471180426" | "00471180426" | "471180426"
    }

    def "Test buildRequestWithPatientData #desc"() {

        given:
        def senzingRequest = new SenzingRequest()

        when:
        senzingRequest = SenzingRequest.buildRequestWithPatientData(dob, f_name, l_name, senzingRequest)

        then:
        senzingRequest.getNameFirst() == f_name
        senzingRequest.getNameLast() == l_name
        senzingRequest.getDateOfBirth() == dob
        senzingRequest.getEmpId() == empId

        where:
        desc          | f_name    | l_name    | search_id   | dob          | empId
        "Happy Path " | "Captain" | "America" | "471180426" | "1959/05/26" | null
    }

    def "Test buildRequestWithSearchId #desc"() {

        given:
        def senzingRequest = SenzingRequest.builder().nameFirst(f_name)
                .nameLast(l_name).dateOfBirth(dob).searchId(search_id).build()

        when:
        senzingRequest = SenzingRequest.buildRequestWithSearchId(senzingRequest)

        then:
        senzingRequest.getNameFirst() == f_name
        senzingRequest.getNameLast() == l_name
        senzingRequest.getDateOfBirth() == dob
        senzingRequest.getEmpId() == empId
        senzingRequest.getIdentifiers().size() == identifier_size

        where:
        desc          | f_name    | l_name    | search_id   | dob          | empId | identifier_size
        "Happy Path " | "Captain" | "America" | "471180426" | "1959/05/26" | null | 2
    }

    def "Test buildRequestWithEmpId #desc"() {

        given:
        def senzingRequest = SenzingRequest.builder().empId(empId).build()

        when:
        senzingRequest = SenzingRequest.buildRequestWithEmpId(senzingRequest)

        then:
        senzingRequest.getEmpId() == empId

        where:
        desc          | empId
        "Happy Path " | "msId"
    }
}
