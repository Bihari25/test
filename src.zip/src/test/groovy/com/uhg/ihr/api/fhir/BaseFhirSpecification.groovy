package com.uhg.ihr.api.fhir

import com.fasterxml.jackson.databind.ObjectMapper
import com.google.common.collect.Iterables
import com.uhg.ihr.api.util.TestData
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper
import com.uhg.ihr.centrihealth.api.model.FhirMapper
import com.uhg.ihr.centrihealth.api.util.AppUtils
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils
import io.micronaut.http.HttpRequest
import org.hl7.fhir.r4.model.AllergyIntolerance
import org.hl7.fhir.r4.model.Annotation
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.DateTimeType
import org.hl7.fhir.r4.model.Dosage
import org.hl7.fhir.r4.model.Extension
import org.hl7.fhir.r4.model.HumanName
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.InstantType
import org.hl7.fhir.r4.model.Medication
import org.hl7.fhir.r4.model.MedicationStatement
import org.hl7.fhir.r4.model.Organization
import org.hl7.fhir.r4.model.Patient
import org.hl7.fhir.r4.model.Period
import org.hl7.fhir.r4.model.Practitioner
import org.hl7.fhir.r4.model.PractitionerRole
import org.hl7.fhir.r4.model.Provenance
import org.hl7.fhir.r4.model.Quantity
import org.hl7.fhir.r4.model.Reference
import org.hl7.fhir.r4.model.RelatedPerson
import org.hl7.fhir.r4.model.ResourceType
import org.hl7.fhir.r4.model.StringType
import spock.lang.Shared
import spock.lang.Specification

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

class BaseFhirSpecification extends Specification {

    @Shared
    public static final ObjectMapper MAPPER = new ObjectMapper()

    @Shared
    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy/MM/dd", Locale.US)

    @Shared
    public static final DateTimeFormatter FORMATTER_HYPHEN = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US);

    @Shared
    TimeZone DEFAULT_TIMEZONE = TimeZone.getDefault()

    @Shared
    def fhirAttributesWrapper = FhirAttributesWrapper.builder().employeeId(new HashSet<>()).build()

    static String TOKEN = "Bearer eyJhbGciOiJSUzUxMiJ9.eyJyb2xlIjoidXNlciIsImNyZWF0ZWQiOjE1MjI4NDk5OTE3OTcsInVzZXJuYW1lIjoiY2xvdWRzZGsifQ.dzfwWRugsnhPHB0RNT9lZHnX7gvNfGks_ivTc_dQ6-ejM6B1-Chx3WrwBE8drdy4ZbvkVTlHkHRSu3nBZi3Aw0wmN5N7UPUI0wP2KhAHGQS4-LOXgD58ioX9ep3k6hZQqy-oJor5Q3wZS8HJKMMY8izIROtJ5z-z5Y2RRw3ONnQLL5JR40hF9d5mFKA8Y1giEP32qg259MVbdkHNkI0ceq8hrXJ7w_OD4-JPteNhM9EeyNOmzjrKSEG-tkYrWI7g5xgvgMuO8iHFym4WhkDT6FNfcK2xs8QfCbJCZqV28xSIjbrm0El0L7kRzJbsKBxQ7FNJ35iaX18DpQMpu6usUQ"
    static String CORRELATION_ID = "abcdefg1234567"
    static String CORRELATION_HEADER = "optum-cid-ext"
    static String CONSUMER_USER_NAME_HEADER = "X-Consumer-Username"
    static String CONSUMER_USER_NAME = "abc.def"

    def setupSpec() {
        TimeZone.setDefault(TimeZone.getTimeZone(ZoneId.of("UTC")))
    }

    def cleanupSpec() {
        TimeZone.setDefault(DEFAULT_TIMEZONE)
    }

    static Bundle getResourceBundle(fileName) {
        String message = AppUtils.readResource(fileName)
        return getBundle(message)
    }

    static Bundle getBundle(sample) {
        return FhirMapper.FHIR_CONTEXT.newJsonParser().parseResource(sample) as Bundle
    }

    static buildActionFlag(code, display) {
        return new Coding().setCode(code).setDisplay(display)
    }

    static buildLastUpdated(date) {
        return new InstantType(date)
    }

    static buildCoding(system, code) {
        return new Coding().setSystem(system).setCode(code)
    }

    static buildDisplayCoding(system, display) {
        return new Coding().setSystem(system).setDisplay(display)
    }

    static buildAssertedDate(String date) {
        return new DateTimeType(date)
    }

    static buildPeriod(start, end) {
        return new Period().setStart(toDateFromUtc(start)).setEnd(toDateFromUtc(end))
    }

    static toDateFromUtc(String date) {
        try {
            return Date.from(ZonedDateTime.parse(date).toInstant())
        } catch (DateTimeParseException de) {
            return null
        }
    }

    static DateTimeType toDateTimeType(String date) {
        try {
            LocalDate ld = LocalDate.parse(date, FORMATTER)
            return new DateTimeType(Date.from(ld.atStartOfDay(ZoneOffset.UTC).toInstant()))
        } catch (DateTimeParseException de) {
            return null
        }
    }

    static baseRequest() {
        return HttpRequest.PUT("/bundles/v1", "")
                .header(CORRELATION_HEADER, CORRELATION_ID)
                .header(CONSUMER_USER_NAME_HEADER, CONSUMER_USER_NAME)
                .header("JWT", TOKEN)
    }

    static buildExtension(url, date) {
        return new Extension().setUrl(url).setValue(toDateTimeType(date))
    }

    static buildAnnotation(Object referenceResource, String authorReference, String text, Date time, List<Extension> extension) {
        return new Annotation()
                .setAuthor(new Reference(referenceResource).setReference(authorReference))
                .setText(text)
                .setTime(time)
                .setExtension(extension)
    }

    static buildPatientNote(String authorReference, String text, Date time, List<Extension> extension) {
        Patient patient = TestData.buildPatientResource()
        return buildAnnotation(patient, authorReference, text, time, extension)
    }

    static buildClinicalNote(String authorReference, String text, Date time, List<Extension> extension) {
        Practitioner practitioner = TestData.buildPractitionerResource()
        return buildAnnotation(practitioner, authorReference, text, time, extension)
    }

    static buildExtension(String url, String value) {
        return new Extension().setUrl(url).setValue(new StringType(value))
    }

    static buildIdentifier(String text, String value) {
        return new Identifier().setType(new CodeableConcept().setText(text)).setValue(value)
    }


    static toDate(String date) {
        try {
            if (ValidationUtils.isDateTime(date)) {
                return Date.from(ZonedDateTime.parse(date).toInstant());
            } else if (ValidationUtils.isDatePatternSlash(date)) {
                LocalDate ld = LocalDate.parse(date, FORMATTER);
                return Date.from(ld.atStartOfDay(ZoneOffset.UTC).toInstant());
            } else if (ValidationUtils.isDatePatternHyphen(date)) {
                LocalDate ld = LocalDate.parse(date, FORMATTER_HYPHEN);
                return Date.from(ld.atStartOfDay(ZoneOffset.UTC).toInstant());
            } else {
                return null;
            }
        } catch (DateTimeParseException de) {
            return null;
        }
    }

    static baseFhirRequest() {
        return HttpRequest.PUT("/bundles/v1", fhirBundleAsString())
                .header(CORRELATION_HEADER, CORRELATION_ID)
                .header(CONSUMER_USER_NAME_HEADER, CONSUMER_USER_NAME)
                .header("JWT", TOKEN)
    }

    static String fhirBundleAsString() {
        Bundle bundle = fhirBundleRequest()
        return FhirMapper.bundleToString(bundle)
    }

    static Bundle fhirBundleRequest() {
        return getResourceBundle("ingest_medication.json")
    }

    static buildCodingForAgent(system, code, String display) {
        return new Coding().setSystem(system).setCode(code).setDisplay(display)
    }

    static buildCodeableConcept(String text) {
        return new CodeableConcept().setText(text)
    }

    static buildCodeableConcept(String system, String code) {
        return new CodeableConcept().setCoding(List.of(buildCoding(system, code)))
    }

    static buildHumanName(String fn, String ln) {
        return new HumanName().setFamily(ln).setGiven([buildGiven(fn)] as List<StringType>)
    }

    static buildGiven(String given) {
        return new StringType(given)
    }

    static buildOrganization(identifierText, identifierValue, addIdentifier, count) {
        def org = new Organization()
        if (addIdentifier) {
            org.addIdentifier(buildIdentifier(identifierText, identifierValue))
        }
        if (count == 2) {
            org.addIdentifier(buildIdentifier(identifierText, identifierValue))
        }
        return org
    }

    static buildRelatedPerson(addRelationship, relationshipText, addName, fn, ln, addDob, dob) {
        def person = new RelatedPerson()
        if (addRelationship) {
            person.addRelationship(buildCodeableConcept(relationshipText))
        }
        if (addName) {
            person.addName(buildHumanName(fn, ln))
        }
        if (addDob) {
            person.setBirthDate(toDate(dob))
        }
        return person
    }

    static buildPractitionerRole(codeText) {
        def role = new PractitionerRole()
        if (codeText != null) {
            role.addCode(buildCodeableConcept(codeText))
        }
        return role
    }

    static String getCodeUUID() {
        return UUID.randomUUID().toString()
    }

    static buildProvAgentWhoOrgBundle() {
        def org = buildOrganization()
        def component = new Provenance.ProvenanceAgentComponent()
        component.setWho(new Reference(org).setReference("Organization/" + org.getId()))
        def provenance = buildProvenance()
        provenance.addAgent(component)
        def bundle = buildBundle()
        bundle.addEntry().setResource(provenance)
        bundle.addEntry().setResource(org)
        return bundle
    }

    static buildProvAgentWhoPractBundle() {
        def practitioner = buildPractitioner()
        def component = new Provenance.ProvenanceAgentComponent()
        component.setWho(new Reference(practitioner).setReference("Practitioner/" + practitioner.getId()))
        def provenance = buildProvenance()
        provenance.addAgent(component)
        def bundle = buildBundle()
        bundle.addEntry().setResource(provenance)
        bundle.addEntry().setResource(practitioner)
        return bundle
    }

    static buildOrganization() {
        def org = new Organization()
        org.setId(getCodeUUID())
        return org
    }

    static buildPractitioner() {
        def pract = new Practitioner()
        pract.setId(getCodeUUID())
        return pract
    }

    static Provenance buildProvenance() {
        Provenance provenance = new Provenance()
        provenance.setId(getCodeUUID())
        //Recorded
        provenance.setRecorded(toDateFromUtc("2020-02-17T11:45:41Z"))
        return provenance
    }

    static buildBundle() {
        def bundle = new Bundle()
        bundle.setId(getCodeUUID())
        bundle.setType(Bundle.BundleType.TRANSACTION)
        return bundle
    }

    static buildProvAgentWhoRPBundle() {
        def rp = buildRelatedPerson()
        def component = new Provenance.ProvenanceAgentComponent()
        component.setWho(new Reference(rp).setReference("RelatedPerson/" + rp.getId()))
        def provenance = buildProvenance()
        provenance.addAgent(component)
        def bundle = buildBundle()
        bundle.addEntry().setResource(provenance)
        bundle.addEntry().setResource(rp)
        return bundle
    }

    static buildProvAgentWhoPatientBundle() {
        def patient = buildPatient()
        def component = new Provenance.ProvenanceAgentComponent()
        component.setWho(new Reference(patient).setReference("Patient/" + patient.getId()))
        def provenance = buildProvenance()
        provenance.addAgent(component)
        def bundle = buildBundle()
        bundle.addEntry().setResource(provenance)
        bundle.addEntry().setResource(patient)
        return bundle
    }

    static buildRelatedPerson() {
        def rp = new RelatedPerson()
        rp.setId(getCodeUUID())
        return rp
    }

    static buildPatient() {
        def patient = new Patient()
        patient.setId(getCodeUUID())
        return patient
    }

    static Medication buildMedication() {
        return buildMedication(getCodeUUID())
    }

    static Medication buildMedication(String id) {
        return (Medication) new Medication().setId(id)
    }

    static buildMedicationStatement() {
        def statement = new MedicationStatement()
        statement.setId(getCodeUUID())
        return statement
    }

    static buildAllergyIntolerance() {
        def allergy = new AllergyIntolerance()
        allergy.setId(getCodeUUID())
        return allergy
    }

    static buildProvAgentWhoMedicationBundle() {
        def medication = buildMedication()
        def component = new Provenance.ProvenanceAgentComponent()
        component.setWho(new Reference(medication).setReference("Medication/" + medication.getId()))
        def provenance = buildProvenance()
        provenance.addAgent(component)
        def bundle = buildBundle()
        bundle.addEntry().setResource(provenance)
        bundle.addEntry().setResource(medication)
        return bundle
    }

    static buildProvenanceTargetBundle() {
        def medication = buildMedicationStatement()
        def allergy = buildAllergyIntolerance()
        def provenance = buildProvenance()
        provenance.addTarget(new Reference(medication).setReference(medication.getResourceType().toString() + "/" + medication.getId()))
        provenance.addTarget(new Reference(allergy).setReference(allergy.getResourceType().toString() + "/" + allergy.getId()))
        def bundle = buildBundle()
        bundle.addEntry().setResource(provenance)
        bundle.addEntry().setResource(allergy)
        return bundle
    }

    static MedicationStatement buildDosage(String text, BigDecimal value, String unit) {
        return new MedicationStatement()
                .addDosage(new Dosage().setText(text).addDoseAndRate(new Dosage.DosageDoseAndRateComponent().setDose(new Quantity().setValue(value).setUnit(unit))))
    }

    static getResourceFromBundle(Bundle bundle, ResourceType resourceType) {
        for (Bundle.BundleEntryComponent entity : bundle.getEntry()) {
            if (resourceType == entity.getResource().getResourceType()) {
                return entity.getResource()
            }
        }
    }
    static Identifier getIdentifierFromList(List<Identifier> ids, String name) {
        List<Identifier> found = ids.findAll { id -> name == id.getType().getText() || name == id.getValue() }
        return Iterables.getOnlyElement(found)
    }
}
