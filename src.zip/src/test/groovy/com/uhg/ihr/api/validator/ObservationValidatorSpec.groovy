package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.validator.ObservationValidator
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.Narrative
import org.hl7.fhir.r4.model.Observation
import org.hl7.fhir.r4.model.StringType
import spock.lang.Unroll

@Unroll
class ObservationValidatorSpec extends BaseFhirSpecification {

    def "Valid Observation test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle(fileName)

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Observation) {

                try {
                    Observation observation = (Observation) entity.getResource()
                    ObservationValidator.of().validate(observation, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description | fileName            || errorMessage || expected
        "HappyPath" | "observations.json" || null         || true
    }

    def "Invalid Observation test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle("observations.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Observation) {

                try {
                    Observation observation = (Observation) entity.getResource()
                    if (scenario == "valueString") {
                        observation.setValue(new StringType("10.4"))
                    }
                    ObservationValidator.of().validate(observation, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description   | scenario      || errorMessage                              || expected
        "valueString" | "valueString" || ObservationValidator.INVALID_VALUE_STRING || false
    }
}
