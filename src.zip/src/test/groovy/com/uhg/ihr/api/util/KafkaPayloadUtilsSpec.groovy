package com.uhg.ihr.api.util

import com.fasterxml.jackson.databind.node.TextNode
import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.model.ActorIdType
import com.uhg.ihr.centrihealth.api.util.KafkaPayloadUtils
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import org.hl7.fhir.r4.model.Bundle
import spock.lang.Unroll

class KafkaPayloadUtilsSpec extends BaseFhirSpecification {

    DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss,SSSXXX", Locale.US)

    @Unroll
    def "Test fhirBundle"() {

        given:
        def uuid = "2019-01-02T03-04-44Z-Client-1234"
        def actorIdMap = [(ActorIdType.PATIENT) : "XXXTEST003"]
        Bundle resourceBundle = getResourceBundle(fileName)

        when:
        def jsonString = KafkaPayloadUtils.getBundleJsonString(actorIdMap, resourceBundle)
        def uuidNode = MAPPER.readTree(jsonString).get("uuid")
        String refId = ((TextNode) uuidNode).asText()

        then:
        refId == uuid

        where:
        fileName                 | referenceId
        "ingest_medication.json" | "2019-01-02T03-04-44Z-Rally-1sE"
    }

    def "Test the size of List<ActorIds>"() {

        given:
        def actorIdMap = [(ActorIdType.PATIENT) : "XXXTEST003"]
        def list = KafkaPayloadUtils.getActorIdsList(actorIdMap)

        expect:
        list.size() == 1
    }

    def "Test the  formated Date"() {
        given:
        ZonedDateTime zonedDateTimeNow = ZonedDateTime.now(ZoneId.systemDefault())
        String dateAsString = zonedDateTimeNow.format(FORMATTER)

        when:
        def returnedDate = KafkaPayloadUtils.formatDateAsString()

        then:
        dateAsString.contains(returnedDate.substring(0, 10))
    }

    def "Test the kafka payload"() {

        given:
        Bundle resourceBundle = getResourceBundle("ingest_medication.json")

        when:
        def nodeAsString = MAPPER.writeValueAsString("API_INGEST")
        def payload = KafkaPayloadUtils.buildKafkaPayload(nodeAsString, resourceBundle.getId())

        then:
        payload.uuid == "2019-01-02T03-04-44Z-Client-1234"
        payload.createTimestamp != null
        payload.updateTimestamp != null
        payload.interfaceType == "API_INGEST"
    }
}