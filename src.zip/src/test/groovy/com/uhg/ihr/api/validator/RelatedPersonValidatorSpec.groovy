package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.validator.RelatedPersonInfoCodeEnum
import com.uhg.ihr.centrihealth.api.validator.RelatedPersonValidator

class RelatedPersonValidatorSpec  extends BaseFhirSpecification {

    def "Test validate"() {
        given:
        def exception = false
        def person = buildRelatedPerson(addRelationship, relationshipText, addName, fn, ln, addDob, dob)
        when:
        try {
            RelatedPersonValidator.of().validate(person, null)
        } catch (IhrBadRequestException ibre) {
            exception = true
        }
        then:
        exception == failed

        where:
        desc                          | addRelationship | relationshipText                         | addName | fn   | ln   | addDob | dob          || failed
        "Happy Path"                  | true            | RelatedPersonInfoCodeEnum.CAREGIVER.code | true    | "fn" | "ln" | true   | "1959/05/26" || false
        "Incorrect relationship text" | true            | "caregver"                               | true    | "fn" | "ln" | true   | "1959/05/26" || true
        "Name and DOB present"        | false           | RelatedPersonInfoCodeEnum.CAREGIVER.code | true    | "fn" | "ln" | true   | "1959/05/26" || false
        "Last name is null"           | false           | RelatedPersonInfoCodeEnum.CAREGIVER.code | true    | "fn" | null | true   | "1959/05/26" || true
        "DOB is not added"            | false           | RelatedPersonInfoCodeEnum.CAREGIVER.code | true    | "fn" | "ln" | false  | "1959/05/26" || true
    }
}
