package com.uhg.ihr.api.validator

import com.uhg.ihr.api.util.TestData
import com.uhg.ihr.centrihealth.api.logging.LoggingFilter
import io.micronaut.http.HttpRequest
import io.micronaut.http.MediaType
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.Coverage
import org.hl7.fhir.r4.model.Patient
import spock.lang.Ignore
import spock.lang.Specification
import spock.lang.Unroll

class LogValidatorSpec extends Specification {

    //FIXME: these test cases dont validate the logs
    @Unroll
    @Ignore
    void "Happy Path Test #desc"() {
        given:
        def patient = new Patient()
        def birthDate = new Date()
        patient.setBirthDate(birthDate)
        def guid = UUID.randomUUID().toString()
        patient.setId(guid)
        patient.addName()
                .setFamily("Mouse")
                .addGiven("Minnie")
        def bundle = new Bundle()
        bundle.setType(Bundle.BundleType.TRANSACTION)
        bundle.addEntry()
                .setResource(patient)
        def coverage = new Coverage()
        guid = UUID.randomUUID().toString()
        coverage.setId(guid)
        coverage.addIdentifier()
                .setSystem("Policy Number")
                .setValue("903033")
        coverage.addIdentifier()
                .setSystem("searchId")
                .setValue("00000251082177")
        coverage.addIdentifier()
                .setSystem("RALLYID")
                .setValue("ACT84169207")
        bundle.addEntry()
                .setResource(coverage)
        bundle.addEntry()
                .getRequest()
                .setUrl("AllergyIntolerance")
                .setMethod(Bundle.HTTPVerb.GET)
        bundle.addEntry()
                .getRequest()
                .setUrl("MedicationStatement")
                .setMethod(Bundle.HTTPVerb.GET)
        bundle.setLanguage("EN")

        HttpRequest<String> req = TestData.baseRequest().accept(MediaType.of("application/fhir+json"))

        expect:
        //LoggingFilter.logStart(req, VALIDATOR)
        LoggingFilter.logSuccess(req, "FhirValidator.isRequestValid()")
        true

        where:
        desc             | dateValues   || expected
        "VALID_FORMAT"   | "2013/09/09" || true
        "INVALID_FORMAT" | "09/12/1920" || false
        "INVALID_FORMAT" | "07/12/20"   || false
        "INVALID_FORMAT" | "20-20-2020" || false
        "INVALID_FORMAT" | "2012-12-05" || false
        "EMPTY"          | ""           || false
        "EMPTY"          | "  "         || false
        "null"           | null         || false
        "INVALID_ENTRY"  | "abcd"       || false
    }

}
