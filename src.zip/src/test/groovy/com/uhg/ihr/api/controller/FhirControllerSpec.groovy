package com.uhg.ihr.api.controller

import com.uhg.ihr.api.WireMockBaseTest
import io.micronaut.context.annotation.Requires
import io.micronaut.core.util.StringUtils
import io.micronaut.http.HttpRequest
import io.micronaut.http.MediaType
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.test.extensions.spock.annotation.MicronautTest
import spock.lang.Unroll

@MicronautTest
@Requires(property = "micronaut.security.stargate.enabled", notEquals = StringUtils.FALSE)
@Unroll
class FhirControllerSpec extends WireMockBaseTest {

    def "it 401 on accept type"() {
        when:
        HttpRequest req = baseFhirRequest().accept(MediaType.of("application/fhir+json"))

        then:
        def exceptionThrown = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hcre) {
            assert hcre.getMessage().contains('Unauthorized')
            assert 401 == hcre.getResponse().getStatus().code
            exceptionThrown = true
        }
        exceptionThrown
    }

}