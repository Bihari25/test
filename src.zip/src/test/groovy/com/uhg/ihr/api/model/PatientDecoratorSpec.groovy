package com.uhg.ihr.api.model

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.model.MedicationStatementDecorator
import com.uhg.ihr.centrihealth.api.model.PatientDecorator
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest
import org.hl7.fhir.r4.model.Bundle

class PatientDecoratorSpec extends BaseFhirSpecification {

    def "Test buildSenzingRequest #desc"() {

        given:
        def resourceBundle = getResourceBundle(fileName)
        def decorator = new PatientDecorator()
        def senzingRequest = new SenzingRequest()

        when:
        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            senzingRequest = decorator.buildSenzingRequest(entity, senzingRequest)
        }

        then:
        f_name == senzingRequest.getNameFirst()
        l_name == senzingRequest.getNameLast()
        dob == senzingRequest.getDateOfBirth()

        where:
        desc           | fileName                 | f_name   | l_name  | dob
        "Happy Path"   | "ingest_medication.json" | "Minnie"  | "Mouse" | "1959/05/26"
        "Unhappy Path" | "patient_missing.json"  | null  | null | null
    }
}
