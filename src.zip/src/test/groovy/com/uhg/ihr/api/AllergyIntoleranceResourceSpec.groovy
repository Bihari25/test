package com.uhg.ihr.api

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.domainresource.AllergyIntoleranceResource
import org.hl7.fhir.r4.model.AllergyIntolerance
import org.hl7.fhir.r4.model.Annotation
import spock.lang.Ignore
import spock.lang.Unroll

@Ignore
class AllergyIntoleranceResourceSpec extends BaseFhirSpecification {

    static String TEXT_1000_CH =  "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" +
            "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" +
            "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" +
            "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" +
            "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" +
            "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" +
            "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" +
            "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" +
            "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" +
            "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" +
            "1234567890"

    static String TEXT_25_WHITE_SPACE = "                         "

    static String TEXT_25_CH = "1234567890123456789012345"

    @Unroll
    def "Test setNoteText desc#"() {

        given:
        def allergyIntolerance = createAllergyIntolerance(note1, note2)
        def newAllergyIntolerance = new AllergyIntolerance()

        when:
        AllergyIntoleranceResource.setNoteText(allergyIntolerance, newAllergyIntolerance)

        then:
        newAllergyIntolerance.getNote().get(0).getText().length() == TEXT_1000_CH.length()
        newAllergyIntolerance.getNote().get(1).getText().length() == TEXT_25_CH.length()

        where:
        desc        | note1                              | note2
        "1000"      | TEXT_1000_CH                       | TEXT_25_CH
        "1000 + 25" | TEXT_1000_CH + TEXT_25_WHITE_SPACE | TEXT_25_CH + TEXT_25_WHITE_SPACE
        "25 + 1000" | TEXT_25_WHITE_SPACE + TEXT_1000_CH | TEXT_25_WHITE_SPACE + TEXT_25_CH
    }

    def createAllergyIntolerance(String text1, String text2) {
        AllergyIntolerance allergyIntolerance = new AllergyIntolerance();
        def notes = [new Annotation().setText(text1), new Annotation().setText(text2)] as List<Annotation>
        return allergyIntolerance.setNote(notes)
    }

}
