package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.validator.AllergyIntoleranceValidator
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils
import org.hl7.fhir.r4.model.AllergyIntolerance
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.RelatedPerson
import org.hl7.fhir.r4.model.Resource
import org.hl7.fhir.r4.model.ResourceType
import spock.lang.Shared
import spock.lang.Unroll

@Unroll
class AllergyIntoleranceValidatorSpec extends BaseFhirSpecification {

    @Shared
    String MISSING_INFORMATION_SOURCE = "Missing information source"
    @Shared
    String MISSING_INFORMATION_TEXT = "Missing/Incorrect information source text"
    @Shared
    String ALLERGY_CODE_SYSTEM = "http://hl7.org/fhir/sid/ndc"

    def "Invalid Allergy Intolerance test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle("allergyIntolerance.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof AllergyIntolerance) {

                try {
                    AllergyIntolerance allergyIntolerance = (AllergyIntolerance) entity.getResource()
                    if (scenario == "recordKey") {
                        allergyIntolerance.addIdentifier().setType(new CodeableConcept().setText("recordKey-Test"))
                    }
                    if (scenario == "referenceId") {
                        allergyIntolerance.addIdentifier(new Identifier().setType(new CodeableConcept().setText("reference")))
                    }
                    AllergyIntoleranceValidator.of().validate(allergyIntolerance, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description   | scenario      || errorMessage                           || expected
        "ReferenceId" | "referenceId" || ValidationUtils.INVALID_IDENTIFIER_KEY || false
        "RecordKey"   | "recordKey"   || ValidationUtils.INVALID_IDENTIFIER_KEY || false
    }

    def "Validate validateAsserter #desc"() {

        given:
        Bundle resourceBundle = getResourceBundle("allergyIntolerance.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof AllergyIntolerance) {
                try {
                    AllergyIntolerance allergyIntolerance = (AllergyIntolerance) entity.getResource()
                    Resource resource = (Resource) allergyIntolerance.getAsserter().getResource()
                    if (resource.toString().contains(ResourceType.RelatedPerson.toString())) {
                        if (condition == "relatedPerson") {
                            ((RelatedPerson) resource).setRelationship(null)
                        } else if (condition == "relatedText") {
                            ((RelatedPerson) resource).getRelationshipFirstRep().setText("")
                        } else if (condition == "IncorrectText") {
                            ((RelatedPerson) resource).getRelationshipFirstRep().setText("ZXU")
                        }
                    }
                    AllergyIntoleranceValidator.validateAsserter(resource, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        desc                         | condition       || errorMessage               || expected
        "Success"                    | ""              || null                       || true
        "Missing Information Source" | "relatedPerson" || MISSING_INFORMATION_SOURCE || false
        "Missing Information Text"   | "relatedText"   || MISSING_INFORMATION_TEXT   || false
        "Incorrect Information Text" | "IncorrectText" || MISSING_INFORMATION_TEXT   || false

    }

    void "Validate validateAllergyReaction #desc"() {

        def errorMsg = ""

        given:
        def intolerance = new AllergyIntolerance()
        def codingList = [buildCoding("http://snomed.info/sct", "xyz")] as List<Coding>
        CodeableConcept manifestation = new CodeableConcept()
        if (hasCode) {
            intolerance.setCode(new CodeableConcept().setText(allergy))
        }
        if (hasReaction) {
            manifestation.setCoding(codingList)
            manifestation.setText(text)
            intolerance.addReaction().addManifestation(manifestation)
        }
        try {
            AllergyIntoleranceValidator.validateAllergyReaction(intolerance)
        } catch (IhrBadRequestException ee) {
            errorMsg = ee.getMessage()
        }

        expect:
        errorMsg == expected

        where:
        desc                            | hasCode | hasReaction | text                      | allergy || expected
        "Success"                       | true    | true        | "Chemotherapy Medication" | "cold"  || ""
        "Success-No Reaction & Allergy" | true    | false       | "Chemotherapy Medication" | ""      || ""
        "Success-No Code"               | false   | true        | "Chemotherapy Medication" | ""      || ""
        "Success-No Code & Reaction"    | false   | false       | "Chemotherapy Medication" | ""      || ""
        "Reaction Missing"              | true    | false       | "Chemotherapy Medication" | "cold"  || AllergyIntoleranceValidator.ALLERGY_REACTION_REQUIRED
        "AllergyText is missing"        | true    | false       | ""                        | "cold"  || AllergyIntoleranceValidator.ALLERGY_REACTION_REQUIRED
    }

    void "Test isActionFlagUpsert #desc"() {
        def result = false

        given:
        def codingList = [buildActionFlag(code, display)] as List<Coding>

        when:
        result = AllergyIntoleranceValidator.isActionFlagUpsert(codingList)

        then:
        result == expected

        where:
        desc                | code         | display  || expected
        "Success"           | "actionFlag" | "Upsert" || true
        "Incorrect Display" | "actionFlag" | "Delete" || false
        "Incorrect Code"    | "actonFlag"  | "Upsert" || false
        "No Code"           | ""           | "Upsert" || false
    }

    void "Validate validateAllergyCode #desc"() {
        def errorMsg = ""

        given:
        def codingList = [buildCoding(system, code)] as List<Coding>
        def codeableConcept = new CodeableConcept()
        codeableConcept.setCoding codingList
        def intolerance = new AllergyIntolerance()
        if (hasIntolerance) {
            intolerance.setCode(codeableConcept.setText(allergy))
        }
        try {
            AllergyIntoleranceValidator.validateAllergyCode(intolerance, false)
        } catch (IhrBadRequestException ee) {
            errorMsg = ee.getMessage()

        }

        expect:
        errorMsg == expected

        where:
        desc                      | hasIntolerance | allergy | system                 | code  || expected
        "Happy Path"              | true           | "cold"  | ALLERGY_CODE_SYSTEM    | "123" || ""
        "Intolerance is required" | false          | "cold"  | ALLERGY_CODE_SYSTEM    | "123" || AllergyIntoleranceValidator.ALLERGY_CODE_REQUIRED
        "AllergyCode is empty"    | true           | ""      | ""                     | ""    || AllergyIntoleranceValidator.ALLERGY_CODE_REQUIRED
        "AllergyCode is required" | true           | null    | ""                     | ""    || AllergyIntoleranceValidator.ALLERGY_CODE_REQUIRED
    }

    void "Validate validateReactionManifestation #desc"() {
        def errorMsg = ""

        given:
        def intolerance = new AllergyIntolerance()
        def codingList = [buildCoding("http://snomed.info/sct", "xyz")] as List<Coding>
        CodeableConcept manifestation = new CodeableConcept()
        if (hasReaction) {
            manifestation.setCoding(codingList)
            manifestation.setText("Chemotherapy Medication")
            intolerance.addReaction().addManifestation(manifestation)
        }
        try {
            AllergyIntoleranceValidator.validateReactionManifestation(intolerance, recordKey)
        } catch (IhrBadRequestException ee) {
            errorMsg = ee.getMessage()
        }
        expect:
        errorMsg == expected

        where:
        desc                   | recordKey | hasReaction || expected
        "Success"              | true      | true        || ""
        "Success-No RecordKey" | false     | true        || ""
        "Reaction is missing"  | true      | false       || AllergyIntoleranceValidator.ALLERGY_REACTION_IS_REQUIRED
    }
}