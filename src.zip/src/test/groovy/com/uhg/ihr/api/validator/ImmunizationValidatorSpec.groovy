package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.validator.ImmunizationsValidator
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.Immunization

class ImmunizationValidatorSpec extends BaseFhirSpecification {
    def "Valid Immunization test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle(fileName)

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Immunization) {

                try {
                    Immunization immunization = (Immunization) entity.getResource()
                    ImmunizationsValidator.of().validate(immunization, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description | fileName            || errorMessage || expected
        "HappyPath" | "Immunization.json" || null         || true
    }

    def "Invalid Immunization test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle("Immunization.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Immunization) {

                try {
                    Immunization immunization = (Immunization) entity.getResource()
                    if (scenario == "referenceId") {
                        immunization.addIdentifier(new Identifier().setType(new CodeableConcept().setText("reference")))
                    }
                    ImmunizationsValidator.of().validate(immunization, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description   | scenario      || errorMessage                           || expected
        "ReferenceId" | "referenceId" || ValidationUtils.INVALID_IDENTIFIER_KEY || false
    }
}
