package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper
import com.uhg.ihr.centrihealth.api.validator.MedicationStatementValidator
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.Extension
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.Medication
import org.hl7.fhir.r4.model.MedicationStatement
import org.hl7.fhir.r4.model.Reference
import org.hl7.fhir.r4.model.Resource
import spock.lang.Shared
import spock.lang.Unroll

import static com.uhg.ihr.api.util.TestData.defaultFhirAttributesWrapper
import static com.uhg.ihr.api.util.TestData.defaultMedicationStatement

@Unroll
class MedicationStatementValidatorSpec extends BaseFhirSpecification {

    @Shared
    String REQUIRED_DATA_AUTHOR_IDENTIFIER = "dataAuthorIdentifier is required as date asserted is present"
    @Shared
    String MEDICATION_CODE_SYSTEM = "http://hl7.org/fhir/sid/ndc"
    @Shared
    String MISSING_MEDICATION_CODE = "Missing/Incorrect medication code system"
    @Shared
    String CODE_OR_SYSTEM_MISSING = "Code or System missing in Coding"
    @Shared
    String INVALID_IDENTIFIER = "Invalid Identifier"

    @Shared
    MedicationStatementValidator validator = MedicationStatementValidator.of()

    Bundle statementBundle = getResourceBundle("medicationStatement.json")

    def "Medication statement test cases #description"() {

        given:
        def isValid = false
        def validationMessage = null

        when:

        for (Bundle.BundleEntryComponent entity : statementBundle.getEntry()) {
            if (entity.getResource() instanceof MedicationStatement) {

                try {
                    MedicationStatement medicationStatement = (MedicationStatement) entity.getResource()
                    if (setIncorrectTag) {
                        medicationStatement.getMeta().getTag().get(0).setDisplay(null)
                    }
                    MedicationStatementValidator.of().validate(medicationStatement, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description         | setIncorrectTag || errorMessage                        || expected
        "HappyPath"         | false           || null                                || true
        "DisplayTagMissing" | true            || ValidationUtils.INVALID_ACTION_FLAG || false
    }

    def "Invalid Medication statement #description"() {

        given:
        MedicationStatement ms = defaultMedicationStatement()

        when:
        ms.setBasedOn(basedOn).setPartOf(partOf).setExtension(extension)
        validator.validate((Resource) ms, defaultFhirAttributesWrapper())

        then:
        IhrBadRequestException ex = thrown()
        errorMessage == ex.getMessage()

        where:
        description                       | basedOn           | partOf            | extension         || errorMessage
        "MedicationRequest - basedOn"     | [new Reference()] | null              | null              || MedicationStatementValidator.INVALID_MEDICATION_REQUEST
        "MedicationDispense - partOf"     | null              | [new Reference()] | null              || MedicationStatementValidator.INVALID_MEDICATION_DISPENSE
        "MedicationExtension - extension" | null              | null              | [new Extension()] || MedicationStatementValidator.MISSING_EXTENSION_INFO
    }

    @Unroll
    void "Validate isDataAuthorIdentifierRequired #desc"() {

        def result = ""
        given:
        def identifierList = [buildIdentifier(identifierText, identifierValue)] as List<Identifier>
        //Asserted Date
        def assertedDateExists = ValidationUtils.hasValidateDateTimeType(buildAssertedDate(date))
        //Check for review ms id
        boolean dataAuthorIdentifierExists = ValidationUtils.isRequiredIdentifierExists(identifierList, "dataAuthorIdentifier")

        when:
        try {
            MedicationStatementValidator.isDataAuthorIdentifierRequired(assertedDateExists, dataAuthorIdentifierExists)
        } catch (IhrBadRequestException ibre) {
            result = ibre.getMessage()
        }

        then:
        result == expected

        where:
        desc     | identifierText         | identifierValue | date                            || expected
        "Test 1" | "dataAuthorIdentifier" | "msid"          | "2019-10-24T13:33:05.000+00:00" || ""
        "Test 2" | "dataAuthorIdentifier" | "msid"          | ""                              || ""
        "Test 3" | "dataAuthorIdentifier" | ""              | "2019-10-24T13:33:05.000+00:00" || REQUIRED_DATA_AUTHOR_IDENTIFIER
        "Test 4" | ""                     | "msid"          | "2019-10-24T13:33:05.000+00:00" || REQUIRED_DATA_AUTHOR_IDENTIFIER
    }

    @Unroll
    void "Validate validateMedication #desc"() {

        def result = ""
        given:
        def codingList = [buildCoding(system, code)] as List<Coding>
        def codeableConcept = new CodeableConcept()
        codeableConcept.setCoding codingList

        def identifierList = [buildIdentifier(identifierText, identifierValue)] as List<Identifier>
        if (condition == "codeable") {
            codeableConcept = null
        }
        def medication = new Medication().setCode(codeableConcept)
        //Check for record key
        boolean recordKeyExists = ValidationUtils.isRequiredIdentifierExists(identifierList, "recordKey")

        when:
        try {
            MedicationStatementValidator.validateMedication(medication, recordKeyExists)
        } catch (IhrBadRequestException ibre) {
            result = ibre.getMessage()
        }

        then:
        result == expected

        where:
        desc     | identifierText | identifierValue | condition  | system                 | code  || expected
        "Test 1" | "recordKey"    | "value"         | ""         | MEDICATION_CODE_SYSTEM | "123" || ""
        "Test 2" | "recordKey"    | ""              | ""         | ""                     | "123" || CODE_OR_SYSTEM_MISSING
        "Test 3" | "recordKey"    | ""              | ""         | MEDICATION_CODE_SYSTEM | ""    || CODE_OR_SYSTEM_MISSING
        "Test 4" | "recordKey"    | ""              | "codeable" | ""                     | ""    || MedicationStatementValidator.CONCEPT_CODE_REQUIRED
        "Test 5" | "recordKey"    | "value"         | ""         | ""                     | ""    || ""
        "Test 6" | "recordKey"    | "value"         | ""         | MEDICATION_CODE_SYSTEM | ""    || CODE_OR_SYSTEM_MISSING
        "Test 7" | "recordKey"    | "value"         | ""         | "xyx"                  | "123" || MISSING_MEDICATION_CODE
        "Test 8" | "recordKey"    | "value"         | "codeable" | "xyx"                  | "123" || ""
    }

    @Unroll
    void "Validate validateMedicationIdentifier #desc"() {

        def result = ""
        given:
        def medication = new Medication()
        medication.addIdentifier(buildIdentifier(identifierText, identifierValue))

        when:
        try {
            MedicationStatementValidator.validateMedication(medication, false)
        } catch (IhrBadRequestException ibre) {
            result = ibre.getMessage()
        }

        then:
        result == expected

        where:
        desc                   | identifierText | identifierValue | expected
        "Incorrect identifier" | "recordKey"    | "value"         | INVALID_IDENTIFIER
        "Happy Path"           | "conceptChid"  | "conceptChid"   | ""
        "Null values"          | null           | null            | MedicationStatementValidator.CONCEPT_CODE_REQUIRED
    }

    @Unroll
    void "Validate validateMedicationReference #desc"() {
        def error = false
        given:
        def statement = new MedicationStatement()
        statement.setMedication(null)
        try {
            MedicationStatementValidator.validateMedicationReference(statement, false)
        } catch (IhrBadRequestException) {
            error = true
        }

        expect:
        error
    }

    @Unroll
    void "Test isActionFlagUpsert #desc"() {
        def result = false
        given:
        def codingList = [buildActionFlag(code, display)] as List<Coding>

        when:
        result = MedicationStatementValidator.of().isActionFlagUpsert(codingList)

        then:
        result == expected

        where:
        desc             | code         | display  || expected
        "Happy Path"     | "actionFlag" | "Upsert" || true
        "UnHappy Path 1" | "actionFlag" | "Delete" || false
        "UnHappy Path 2" | "actonFlag"  | "Upsert" || false
        "UnHappy Path 3" | ""           | "Upsert" || false
    }

    @Unroll
    void "Test isUrlValidForMedicationExtension #desc"() {
        def result = false
        given:
        List<Extension> extensionList = new ArrayList()
        def extension = buildExtension(url, date)
        extensionList.add(extension)

        when:
        result = MedicationStatementValidator.isUrlValidForMedicationExtension(extensionList)

        then:
        result == expected

        where:
        desc             | url                                                      | date         || expected
        "Happy Path 1"   | MedicationStatementValidator.IHR_HOLD_DATE_URL           | "2018/03/28" || true
        "Happy Path 2"   | MedicationStatementValidator.IHR_ADHERENCE_STOP_DATE_URL | "2019/03/28" || true
        "Happy Path 3"   | MedicationStatementValidator.IHR_RESTART_DATE_URL        | "2020/03/28" || true
        "Happy Path 4"   | MedicationStatementValidator.TAKEN_AS_ORDERED_URL        | "2018/03/28" || true
        "UnHappy Path 1" | ""                                                       | "2018/03/28" || false
    }

    @Unroll
    void "Test medicationStatusReason #desc"() {
        def success = true
        def message = ""
        given:
        def concept = new CodeableConcept()
        def coding = buildCoding(system, code)
        concept.addCoding(coding)
        if (addCode) {
            concept.addCoding(coding)
        }

        when:
        try {
            MedicationStatementValidator.medicationStatusReason(concept)
        }
        catch (IhrBadRequestException ibre) {
            success = false
            message = ibre.getMessage()
        }

        then:
        success == pass
        message == errMsg

        where:
        desc            | system                                         | addCode | code  || pass  | errMsg
        "Happy Path 1"  | "http://snomed.info/sct"                       | false   | "xyz" || true  | ""
        "Multiple Code" | MedicationStatementValidator.IHR_HOLD_DATE_URL | true    | "xyz" || false | MedicationStatementValidator.STATUS_REASON_CODING_ERROR
        "System Null"   | null                                           | true    | "xyz" || false | CODE_OR_SYSTEM_MISSING
    }

    @Unroll
    void "Test MeidcationStatement validation #desc"() {
        given:
        def result = true
        Bundle resourceBundle = getResourceBundle(fileName)
        def wrapper = FhirAttributesWrapper.builder().employeeId(new HashSet<>()).build()

        when:
        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof MedicationStatement) {
                try {
                    MedicationStatementValidator.of().validate((MedicationStatement) entity.getResource(), wrapper)
                }
                catch (IhrBadRequestException ibre) {
                    result = false
                }
            }
        }

        then:
        result == expected

        where:
        desc                                 | fileName     | expected
        "Happy Path 1"                       | "ngpd.json"  | true
        "Only Upsert Flag is allowed"        | "ngpd1.json" | false
        "Status exists recordKey missing"    | "ngpd2.json" | false
        "StatusReason exists status missing" | "ngpd3.json" | false
    }

    @Unroll
    void "Test isMedicationEditableFieldAvailable #desc"() {
        given:
        def result = false
        Bundle resourceBundle = getResourceBundle(fileName)

        when:
        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof MedicationStatement) {
                result = MedicationStatementValidator.isMedicationEditableFieldAvailable((MedicationStatement) entity.getResource())
            }
        }

        then:
        result == expected

        where:
        desc             | fileName                || expected
        "Happy Path 1"   | "ngpd.json"             || true
        "Unhappy Path 1" | "editable-missing.json" || false
    }

    @Unroll
    def "Test validateMedicationReference #desc"() {
        given:
        def statement = buildMedicationStatement()
        def medication = buildMedication()
        def exception = false
        def errorMessage = ""

        when:
        try {
            statement.setMedication(new Reference(medication).setReference(referenceValue))
            statement.getMedicationReference().setResource(resource)
            statement.getMedicationReference().setReference(referenceValue)
            if (null != statement.getMedicationReference().getResource() && seCodeAndIdentifier) {
                ((Medication) statement.getMedicationReference().getResource()).addIdentifier(buildIdentifier(identifierText, "08908909"))
                ((Medication) statement.getMedicationReference().getResource()).setCode(new CodeableConcept(buildCoding(codeText, "235234")))
            }
            MedicationStatementValidator.validateMedicationReference(statement, recordKey)
        } catch (IhrBadRequestException ibre) {
            exception = true
            errorMessage = ibre.getMessage()
        }

        then:
        exception == failed
        errorMessage == errMessage

        where:
        desc                                  | recordKey | resource          | referenceValue                   | seCodeAndIdentifier | codeText               | identifierText || failed | errMessage
        "Happy Path"                          | false     | buildMedication() | "Medication/" + resource.getId() | true                | MEDICATION_CODE_SYSTEM | "conceptChid"  || false  | ""
        "Null resource"                       | false     | null              | "Medication/" + "123532"         | false               | MEDICATION_CODE_SYSTEM | "conceptChid"  || true   | "Invalid Medication Reference"
        "Null resource and invalid reference" | false     | null              | null                             | false               | MEDICATION_CODE_SYSTEM | "conceptChid"  || true   | MedicationStatementValidator.MEDICATION_REQUIRED
        "Missing Code and Identifier"         | false     | buildMedication() | "Medication/" + resource.getId() | false               | MEDICATION_CODE_SYSTEM | "conceptChid"  || true   | MedicationStatementValidator.CONCEPT_CODE_REQUIRED
        "Invalid Identifier"                  | false     | buildMedication() | "Medication/" + resource.getId() | true                | MEDICATION_CODE_SYSTEM | "conceptChi"   || true   | INVALID_IDENTIFIER
        "Invalid Code"                        | false     | buildMedication() | "Medication/" + resource.getId() | true                | "codesytem"            | "conceptChid"  || true   | MISSING_MEDICATION_CODE

    }


    def "Test validateInformationSourceReference #desc"() {
        given:
        def exception = false

        when:
        for (Bundle.BundleEntryComponent entity : statementBundle.getEntry()) {
            if (entity.getResource() instanceof MedicationStatement) {
                try {
                    def statement = (MedicationStatement) entity.getResource()
                    if (setReferenceToNull) {
                        statement.setInformationSource(null)
                    }
                    MedicationStatementValidator.validateInformationSourceReference(statement, null)
                } catch (IhrBadRequestException ibre) {
                    exception = true
                }
            }
        }
        then:
        exception == failed

        where:
        desc           | setReferenceToNull || failed
        "Happy Path"   | false              || false
        "UnHappy Path" | true               || true
    }

    def "Validate  validateDoseAndRateQuantity  #desc"() {

        given:
        def text = "test doseAndRateQuantity"
        MedicationStatement ms = buildDosage(text, value, unit)

        when:
        def isValid = false
        def validationMessage = null

        try {
            MedicationStatementValidator.validateDoseAndRateQuantity(ms.getDosage().get(0).getDoseAndRate());
            isValid = true
        }
        catch (IhrBadRequestException | Exception ee) {
            validationMessage = ee.getMessage()
            isValid = false
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        desc                                     | value | unit  || errorMessage                                              || expected
        "passes "                                | 1     | "TAB" || null                                                      || true
        "invalid dQV value ,dQU present "        | 1.2   | "tab" || MedicationStatementValidator.MISSING_MED_DOSAGE_QV        || false
        "dQV value  present ,invalid dQU "       | 1     | " "   || MedicationStatementValidator.MISSING_MED_DOSAGE_QU        || false
        "dQV not present ,dQU present"           | null  | "mg"  || MedicationStatementValidator.DOSE_QUANTITY_VALUE_REQUIRED || false
        "passes - dQV present ,dQU not present " | 1     | null  || null                                                      || true
    }

}

