package com.uhg.ihr.api.model

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.model.ActorIdType
import com.uhg.ihr.centrihealth.api.model.FhirMapper
import com.uhg.ihr.centrihealth.api.util.KafkaPayloadUtils
import com.uhg.ihr.centrihealth.api.validator.CoverageEnum
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.Coverage
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.MedicationStatement
import spock.lang.Unroll

@Unroll
class FHIRMapperSpec extends BaseFhirSpecification {

    def "Validate api request object population from fhir bundle"() {

        given:
        def resourceBundle = getResourceBundle(fileName)
        def fhirMapper = new FhirMapper()

        when:
        def senzingRequest = fhirMapper.buildSenzingRequest(resourceBundle)

        then:
        f_name == senzingRequest.getNameFirst()
        l_name == senzingRequest.getNameLast()
        search_id == senzingRequest.getSearchId()

        where:
        fileName      | f_name    | l_name    | search_id
        "bundle.json" | "Captain" | "America" | "471180426"
    }

    def "Test getReferenceIdsForResources"() {

        given:
        def actorIdMap = [(ActorIdType.PATIENT): "XXXTEST003"]
        def actorIdsList = KafkaPayloadUtils.getActorIdsList(actorIdMap)
        def resourceBundle = getResourceBundle(fileName)

        when:
        def ids = FhirMapper.getReferenceIdsForResources(resourceBundle, actorIdsList)

        then:
        ids.size() == count

        where:
        fileName                   | count
        "unReferredResource.json"  | 5
        "unReferredResource1.json" | 3
    }

    def "Test createIngestBundleJson"() {

        given:
        def actorIdMap = [(ActorIdType.PATIENT): "XXXTEST003"]
        def resourceBundle = getResourceBundle("ingest_medication.json")

        when:
        def actorIdsList = KafkaPayloadUtils.getActorIdsList(actorIdMap)
        def nodeAsString = FhirMapper.createIngestBundleJson(resourceBundle, actorIdsList)

        then:
        nodeAsString.contains("{\"resourceType\":\"Patient\",\"id\":\"4c2f3281-eab3-459c-840c-862c7528277e\",")
        nodeAsString.contains("{\"resourceType\":\"Coverage\",\"id\":\"74b2befb-2cc8-4de6-8325-458e0c47fcfe\",")
        nodeAsString.contains("{\"type\":{\"text\":\"actorId\"},\"value\":\"XXXTEST003\"}")
        nodeAsString.contains("{\"resourceType\":\"MedicationStatement\",\"id\":\"7ab2befb-2cc8-4de6-8325-458e0c47fcfe\",")
        nodeAsString.contains("{\"lastUpdated\":\"2019-10-24T13:33:05.000+00:00\",\"tag\":[{\"code\":\"actionFlag\",\"display\":\"Upsert\"}]}")
        nodeAsString.contains("\"identifier\":[{\"type\":{\"text\":\"recordKey\"}")
        nodeAsString.contains("{\"reference\":\"Practitioner/4c2f3281-eab3-459c-840c-862c7528277i\"}")
        nodeAsString.contains("{\"type\":{\"text\":\"NPI\"},\"value\":\"1234567890\"}],\"name\":[{\"text\":\"Author/name\"}]}}")
        nodeAsString.contains("\"time\":\"2018-03-28T00:00:00+00:00\",\"text\":\"Patient reports rationing medication due to its expense.\"}")
        nodeAsString.contains("{\"resourceType\":\"PractitionerRole\",\"id\":\"5bce63a1-c894-4c07-809d-15b48ed91d7f\",")
    }

    def "Test processCoverage"() {

        given:
        def actorIdMap = [(ActorIdType.PATIENT): "XXXTEST003"]
        def actorIdsList = KafkaPayloadUtils.getActorIdsList(actorIdMap)
        def resourceBundle = getResourceBundle("ingest_medication.json")
        def actorId = null

        when:
        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Coverage) {
                Coverage coverage = (Coverage) entity.getResource()
                FhirMapper.processCoverage(coverage, actorIdsList)
                for (Identifier identifier : coverage.getIdentifier()) {
                    if (identifier.getType().getText() == CoverageEnum.ACTOR_ID.getValue()) {
                        actorId = identifier.getValue()
                        break
                    }
                }
                break
            }
        }

        then:
        actorId == "XXXTEST003"
    }

    def "Test validateDataAuthorIdentifier #desc"() {

        given:
        Bundle resourceBundle = getResourceBundle(filename)
        def exceptionMessage = ""

        when:
        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof MedicationStatement) {
                try {
                    MedicationStatement medicationStatement = (MedicationStatement) entity.getResource()
                    ValidationUtils.validateEmployeeId(medicationStatement.getIdentifier(), fhirAttributesWrapper)
                } catch (IhrBadRequestException ibre) {
                    exceptionMessage = ibre.getMessage()
                }
            }
        }

        then:
        exceptionMessage == expected

        where:
        desc           | filename                   | expected
        "Happy Path"   | "multi-medication.json"    | ""
        "UnHappy Path" | "mismatch-reviewerId.json" | ValidationUtils.EMPLOYEE_IDS_MISMATCH
    }

    def "Test buildSenzingRequest #desc"() {

        given:
        Bundle resourceBundle = getResourceBundle(filename)
        def senzingRequest

        when:
        senzingRequest = FhirMapper.buildSenzingRequest(resourceBundle)

        then:
        senzingRequest.getNameFirst() == firstName
        senzingRequest.getNameLast() == lastName
        senzingRequest.getDateOfBirth() == dob
        senzingRequest.getSearchId() == searchId
        senzingRequest.getEmpId() == empId

        where:
        desc          | filename                        | firstName | lastName | dob          | searchId         | empId
        "Happy Path"  | "ihr-api-ingest_new_edits.json" | "Minnie"  | "Mouse"  | "1959/05/26" | "00000251082177" | "NMOON1000"
        "Null values" | "patient_missing.json"          | null      | null     | null         | null             | null
    }
}
