package com.uhg.ihr.api.logging

import com.uhg.ihr.centrihealth.api.exception.HttpResponseException
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.exception.IhrFhirParseException
import com.uhg.ihr.centrihealth.api.exception.IhrNotAcceptableException
import com.uhg.ihr.centrihealth.api.exception.IhrNotFoundException
import com.uhg.ihr.centrihealth.api.logging.LoggingFilter
import com.uhg.ihr.centrihealth.api.security.Encryptor
import io.micronaut.http.HttpMethod
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpStatus
import io.micronaut.http.MutableHttpResponse
import io.micronaut.http.simple.SimpleHttpRequest
import io.micronaut.security.authentication.AuthenticationException
import spock.lang.Specification
import spock.lang.Unroll

import javax.validation.ConstraintViolation
import javax.validation.ConstraintViolationException

class LoggingFilterSpec extends Specification {

    public static final String TOKEN = "Bearer eyJhbGciOiJSUzUxMiJ9"
    public static final String CORRELATION_HEADER = "optum-cid-ext"
    public static final String CORRELATION_ID = "Test"
    public static final String CONTENT_TYPE = "application/fhir+json"
    public static final String ACCEPT = "Accept"

    def httpRequest = HttpRequest.PUT("/bundles/v1", "")
            .header(ACCEPT, CONTENT_TYPE)
            .header(CORRELATION_HEADER, CORRELATION_ID)
            .header("JWT", TOKEN)

    @Unroll
    def "it logs httpStatus fail #desc"() {
        when:
        def req = httpRequest
        LoggingFilter.addErrorHttpStatus(req, inputEx)
        def code = req.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())

        then:
        code.get("httpStatus") == expectedCode

        where:
        desc            | inputEx                                                                 || expectedCode
        'notFound'      | new IhrNotFoundException("oh no")                                       || 404
        'badRequest'    | new IhrBadRequestException("oh no")                                     || 400
        'badRequest'    | new IhrFhirParseException("oh no")                                      || 400
        'badRequest'    | new HttpResponseException(400, "oh no")                                 || 400
        'invalid'       | new ConstraintViolationException(new HashSet<ConstraintViolation<?>>()) || 400
        'unauthorized'  | new AuthenticationException("oh no")                                    || 401
        'notAcceptable' | new IhrNotAcceptableException("oh no")                                  || 406
        'unknown'       | new RuntimeException()                                                  || 500
    }

    @Unroll
    def "it logs httpStatus happy path #desc"() {
        given:
        Encryptor encryptor = new Encryptor("testPublicKey")
        LoggingFilter loggingFilter = new LoggingFilter(false, encryptor)
        MutableHttpResponse res = Mock(MutableHttpResponse)
        res.getStatus() >> status
        HttpRequest<String> req = new SimpleHttpRequest(HttpMethod.PUT, "http://hello.com/example", null)

        when:
        if (desc == "success") {
            loggingFilter.log(req, res, null)
        } else if (desc == "internalServerError") {
            loggingFilter.log(req, res, new Throwable("test error"))
        } else if (desc == "unauthorized") {
            loggingFilter.log(req, res, new AuthenticationException("unauthorized"))
        } else {
            loggingFilter.log(req, res, null)
        }
        def code = req.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())

        then:
        code.get("httpStatus") == expectedCode
        code.get("error") == errorMessage

        where:
        desc                  | status                           | errorMessage   || expectedCode
        'success'             | HttpStatus.ACCEPTED              | null           || 202
        'unauthorized'        | HttpStatus.UNAUTHORIZED          | "unauthorized" || 401
        'internalServerError' | HttpStatus.INTERNAL_SERVER_ERROR | "test error"   || 500
        'empty'               | null                             | null           || 202
    }
}