package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.validator.OrganizationValidator
import com.uhg.ihr.centrihealth.api.validator.PatientValidator
import com.uhg.ihr.centrihealth.api.validator.PractitionerValidator
import com.uhg.ihr.centrihealth.api.validator.ProvenanceValidator
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Organization
import org.hl7.fhir.r4.model.Patient
import org.hl7.fhir.r4.model.Practitioner
import org.hl7.fhir.r4.model.Provenance
import org.hl7.fhir.r4.model.Reference
import org.hl7.fhir.r4.model.RelatedPerson
import org.hl7.fhir.r4.model.Resource
import org.junit.platform.commons.util.StringUtils
import spock.lang.Unroll

@Unroll
class ProvenanceValidatorSpec extends BaseFhirSpecification {

    static final String RELATIONSHIP_TEXT = "Health Care Proxy"
    def dob = toDate("1985/03/21")
    static final validator = ProvenanceValidator.of()
    def message = ""

    def "Validate Target #desc"() {

        given:
        def provenance = buildProvenance()
        def medication = buildMedicationStatement()

        when:
        try {
            provenance.addTarget(new Reference(medication).setReference(medRefValue))
            provenance.getTargetFirstRep().setResource(medResource)
            provenance.getTargetFirstRep().setReference(medRefValue)
            if (setTargetNull) {
                provenance.setTarget(null)
            }
            validator.validateTarget(provenance)

        }
        catch (Exception ex) {
            message = ex.getMessage()
            println(message)
        }

        then:
        message == errorMessage

        where:
        desc               | medResource                | medRefValue                                  | setTargetNull || errorMessage
        "Happy Path"       | buildMedicationStatement() | "MedicationStatement/" + medResource.getId() | false         || ""
        "Resource is Null" | null                       | "MedicationStatement/" + "123532"            | false         || ProvenanceValidator.INVALID_TARGET_REFERENCE
        "Target is Null"   | null                       | null                                         | true          || ProvenanceValidator.TARGET_REQUIRED

    }

    def "Validate Recorded #desc"() {

        given:
        Provenance provenance = new Provenance()
        provenance.setRecorded(toDateFromUtc(recordedDate))
        def exception = false

        when:
        try {
            validator.validateRecorded(provenance)
        }
        catch (Exception ex) {
            exception = true
        }

        then:
        exception == failed


        where:
        desc           | recordedDate                    || failed
        "Date is null" | ""                              || true
        "Success "     | "2019-10-24T13:33:05.000+00:00" || false
    }


    def "Validate AgentType"() {
        given:
        Provenance provenance = new Provenance()
        Provenance.ProvenanceAgentComponent agentComponent = new Provenance.ProvenanceAgentComponent()
        CodeableConcept concept = new CodeableConcept()
        agentComponent.setType(concept)
        provenance.addAgent(agentComponent)
        def exception = false

        when:
        def coding = buildCodingForAgent(system, code, display)
        concept.addCoding(coding)
        try {
            validator.validateAgentType(provenance.getAgent())
        } catch (Exception ex) {
            exception = true
            message = ex.getMessage()
        }

        then:
        exception == failed
        message == errorMessage

        where:
        desc                            | system                                    | code     | display     || failed | errorMessage
        "Happy Path"                    | ProvenanceValidator.AGENT_TYPE_SYSTEM_URL | "author" | "Author"    || false  | ""
        "System is incorrect"           | "xyz.url"                                 | "author" | "Author"    || true   | ProvenanceValidator.AGENT_TYPE_EXCEPTION
        "System is null"                | null                                      | "author" | "Author"    || true   | ProvenanceValidator.AGENT_TYPE_EXCEPTION
        "Code is null"                  | ProvenanceValidator.AGENT_TYPE_SYSTEM_URL | null     | "Author"    || true   | ProvenanceValidator.AGENT_TYPE_EXCEPTION
        "Code is incorrect"             | ProvenanceValidator.AGENT_TYPE_SYSTEM_URL | "autho"  | "Author"    || true   | "Unknown ProvenanceAgentType code 'autho'"
        "Display is null"               | ProvenanceValidator.AGENT_TYPE_SYSTEM_URL | "author" | null        || true   | ProvenanceValidator.AGENT_TYPE_EXCEPTION
        "Display is incorrect"          | ProvenanceValidator.AGENT_TYPE_SYSTEM_URL | "author" | "AUTHOR"    || true   | ProvenanceValidator.AGENT_TYPE_EXCEPTION
        "Code and Display is different" | ProvenanceValidator.AGENT_TYPE_SYSTEM_URL | "author" | "Assembler" || true   | ProvenanceValidator.AGENT_TYPE_EXCEPTION
    }

    def "validate AgentWho for Incorrect Reference #desc"() {
        given:
        Bundle bundle = buildProvAgentWhoMedicationBundle()

        when:
        for (Bundle.BundleEntryComponent entry : bundle.getEntry()) {
            if (entry.getResource() instanceof Provenance) {
                Provenance provenance = (Provenance) entry.getResource()
                validator.validateAgentWho(provenance.getAgent(), null)
            }
        }

        then:
        IhrBadRequestException ex = thrown()
        ex.getMessage() == ProvenanceValidator.INVALID_AGENT_WHO_REFERENCE

    }


    def "validate AgentWho For Patient"() {
        given:
        Bundle bundle = buildProvAgentWhoPatientBundle()
        def exception = false

        when:
        try {
            for (Bundle.BundleEntryComponent entry : bundle.getEntry()) {
                if (entry.getResource() instanceof Provenance) {
                    Provenance provenance = (Provenance) entry.getResource()
                    if ((Resource) provenance.getAgentFirstRep().getWho().getResource() instanceof Patient) {
                        Patient patient = (Patient) provenance.getAgentFirstRep().getWho().getResource()
                        if (StringUtils.isNotBlank(fn)) {
                            patient.addName(buildHumanName(fn, ln))
                        }
                        if (addDob) {
                            patient.setBirthDate(dob)
                        }
                        validator.validateAgentWho(provenance.getAgent(), null)
                    }
                }
            }
        }
        catch (Exception ex) {
            exception = true
            message = ex.getMessage()
        }

        then:
        exception == failed
        message == errorMessage

        where:
        desc           | fn   | ln   | addDob || failed | errorMessage
        "Happy Path"   | "fn" | "ln" | true   || false  | ""
        "fn is blank"  | ""   | "ln" | true   || true   | PatientValidator.PATIENT_NAME_MISSING
        "DOB is blank" | "fn" | "ln" | false  || true   | PatientValidator.INVALID_BIRTHDAY_FORMAT
    }

    def "validate AgentWho For RelatedPerson"() {
        given:
        Bundle bundle = buildProvAgentWhoRPBundle()
        def exception = false

        when:
        try {
            for (Bundle.BundleEntryComponent entry : bundle.getEntry()) {
                if (entry.getResource() instanceof Provenance) {
                    Provenance provenance = (Provenance) entry.getResource()
                    RelatedPerson person = (RelatedPerson) provenance.getAgentFirstRep().getWho().getResource()
                    if (StringUtils.isNotBlank(fn)) {
                        person.addName(buildHumanName(fn, ln))
                    }
                    person.setBirthDate(dob)
                    if (StringUtils.isNotBlank(codeText)) {
                        person.addRelationship(buildCodeableConcept(codeText))
                    }
                    validator.validateAgentWho(provenance.getAgent(), null)
                }
            }
        }
        catch (Exception ex) {
            exception = true
            message = ex.getMessage()
        }

        then:
        exception == failed
        message == errorMessage

        where:
        desc                    | fn   | ln   | codeText    || failed | errorMessage
        "Happy Path"            | "fn" | "ln" | "Caregiver" || false  | ""
        "FName is blank"        | ""   | "ln" | "Caregiver" || false  | ""
        "Relationship is blank" | "fn" | "ln" | ""          || false  | ""
        "All are blank"         | ""   | ""   | ""          || true   | "Either relationship or Name and DOB should be available"
    }

    def "validate AgentWho For Practitioner"() {
        given:
        Bundle bundle = buildProvAgentWhoPractBundle()
        def exception = false

        when:
        try {
            for (Bundle.BundleEntryComponent entry : bundle.getEntry()) {
                if (entry.getResource() instanceof Provenance) {
                    Provenance provenance = (Provenance) entry.getResource()
                    Practitioner practitioner = (Practitioner) provenance.getAgentFirstRep().getWho().getResource()
                    practitioner.addIdentifier(buildIdentifier(identifierText, identifierText))
                    validator.validateAgentWho(provenance.getAgent(), null)
                }
            }
        }
        catch (Exception ex) {
            exception = true
            message = ex.getMessage()
        }

        then:
        exception == failed
        message == errorMessage

        where:
        desc                    | identifierText | identifierValue || failed | errorMessage
        "NPI is present"        | "NPI"          | "7089890980"    || false  | ""
        "EmployeeId is present" | "employeeId"   | "1212312"       || false  | ""
        "Both is null"          | ""             | ""              || true   | PractitionerValidator.IDENTIFIER_EXCEPTION
    }

    def "validate AgentWho For Organization"() {
        given:
        Bundle bundle = buildProvAgentWhoOrgBundle()
        def exception = false

        when:
        try {
            for (Bundle.BundleEntryComponent entry : bundle.getEntry()) {
                if (entry.getResource() instanceof Provenance) {
                    Provenance provenance = (Provenance) entry.getResource()
                    Organization organization = (Organization) provenance.getAgentFirstRep().getWho().getResource()
                    organization.addIdentifier(buildIdentifier(identifierText, identifierValue))
                    validator.validateAgentWho(provenance.getAgent(), null)
                }
            }
        }
        catch (Exception ex) {
            exception = true
            message = ex.getMessage()
        }

        then:
        exception == failed
        message == errorMessage

        where:
        desc          | identifierText | identifierValue || failed | errorMessage
        "Happy Path"  | "NPI"          | "31388989"      || false  | ""
        "NPI is null" | "sd"           | "31388989"      || true   | OrganizationValidator.INVALID_ORGANIZATION_IDENTIFIER
    }

    def "Test Agent"() {
        given:
        def provenance = new Provenance()
        def errorMessage = ProvenanceValidator.AGENT_REQUIRED

        when:
        validator.validateAgent(provenance, fhirAttributesWrapper)

        then:
        IhrBadRequestException ex = thrown()
        errorMessage == ex.getMessage()
    }
}
