package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.validator.ConditionValidator
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.Condition
import org.hl7.fhir.r4.model.Extension

class ConditionValidatorSpec extends BaseFhirSpecification {


    def "Valid Condition test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle("condition.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Condition) {

                try {
                    Condition condition = (Condition) entity.getResource()
                    ConditionValidator.of().validate(condition, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage
        where:
        description | fileName         || errorMessage || expected
        "HappyPath" | "condition.json" || null         || true
    }

    def "Invalid Condition test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle("condition.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Condition) {

                try {
                    Condition condition = (Condition) entity.getResource()
                    if (scenario == "extension") {
                        def extensionList = [new Extension()] as List<Extension>
                        condition.setExtension(extensionList)
                    }
                    ConditionValidator.of().validate(condition, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description          | scenario    || errorMessage                         || expected
        "ConditionExtension" | "extension" || ConditionValidator.INVALID_EXTENSION || false
    }
}
