package com.uhg.ihr.api.exception

import com.uhg.ihr.centrihealth.api.exception.HttpResponseException
import com.uhg.ihr.centrihealth.api.exception.HttpResponseExceptionHandler
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpStatus
import spock.lang.Specification

class HttpResponseExceptionHandlerSpec extends Specification {

    HttpRequest mockHttpRequest = Mock(HttpRequest)
    HttpResponseException httpResponseException = new HttpResponseException(HttpStatus.UNPROCESSABLE_ENTITY.getCode(), "Exception Message");

    HttpResponseExceptionHandler httpResponseExceptionHandler = new HttpResponseExceptionHandler()

    def "HttpResponseExceptionHandler:handle"() {
        when:
        def result = httpResponseExceptionHandler.handle(mockHttpRequest, httpResponseException)

        then:
        result.getStatus().code == HttpStatus.UNPROCESSABLE_ENTITY.getCode()
    }

}