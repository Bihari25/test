package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.validator.CareGiverValidator
import com.uhg.ihr.centrihealth.api.validator.CareTeamValidator
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CareTeam
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Identifier

class CareGiverValidatorSpec extends BaseFhirSpecification {
    def "Valid CareGivertest cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle(fileName)

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof CareTeam) {

                try {
                    CareTeam  caregiver = (CareTeam) entity.getResource();
                    CareGiverValidator.validate(caregiver);
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description | fileName        || errorMessage || expected
        "HappyPath" | "careGiver.json" || null         || true
    }

    def "Invalid CareGiver test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle("careGiver.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof CareTeam) {

                try {
                    CareTeam caregiver = (CareTeam) entity.getResource()
                    if (scenario == "referenceId") {
                        caregiver.addIdentifier(new Identifier().setType(new CodeableConcept().setText("reference")))
                    }
                    CareGiverValidator.validate(caregiver);
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description   | scenario      || errorMessage                           || expected
        "ReferenceId" | "referenceId" || ValidationUtils.INVALID_IDENTIFIER_KEY || false
    }
}
