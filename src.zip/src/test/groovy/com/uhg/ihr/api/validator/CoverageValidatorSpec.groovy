package com.uhg.ihr.api.validator

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.util.AppUtils
import com.uhg.ihr.centrihealth.api.validator.CoverageValidator
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.Coverage
import spock.lang.Shared
import spock.lang.Unroll

@Unroll
class CoverageValidatorSpec extends BaseFhirSpecification {

    @Shared
    String INVALID_IDENTIFIER_KEY = "Invalid identifier"
    @Shared
    String MISSING_IDENTIFIER_VALUE = "Missing value for Identifier"
    @Shared
    String MISSING_SEARCH_ID = "Missing Search Id"


    def "Coverage test cases #desc"() {

        given:
        Bundle resourceBundle = getResourceBundle("medicationStatement.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Coverage) {
                try {
                    Coverage coverage = (Coverage) entity.getResource()
                    if (condition == "searchIdIsNull") {
                        coverage.getIdentifierFirstRep().getType().setText("")
                    } else if (condition == "searchIdValueIsNull") {
                        coverage.getIdentifierFirstRep().setValue("")
                    } else if (condition == "IncorrectSearchIdText") {
                        coverage.getIdentifierFirstRep().getType().setText("search")
                    } else if (condition == "correIdIsNull") {
                        coverage.getIdentifier().get(1).getType().setText("")
                    } else if (condition == "correIdValueIsNull") {
                        coverage.getIdentifier().get(1).setValue("")
                    } else if (condition == "IncorrectCorreIdText") {
                        coverage.getIdentifier().get(1).getType().setText("corr")
                    }
                    CoverageValidator.validate(coverage, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        desc                           | condition               || errorMessage             || expected
        "HappyPath"                    | ""                      || null                     || true
        "Missing searchId Text"        | "searchIdIsNull"        || INVALID_IDENTIFIER_KEY   || false
        "Missing searchId value"       | "searchIdValueIsNull"   || MISSING_IDENTIFIER_VALUE || false
        "Incorrect searchId Text"      | "IncorrectSearchIdText" || INVALID_IDENTIFIER_KEY   || false
        "Missing correlationId Text"   | "correIdIsNull"         || INVALID_IDENTIFIER_KEY   || false
        "Missing correlationId value"  | "correIdValueIsNull"    || MISSING_IDENTIFIER_VALUE || false
        "Incorrect correlationId Text" | "IncorrectCorreIdText"  || INVALID_IDENTIFIER_KEY   || false
    }

    def "Test Search Id #desc"() {

        given:
        String message = AppUtils.readResource("medicationStatement.json")
        JsonNode dataNode = MAPPER.readValue(message, JsonNode.class)

        if (isSearchIdMissing) {
            ((ObjectNode) dataNode.get("entry").get(1).get("resource").get("identifier").get(0)).put("value", "")
        }
        def resourceBundle = getBundle(dataNode.toString())
        def validator = new CoverageValidator()
        def error = false

        when:
        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Coverage) {
                try {
                    Coverage coverage = (Coverage) entity.getResource()
                    validator.validate(coverage, fhirAttributesWrapper)
                } catch (Exception ex) {
                    error = true
                }
            }
        }

        then:
        error == failed

        where:
        desc           | isSearchIdMissing | failed
        "Happy Path"   | false             | false
        "UnHappy Path" | true              | true
    }
}
