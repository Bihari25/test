package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.validator.PractitionerValidator
import org.hl7.fhir.r4.model.Practitioner
import spock.lang.Unroll

@Unroll
class PractitionerValidatorSpec extends BaseFhirSpecification{

    def "Test validateIdentifier"() {

        given:
        def exception = false
        Practitioner practitioner = new Practitioner()
        practitioner.addIdentifier(buildIdentifier(identifierText, identifierValue))

        when:
        try {
            PractitionerValidator.of().validateIdentifier(practitioner)
        }
        catch (IhrBadRequestException ibr) {
            exception = true
        }

        then:
        exception == failed

        where:
        desc                         | identifierText | identifierValue || failed
        "employeeId present"         | "employeeId"   | "12345"         || false
        "NPI present"                | "NPI"          | "12345"         || false
        "employeeId is incorrect"    | "employeId"    | "12345"         || true
        "NPI is incorrect"           | "npi"          | "12345"         || true
        "employeeId value is null "  | "employeeId"   | null            || true
        "employeeId value is blank " | "employeeId"   | " "             || true
        "NPI value is null "         | "NPI"          | null            || true
        "NPI value is blank "        | "NPI"          | " "             || true
    }
}
