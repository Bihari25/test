package com.uhg.ihr.api.validator


import com.uhg.ihr.api.util.TestData
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.model.FhirMapper
import com.uhg.ihr.centrihealth.api.validator.FhirValidator
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.MedicationStatement
import org.hl7.fhir.r4.model.Provenance
import org.hl7.fhir.r4.model.Reference
import org.hl7.fhir.r4.model.ResourceType
import spock.lang.Unroll

@Unroll
class FhirValidatorSpec extends TestData {

    def "Test for resource availability #desc"() {

        given:
        Bundle resourceBundle = getResourceBundle(fileName)

        if ("bundleId".equals(condition)) {
            resourceBundle.setId(null)
        } else if ("resourceId".equals(condition)) {
            MedicationStatement statement = getResourceFromBundle(resourceBundle, ResourceType.MedicationStatement)
            statement.setId(null)
        }

        when:
        def exceptionMessage = ""
        try {
            FhirValidator.isRequiredResourceAvailable(resourceBundle)
        } catch (IhrBadRequestException ibre) {
            exceptionMessage = ibre.getMessage()
        }

        then:
        exceptionMessage.contains(expected)

        where:
        desc | fileName                  | condition    || expected
        "1"  | "ingest_medication.json"  | ""           || ""
        "2"  | "ingest_medication.json"  | "bundleId"   || "Invalid bundle id"
        "3"  | "ingest_medication.json"  | "resourceId" || "Invalid resource id : MedicationStatement"
        "4"  | "allergyIntolerance.json" | ""           || ""
        "5"  | "condition.json"          | ""           || ""

    }


    def "Test isResourceIdUnique #desc"() {

        given:
        Bundle resourceBundle = getResourceBundle(filename)
        def status = true

        when:

        try {
            FhirValidator.isResourceIdUnique(resourceBundle)
        } catch (IhrBadRequestException ibre) {
            status = false
        }

        then:
        status == expected

        where:
        desc            | filename                 || expected
        "Happy Path "   | "ingest_medication.json" || true
        "Duplicate ids" | "duplicate_ids.json"     || false
    }

    def "Test isMandatoryResourceAvailable #desc"() {

        def status = true
        given:
        Bundle resourceBundle = getResourceBundle(filename)

        when:

        try {
            FhirValidator.isMandatoryResourceAvailable(resourceBundle)
        } catch (IhrBadRequestException ibre) {
            status = false
        }

        then:
        status == expected

        where:
        desc                 | filename                            || expected
        "Happy Path "        | "ingest_medication_provenance.json" || true
        "Patient Missing"    | "patient_missing.json"              || false
        "Coverage Missing"   | "coverage_missing.json"             || false
        "Provenance Missing" | "ingest_medication.json"            || false
    }

    def "Test resource ids #desc"() {

        when:
        def valid = FhirValidator.isInValidResourceId(resourceId)

        then:
        valid == expected

        where:
        desc         | resourceId                                                          || expected
        "bundleId"   | "2019-01-02T03-04-44Z4Client-1234"                                  || false
        "invalidCol" | "2019-01-02T03:04:44Z4Client-1234"                                  || true
        "resourceId" | "4c2f3281-eab3-459c-840c-862c7528277e"                              || false
        "invalidAmp" | "2019-01-02T03&04&44Z4Client-1234"                                  || true
        "invalidHas" | "4c2f3281#eab3-459c#840c-862c7528277e"                              || true
        "exceed64"   | "4c2f3281-eab3-459c-840c-862c7528277e-eab3-459c-840c-345w-4c2f3281" || true
        "exact64"    | "4c2f3281-eab3-459c-840c-862c7528277e-eab3-459c-840c-345w-4c2f328"  || false
    }

    def "Test validateTargetForProvenance #desc"() {

        given:
        Bundle resourceBundle = buildProvenanceTargetBundle()
        def exception = false
        def message = ""

        when:
        Provenance provenance = getResourceFromBundle(resourceBundle, ResourceType.Provenance)
        try {
            if (count == 0) {
                provenance.setTarget(null)
            }
            FhirValidator.validateTargetForProvenance(provenance, count)
        } catch (IhrBadRequestException ibre) {
            exception = true
            message = ibre.getMessage()
        }
        then:
        exception == failed
        message == errorMessage

        where:
        desc                             | count || failed | errorMessage
        "Happy Path"                     | 2     || false  | ""
        "Duplicate References in target" | 3     || true   | FhirValidator.MISSING_RESOURCES_ERROR
        "Resources Missing in target"    | 1     || true   | FhirValidator.DUPLICATE_REFERENCES_ERROR
    }

    def "Test target for missing resources #desc"() {

        given:
        Bundle resourceBundle = defaultBundle()
        Provenance provenance = getResourceFromBundle(resourceBundle, ResourceType.Provenance)
        Reference reference = provenance.getTargetFirstRep()
        provenance.getTarget().get(1).setReference(reference.getReference())
        def bundleAsString = FhirMapper.bundleToString(resourceBundle)

        when:
        FhirValidator.parseAndValidateBundle(bundleAsString)

        then:
        IhrBadRequestException ex = thrown()
        ex.getMessage() == errorMessage

        where:
        desc                            || errorMessage
        "All resources are not covered" || FhirValidator.MISSING_RESOURCES_ERROR
    }
}
