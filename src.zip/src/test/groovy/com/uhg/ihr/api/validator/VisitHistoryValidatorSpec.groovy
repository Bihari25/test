package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.validator.HealthDeviceValidator
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils
import com.uhg.ihr.centrihealth.api.validator.VisitHistoryValidator
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Device
import org.hl7.fhir.r4.model.Encounter
import org.hl7.fhir.r4.model.Identifier
import spock.lang.Unroll

@Unroll
class VisitHistoryValidatorSpec extends BaseFhirSpecification {

    def "Valid VisitHistory test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle(fileName)

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Encounter) {

                try {
                    Encounter visit = (Encounter) entity.getResource()
                    VisitHistoryValidator.of().validate(visit, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description | fileName            || errorMessage || expected
        "HappyPath" | "visitHistory.json" || null         || true
    }

    def "Invalid visitHistory test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle("visitHistory.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Encounter) {

                try {
                    Encounter visit = (Encounter) entity.getResource()

                    if (scenario == "referenceId") {
                        visit.addIdentifier(new Identifier().setType(new CodeableConcept().setText("reference")))
                    }
                    VisitHistoryValidator.of().validate(visit, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description   | scenario      || errorMessage                           || expected
        "ReferenceId" | "referenceId" || ValidationUtils.INVALID_IDENTIFIER_KEY || false
    }
}
