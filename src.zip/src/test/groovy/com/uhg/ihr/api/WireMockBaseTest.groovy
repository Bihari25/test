package com.uhg.ihr.api

import com.fasterxml.jackson.databind.ObjectMapper
import com.github.tomakehurst.wiremock.junit.WireMockRule
import com.uhg.ihr.api.fhir.BaseFhirSpecification
import io.micronaut.context.annotation.Property
import io.micronaut.http.client.RxHttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.test.extensions.spock.annotation.MicronautTest
import javax.inject.Inject
import org.junit.ClassRule
import spock.lang.Shared

@MicronautTest
@Property(name = "micronaut.security.stargate.enabled", value = "false")
@Property(name = "senzing.secretKey", value = "55555555555555555555555555555555555555555555555555555555555555555555555555555555")
class WireMockBaseTest extends BaseFhirSpecification {

    @Inject
    @Client(id = '/', configuration = WireMockHttpClientConfiguration.class)
    RxHttpClient httpClient

    @ClassRule
    @Shared
    WireMockRule wireMockRule = new WireMockRule(8089)

    def cleanup() {
        clearMatches()
    }

    def clearMatches() {
        wireMockRule.resetAll()
    }

}

