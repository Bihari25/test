# IDZ-Streamer

Sample run command :
This IDZ -Streamer job contain following functionality .
                    1. Sending payload message to Kafka topic 
                    2.Sending transaction indexing message to indexing Kafka topic
                    3. Save summery level record into Elastic Search.
                    
 Configuration file path  
 ==========================
     https://github.optum.com/IHR/IDZ_B50_Resource              

Sample run command:
==================


pha b50
=========

spark-submit --class com.uhg.ihr.idz.streamer.pharmacyStreamer --master k8s://https://10.202.2.235:6443 --deploy-mode cluster --name pharmacy-b50-streamer local:////mapr/datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_conf/ihr-streamer-0.0.10-SNAPSHOT.jar /datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_inbound/test /datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_conf/pharmacy_streamer.conf

pha old path
============

spark-submit --class com.uhg.ihr.idz.streamer.MedRxOldPathStreamer --master k8s://https://10.202.2.235:6443 --deploy-mode cluster --name pharmacy-b50-old local:////mapr/datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_conf/ihr-streamer-0.0.10-SNAPSHOT.jar /datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_inbound/old_pha /datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_conf/pharmacy_old_streamer.conf

med old path
============

spark-submit --class com.uhg.ihr.idz.streamer.MedRxOldPathStreamer --master k8s://https://10.202.2.235:6443 --deploy-mode cluster --name medical-b50-old local:////mapr/datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_conf/ihr-streamer-0.0.10-SNAPSHOT.jar /datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_inbound/old_med /datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_conf/medical_old_streamer.conf


med b50
=========

spark-submit --class com.uhg.ihr.idz.streamer.medicalStreamer --master k8s://https://10.202.2.235:6443 --deploy-mode cluster --name medical-b50 local:////mapr/datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_conf/ihr-streamer-0.0.10-SNAPSHOT.jar /datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_inbound/med/test1 /datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_conf/medical_streamer.conf


MemberE&I


spark-submit --class com.uhg.ihr.idz.streamer.memberStreamer --master k8s://https://10.202.2.235:6443 --deploy-mode cluster --name b50-memberStreamer local:////mapr/datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_conf/ihr-streamer-0.0.10-SNAPSHOT.jar /datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_inbound/memberEi /datalake/optum/optuminsight/p_edh/prd/uhc/ihr_stg/stg/developer/fixlib/vjaiswa8/vivek/s_conf/EiMember_streamer.conf












