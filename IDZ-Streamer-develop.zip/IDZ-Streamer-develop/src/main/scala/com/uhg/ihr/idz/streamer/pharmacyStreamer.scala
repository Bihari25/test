package com.uhg.ihr.idz.streamer

import java.io.{File, FileInputStream}
import java.util.Properties

import com.uhg.ihr.idz.common.{CustomFunctions, Logger, RX_Overpunch_Logic}
import com.uhg.ihr.idz.schema.RX_Input_Schema
import com.uhg.ihr.idz.utils.Utils
import com.uhg.ihr.idz.utils.Utils.{DebatchMessage, MetaData}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.{SparkConf, SparkContext}

object pharmacyStreamer {

  def main(args: Array[String]): Unit = {

    if (args.length != 2) {
      Logger.log.info(s"Please Pass the valid input parameters (inputPath,propertiesFile,outputPath) ")
      Logger.log.error("  ==> ==> ==>  Exiting the job  <== <== <== ")
      System.exit(1)
    }
    val startTime = System.currentTimeMillis()
    val inputPath = args(0)
    val propertiesFile = args(1)
    Logger.log.error("Input File Path  ==> " + inputPath)
    Logger.log.error("propertiesFile File Path  ==> " + propertiesFile)

    try {

      val prop = new Properties()
      val path = new FileInputStream( propertiesFile)
      try {
        prop.load(path)
      } finally {
        path.close()
      }

      if (prop.isEmpty) {
        Logger.log.error(s"Please pass valid path for  propertiesFile  ==>  $path  ")
        Logger.log.error("  ==> ==> ==>  Exiting the job  <== <== <== ")
        System.exit(1)
      }


      val AppName = prop.getProperty("source_type")
      Logger.log.info("AppName =>" + AppName)

      val UUID = prop.getProperty("messageUUID")
      Logger.log.info("uuid =>" + UUID)

      val fileName = prop.getProperty("sourceName")
      Logger.log.info("fileName =>" + fileName)

      val Payload = prop.getProperty("payload")
      Logger.log.info("Payload =>" + Payload)

      val interfaceType = prop.getProperty("interface")
      Logger.log.info("interfaceType =>" + interfaceType)

      val interfaceName = prop.getProperty("interface_type")
      Logger.log.info("interfaceType =>" + interfaceName)

      val topic = prop.getProperty("kafka_topic")
      Logger.log.info("kafka topic Name =>" + topic)


      val server = prop.getProperty("kafka_server")
      Logger.log.info("kafka server name  =>" + server)

      val trustStorePath = prop.getProperty("trust_store_path")
      Logger.log.info("kafka trust store path  =>" + trustStorePath)


      val trustStorePwd = prop.getProperty("trust_store_pwd")

      val scrWriteUser = prop.getProperty("scram_write_user")
      Logger.log.info("kafka scr write user   =>" + server)

      val scrWritePwd = prop.getProperty("scram_write_pwd")

      val scrReadUser = prop.getProperty("scram_read_user")
      Logger.log.info("kafka scr write user   =>" + server)

      val scrReadPwd = prop.getProperty("scram_read_pwd")

      val algorithm = prop.getProperty("algorithm")

      val securityEnabled = prop.getProperty("securityEnabled")

      val retries = prop.getProperty("retries")
      val requestTimeOut = prop.getProperty("requestTimeOut")
      val requestSize = prop.getProperty("requestSize")

      val es_Nodes = prop.getProperty("es_Nodes")
      Logger.log.info("Elastic search node name =>" + es_Nodes)

      val es_Port = prop.getProperty("es_Port")
      Logger.log.info("Elastic search Port no =>" + es_Port)

      val es_Index = prop.getProperty("es_Index")
      Logger.log.info("Elastic search index table name =>" + es_Index)

      val es_user = prop.getProperty("es_user")
      Logger.log.info("es user Name: => " + es_user)
      val es_pwd = prop.getProperty("es_pwd")


      val conf = new SparkConf().setAppName("pharmacy-Streamer Job")
      conf.set("spark.driver.cores", prop.getProperty("driver_cores"))
      conf.set("spark.executor.instances", prop.getProperty("executor_instances"))
      conf.set("spark.executor.memory", prop.getProperty("executor_memory"))
      conf.set("spark.driver.memory", prop.getProperty("driver_memory"))
      conf.set("spark.executor.cores", prop.getProperty("executor_cores"))
      conf.set("spark.default.parallelism", prop.getProperty("default_parallelism"))
      conf.set("spark.sql.shuffle.partitions", prop.getProperty("sql_shuffle_partitions"))
      conf.set("spark.yarn.executor.memoryoverhead", prop.getProperty("yarn_executor_memoryoverhead"))
      conf.set("spark.driver.maxResultSize", prop.getProperty("driver_maxResultSize"))
      conf.set("spark.memory.fraction", prop.getProperty("memory_fraction"))
      conf.set("spark.debug.maxToStringFields", prop.getProperty("maxToStringFields"))
      conf.set("spark.es.nodes", es_Nodes)
      conf.set("spark.es.port", es_Port)
      conf.set("spark.es.net.http.auth.user", es_user)
      conf.set("spark.es.net.http.auth.pass", es_pwd)
      conf.set("spark.es.nodes.wan.only", "true")
      conf.set("spark.es.mapping.id", fileName)
      conf.set("spark.es.write.operation", "upsert")
      conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")


      val sc = new SparkContext(conf)
      val sqlContext = new org.apache.spark.sql.SQLContext(sc)
      val spark = SparkSession.builder().getOrCreate()
      import org.apache.spark.sql.functions._
      import sqlContext.implicits._
      Logger.log.info("***** Configuration details *****" + conf.toDebugString)

      val ListOfFiles = Utils.getFilePaths(inputPath,sc).map(x => x.getName).filter(x => x.contains("RXCHF70CL")).toBuffer
      Logger.log.info("Number of  file found in input path ==>  " + ListOfFiles.size + " FILES ")

      /**
        * Exit if the input Directory is Empty.
        */
      if (ListOfFiles.isEmpty) {
        Logger.log.info(s"Source ${inputPath} is Empty or doesn't exist.")
        Logger.log.error("  ==> ==> ==>  Exiting the job  <== <== <== ")
        System.exit(1)
      }

      Logger.log.info("*********** creating uuid ***********")
      /**
        * register an UDF that creates a random ID MED_<timestamp>_<uuid>
        */
      val generateUUID = udf { (srcType: String) => Utils.generateUUID(srcType) }

      Logger.log.info("*********** uuid created  **************")
      Logger.log.info("*********** Reading input file   **************")
      //reading input file one by one
      val inputFile = sc.textFile(inputPath).filter(x => x.startsWith("4"))
      Logger.log.info("*********** Reading input file completed  **************")
      val lengths = Seq(1, 10, 7, 15, 2, 1, 6, 55, 6, 3, 3, 12, 8, 20, 2, 30, 10, 2, 11, 3, 1, 11, 10, 2, 4, 8, 2, 2, 10, 13, 1, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 15, 25, 1, 8, 1, 20, 15, 3, 1, 15, 2, 15, 25, 15, 6, 6, 15, 2, 2, 11, 2, 20, 25, 15, 1, 8, 40, 40, 15, 2, 15, 2, 1, 2, 8, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 15, 10, 10, 10, 1, 1, 8, 14, 60, 5, 6, 9, 15, 15, 9, 8, 6, 15, 3, 1, 2, 1, 40, 1, 1, 9, 9, 8, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 8, 9, 10, 6, 6, 10, 10, 2, 9, 1, 9, 1, 9, 1, 29, 300, 50)

      val SplitData = inputFile.map(CustomFunctions.parseLinePerFixedLengths(_, lengths)).toDF.withColumnRenamed("value", "fields")
      val answer = lengths.indices.foldLeft(SplitData) {
        case (result, idx) =>
          result.toDF.withColumn(s"col_$idx", $"fields".getItem(idx))
      }
      Logger.log.info("***** Creating dataframe for claims records *****")
      val newDFSchema = spark.createDataFrame(answer.drop("fields").rdd, RX_Input_Schema.customSchema)

      Logger.log.info("***** Applying overpunch logic *****")

      val data = RX_Overpunch_Logic.overpunch(spark, newDFSchema)

      val currentTimestamp = Utils.getCurrentTimestamp()

      val selection = data.columns.map(col)
      val inputcolumn = data.withColumn("payload", concat_ws("|", selection: _*))
        .withColumn("filename", input_file_name())
        .withColumn("uuid", generateUUID(lit(AppName)))
        .withColumn("interfaceType", lit(interfaceName))
        .withColumn("createTimestamp",lit(currentTimestamp))
        .withColumn("updateTimestamp",lit(currentTimestamp))

      Logger.log.info("***** Selecting required column *****")

      val data1 = inputcolumn.select($"uuid".as(UUID)
        , $"filename".as(fileName)
        , $"interfaceType".as(interfaceType)
        , $"payload".as(Payload)
        , $"createTimestamp"
        , $"updateTimestamp")

      Logger.log.info("***** Selecting required column created  *****")
      
      
      data1.persist()

      val data2 = data1.map {
        case Row(uuid: String, fileName: String ,interface:String, payload:String, createTimestamp:String, updateTimestamp:String) => DebatchMessage(uuid,fileName,interface,payload,createTimestamp,updateTimestamp,MetaData(null,null,null))
      }.as[DebatchMessage].toJSON

      Logger.log.info(s"***** Topic: ${topic} *****")
      Logger.log.info(s"***** Server: ${server} *****")

      /**
        * Pushing Messages to Kafka
        */
      try {
        Logger.log.info("***** Pushing messages to Kafka *****")

        if(securityEnabled.equalsIgnoreCase("true")){
          Utils.writeToSecureTopic(spark, data2, topic, server,trustStorePath,trustStorePwd,scrWriteUser,scrWritePwd,scrReadUser,scrReadPwd,algorithm,requestTimeOut,retries,requestSize)
        } else {
          Utils.writeToTopic(spark, data2, topic, server,requestTimeOut,retries,requestSize)
        }

        Logger.log.info("***** Completed pushing messages to Kafka *****")
      } catch {
        case e: Exception => Logger.log.error("Exception while sending Streaming  message  to kafka " + e.getMessage)
          Logger.log.error(e.printStackTrace())
      }


      /**
        * Elastic Search Summary Indexing
        */
      Utils.writeSummaryToES(data1,interfaceName,es_Index)


      val OutputEndTimeMillis = System.currentTimeMillis()
      val OutputDurationMinutes = OutputEndTimeMillis.-(startTime)./(60000)
      val OutputDurationSeconds = OutputEndTimeMillis.-(startTime)./(1000).%(60)
      Logger.log.info(s"Job Execution Time : $OutputDurationMinutes minutes and $OutputDurationSeconds Seconds")
      Logger.log.info("   ************* END OF PHARMACY-STREAMER JOB ***************\n")

      sc.stop()
      spark.stop()


    } catch {
      case e: Exception => Logger.log.error(s"Exception at Main PHARMACY-STREAMER   Object" + e.getMessage)
        Logger.log.info(s"exception in main +" + e.printStackTrace())
        throw e
    } //catch
  } //main
} //object
