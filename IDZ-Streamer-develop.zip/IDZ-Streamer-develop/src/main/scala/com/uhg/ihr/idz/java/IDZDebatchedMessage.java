package com.uhg.ihr.idz.java;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IDZDebatchedMessage {
    @JsonProperty("uuid")
    private String uuid;
    @JsonProperty("fileName")
    private String fileName;
    @JsonProperty("interfaceType")
    private String interfaceType;
    @JsonProperty("payload")
    private String payload;
    @JsonProperty("createTimestamp")
    private String createTimestamp;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getInterfaceType() {
        return interfaceType;
    }

    public void setInterfaceType(String interfaceType) {
        this.interfaceType = interfaceType;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public String getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp(String createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    @Override
    public String toString() {
        return "{" +
                "uuid='" + uuid + '\'' +
                ", fileName='" + fileName + '\'' +
                ", interfaceType='" + interfaceType + '\'' +
                ", payload='" + payload + '\'' +
                ", createTimestamp='" + createTimestamp + '\'' +
                '}';
    }
}

