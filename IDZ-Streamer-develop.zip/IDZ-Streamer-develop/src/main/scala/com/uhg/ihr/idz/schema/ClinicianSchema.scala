package com.uhg.ihr.idz.schema

import org.apache.spark.sql.types.{StringType, StructField, StructType}

object ClinicianSchema {

  //creating Schema for Clinician Roster Data

  val ClinicianSchema = StructType(Array(
    StructField("ID", StringType, true),
    StructField("FIRST_NAME", StringType, true),
    StructField("LAST_NAME", StringType, true),
    StructField("MIDDLE_NAME", StringType, true),
    StructField("EMAIL_ID", StringType, true),
    StructField("JOB_CODE", StringType, true),
    StructField("JOB_TITLE", StringType, true)))

}
