package com.uhg.ihr.idz.streamer

import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.{Calendar, Properties}

import com.uhg.ihr.idz.common.Logger
import com.uhg.ihr.idz.java.IDZKafkaUtil
import com.uhg.ihr.idz.utils.Utils
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.elasticsearch.spark.sql._
import com.uhg.ihr.idz.utils.Utils.{DebatchMessage, MetaData}
import org.apache.spark.SparkConf
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions.to_json
import org.apache.hadoop.fs._
import com.uhg.ihr.idz.java._

import scala.io.Source

object BiometricsStreamer {

  var props: Properties = _

  def main(args: Array[String]): Unit = {

    if (args.length != 2) {
      Logger.log.info(s"Please Pass the valid input parameter \nPropertiesFile  \n DateFile ")
      System.exit(1)
    }

    //Arguments
    val propertiesFilePath = args(0)
    val dateFilePath = args(1)
    var datestamp = ""


    Logger.log.info("DateFile Path: => " + dateFilePath)
    Logger.log.info("PropertiesFile: => " + propertiesFilePath)

    Logger.log.info("Reading the properties File")

    val prop = new Properties()
    var path: FileInputStream = null

    try {
      path = new FileInputStream(propertiesFilePath)
      val startTime = System.currentTimeMillis()
      prop.load(path)


      // Reading query from thr resource file
      try {
        val file = "BiometricQuery.properties"
        props = new Properties()
        var paths = getClass.getClassLoader().getResourceAsStream(file)
        try {
          props.load(paths)
        } finally {
          paths.close
        }
      } catch {
        case e: Exception => Logger.log.error("Exception while reading the Query from the resource folder properties file" + e.printStackTrace() + e)
          System.exit(1)
      }


      /**
        * register an UDF that creates a random ID LBS_<timestamp>_<uuid>
        */
      val generateUUID = udf { (srcType: String) => Utils.generateUUID(srcType) }

      Logger.log.info("Reading the properties File completed")

      val AppName = prop.getProperty("source_type")
      Logger.log.info("source_type =>" + AppName)

      val UUID = prop.getProperty("messageUUID")
      Logger.log.info("uuid =>" + UUID)

      val fileName = prop.getProperty("sourceName")
      Logger.log.info("fileName =>" + fileName)

      val Payload = prop.getProperty("payload")
      Logger.log.info("Payload =>" + Payload)

      val interfaceType = prop.getProperty("interface")
      Logger.log.info("interfaceType =>" + interfaceType)

      val interfaceName = prop.getProperty("interface_type")
      Logger.log.info("interfaceType =>" + interfaceName)

      val topic = prop.getProperty("kafka_topic")
      Logger.log.info("topic Name =>" + topic)

      val server = prop.getProperty("kafka_server")
      Logger.log.info("kafka.bootstrap.servers =>" + server)

      val trustStorePath = prop.getProperty("trust_store_path")
      Logger.log.info("kafka trust store path  =>" + trustStorePath)

      val trustStorePwd = prop.getProperty("trust_store_pwd")

      val scrWriteUser = prop.getProperty("scram_write_user")
      Logger.log.info("kafka scr write user   =>" + server)

      val scrWritePwd = prop.getProperty("scram_write_pwd")

      val scrReadUser = prop.getProperty("scram_read_user")
      Logger.log.info("kafka scr write user   =>" + server)

      val scrReadPwd = prop.getProperty("scram_read_pwd")

      val algorithm = prop.getProperty("algorithm")

      val securityEnabled = prop.getProperty("securityEnabled")
      Logger.log.info("kafka Security Enabled: =>" + securityEnabled)

      val retries = prop.getProperty("retries")
      Logger.log.info("Number of retries: =>" + retries)

      val requestTimeOut = prop.getProperty("requestTimeOut")
      Logger.log.info("Request Timeout is: =>" + requestTimeOut)

      val requestSize = prop.getProperty("requestSize")
      Logger.log.info("Request Size is  =>" + requestSize)

      val es_Nodes = prop.getProperty("es_Nodes")
      Logger.log.info("kafka.bootstrap.nodes =>" + es_Nodes)

      val es_Port = prop.getProperty("es_Port")
      Logger.log.info("kafka.bootstrap.port =>" + es_Port)

      val es_Index = prop.getProperty("es_Index")
      Logger.log.info("kafka.bootstrap.index =>" + es_Index)

      val es_user = prop.getProperty("es_user")
      Logger.log.info("kafka.bootstrap.user =>" + es_user)

      val es_pwd = prop.getProperty("es_pwd")


      val KAFKA_SERVER = prop.getProperty("kafka_server")
      val KAFKA_TOPIC = prop.getProperty("kafka_topic")
      val SECURITY_PROTOCOL = prop.getProperty("securityProtocol")
      val SASL_MECHANISM = prop.getProperty("sasl_mechanism")
      val SASL_JAAS_CONFIG = prop.getProperty("sasl_jaas_config")
      val LAG_FOR_DUMMY = prop.getProperty("lag_for_dummy");


      val (uuid, filename, interface, payload) = (prop.getProperty("messageUUID"), prop.getProperty("sourceName"), prop.getProperty("interface"), prop.getProperty("payload"))


      val conf = new SparkConf().setAppName("BiometricsStreamer")
      conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      conf.set("spark.driver.cores", prop.getProperty("driver_cores"))
      conf.set("spark.executor.instances", prop.getProperty("executor_instances"))
      conf.set("spark.executor.memory", prop.getProperty("executor_memory"))
      conf.set("spark.driver.memory", prop.getProperty("driver_memory"))
      conf.set("spark.executor.cores", prop.getProperty("executor_cores"))
      conf.set("spark.default.parallelism", prop.getProperty("default_parallelism"))
      conf.set("spark.sql.shuffle.partitions", prop.getProperty("sql_shuffle_partitions"))
      conf.set("spark.yarn.executor.memoryoverhead", prop.getProperty("yarn_executor_memoryoverhead"))
      conf.set("spark.driver.maxResultSize", prop.getProperty("driver_maxResultSize"))
      conf.set("spark.memory.fraction", prop.getProperty("memory_fraction"))
      conf.set("spark.debug.maxToStringFields", prop.getProperty("maxToStringFields"))
      conf.set("spark.es.nodes", es_Nodes)
      conf.set("spark.es.port", es_Port)
      conf.set("spark.es.net.http.auth.user", es_user)
      conf.set("spark.es.net.http.auth.pass", es_pwd)
      conf.set("spark.es.nodes.wan.only", "true")
      conf.set("spark.es.mapping.id", fileName)
      conf.set("spark.es.write.operation", "upsert")
      conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")


      val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()


      val sc = spark.sparkContext
      import spark.implicits._
      Logger.log.info("Job started")


      // Extraction -Datefile

      Logger.log.info("Started Reading the Queries")

      val datePath = dateFilePath + "/*.txt"
      Logger.log.info("load date file is " + datePath)
      val dateStamp: String = spark.read.textFile(datePath).collect()(0).trim

      println("The Lastrun date Timestamp from the file is " + dateStamp + "(in Format yyyy-MM-dd HH:mm:ss:SSS)")

      val today = Calendar.getInstance().getTime()
      val dateFormatFile = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS")
      val lastRunDate = dateFormatFile.format(today)
      val LastStr = Seq(lastRunDate)
      println("The Lastrun date written to file at the end of Job is " + lastRunDate)

      val fileFormatOutput = new SimpleDateFormat("yyyyMMddHHmmss")
      val fileDate = fileFormatOutput.format(today)
      println("The extraction date present in the filename attribute is " + fileDate)


      // Extraction Query

      val bioQry = props.getProperty("spark.hive.join.bioQry").replace("$lastruntmsp", dateStamp)

      Logger.log.info("Query used for extraction is " + bioQry)

      val bio_df = spark.sql(s"""$bioQry""").na.fill("")

      // Payload
      val currentTimestamp = Utils.getCurrentTimestamp()
      val columns = bio_df.columns.map(col)

      val data = bio_df.withColumn("payload", concat_ws("|", columns: _*)).withColumn("key", $"TRANSACTION_ID").withColumn("filename", concat(lit("Biometric-Daily-"), lit(fileDate)))
        .withColumn("uuid", generateUUID(lit(AppName)))
        .withColumn("interfaceType", lit(interfaceName))
        .withColumn("createTimestamp", lit(currentTimestamp))
        .withColumn("updateTimestamp", lit(currentTimestamp))


      Logger.log.info("<===== Selecting required column =====>")

      val data1 = data.select($"key", $"uuid".as(UUID)
        , $"filename".as(fileName)
        , $"interfaceType".as(interfaceType)
        , $"payload".as(Payload)
        , $"createTimestamp"
        , $"updateTimestamp")

      Logger.log.info("<=====  Selecting required column created  ======>")

      data1.persist()

      val data2 = data1.map {
        case Row(key: String, uuid: String, fileName: String, interface: String, payload: String, createTimestamp: String, updateTimestamp: String) => (key, uuid, fileName, interface, payload, createTimestamp, updateTimestamp, MetaData(null, null, null))
      }.toDF("key", "uuid", "fileName", "interfaceType", "payload", "createTimestamp", "updateTimestamp", "metadata")

      val data3 = data2.select(to_json(struct($"uuid", $"fileName", $"interfaceType", $"payload", $"createTimestamp", $"updateTimestamp", $"metadata")).alias("value"), $"key".alias("key"))

      /**
        * Pushing Messages to Kafka
        */
      try {
        Logger.log.info("============>  sending Streaming  message to kafka <============")
        if (securityEnabled.equalsIgnoreCase("true")) {
          Utils.writeToSecureTopicWithKey(spark, data3, KAFKA_TOPIC, KAFKA_SERVER, trustStorePath, trustStorePwd, scrWriteUser, scrWritePwd, scrReadUser, scrReadPwd, algorithm, requestTimeOut, retries, requestSize)
        } else {
          Utils.writeToTopicWithKey(spark, data3, KAFKA_TOPIC, KAFKA_SERVER, requestTimeOut, retries, requestSize)
        }
        val kafkaProducerProps = new Properties()
        kafkaProducerProps.setProperty("bootstrap.servers", KAFKA_SERVER)
        kafkaProducerProps.setProperty("security.protocol", SECURITY_PROTOCOL)
        kafkaProducerProps.setProperty("ssl.truststore.location", trustStorePath)
        kafkaProducerProps.setProperty("ssl.truststore.password", trustStorePwd)
        kafkaProducerProps.setProperty("ssl.endpoint.identification.algorithm", algorithm)
        kafkaProducerProps.setProperty("sasl.mechanism", SASL_MECHANISM)
        kafkaProducerProps.setProperty("sasl.jaas.config", SASL_JAAS_CONFIG)

        def idzKafkaUtil: IDZKafkaUtil = new IDZKafkaUtil(kafkaProducerProps)

        idzKafkaUtil.sendDummyMessagesToKafka(KAFKA_TOPIC, LAG_FOR_DUMMY.toLong);
        Logger.log.info("============> sending Streaming  message to kafka completed <============")
      } catch {
        case e: Exception => Logger.log.error("Exception while sending Streaming  message  to kafka " + e.getMessage)
          Logger.log.info("Failed to push records to Kafka. Please check if the provided Cluster details are accurate.")
          System.exit(1);
      }


      /**
        * Elastic Search Summary Indexing
        */
      Utils.writeSummaryToES(data1, interfaceName, es_Index)

      val OutputEndTimeMillis = System.currentTimeMillis()
      val OutputDurationMinutes = OutputEndTimeMillis.-(startTime)./(60000)
      val OutputDurationSeconds = OutputEndTimeMillis.-(startTime)./(1000).%(60)
      Logger.log.info(s"Job Execution Time : $OutputDurationMinutes minutes and $OutputDurationSeconds Seconds")
      Logger.log.info("   ************* End of Biometrics Streamer job ***************\n")

      Logger.log.info(s"Started Writing the Lastrun timestamp to the file")

      // Writing lastrun timestamp to file

      val dateFileRDD = sc.parallelize(LastStr).toDF()
      dateFileRDD.repartition(1).write.mode("overwrite").format("text").save(dateFilePath)

      // Rename the part file
      val fs = FileSystem.get(sc.hadoopConfiguration)
      val partFile = fs.globStatus(new Path(dateFilePath + "/part*"))(0).getPath().getName()
      val newDateFile = "Biometric_Extract_date.txt"
      fs.rename(new Path(dateFilePath + "/" + partFile), new Path(dateFilePath + "/" + newDateFile))

      Logger.log.info(s"Completed Writing the Lastrun timestamp to the file")

      data1.unpersist()
      sc.stop()
      spark.stop()

    } catch {
      case e: Exception => Logger.log.error("Exception at Main Biometrics Streamer " + e.getMessage)
        Logger.log.info(s"exception in main +" + e.printStackTrace())
        throw e
    } finally {
      path.close
    }
  } //main
}

















