package com.uhg.ihr.idz.streamer

import java.io.FileInputStream
import java.util.Properties

import com.uhg.ihr.idz.common.Logger
import com.uhg.ihr.idz.utils.Utils
import com.uhg.ihr.idz.utils.Utils.{DebatchMessage, MetaData}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.elasticsearch.spark.sql._
import org.apache.hadoop.fs.{FileSystem, Path}

object acoStreamer {

  var KAFKA_TOPIC: String = _
  var KAFKA_SERVER: String = _
  var SOURCE_TYPE: String = _
  var INTERFACE_TYPE: String = _
  var ES_NODES: String = _
  var ES_PORT: String = _
  var ES_INDEX: String = _
  var tranTopic: String = _
  var tranServer: String = _
  var applicationName: String = _
  var applicationVersion: String = _
  var trustStorePath: String = _
  var trustStorePwd: String = _
  var scrWriteUser: String = _
  var scrWritePwd: String = _
  var scrReadUser: String = _
  var scrReadPwd: String = _
  var algorithm: String = _
  var securityEnabled: String = _
  var requestTimeOut: String = _
  var retries: String = _
  var requestSize:String  = _



  def main(args: Array[String]): Unit = {

    var inputFile: String = null
    var propertiesFile: String = null
    var flag: String = null

    try {
      inputFile = args(0)
      propertiesFile = args(1)
      flag = args(2)
    } catch {
      case x: ArrayIndexOutOfBoundsException => {
        Logger.log.info(s"Please Pass the valid input parameters \nInputPath : $inputFile \nFile type: $flag  \n propertiesFile Path :$propertiesFile \n")
        Logger.log.info(x.getMessage)
        sys.exit(1)
      }
    }

    if (flag.equalsIgnoreCase("Member") || flag.equalsIgnoreCase("Provider") || flag.equalsIgnoreCase("Demographics")) {
      Logger.log.info("Inputfile path :=> " + args(0))
      Logger.log.info("propertiesFile path :=>  " + args(1))
      Logger.log.info("File type:=>  " + args(2))
    }
    else {
      Logger.log.info("The file type is not provided correctly. \nThe acceptable values for a file type are 'Member' or 'Provider' or 'Demographics'")
      sys.exit(1)
    }
    val processStartTimeMillis = System.currentTimeMillis()
    //Creates the properties object.
    val prop = new Properties()
    val path = new FileInputStream( propertiesFile)

    try {
      prop.load(path)
    } finally {
      path.close()
    }

    KAFKA_TOPIC = prop.getProperty("kafka_topic")
    KAFKA_SERVER = prop.getProperty("kafka_server")
    SOURCE_TYPE = prop.getProperty("source_type")
    trustStorePath = prop.getProperty("trust_store_path")
    trustStorePwd = prop.getProperty("trust_store_pwd")
    scrWriteUser = prop.getProperty("scram_write_user")
    scrWritePwd = prop.getProperty("scram_write_pwd")
    scrReadUser = prop.getProperty("scram_read_user")
    scrReadPwd = prop.getProperty("scram_read_pwd")
    algorithm = prop.getProperty("algorithm")
    securityEnabled = prop.getProperty("securityEnabled")
    retries = prop.getProperty("retries")
    requestTimeOut = prop.getProperty("requestTimeOut")
    requestSize = prop.getProperty("requestSize")

    ES_NODES = prop.getProperty("es_Nodes")
    ES_PORT = prop.getProperty("es_Port")
    ES_INDEX = prop.getProperty("es_Index")
    Logger.log.info("Elastic Search Nodes : => " + ES_NODES)
    Logger.log.info("Elastic Search Port : => " + ES_PORT)
    Logger.log.info("Elastic Search Index : => " + ES_INDEX)


    val uuid = prop.getProperty("messageUUID")
    val filename = prop.getProperty("sourceName")
    val payload = prop.getProperty("payload")
    val interface = prop.getProperty("interface")
    val es_user = prop.getProperty("es_user")
    Logger.log.info("es user Name: => " + es_user)
    val es_pwd = prop.getProperty("es_pwd")

    // Creates the SparkConfig object.
    val conf = new SparkConf().setAppName("ACO_FILE_DEBATCHING")

    conf.set("spark.driver.cores", prop.getProperty("driver_cores"))
    conf.set("spark.executor.instances", prop.getProperty("executor_instances"))
    conf.set("spark.executor.memory", prop.getProperty("executor_memory"))
    conf.set("spark.driver.memory", prop.getProperty("driver_memory"))
    conf.set("spark.executor.cores", prop.getProperty("executor_cores"))
    conf.set("spark.default.parallelism", prop.getProperty("default_parallelism"))
    conf.set("spark.sql.shuffle.partitions", prop.getProperty("sql_shuffle_partitions"))
    conf.set("spark.yarn.executor.memoryoverhead", prop.getProperty("yarn_executor_memoryoverhead"))
    conf.set("spark.driver.maxResultSize", prop.getProperty("driver_maxResultSize"))
    conf.set("spark.memory.fraction", prop.getProperty("memory_fraction"))

    //elastic search conf info
    conf.set("spark.es.nodes", ES_NODES)
    conf.set("spark.es.port", ES_PORT)
    conf.set("spark.es.net.http.auth.user", es_user)
    conf.set("spark.es.net.http.auth.pass", es_pwd)
    conf.set("spark.es.nodes.wan.only", "true")
    conf.set("spark.es.mapping.id", filename)
    conf.set("spark.es.write.operation", "upsert")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")


    // Creates the session for the current file.
    val spark = SparkSession.builder().config(conf).getOrCreate()
    import spark.implicits._
    val sc = spark.sparkContext

    /**
      * Exit if the input Directory is Empty.
      */
    if(Utils.getFilePaths(inputFile,sc).length == 0){
      Logger.log.info(s"Source ${inputFile} is Empty or doesn't exist.")
      Logger.log.error("==> ==> ==>  Exiting the Job  <== <== <==")
      System.exit(1)
    }

    Logger.log.info("Spark Session created")

    /**
      * register an UDF that creates a random ID MED_<timestamp>_<uuid>
      */
    val generateUUID = udf { (srcType: String) => Utils.generateUUID(srcType) }

    // To match the pattern in HICN. The below function is used
    val regudf = (str: String) => {
      val reg = "[1-9][AC-HJKMNP-RT-Y][0-9AC-HJKMNP-RT-Y][0-9][AC-HJKMNP-RT-Y][0-9AC-HJKMNP-RT-Y][0-9][AC-HJKMNP-RT-Y][AC-HJKMNP-RT-Y][0-9][0-9]"
      str.matches(reg)
    }
    spark.udf.register("regudf", regudf)

    var finalDF = spark.emptyDataFrame;

    if (flag.equalsIgnoreCase("Member")) {
      val ACOMemberRoasterSchema = StructType(Array(
        StructField("TIN", StringType, true),
        StructField("PRACTICE_ID", StringType, true),
        StructField("PRACTICE_NAME", StringType, true),
        StructField("MPIN", StringType, true),
        StructField("PROVIDER_FIRST_NAME", StringType, true),
        StructField("PROVIDER_LAST_NAME", StringType, true),
        StructField("MEMBER_FIRST_NAME", StringType, true),
        StructField("MEMBER_LAST_NAME", StringType, true),
        StructField("INDV_ID", StringType, true),
        StructField("ALT_ID", StringType, true),
        StructField("MEMBER_BIRTH_DATE", StringType, true),
        StructField("MEMBER_GENDER", StringType, true),
        StructField("LINE_OF_BUSINESS", StringType, true),
        StructField("HEALTH_PLAN_FUNDING_CD", StringType, true),
        StructField("SUBSCRIBER_ID", StringType, true),
        StructField("COMPANY_NAME", StringType, true),
        StructField("PROGRAM", StringType, true),
        StructField("PRACTICE_STATE", StringType, true),
        StructField("FLAG_01", StringType, true),
        StructField("CARD_ID", StringType, true),
        StructField("MEMBER_ZIP_CODE", StringType, true),
        StructField("MEMBER_STATE", StringType, true),
        StructField("LAST_UPDATE", StringType, true),
        StructField("INSERT_USER", StringType, true),
        StructField("INSERT_DATETIME", StringType, true),
        StructField("BATCH_KEY", StringType, true),
        StructField("MEMBER_COUNTY", StringType, true),
        StructField("NPI", StringType, true),
        StructField("HICN", StringType, true),
        StructField("SITE", StringType, true),
        StructField("NETWORK_NUMBER", StringType, true),
        StructField("NETWORK_NAME", StringType, true),
        StructField("ACO_SMRY", StringType, true),
        StructField("ACO_NAME", StringType, true),
        StructField("MDE_SITE", StringType, true),
        StructField("MDE_NETWORK_NUMBER", StringType, true),
        StructField("HMO_FLAG", StringType, true),
        StructField("START_DATE", StringType, true),
        StructField("END_DATE", StringType, true),
        StructField("CARD_ID_TYPE", StringType, true)))

      // Reads the file into the data frame with the above given schema.
      val memberDf = spark.read.format("csv")
        .option("header", false)
        .option("delimiter", "|")
        .schema(ACOMemberRoasterSchema)
        .load(inputFile)

      // Filters the first row. The first row has headers of the file.
      val sourceWithoutHeader = memberDf.filter(($"PRACTICE_ID") !== "PRACTICE_ID")
      sourceWithoutHeader.createOrReplaceTempView("member_tbl")


      //SQL Query to generate the Output file including MBI
      //Pattern Matching used : "[1-9][AC-HJKMNP-RT-Y][0-9AC-HJKMNP-RT-Y][0-9][AC-HJKMNP-RT-Y][0-9AC-HJKMNP-RT-Y][0-9][AC-HJKMNP-RT-Y][AC-HJKMNP-RT-Y][0-9][0-9]"
      //If TRUE then HICN is NULLIFIED and value moved to MBI.
      //If False then HICN left as is and MBI is NULL

      val query = """select TIN,PRACTICE_ID,PRACTICE_NAME,MPIN,PROVIDER_FIRST_NAME,PROVIDER_LAST_NAME,MEMBER_FIRST_NAME,MEMBER_LAST_NAME,INDV_ID,ALT_ID,MEMBER_BIRTH_DATE,MEMBER_GENDER,LINE_OF_BUSINESS,HEALTH_PLAN_FUNDING_CD,SUBSCRIBER_ID,COMPANY_NAME,PROGRAM,PRACTICE_STATE,FLAG_01,CARD_ID,MEMBER_ZIP_CODE,MEMBER_STATE,LAST_UPDATE,INSERT_USER,INSERT_DATETIME,BATCH_KEY,MEMBER_COUNTY,NPI,case when (HICN is not null and regudf(HICN)) then "" else HICN end as HICN,SITE,NETWORK_NUMBER,NETWORK_NAME,ACO_SMRY,ACO_NAME,MDE_SITE,MDE_NETWORK_NUMBER,HMO_FLAG,START_DATE,END_DATE,CARD_ID_TYPE,case when (HICN is not null and regudf(HICN)) then HICN else "" end as MBI from member_tbl"""
      // Concatenates all the columns in the DataFrame.
      INTERFACE_TYPE = prop.getProperty("MemberType")
      val memberDF = spark.sql(query)
      finalDF = memberDF.na.fill("")
        .select(concat_ws("|", memberDF.columns.map(c => col(c)): _*).as("payload"))
        .withColumn("interfacetype", lit(INTERFACE_TYPE))

      Logger.log.info("Member completed")
    }
    else {
      val otherDf = spark.read.format("csv")
        .option("header", false)
        .load(inputFile)
        .select(col("_c0").as("payload"))

      if (flag.equalsIgnoreCase("Demographics")) {
        INTERFACE_TYPE = prop.getProperty("DemographicsType")
      }
      else {
        INTERFACE_TYPE = prop.getProperty("ProviderType")
      }

      val header = otherDf.first()
      finalDF = otherDf.filter(r => r != header)
        .withColumn("interfacetype", lit(INTERFACE_TYPE))

      Logger.log.info("File is ready for kafka topic.")
    }

    val currentTimestamp = Utils.getCurrentTimestamp()

    // Appends the uuid, file name columns to the dataFrame.
    val completeDataFrame = finalDF.withColumn("filename", input_file_name())
      .withColumn("uuid", generateUUID(lit(SOURCE_TYPE)))
      .withColumn("createTimestamp",lit(currentTimestamp))
      .withColumn("updateTimestamp",lit(currentTimestamp))
      .select($"uuid".as(uuid)
        , $"filename".as(filename)
        , $"interfacetype".as(interface)
        , $"payload".as(payload)
        , $"createTimestamp"
        , $"updateTimestamp")
    completeDataFrame.persist()

    val jsonDF = completeDataFrame.map {
      case Row(uuid: String, fileName: String ,interface:String, payload:String, createTimestamp:String, updateTimestamp:String) => DebatchMessage(uuid,fileName,interface,payload,createTimestamp,updateTimestamp,MetaData(null,null,null))
    }.as[DebatchMessage].toJSON


    /**
      * Pushing Messages to Kafka
      */
    try {
      Logger.log.info("***** sending Streaming  message to kafka *****")
      if(securityEnabled.equalsIgnoreCase("true")) {
        Utils.writeToSecureTopic(spark, jsonDF, KAFKA_TOPIC, KAFKA_SERVER, trustStorePath, trustStorePwd, scrWriteUser, scrWritePwd, scrReadUser, scrReadPwd, algorithm ,requestTimeOut,retries,requestSize)
      }else {
        Utils.writeToTopic(spark, jsonDF, KAFKA_TOPIC, KAFKA_SERVER,requestTimeOut,retries,requestSize)
      }
      Logger.log.info("***** sending Streaming  message to kafka completed *****")

      /**
        * Elastic Search Summary Indexing
        */
      Utils.writeSummaryToES(completeDataFrame,INTERFACE_TYPE,ES_INDEX)

      val OutputEndTimeMillis = System.currentTimeMillis()
      val OutputDurationMinutes = OutputEndTimeMillis.-(processStartTimeMillis)./(60000)
      val OutputDurationSeconds = OutputEndTimeMillis.-(processStartTimeMillis)./(1000).%(60)
      Logger.log.info(s"Job Execution Time : $OutputDurationMinutes minutes and $OutputDurationSeconds Seconds")
      Logger.log.info("   ************* END OF ACO-Streamer JOB ***************\n")

    } catch {
      case e: Exception => {
        Logger.log.error("Exception while sending transaction Elastic  Streaming  message to kafka: " + e.getMessage())
        Logger.log.error(e.printStackTrace())
      }
    }

    spark.stop()

  }

}

