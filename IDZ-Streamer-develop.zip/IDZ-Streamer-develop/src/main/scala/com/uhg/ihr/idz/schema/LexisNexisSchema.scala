package com.uhg.ihr.idz.schema

import org.apache.spark.sql.types.{StringType, StructField, StructType}

object LexisNexisSchema {
  //creating Schema for LeXis Nexiss Data

  val LexisNexisSchema = StructType(Array(
    StructField("NPI", StringType, true),
    StructField("DEA", StringType, true),
    StructField("DEA_STATE", StringType, true),
    StructField("EXPIRATION_DATE", StringType, true),
    StructField("DEA_EFFECTIVE_DATE", StringType, true),
    StructField("DEA_SCHEDULE", StringType, true),
    StructField("DEA_BUSINESS_ACTIVITY_CODE", StringType, true),
    StructField("DEA_BUSINESS_ACTIVITY_SUB_CODE", StringType, true),
    StructField("DEA_STATUS", StringType, true),
    StructField("FIRST", StringType, true),
    StructField("MIDDLE", StringType, true),
    StructField("LAST", StringType, true),
    StructField("SUFFIX", StringType, true),
    StructField("PRACT_TYPE", StringType, true),
    StructField("SPECIALTY_DESC", StringType, true),
    StructField("HMS_PIID", StringType, true),
    StructField("CHNG_FLAG", StringType, true)))

}
