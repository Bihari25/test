package com.uhg.ihr.idz.streamer


import java.io.{File, FileInputStream}
import java.net.URI
import java.nio.file.{Files, Path}
import java.util.Properties
import util.control.Breaks._
import com.uhg.ihr.idz.common.Logger
import com.uhg.ihr.idz.utils.Utils
import com.uhg.ihr.idz.utils.Utils.{DebatchMessage, MetaData}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Row, SparkSession}
import org.elasticsearch.spark.sql._

object medicalStreamer {

  var PROPS: Properties = _
  var INPUT_DIR_PATH: String = _
  var INPUT_PROPERTIES_FILE: String = _
  var KAFKA_TOPIC: String = _
  var SOURCE_TYPE: String = _
  var KAFKA_SERVER: String = _
  var INTERFACE_TYPE: String = _
  var ES_NODES: String = _
  var ES_PORT: String = _
  var ES_INDEX: String = _
  var TRAN_KAFKA_TOPIC: String = _
  var TRAN_KAFKA_SERVER: String = _
  var trustStorePath: String = _
  var trustStorePwd: String = _
  var scrWriteUser: String = _
  var scrWritePwd: String = _
  var scrReadUser: String = _
  var scrReadPwd: String = _
  var algorithm: String = _
  var securityEnabled: String = _
  var requestTimeOut:String = _
  var retries:String = _
  var requestSize:String = _


  def main(args: Array[String]): Unit = {

    if (args.length != 2) {
      Logger.log.info(s"Please Pass the valid input parameter \nInputFilePath  \n PropertiesFile ")
      System.exit(1)
    }

    //Arguments
    INPUT_DIR_PATH = args(0)
    INPUT_PROPERTIES_FILE = args(1)



    Logger.log.info("InputFile Path: => " + INPUT_DIR_PATH)
    Logger.log.info("PropertiesFile : => " + INPUT_PROPERTIES_FILE)
    val processStartTimeMillis = System.currentTimeMillis()

    try {
      //Reading the properties file
      PROPS = new Properties()
      val path = new FileInputStream(INPUT_PROPERTIES_FILE)

      try {
        PROPS.load(path)
      } finally {
        path.close
      }

      //Common properties
      KAFKA_TOPIC = PROPS.getProperty("kafka_topic") //Kafka topic to push data to
      SOURCE_TYPE = PROPS.getProperty("source_type")
      KAFKA_SERVER = PROPS.getProperty("kafka_server")
      INTERFACE_TYPE = PROPS.getProperty("interface_type")
      trustStorePath = PROPS.getProperty("trust_store_path")
      trustStorePwd = PROPS.getProperty("trust_store_pwd")
      scrWriteUser = PROPS.getProperty("scram_write_user")
      scrWritePwd = PROPS.getProperty("scram_write_pwd")
      scrReadUser = PROPS.getProperty("scram_read_user")
      scrReadPwd = PROPS.getProperty("scram_read_pwd")
      algorithm = PROPS.getProperty("algorithm")
      securityEnabled = PROPS.getProperty("securityEnabled")
      retries = PROPS.getProperty("retries")
      requestTimeOut = PROPS.getProperty("requestTimeOut")
      requestSize = PROPS.getProperty("requestSize")

      ES_NODES = PROPS.getProperty("es_Nodes")
      ES_PORT = PROPS.getProperty("es_Port")
      ES_INDEX = PROPS.getProperty("es_Index")


      Logger.log.info("Elastic Search Nodes : => " + ES_NODES)
      Logger.log.info("Elastic Search Port : => " + ES_PORT)
      Logger.log.info("Elastic Search Index : => " + ES_INDEX)

      Logger.log.info("Kafka Topic : => " + KAFKA_TOPIC)
      Logger.log.info("Kafka Server : => " + KAFKA_SERVER)
      Logger.log.info("Interface Name : => " + INTERFACE_TYPE)

      //Export Columns
      val uuid = PROPS.getProperty("messageUUID")
      val fileName = PROPS.getProperty("sourceName")
      val interface = PROPS.getProperty("interface")
      val payload = PROPS.getProperty("payload")
      val es_user = PROPS.getProperty("es_user")
      Logger.log.info("es user Name: => " + es_user)
      val es_pwd = PROPS.getProperty("es_pwd")


      val spark = SparkSession.builder()
        .appName("Medical-b50-Streaming")
        .config("spark.driver.cores", PROPS.getProperty("driver_cores"))
        .config("spark.executor.instances", PROPS.getProperty("executor_instances"))
        .config("spark.executor.memory", PROPS.getProperty("executor_memory"))
        .config("spark.driver.memory", PROPS.getProperty("driver_memory"))
        .config("spark.executor.cores", PROPS.getProperty("executor_cores"))
        .config("spark.default.parallelism", PROPS.getProperty("default_parallelism"))
        .config("spark.sql.shuffle.partitions", PROPS.getProperty("sql_shuffle_partitions"))
        .config("spark.yarn.executor.memoryoverhead", PROPS.getProperty("yarn_executor_memoryoverhead"))
        .config("spark.driver.maxResultSize", PROPS.getProperty("driver_maxResultSize"))
        .config("spark.memory.fraction", PROPS.getProperty("memory_fraction"))
        .config("spark.es.nodes", ES_NODES)
        .config("spark.es.port", ES_PORT)
        .config("spark.es.net.http.auth.user", es_user)
        .config("spark.es.net.http.auth.pass", es_pwd)
        .config("spark.es.nodes.wan.only", "true")
        .config("spark.es.mapping.id", fileName)
        .config("spark.es.write.operation", "upsert")
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .getOrCreate()

      val sc = spark.sparkContext
      import spark.implicits._

      //Get the list of Input files from given INPUT_DIR_PATH
      val ListOfFiles = Utils.getFilePaths(INPUT_DIR_PATH,sc).map(x => x.getName).filter(x => x.startsWith("thread") && x.contains("x12")).toBuffer

      /**
        * Exit if the input Directory is Empty.
        */
      if (ListOfFiles.isEmpty) {
        Logger.log.info(s"Source ${INPUT_DIR_PATH} is Empty or doesn't exist.")
        Logger.log.error("  ==> ==> ==>  Exiting the Job  <== <== <== ")
        System.exit(1)
      }

      /**
        * register an UDF that creates a random ID MED_<timestamp>_<uuid>
        */
      val generateUUID = udf { (srcType: String) => Utils.generateUUID(srcType) }

      while (ListOfFiles.nonEmpty) {

        // Setting the default delimiter
        sc.hadoopConfiguration.set("textinputformat.record.delimiter", "\n")
        val Clm = ListOfFiles(0)
        val Clm_new = Clm.replace("[","?").replace("]","?")
        val ClaimFile = INPUT_DIR_PATH + "/" + Clm_new
        Logger.log.info("Claim file name:" + ClaimFile)
        val absoluteFileName = ClaimFile.replaceFirst("\\?","[").replaceFirst("\\?","]")
        val metadata = Clm_new.replace("x12", "metadata")
        val metaDataFile = INPUT_DIR_PATH + "/" + metadata
        Logger.log.info("metaDataFileName:" + metaDataFile)


        val metaDf = sc.textFile(metaDataFile)
          .map(a => "K3**" + a)
          .map(a => a.replace("~", "*"))
          .map(a => a.reverse)
          .map(a => a.replaceFirst("[\\*]", "~"))
          .map(a => a.reverse)
          .map(a => (a.split("[\\*]")(2), a)).toDF
        metaDf.createOrReplaceTempView("metaData")


        val df1 = spark.sql("select concat('ICN_',_1) as key,_2 as value from metaData")
        df1.createOrReplaceTempView("metaData1")


        val delimit = "~\nISA*"
        sc.hadoopConfiguration.set("textinputformat.record.delimiter", delimit)

        val df = sc.textFile(ClaimFile).map(x => ("ISA*" ++ x ++ "~")).map(r => r.replace("ISA*ISA*", "ISA*")).map(r => r.replace("~\n~", "~")).toDF("delimit_column")

        df.select(when(substring(($"delimit_column"), 105, 2) === ":~" && substring(reverse($"delimit_column"), 13, 4) === "*AEI", $"delimit_column") as "delimit_column").createOrReplaceTempView("claimDataTab")

        spark.sql("select regexp_replace(trim(SUBSTR(delimit_column,INSTR(delimit_column,'K3*ICN ')+3,INSTR(delimit_column,'Trace Number')-INSTR(delimit_column,'K3*ICN ')-3)),' ','_') as key,delimit_column  from claimDataTab").createOrReplaceTempView("claimDataTab1")

        val Output = spark.sql(
          """select a.delimit_column as payload
            |,(case when b.value is not null then split(b.value, "\\*")[7] else "" end) as subscriberid
            |,(case when b.value is not null then split(b.value, "\\*")[2] else "" end) as icn
            |,(case when b.value is not null then split(b.value, "\\*")[8] else "" end) as mpin
            |from claimDataTab1 a left outer join metaData1 b on a.key=b.key""".stripMargin)

        val currentTimestamp = Utils.getCurrentTimestamp()

        val medDebatch_df = Output.toDF("payload","subscriberid","icn","mpin")
          .withColumn("payload", regexp_replace($"payload", "[\\r\\n]", ""))
          .withColumn("uuid", generateUUID(lit(SOURCE_TYPE)))
          .withColumn("interfacename", lit(INTERFACE_TYPE))
          .withColumn("filename", lit(absoluteFileName))
          .withColumn("createTimestamp",lit(currentTimestamp))
          .withColumn("updateTimestamp",lit(currentTimestamp))

        val data1 = medDebatch_df.select($"uuid".as(uuid)
          , $"filename".as(fileName)
          , $"interfacename".as(interface)
          , $"payload".as(payload)
          , $"createTimestamp"
          , $"updateTimestamp"
          , $"subscriberid"
          , $"icn"
          , $"mpin")

        data1.persist()


        val data2 = data1.map {
          case Row(uuid: String, fileName: String ,interface:String, payload:String, createTimestamp:String, updateTimestamp:String,  subscriberId:String,icn:String, mpin:String) => DebatchMessage(uuid,fileName,interface,payload,createTimestamp,updateTimestamp,MetaData(Utils.isEmptyThenNull(subscriberId),Utils.isEmptyThenNull(icn),Utils.isEmptyThenNull(mpin)))
        }.as[DebatchMessage].toJSON

        /**
          * Pushing Messages to Kafka
          */
        try {
          Logger.log.info("***** Pushing messages to Kafka *****")
          if(securityEnabled.equalsIgnoreCase("true")) {
            Utils.writeToSecureTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER,trustStorePath,trustStorePwd,scrWriteUser,scrWritePwd,scrReadUser,scrReadPwd,algorithm,requestTimeOut,retries,requestSize)
          }else {
            Utils.writeToTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER,requestTimeOut,retries,requestSize)
          }
          Logger.log.info("***** Completed pushing messages to Kafka *****")
        } catch {
          case e: Exception => Logger.log.error("Exception while sending Streaming  message to kafka " + e.getMessage)
        }


        /**
          * Elastic Search Summary Indexing
          */
        Utils.writeSummaryToES(data1,INTERFACE_TYPE,ES_INDEX)


        val OutputEndTimeMillis = System.currentTimeMillis()
        val OutputDurationMinutes = OutputEndTimeMillis.-(processStartTimeMillis)./(60000)
        val OutputDurationSeconds = OutputEndTimeMillis.-(processStartTimeMillis)./(1000).%(60)
        Logger.log.info(s"Job Execution Time : $OutputDurationMinutes minutes and $OutputDurationSeconds Seconds")
        Logger.log.info("*************** END OF Medical-Streamer JOB ***************\n")

        ListOfFiles.remove(0)
        data1.unpersist()
      }

      sc.stop()
      spark.stop()

      Logger.log.info("*************** end of job ***************\n")

    }catch {
      case e: Exception => Logger.log.error(s"Exception at in medicalStreamer Object" + e.getMessage + e)
        Logger.log.info(s"exception in main +" + e.printStackTrace())
        throw e
    }
  }
}
