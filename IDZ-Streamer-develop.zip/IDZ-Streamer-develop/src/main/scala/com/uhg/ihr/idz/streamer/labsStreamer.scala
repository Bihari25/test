package com.uhg.ihr.idz.streamer

import com.uhg.ihr.idz.utils.Utils.{DebatchMessage, MetaData}
import org.apache.spark.sql.Row
import java.io.FileInputStream
import java.util.Properties

import com.uhg.ihr.idz.common.Logger
import com.uhg.ihr.idz.utils.Utils
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object labsStreamer {

  var SOURCE_TYPE: String = _
  var KAFKA_SERVER: String = _
  var KAFKA_TOPIC: String = _
  var ES_NODES: String = _
  var ES_PORT: String = _
  var ES_INDEX: String = _
  var trustStorePath: String = _
  var trustStorePwd: String = _
  var scrWriteUser: String = _
  var scrWritePwd: String = _
  var scrReadUser: String = _
  var scrReadPwd: String = _
  var algorithm: String = _
  var securityEnabled: String = _
  var requestTimeOut:String = _
  var retries:String = _
  var requestSize:String = _


  def main(args: Array[String]): Unit = {

    if (args.length != 2) {
      Logger.log.info(s"Please Pass the valid input parameter:\nInputFilePath  \npropertiesFile ")
      System.exit(1)
    }

    //Arguments
    val inputFilePath = args(0)
    val propertiesFile = args(1)

    Logger.log.info("InputFile Path: => " + inputFilePath)
    Logger.log.info("propertiesFile :> " + propertiesFile)
    val startTime = System.currentTimeMillis()
    Logger.log.info("Reading the properties File")

    try {
      val prop = new Properties()
      val path = new FileInputStream(propertiesFile)

      try {
        prop.load(path)
      }
      finally {
        path.close
      }


      /**
        * register an UDF that creates a random ID LBS_<timestamp>_<uuid>
        */

      val generateUUID = udf { (srcType: String) => Utils.generateUUID(srcType) }


      SOURCE_TYPE = prop.getProperty("source_type")
      KAFKA_SERVER = prop.getProperty("kafka_server")
      KAFKA_TOPIC = prop.getProperty("kafka_topic")

      ES_NODES = prop.getProperty("es_Nodes")
      ES_PORT = prop.getProperty("es_Port")
      ES_INDEX = prop.getProperty("es_Index")
      trustStorePath = prop.getProperty("trust_store_path")
      trustStorePwd = prop.getProperty("trust_store_pwd")
      scrWriteUser = prop.getProperty("scram_write_user")
      scrWritePwd = prop.getProperty("scram_write_pwd")
      scrReadUser = prop.getProperty("scram_read_user")
      scrReadPwd = prop.getProperty("scram_read_pwd")
      algorithm = prop.getProperty("algorithm")
      securityEnabled = prop.getProperty("securityEnabled")
      retries = prop.getProperty("retries")
      requestTimeOut = prop.getProperty("requestTimeOut")
      requestSize = prop.getProperty("requestSize")

      Logger.log.info("Elastic Search Nodes : => " + ES_NODES)
      Logger.log.info("Elastic Search Port : => " + ES_PORT)
      Logger.log.info("Elastic Search Index : => " + ES_INDEX)


      val es_Nodes = prop.getProperty("es_Nodes")
      Logger.log.info("Elastic search node name =>" + es_Nodes)

      val es_Port = prop.getProperty("es_Port")
      Logger.log.info("Elastic search Port no =>" + es_Port)

      val es_Index = prop.getProperty("es_Index")
      Logger.log.info("Elastic search index table name =>" + es_Index)

      val es_user = prop.getProperty("es_user")
      Logger.log.info("es user Name: => " + es_user)

      val es_pwd = prop.getProperty("es_pwd")

      val interfaceName = prop.getProperty("interface_type")
      Logger.log.info("streamer Status interfaceName =>" + interfaceName)

      val (uuid, filename, interface, payload) = (prop.getProperty("messageUUID"), prop.getProperty("sourceName"), prop.getProperty("interface"), prop.getProperty("payload"))

      // passing the spark configurations
      val conf = new SparkConf().setAppName("Labs_Debatch")
      conf.set("spark.driver.cores", prop.getProperty("driver_cores"))
      conf.set("spark.executor.instances", prop.getProperty("executor_instances"))
      conf.set("spark.executor.memory", prop.getProperty("executor_memory"))
      conf.set("spark.driver.memory", prop.getProperty("driver_memory"))
      conf.set("spark.executor.cores", prop.getProperty("executor_cores"))
      conf.set("spark.default.parallelism", prop.getProperty("default_parallelism"))
      conf.set("spark.sql.shuffle.partitions", prop.getProperty("sql_shuffle_partitions"))
      conf.set("spark.yarn.executor.memoryoverhead", prop.getProperty("yarn_executor_memoryoverhead"))
      conf.set("spark.driver.maxResultSize", prop.getProperty("driver_maxResultSize"))
      conf.set("spark.memory.fraction", prop.getProperty("memory_fraction"))
      conf.set("spark.debug.maxToStringFields", prop.getProperty("maxToStringFields"))
      conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      conf.set("spark.es.nodes", ES_NODES)
      conf.set("spark.es.port", ES_PORT)
      conf.set("spark.es.net.http.auth.user", es_user)
      conf.set("spark.es.net.http.auth.pass", es_pwd)
      conf.set("spark.es.nodes.wan.only", "true")
      conf.set("spark.es.mapping.id", filename)
      conf.set("spark.es.write.operation", "upsert")


      // Creating the spark context & session
      val spark = SparkSession.builder().config(conf).getOrCreate()
      val sc = spark.sparkContext
      import spark.implicits._

      // Delimiter to read the file
      Logger.log.info("Reading the Input files")

      val delimit = "MSH|^~"
      sc.hadoopConfiguration.set("textinputformat.record.delimiter", delimit)


      /**
        * Exit if the input Directory is Empty.
        */
      if(Utils.getFilePaths(inputFilePath,sc).length == 0){
        Logger.log.info(s"Source ${inputFilePath} is Empty or doesn't exist.")
        Logger.log.error("==> ==> ==>  Exiting the Job  <== <== <==")
        System.exit(1)
      }

      val inputDf = sc.textFile(inputFilePath)
        .map(x => x.split("BTS\\|")(0)).map(x => ("MSH|^~" + x))
        .map(x => x.replace("\r", ""))
        .map(x => x.replace("\n", "\r"))
        .toDF("delimit_column")

      val currentTimestamp = Utils.getCurrentTimestamp()

      val outputDf = inputDf.filter($"delimit_column".contains("MSH|^~\\&|"))
        .withColumn("uuid", generateUUID(lit(SOURCE_TYPE)))
        .withColumn("filename", input_file_name())
        .withColumn("InterfaceType", lit(prop.getProperty("interface_type")))
        .withColumn("createTimestamp",lit(currentTimestamp))
        .withColumn("updateTimestamp",lit(currentTimestamp))


      val data1 = outputDf.select($"uuid".as(uuid)
        , $"filename".as(filename)
        , $"InterfaceType".as(interface)
        , $"delimit_column".as(payload)
        , $"createTimestamp"
        , $"updateTimestamp")

      data1.persist()

      val data2 = data1.map {
        case Row(uuid: String, fileName: String ,interface:String, payload:String, createTimestamp:String, updateTimestamp:String) => DebatchMessage(uuid,fileName,interface,payload,createTimestamp,updateTimestamp, MetaData(null,null,null))
      }.as[DebatchMessage].toJSON

      Logger.log.info("***** Selecting required column created  *****")


      /**
        * Pushing Messages to Kafka
        */
      try {
        Logger.log.info("***** sending Streaming  message to kafka *****")

        if(securityEnabled.equalsIgnoreCase("true")) {

          Utils.writeToSecureTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER,trustStorePath,trustStorePwd,scrWriteUser,scrWritePwd,scrReadUser,scrReadPwd,algorithm,requestTimeOut,retries,requestSize)
        }else {
          Utils.writeToTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER,requestTimeOut,retries,requestSize)

        }
        Logger.log.info("***** sending Streaming  message  to kafka  completed *****")
      } catch {
        case e: Exception => Logger.log.error("Exception while sending Streaming  message  to kafka " + e.getMessage + e)
          Logger.log.error(e.printStackTrace())
          throw new RuntimeException("Failed to push records to Kafka. Please check if the provided Cluster details are accurate.")
      }


      /**
        * Elastic Search Summary Indexing
        */
      Utils.writeSummaryToES(data1,interfaceName,es_Index)

      val OutputEndTimeMillis = System.currentTimeMillis()
      val OutputDurationMinutes = OutputEndTimeMillis.-(startTime)./(60000)
      val OutputDurationSeconds = OutputEndTimeMillis.-(startTime)./(1000).%(60)
      Logger.log.info(s"Job Execution Time : $OutputDurationMinutes minutes and $OutputDurationSeconds Seconds")
      Logger.log.info("   ************* END OF LABS-STREAMER JOB ***************\n")
      sc.stop()
      spark.stop()


    } catch {
      case e: Exception => Logger.log.error(s"Exception at labsStreamer Object" + e.getMessage + e)
        Logger.log.info(s"exception in main +" + e.printStackTrace())
        throw e
    } //catch


  }
}