package com.uhg.ihr.idz.streamer

import java.io.FileInputStream
import java.util.Properties

import com.uhg.ihr.idz.common.Logger
import com.uhg.ihr.idz.common.Logger.log
import com.uhg.ihr.idz.schema.npiSchema
import com.uhg.ihr.idz.utils.Utils
import com.uhg.ihr.idz.utils.Utils.{DebatchMessage, MetaData}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.functions._

object npiStreamer {

  var KAFKA_TOPIC: String = _
  var KAFKA_SERVER: String = _
  var SOURCE_TYPE: String = _
  var INTERFACE_TYPE: String = _
  var uuid: String = _
  var fileName: String = _
  var payload: String = _
  var interface: String = _
  var ES_NODES: String = _
  var ES_PORT: String = _
  var ES_INDEX: String = _
  var ES_USER :String = _
  var ES_PWD :String = _
  var tranTopic: String = _
  var tranServer: String = _
  var applicationName: String = _
  var applicationVersion: String = _
  var trustStorePath: String = _
  var trustStorePwd: String = _
  var scrWriteUser: String = _
  var scrWritePwd: String = _
  var scrReadUser: String = _
  var scrReadPwd: String = _
  var algorithm: String = _
  var securityEnabled: String = _
  var requestTimeOut:String = _
  var retries:String = _
  var requestSize:String = _




  def main(args: Array[String]): Unit = {
    var inputDir = ""
    var propPath = ""

    if (args.length != 2) {
      log.info("Enter proper number of arguments.")
      sys.exit(1)
    }

    try {
      inputDir = args(0)
      propPath = args(1)
    } catch {
      case x: ArrayIndexOutOfBoundsException => {
        log.info(s"Please Pass the valid input parameters \nInputPath : $inputDir  \n propertiesFile Path :$propPath \n")
        log.info(x.getMessage)
        sys.exit(1)
      }
    }

    try {
      val propStream = new FileInputStream(propPath)
      val properties = new Properties()
      val startTime = System.currentTimeMillis()

      try {
        properties.load(propStream)
      } finally {
        propStream.close
      }

      //Streaming properties
      KAFKA_TOPIC = properties.getProperty("kafka_topic")
      KAFKA_SERVER = properties.getProperty("kafka_server")
      SOURCE_TYPE = properties.getProperty("source_type")
      INTERFACE_TYPE = properties.getProperty("interface_type")
      uuid = properties.getProperty("messageUUID")
      fileName = properties.getProperty("sourceName")
      payload = properties.getProperty("payload")
      interface = properties.getProperty("interface")
      SOURCE_TYPE = properties.getProperty("source_type")
      trustStorePath = properties.getProperty("trust_store_path")
      trustStorePwd = properties.getProperty("trust_store_pwd")
      scrWriteUser = properties.getProperty("scram_write_user")
      scrWritePwd = properties.getProperty("scram_write_pwd")
      scrReadUser = properties.getProperty("scram_read_user")
      scrReadPwd = properties.getProperty("scram_read_pwd")
      algorithm = properties.getProperty("algorithm")
      securityEnabled = properties.getProperty("securityEnabled")
      retries = properties.getProperty("retries")
      requestTimeOut = properties.getProperty("requestTimeOut")
      requestSize = properties.getProperty("requestSize")


      //Elastic search indexing properties
      ES_NODES = properties.getProperty("es_Nodes")
      ES_PORT = properties.getProperty("es_Port")
      ES_INDEX = properties.getProperty("es_Index")
	    ES_USER = properties.getProperty("es_user")
	    ES_PWD = properties.getProperty("es_pwd")


      log.info("Transactional indexing topic Name =>" + tranTopic)
      log.info("Transactional indexing kafka bootstrap servers =>" + tranServer)
      log.info("Elastic Search Nodes : => " + ES_NODES)
      log.info("Elastic Search Port : => " + ES_PORT)
      log.info("Elastic Search Index : => " + ES_INDEX)
      log.info("Elastic search user :=>" + ES_USER)

      val conf = new SparkConf()

      conf.set("spark.driver.cores", properties.getProperty("driver_cores"))
      conf.set("spark.executor.instances", properties.getProperty("executor_instances"))
      conf.set("spark.executor.memory", properties.getProperty("executor_memory"))
      conf.set("spark.driver.memory", properties.getProperty("driver_memory"))
      conf.set("spark.executor.cores", properties.getProperty("executor_cores"))
      conf.set("spark.default.parallelism", properties.getProperty("default_parallelism"))
      conf.set("spark.sql.shuffle.partitions", properties.getProperty("sql_shuffle_partitions"))
      conf.set("spark.yarn.executor.memoryoverhead", properties.getProperty("yarn_executor_memoryoverhead"))
      conf.set("spark.driver.maxResultSize", properties.getProperty("driver_maxResultSize"))
      conf.set("spark.memory.fraction", properties.getProperty("memory_fraction"))
      conf.set("spark.es.nodes", ES_NODES)
      conf.set("spark.es.port", ES_PORT)
      conf.set("spark.es.net.http.auth.user", ES_USER)
      conf.set("spark.es.net.http.auth.pass", ES_PWD)
      conf.set("spark.es.nodes.wan.only", "true")
      conf.set("spark.es.mapping.id", fileName)
      conf.set("spark.es.write.operation", "upsert")
      conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")



      val spark = SparkSession.builder().config(conf).getOrCreate()
      import spark.implicits._
      val sc = spark.sparkContext

      /**
        * Exit if the input Directory is Empty.
        */
      if(Utils.getFilePaths(inputDir,sc).length == 0){
        Logger.log.info(s"Source ${inputDir} is Empty or doesn't exist.")
        Logger.log.error("==> ==> ==>  Exiting the Job  <== <== <==")
        System.exit(1)
      }

      val generateUUID = udf { (srcType: String) => Utils.generateUUID(srcType) }

      val inputDF = spark.read.format("csv").option("delimiter", ",").option("header", "false").schema(npiSchema.schema).load(inputDir)
      val deltaDF = inputDF.withColumn("filename", lit(input_file_name())).filter($"NPI"=!=("NPI"))

      //Preparation for query.
      deltaDF.createOrReplaceTempView("transformtbl")
      val schemaList = npiSchema.schema.toList
      var temp = ""

      //Converting the schema to _c<num> format.
      for (i <- 1 to 329) {
        if (i != 329)
          temp = temp + schemaList(i - 1).name + " as " + "_c" + i + ","
        else
          temp = temp + schemaList(i - 1).name + " as " + "_c" + i
      }
      val query = "select " + temp + ",filename from transformtbl"
      val tdf = spark.sql(query)


      //Query for transformations
      tdf.createOrReplaceTempView("input_table")
      val query2 = """ select _c1,_c2,_c3,_c4,_c5,_c6,_c7,_c8,_c9,_c10,_c11,_c12,_c13,_c14,_c15,_c16,_c17,_c18,_c19,_c20,_c21,_c22,_c23,_c24,_c25,_c26,_c27,_c28,_c29,_c30,_c31,_c32,_c33,_c34,_c35,_c36,_c37,_c38,_c39,_c40,_c41,_c42,_c43,_c44,_c45,_c46,_c47,_c48,_c49,case when _c49 is null or _c50 = "ZZ" then "" else _c50 end as _c50,_c51,_c52,_c53,case when _c53 is null or _c54 = "ZZ" then "" else _c54 end as _c54, _c55, _c56, _c57, case when _c57 is null or _c58 = "ZZ" then "" else _c58 end as _c58, _c59, _c60, _c61, case when _c61 is null or _c62 = "ZZ" then "" else _c62 end as _c62,_c63, _c64, _c65, case when _c65 is null or _c66 = "ZZ" then "" else _c66 end as _c66, _c67, _c68, _c69, case when _c69 is null or _c70 = "ZZ" then "" else _c70 end as _c70, _c71, _c72, _c73, case when _c73 is null or _c74 = "ZZ" then "" else _c74 end as _c74, _c75, _c76, _c77, case when _c77 is null or _c78 = "ZZ" then "" else _c78 end as _c78,_c79, _c80, _c81, case when _c81 is null or _c82 = "ZZ" then "" else _c82 end as _c82,_c83, _c84, _c85, case when _c85 is null or _c86 = "ZZ" then "" else _c86 end as _c86,_c87, _c88, _c89, case when _c89 is null or _c90 = "ZZ" then "" else _c90 end as _c90,_c91, _c92, _c93, case when _c93 is null or _c94 = "ZZ" then "" else _c94 end as _c94,_c95, _c96, _c97, case when _c97 is null or _c98 = "ZZ" then "" else _c98 end as _c98,_c99, _c100, _c101, case when _c101 is null or _c102 = "ZZ" then "" else _c102 end as _c102, _c103, _c104, _c105, case when _c105 is null or _c106 = "ZZ" then "" else _c106 end as _c106, _c107, case when _c108 is null or _c109 is null or _c110 is null or _c111 is null or _c109 = "01" then "" else _c108 end as _c108,case when _c108 is null or _c109 is null or _c110 is null or _c111 is null or _c109 = "01" then "" else _c109 end as _c109,case when _c108 is null or _c109 is null or _c110 is null or _c111 is null or _c109 = "01" then "" else _c110 end as _c110,case when _c108 is null or _c109 is null or _c110 is null or _c111 is null or _c109 = "01" then "" else _c111 end as _c111,case when _c112 is null or _c113 is null or _c114 is null or _c115 is null or _c113 = "01" then "" else _c112 end as _c112,case when _c112 is null or _c113 is null or _c114 is null or _c115 is null or _c113 = "01" then "" else _c113 end as _c113,case when _c112 is null or _c113 is null or _c114 is null or _c115 is null or _c113 = "01" then "" else _c114 end as _c114,case when _c112 is null or _c113 is null or _c114 is null or _c115 is null or _c113 = "01" then "" else _c115 end as _c115,case when _c116 is null or _c117 is null or _c118 is null or _c119 is null or _c117 = "01" then "" else _c116 end as _c116,case when _c116 is null or _c117 is null or _c118 is null or _c119 is null or _c117 = "01" then "" else _c117 end as _c117,case when _c116 is null or _c117 is null or _c118 is null or _c119 is null or _c117 = "01" then "" else _c118 end as _c118,case when _c116 is null or _c117 is null or _c118 is null or _c119 is null or _c117 = "01" then "" else _c119 end as c119,case when _c120 is null or _c121 is null or _c122 is null or _c123 is null or _c121 = "01" then "" else _c120 end as _c120,case when _c120 is null or _c121 is null or _c122 is null or _c123 is null or _c121 = "01" then "" else _c121 end as _c121,case when _c120 is null or _c121 is null or _c122 is null or _c123 is null or _c121 = "01" then "" else _c122 end as _c122,case when _c120 is null or _c121 is null or _c122 is null or _c123 is null or _c121 = "01" then "" else _c123 end as _c123,case when _c124 is null or _c125 is null or _c126 is null or _c127 is null or _c125 = "01" then "" else _c124 end as _c124,case when _c124 is null or _c125 is null or _c126 is null or _c127 is null or _c125 = "01" then "" else _c125 end as _c125,case when _c124 is null or _c125 is null or _c126 is null or _c127 is null or _c125 = "01" then "" else _c126 end as _c126,case when _c124 is null or _c125 is null or _c126 is null or _c127 is null or _c125 = "01" then "" else _c127 end as _c127,case when _c128 is null or _c129 is null or _c130 is null or _c131 is null or _c129 = "01" then "" else _c128 end as _c128,case when _c128 is null or _c129 is null or _c130 is null or _c131 is null or _c129 = "01" then "" else _c129 end as _c129,case when _c128 is null or _c129 is null or _c130 is null or _c131 is null or _c129 = "01" then "" else _c130 end as _c130,case when _c128 is null or _c129 is null or _c130 is null or _c131 is null or _c129 = "01" then "" else _c131 end as _c131,case when _c132 is null or _c133 is null or _c134 is null or _c135 is null or _c133 = "01" then "" else _c132 end as _c132,case when _c132 is null or _c133 is null or _c134 is null or _c135 is null or _c133 = "01" then "" else _c133 end as _c133,case when _c132 is null or _c133 is null or _c134 is null or _c135 is null or _c133 = "01" then "" else _c134 end as _c134,case when _c132 is null or _c133 is null or _c134 is null or _c135 is null or _c133 = "01" then "" else _c135 end as _c135,case when _c136 is null or _c137 is null or _c138 is null or _c139 is null or _c137 = "01" then "" else _c136 end as _c136,case when _c136 is null or _c137 is null or _c138 is null or _c139 is null or _c137 = "01" then "" else _c137 end as _c137,case when _c136 is null or _c137 is null or _c138 is null or _c139 is null or _c137 = "01" then "" else _c138 end as _c138,case when _c136 is null or _c137 is null or _c138 is null or _c139 is null or _c137 = "01" then "" else _c139 end as _c139,case when _c140 is null or _c141 is null or _c142 is null or _c143 is null or _c141 = "01" then "" else _c140 end as _c140,case when _c140 is null or _c141 is null or _c142 is null or _c143 is null or _c141 = "01" then "" else _c141 end as _c141,case when _c140 is null or _c141 is null or _c142 is null or _c143 is null or _c141 = "01" then "" else _c142 end as _c142,case when _c140 is null or _c141 is null or _c142 is null or _c143 is null or _c141 = "01" then "" else _c143 end as _c143,case when _c144 is null or _c145 is null or _c146 is null or _c147 is null or _c145 = "01" then "" else _c144 end as _c144,case when _c144 is null or _c145 is null or _c146 is null or _c147 is null or _c145 = "01" then "" else _c145 end as _c145,case when _c144 is null or _c145 is null or _c146 is null or _c147 is null or _c145 = "01" then "" else _c146 end as _c146,case when _c144 is null or _c145 is null or _c146 is null or _c147 is null or _c145 = "01" then "" else _c147 end as _c147,case when _c148 is null or _c149 is null or _c150 is null or _c151 is null or _c149 = "01" then "" else _c148 end as _c148,case when _c148 is null or _c149 is null or _c150 is null or _c151 is null or _c149 = "01" then "" else _c149 end as _c149,case when _c148 is null or _c149 is null or _c150 is null or _c151 is null or _c149 = "01" then "" else _c150 end as _c150,case when _c148 is null or _c149 is null or _c150 is null or _c151 is null or _c149 = "01" then "" else _c151 end as _c151,case when _c152 is null or _c153 is null or _c154 is null or _c155 is null or _c153 = "01" then "" else _c152 end as _c152,case when _c152 is null or _c153 is null or _c154 is null or _c155 is null or _c153 = "01" then "" else _c153 end as _c153,case when _c152 is null or _c153 is null or _c154 is null or _c155 is null or _c153 = "01" then "" else _c154 end as _c154,case when _c152 is null or _c153 is null or _c154 is null or _c155 is null or _c153 = "01" then "" else _c155 end as _c155,case when _c156 is null or _c157 is null or _c158 is null or _c159 is null or _c157 = "01" then "" else _c156 end as _c156,case when _c156 is null or _c157 is null or _c158 is null or _c159 is null or _c157 = "01" then "" else _c157 end as _c157,case when _c156 is null or _c157 is null or _c158 is null or _c159 is null or _c157 = "01" then "" else _c158 end as _c158,case when _c156 is null or _c157 is null or _c158 is null or _c159 is null or _c157 = "01" then "" else _c159 end as _c159,case when _c160 is null or _c161 is null or _c162 is null or _c163 is null or _c161 = "01" then "" else _c160 end as _c160,case when _c160 is null or _c161 is null or _c162 is null or _c163 is null or _c161 = "01" then "" else _c161 end as _c161,case when _c160 is null or _c161 is null or _c162 is null or _c163 is null or _c161 = "01" then "" else _c162 end as _c162,case when _c160 is null or _c161 is null or _c162 is null or _c163 is null or _c161 = "01" then "" else _c163 end as _c163,case when _c164 is null or _c165 is null or _c166 is null or _c167 is null or _c165 = "01" then "" else _c164 end as _c164,case when _c164 is null or _c165 is null or _c166 is null or _c167 is null or _c165 = "01" then "" else _c165 end as _c165,case when _c164 is null or _c165 is null or _c166 is null or _c167 is null or _c165 = "01" then "" else _c166 end as _c166,case when _c164 is null or _c165 is null or _c166 is null or _c167 is null or _c165 = "01" then "" else _c167 end as _c167,case when _c168 is null or _c169 is null or _c170 is null or _c171 is null or _c169 = "01" then "" else _c168 end as _c168,case when _c168 is null or _c169 is null or _c170 is null or _c171 is null or _c169 = "01" then "" else _c169 end as _c169,case when _c168 is null or _c169 is null or _c170 is null or _c171 is null or _c169 = "01" then "" else _c170 end as _c170,case when _c168 is null or _c169 is null or _c170 is null or _c171 is null or _c169 = "01" then "" else _c171 end as _c171,case when _c172 is null or _c173 is null or _c174 is null or _c175 is null or _c173 = "01" then "" else _c172 end as _c172,case when _c172 is null or _c173 is null or _c174 is null or _c175 is null or _c173 = "01"  then "" else _c173 end as _c173,case when _c172 is null or _c173 is null or _c174 is null or _c175 is null or _c173 = "01" then "" else _c174 end as _c174,case when _c172 is null or _c173 is null or _c174 is null or _c175 is null or _c173 = "01" then "" else _c175 end as _c175,case when _c176 is null or _c177 is null or _c178 is null or _c179 is null or _c177 = "01" then "" else _c176 end as _c176,case when _c176 is null or _c177 is null or _c178 is null or _c179 is null or _c177 = "01" then "" else _c177 end as _c177,case when _c176 is null or _c177 is null or _c178 is null or _c179 is null or _c177 = "01" then "" else _c178 end as _c178,case when _c176 is null or _c177 is null or _c178 is null or _c179 is null or _c177 = "01" then "" else _c179 end as _c179,case when _c180 is null or _c181 is null or _c182 is null or _c183 is null or _c181 = "01" then "" else _c180 end as _c180,case when _c180 is null or _c181 is null or _c182 is null or _c183 is null or _c181 = "01" then "" else _c181 end as _c181,case when _c180 is null or _c181 is null or _c182 is null or _c183 is null or _c181 = "01" then "" else _c182 end as _c182,case when _c180 is null or _c181 is null or _c182 is null or _c183 is null or _c181 = "01" then "" else _c183 end as _c183,case when _c184 is null or _c185 is null or _c186 is null or _c187 is null or _c185 = "01" then "" else _c184 end as _c184,case when _c184 is null or _c185 is null or _c186 is null or _c187 is null or _c185 = "01" then "" else _c185 end as _c185,case when _c184 is null or _c185 is null or _c186 is null or _c187 is null or _c185 = "01" then "" else _c186 end as _c186,case when _c184 is null or _c185 is null or _c186 is null or _c187 is null or _c185 = "01" then "" else _c187 end as _c187,case when _c188 is null or _c189 is null or _c190 is null or _c191 is null or _c189 = "01" then "" else _c188 end as _c188,case when _c188 is null or _c189 is null or _c190 is null or _c191 is null or _c189 = "01" then "" else _c189 end as _c189,case when _c188 is null or _c189 is null or _c190 is null or _c191 is null or _c189 = "01" then "" else _c190 end as _c190,case when _c188 is null or _c189 is null or _c190 is null or _c191 is null or _c189 = "01" then "" else _c191 end as _c191,case when _c192 is null or _c193 is null or _c194 is null or _c195 is null or _c193 = "01" then "" else _c192 end as _c192,case when _c192 is null or _c193 is null or _c194 is null or _c195 is null or _c193 = "01"  then "" else _c193 end as _c193,case when _c192 is null or _c193 is null or _c194 is null or _c195 is null or _c193 = "01" then "" else _c194 end as _c194,case when _c192 is null or _c193 is null or _c194 is null or _c195 is null or _c193 = "01" then "" else _c195 end as _c195,case when _c196 is null or _c197 is null or _c198 is null or _c199 is null or _c197 = "01" then "" else _c196 end as _c196,case when _c196 is null or _c197 is null or _c198 is null or _c199 is null or _c197 = "01" then "" else _c197 end as _c197,case when _c196 is null or _c197 is null or _c198 is null or _c199 is null or _c197 = "01" then "" else _c198 end as _c198,case when _c196 is null or _c197 is null or _c198 is null or _c199 is null or _c197 = "01" then "" else _c199 end as _c199,case when _c200 is null or _c201 is null or _c202 is null or _c203 is null or _c201 = "01" then "" else _c200 end as _c200,case when _c200 is null or _c201 is null or _c202 is null or _c203 is null or _c201 = "01" then "" else _c201 end as _c201,case when _c200 is null or _c201 is null or _c202 is null or _c203 is null or _c201 = "01" then "" else _c202 end as _c202,case when _c200 is null or _c201 is null or _c202 is null or _c203 is null or _c201 = "01" then "" else _c203 end as _c203,case when _c204 is null or _c205 is null or _c206 is null or _c207 is null or _c205 = "01" then "" else _c204 end as _c204,case when _c204 is null or _c205 is null or _c206 is null or _c207 is null or _c205 = "01" then "" else _c205 end as _c205,case when _c204 is null or _c205 is null or _c206 is null or _c207 is null or _c205 = "01" then "" else _c206 end as _c206,case when _c204 is null or _c205 is null or _c206 is null or _c207 is null or _c205 = "01" then "" else _c207 end as _c207,case when _c208 is null or _c209 is null or _c210 is null or _c211 is null or _c209 = "01" then "" else _c208 end as _c208,case when _c208 is null or _c209 is null or _c210 is null or _c211 is null or _c209 = "01" then "" else _c209 end as _c209,case when _c208 is null or _c209 is null or _c210 is null or _c211 is null or _c209 = "01" then "" else _c210 end as _c210,case when _c208 is null or _c209 is null or _c210 is null or _c211 is null or _c209 = "01" then "" else _c211 end as _c211,case when _c212 is null or _c213 is null or _c214 is null or _c215 is null or _c213 = "01" then "" else _c212 end as _c212,case when _c212 is null or _c213 is null or _c214 is null or _c215 is null or _c213 = "01" then "" else _c213 end as _c213,case when _c212 is null or _c213 is null or _c214 is null or _c215 is null or _c213 = "01" then "" else _c214 end as _c214,case when _c212 is null or _c213 is null or _c214 is null or _c215 is null or _c213 = "01" then "" else _c215 end as _c215,case when _c216 is null or _c217 is null or _c218 is null or _c219 is null or _c217 = "01" then "" else _c216 end as _c216,case when _c216 is null or _c217 is null or _c218 is null or _c219 is null or _c217 = "01" then "" else _c217 end as _c217,case when _c216 is null or _c217 is null or _c218 is null or _c219 is null or _c217 = "01" then "" else _c218 end as _c218,case when _c216 is null or _c217 is null or _c218 is null or _c219 is null or _c217 = "01" then "" else _c219 end as _c219,case when _c220 is null or _c221 is null or _c222 is null or _c223 is null or _c221 = "01" then "" else _c220 end as _c220,case when _c220 is null or _c221 is null or _c222 is null or _c223 is null or _c221 = "01" then "" else _c221 end as _c221,case when _c220 is null or _c221 is null or _c222 is null or _c223 is null or _c221 = "01" then "" else _c222 end as _c222,case when _c220 is null or _c221 is null or _c222 is null or _c223 is null or _c221 = "01" then "" else _c223 end as _c223,case when _c224 is null or _c225 is null or _c226 is null or _c227 is null or _c225 = "01" then "" else _c224 end as _c224,case when _c224 is null or _c225 is null or _c226 is null or _c227 is null or _c225 = "01" then "" else _c225 end as _c225,case when _c224 is null or _c225 is null or _c226 is null or _c227 is null or _c225 = "01" then "" else _c226 end as _c226,case when _c224 is null or _c225 is null or _c226 is null or _c227 is null or _c225 = "01" then "" else _c227 end as _c227,case when _c228 is null or _c229 is null or _c230 is null or _c231 is null or _c229 = "01" then "" else _c228 end as _c228,case when _c228 is null or _c229 is null or _c230 is null or _c231 is null or _c229 = "01" then "" else _c229 end as _c229,case when _c228 is null or _c229 is null or _c230 is null or _c231 is null or _c229 = "01" then "" else _c230 end as _c230,case when _c228 is null or _c229 is null or _c230 is null or _c231 is null or _c229 = "01" then "" else _c231 end as _c231,case when _c232 is null or _c233 is null or _c234 is null or _c235 is null or _c233 = "01" then "" else _c232 end as _c232,case when _c232 is null or _c233 is null or _c234 is null or _c235 is null or _c233 = "01" then "" else _c233 end as _c233,case when _c232 is null or _c233 is null or _c234 is null or _c235 is null or _c233 = "01" then "" else _c234 end as _c234,case when _c232 is null or _c233 is null or _c234 is null or _c235 is null or _c233 = "01" then "" else _c235 end as _c235,case when _c236 is null or _c237 is null or _c238 is null or _c239 is null or _c237 = "01" then "" else _c236 end as _c236,case when _c236 is null or _c237 is null or _c238 is null or _c239 is null or _c237 = "01" then "" else _c237 end as _c237,case when _c236 is null or _c237 is null or _c238 is null or _c239 is null or _c237 = "01" then "" else _c238 end as _c238,case when _c236 is null or _c237 is null or _c238 is null or _c239 is null or _c237 = "01" then "" else _c239 end as _c239,case when _c240 is null or _c241 is null or _c242 is null or _c243 is null or _c241 = "01" then "" else _c240 end as _c240,case when _c240 is null or _c241 is null or _c242 is null or _c243 is null or _c241 = "01" then "" else _c241 end as _c241,case when _c240 is null or _c241 is null or _c242 is null or _c243 is null or _c241 = "01" then "" else _c242 end as _c242,case when _c240 is null or _c241 is null or _c242 is null or _c243 is null or _c241 = "01" then "" else _c243 end as _c243,case when _c244 is null or _c245 is null or _c246 is null or _c247 is null or _c245 = "01" then "" else _c244 end as _c244,case when _c244 is null or _c245 is null or _c246 is null or _c247 is null or _c245 = "01" then "" else _c245 end as _c245,case when _c244 is null or _c245 is null or _c246 is null or _c247 is null or _c245 = "01" then "" else _c246 end as _c246,case when _c244 is null or _c245 is null or _c246 is null or _c247 is null or _c245 = "01" then "" else _c247 end as _c247,case when _c248 is null or _c249 is null or _c250 is null or _c251 is null or _c249 = "01" then "" else _c248 end as _c248,case when _c248 is null or _c249 is null or _c250 is null or _c251 is null or _c249 = "01" then "" else _c249 end as _c249,case when _c248 is null or _c249 is null or _c250 is null or _c251 is null or _c249 = "01" then "" else _c250 end as _c250,case when _c248 is null or _c249 is null or _c250 is null or _c251 is null or _c249 = "01" then "" else _c251 end as _c251,case when _c252 is null or _c253 is null or _c254 is null or _c255 is null or _c253 = "01" then "" else _c252 end as _c252,case when _c252 is null or _c253 is null or _c254 is null or _c255 is null or _c253 = "01" then "" else _c253 end as _c253,case when _c252 is null or _c253 is null or _c254 is null or _c255 is null or _c253 = "01" then "" else _c254 end as _c254,case when _c252 is null or _c253 is null or _c254 is null or _c255 is null or _c253 = "01" then "" else _c255 end as _c255,case when _c256 is null or _c257 is null or _c258 is null or _c259 is null or _c257 = "01" then "" else _c256 end as _c256,case when _c256 is null or _c257 is null or _c258 is null or _c259 is null or _c257 = "01" then "" else _c257 end as _c257,case when _c256 is null or _c257 is null or _c258 is null or _c259 is null or _c257 = "01" then "" else _c258 end as _c258,case when _c256 is null or _c257 is null or _c258 is null or _c259 is null or _c257 = "01" then "" else _c259 end as _c259,case when _c260 is null or _c261 is null or _c262 is null or _c263 is null or _c261 = "01" then "" else _c260 end as _c260,case when _c260 is null or _c261 is null or _c262 is null or _c263 is null or _c261 = "01" then "" else _c261 end as _c261,case when _c260 is null or _c261 is null or _c262 is null or _c263 is null or _c261 = "01" then "" else _c262 end as _c262,case when _c260 is null or _c261 is null or _c262 is null or _c263 is null or _c261 = "01" then "" else _c263 end as _c263,case when _c264 is null or _c265 is null or _c266 is null or _c267 is null or _c265 = "01" then "" else _c264 end as _c264,case when _c264 is null or _c265 is null or _c266 is null or _c267 is null or _c265 = "01" then "" else _c265 end as _c265,case when _c264 is null or _c265 is null or _c266 is null or _c267 is null or _c265 = "01" then "" else _c266 end as _c266,case when _c264 is null or _c265 is null or _c266 is null or _c267 is null or _c265 = "01" then "" else _c267 end as _c267,case when _c268 is null or _c269 is null or _c270 is null or _c271 is null or _c269 = "01" then "" else _c268 end as _c268,case when _c268 is null or _c269 is null or _c270 is null or _c271 is null or _c269 = "01" then "" else _c269 end as _c269,case when _c268 is null or _c269 is null or _c270 is null or _c271 is null or _c269 = "01" then "" else _c270 end as _c270,case when _c268 is null or _c269 is null or _c270 is null or _c271 is null or _c269 = "01" then "" else _c271 end as _c271,case when _c272 is null or _c273 is null or _c274 is null or _c275 is null or _c273 = "01" then "" else _c272 end as _c272,case when _c272 is null or _c273 is null or _c274 is null or _c275 is null or _c273 = "01" then "" else _c273 end as _c273,case when _c272 is null or _c273 is null or _c274 is null or _c275 is null or _c273 = "01" then "" else _c274 end as _c274,case when _c272 is null or _c273 is null or _c274 is null or _c275 is null or _c273 = "01" then "" else _c275 end as _c275,case when _c276 is null or _c277 is null or _c278 is null or _c279 is null or _c277 = "01" then "" else _c276 end as _c276,case when _c276 is null or _c277 is null or _c278 is null or _c279 is null or _c277 = "01" then "" else _c277 end as _c277,case when _c276 is null or _c277 is null or _c278 is null or _c279 is null or _c277 = "01" then "" else _c278 end as _c278,case when _c276 is null or _c277 is null or _c278 is null or _c279 is null or _c277 = "01" then "" else _c279 end as _c279,case when _c280 is null or _c281 is null or _c282 is null or _c283 is null or _c281 = "01" then "" else _c280 end as _c280,case when _c280 is null or _c281 is null or _c282 is null or _c283 is null or _c281 = "01" then "" else _c281 end as _c281,case when _c280 is null or _c281 is null or _c282 is null or _c283 is null or _c281 = "01" then "" else _c282 end as _c282,case when _c280 is null or _c281 is null or _c282 is null or _c283 is null or _c281 = "01" then "" else _c283 end as _c283,case when _c284 is null or _c285 is null or _c286 is null or _c287 is null or _c285 = "01" then "" else _c284 end as _c284,case when _c284 is null or _c285 is null or _c286 is null or _c287 is null or _c285 = "01" then "" else _c285 end as _c285,case when _c284 is null or _c285 is null or _c286 is null or _c287 is null or _c285 = "01" then "" else _c286 end as _c286,case when _c284 is null or _c285 is null or _c286 is null or _c287 is null or _c285 = "01" then "" else _c287 end as _c287,case when _c288 is null or _c289 is null or _c290 is null or _c291 is null or _c289 = "01" then "" else _c288 end as _c288,case when _c288 is null or _c289 is null or _c290 is null or _c291 is null or _c289 = "01" then "" else _c289 end as _c289,case when _c288 is null or _c289 is null or _c290 is null or _c291 is null or _c289 = "01" then "" else _c290 end as _c290,case when _c288 is null or _c289 is null or _c290 is null or _c291 is null or _c289 = "01" then "" else _c291 end as _c291,case when _c292 is null or _c293 is null or _c294 is null or _c295 is null or _c293 = "01" then "" else _c292 end as _c292,case when _c292 is null or _c293 is null or _c294 is null or _c295 is null or _c293 = "01" then "" else _c293 end as _c293,case when _c292 is null or _c293 is null or _c294 is null or _c295 is null or _c293 = "01" then "" else _c294 end as _c294,case when _c292 is null or _c293 is null or _c294 is null or _c295 is null or _c293 = "01" then "" else _c295 end as _c295,case when _c296 is null or _c297 is null or _c298 is null or _c299 is null or _c297 = "01" then "" else _c296 end as _c296,case when _c296 is null or _c297 is null or _c298 is null or _c299 is null or _c297 = "01" then "" else _c297 end as _c297,case when _c296 is null or _c297 is null or _c298 is null or _c299 is null or _c297 = "01" then "" else _c298 end as _c298,case when _c296 is null or _c297 is null or _c298 is null or _c299 is null or _c297 = "01" then "" else _c299 end as _c299,case when _c300 is null or _c301 is null or _c302 is null or _c304 is null or _c301 = "01" then "" else _c300 end as _c300,case when _c300 is null or _c301 is null or _c302 is null or _c304 is null or _c301 = "01" then "" else _c301 end as _c301,case when _c300 is null or _c301 is null or _c302 is null or _c304 is null or _c301 = "01" then "" else _c302 end as _c302,_c303,case when _c300 is null or _c301 is null or _c302 is null or _c304 is null or _c301 = "01" then "" else _c304 end as _c304,_c305,_c306,_c307,_c308,_c309,_c310,_c311,_c312,_c313,_c314,case when _c315 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c315="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c315 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c315 end as _c315,case when _c316 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c316="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c316 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c316 end as _c316,case when _c317 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c317="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c317 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c317 end as _c317,case when _c318 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c318="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c318 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c318 end as _c318,case when _c319 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c319="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c319 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c319 end as _c319,case when _c320 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c320="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c320 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c320 end as _c320,case when _c321 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c321="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c321 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c321 end as _c321,case when _c322 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c322="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c322 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c322 end as _c322,case when _c323 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c323="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c323 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c323 end as _c323,case when _c324 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c324="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c324 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c324 end as _c324,case when _c325 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c325="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c325 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c325 end as _c325,case when _c326 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c326="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c326 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c326 end as _c326,case when _c327 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c327="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c327 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c327 end as _c327,case when _c328 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c328="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c328 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c328 end as _c328,case when _c329 ="193400000X MULTIPLE SINGLE SPECIALTY GROUP" or _c329="193400000X SINGLE SPECIALTY GROUP" then "193400000X" when _c329 = "193200000X MULTI-SPECIALTY GROUP" then "193200000X" else _c329 end as _c329, filename  from input_table """
      val finalDF = spark.sql(query2)
      log.info("After query Execution")

      val currentTimestamp = Utils.getCurrentTimestamp()

      //Creating DataFrame for pushing to Kafka
      val tempDF = finalDF.na.fill("")
      val completeDF = tempDF.select(concat_ws("|", tempDF.columns.filter(_!="filename").map(c => col(c)): _*).as("payload"),col("filename"))
        .withColumn("uuid", generateUUID(lit(SOURCE_TYPE)))
        .withColumn("interfacename", lit(INTERFACE_TYPE))
        .withColumn("createTimestamp",lit(currentTimestamp))
        .withColumn("updateTimestamp",lit(currentTimestamp))

     val data1= completeDF.select(col("uuid").as(uuid)
       , col("filename").as(fileName)
       , col("interfacename").as(interface)
       , col("payload").as(payload)
       , col("createTimestamp")
       , col("updateTimestamp"))

      data1.persist()

      val data2 = data1.map {
        case Row(uuid: String, fileName: String ,interface:String, payload:String, createTimestamp:String, updateTimestamp:String) => DebatchMessage(uuid,fileName,interface,payload,createTimestamp,updateTimestamp,MetaData(null,null,null))
      }.as[DebatchMessage].toJSON

      /**
        * Pushing Messages to Kafka
        */
      try {
        Logger.log.info("***** sending Streaming  message to kafka *****")
        if(securityEnabled.equalsIgnoreCase("true")) {

          Utils.writeToSecureTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER, trustStorePath, trustStorePwd, scrWriteUser, scrWritePwd, scrReadUser, scrReadPwd, algorithm,requestTimeOut,retries,requestSize)
        }else {
          Utils.writeToTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER,requestTimeOut,retries,requestSize)

        }

        Logger.log.info("***** sending Streaming  message  to kafka  completed *****")
      } catch {
        case e: Exception => Logger.log.error("Exception while sending Streaming  message  to kafka " + e.getMessage)
          Logger.log.error(e.printStackTrace())
      }


      /**
        * Elastic Search Summary Indexing
        */
      Utils.writeSummaryToES(data1,INTERFACE_TYPE,ES_INDEX)


      val OutputEndTimeMillis = System.currentTimeMillis()
      val OutputDurationMinutes = OutputEndTimeMillis.-(startTime)./(60000)
      val OutputDurationSeconds = OutputEndTimeMillis.-(startTime)./(1000).%(60)
      Logger.log.info(s"Job Execution Time : $OutputDurationMinutes minutes and $OutputDurationSeconds Seconds")
      Logger.log.info("   ************* END OF NPI-STREAMER JOB ***************\n")


      data1.unpersist()
      propStream.close()
      spark.stop()
    } catch {
      case e: Exception => {
        log.error("Npi Streamer process failed: " + e.getMessage)
        log.error(e.printStackTrace())
        System.exit(1)
      }
    }
  }
}
