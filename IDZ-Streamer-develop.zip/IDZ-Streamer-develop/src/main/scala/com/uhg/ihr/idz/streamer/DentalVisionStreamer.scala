package com.uhg.ihr.idz.streamer

import java.io.FileInputStream
import java.util.Properties
import com.uhg.ihr.idz.common.Logger
import com.uhg.ihr.idz.utils.Utils
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.elasticsearch.spark.sql._
import com.uhg.ihr.idz.utils.Utils.{DebatchMessage, MetaData}
import org.apache.spark.SparkConf
import org.apache.spark.sql.Row


object DentalVisionStreamer {


  def main(args: Array[String]): Unit = {

    if (args.length != 2) {
      Logger.log.info(s"Please Pass the valid input parameter \nInputFilePath  \n PropertiesFile ")
      System.exit(1)
    }


    //Arguments
    val inputFilePath = args(0)
    val propertiesFile = args(1)


    Logger.log.info("InputFile Path: => " + inputFilePath)
    Logger.log.info("propertiesFile: => " + propertiesFile)

    Logger.log.info("Reading the properties File")

    val prop = new Properties()
    var path: FileInputStream = null

    try {
      path = new FileInputStream(propertiesFile)
      val startTime = System.currentTimeMillis()
      prop.load(path)

      /**
        * register an UDF that creates a random ID LBS_<timestamp>_<uuid>
        */
      val generateUUID = udf { (srcType: String) => Utils.generateUUID(srcType) }

      /** *
        * udf for trailer transformation
        */

      val replace = udf((data: String, rep: String) => data.replaceFirst(rep, "1"))


      Logger.log.info("Reading the properties File completed")

      val AppName = prop.getProperty("source_type")
      Logger.log.info("source_type =>" + AppName)

      val UUID = prop.getProperty("messageUUID")
      Logger.log.info("uuid =>" + UUID)

      val fileName = prop.getProperty("sourceName")
      Logger.log.info("fileName =>" + fileName)

      val Payload = prop.getProperty("payload")
      Logger.log.info("Payload =>" + Payload)

      val interfaceName = prop.getProperty("interface")
      Logger.log.info("interfaceType =>" + interfaceName)

      val interfaceType = prop.getProperty("interface_type")
      Logger.log.info("interfaceType =>" + interfaceType)

      val topic = prop.getProperty("kafka_topic")
      Logger.log.info("topic Name =>" + topic)

      val server = prop.getProperty("kafka_server")
      Logger.log.info("kafka.bootstrap.servers =>" + server)

      val trustStorePath = prop.getProperty("trust_store_path")
      Logger.log.info("kafka trust store path  =>" + trustStorePath)

      val trustStorePwd = prop.getProperty("trust_store_pwd")

      val scrWriteUser = prop.getProperty("scram_write_user")
      Logger.log.info("kafka scr write user   =>" + server)

      val scrWritePwd = prop.getProperty("scram_write_pwd")

      val scrReadUser = prop.getProperty("scram_read_user")
      Logger.log.info("kafka scr write user   =>" + server)

      val scrReadPwd = prop.getProperty("scram_read_pwd")

      val algorithm = prop.getProperty("algorithm")

      val securityEnabled = prop.getProperty("securityEnabled")
      Logger.log.info("kafka Security Enabled: =>" + securityEnabled)

      val retries = prop.getProperty("retries")
      Logger.log.info("Number of retries: =>" + retries)

      val requestTimeOut = prop.getProperty("requestTimeOut")
      Logger.log.info("Request Timeout is: =>" + requestTimeOut)

      val requestSize = prop.getProperty("requestSize")
      Logger.log.info("Request Size is  =>" + requestSize)

      val es_Nodes = prop.getProperty("es_Nodes")
      Logger.log.info("kafka.bootstrap.nodes =>" + es_Nodes)

      val es_Port = prop.getProperty("es_Port")
      Logger.log.info("kafka.bootstrap.port =>" + es_Port)

      val es_Index = prop.getProperty("es_Index")
      Logger.log.info("kafka.bootstrap.index =>" + es_Index)

      val es_user = prop.getProperty("es_user")
      Logger.log.info("kafka.bootstrap.user =>" + es_user)

      val es_pwd = prop.getProperty("es_pwd")


      val KAFKA_SERVER = prop.getProperty("kafka_server")
      val KAFKA_TOPIC = prop.getProperty("kafka_topic")
      val recordDelimiter = prop.getProperty("recordDelimiter")


      val (uuid, filename, interface, payload) = (prop.getProperty("messageUUID"), prop.getProperty("sourceName"), prop.getProperty("interface"), prop.getProperty("payload"))

      val currentTimestamp = Utils.getCurrentTimestamp()

      val conf = new SparkConf().setAppName("DentalVisionStreamer")
      conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      conf.set("spark.driver.cores", prop.getProperty("driver_cores"))
      conf.set("spark.executor.instances", prop.getProperty("executor_instances"))
      conf.set("spark.executor.memory", prop.getProperty("executor_memory"))
      conf.set("spark.driver.memory", prop.getProperty("driver_memory"))
      conf.set("spark.executor.cores", prop.getProperty("executor_cores"))
      conf.set("spark.default.parallelism", prop.getProperty("default_parallelism"))
      conf.set("spark.sql.shuffle.partitions", prop.getProperty("sql_shuffle_partitions"))
      conf.set("spark.yarn.executor.memoryoverhead", prop.getProperty("yarn_executor_memoryoverhead"))
      conf.set("spark.driver.maxResultSize", prop.getProperty("driver_maxResultSize"))
      conf.set("spark.memory.fraction", prop.getProperty("memory_fraction"))
      conf.set("spark.debug.maxToStringFields", prop.getProperty("maxToStringFields"))
      conf.set("spark.es.nodes", es_Nodes)
      conf.set("spark.es.port", es_Port)
      conf.set("spark.es.net.http.auth.user", es_user)
      conf.set("spark.es.net.http.auth.pass", es_pwd)
      conf.set("spark.es.nodes.wan.only", "true")
      conf.set("spark.es.mapping.id", fileName)
      conf.set("spark.es.write.operation", "upsert")
      conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")


      val spark = SparkSession.builder().config(conf).getOrCreate()

      val sc = spark.sparkContext
      import spark.implicits._

      /**
        * Exit if the input Directory is Empty.
        */
      if(Utils.getFilePaths(inputFilePath,sc).length == 0){
        Logger.log.info(s"Source ${inputFilePath} is Empty or doesn't exist.")
        Logger.log.error("==> ==> ==>  Exiting the Job  <== <== <==")
        System.exit(1)
      }

      System.out.println("Job started")


      // Setting the delimiter
      sc.hadoopConfiguration.set("textinputformat.record.delimiter", recordDelimiter)

      // Reading payload and Filename
      val debatchDf = sc.textFile(inputFilePath).toDF("payload").withColumn("payload", regexp_replace($"payload", "[\\r\\n]", "")).withColumn("filename", input_file_name())

      val updatedDebatchDf = debatchDf.withColumn("payload", split($"payload", "~GE*")(0)).withColumn("payload",concat($"payload",lit("~"))).withColumn("payload",regexp_replace($"payload","~~","~")).withColumn("payload", concat(lit("ST*837"), $"payload")).filter(col("payload").startsWith("""ST*837*"""))

      val headerRecord = debatchDf.filter(col("payload").startsWith("""ISA*""")).withColumnRenamed("payload", "header").withColumnRenamed("filename", "header_filename")
      headerRecord.persist()

      val join1 = updatedDebatchDf.join(headerRecord, debatchDf("filename") === headerRecord("header_filename")).withColumn("updated_payload", concat($"header", $"payload")).select("updated_payload", "filename")

      val trailerRecord = debatchDf.filter(col("payload").contains("~GE*")).withColumnRenamed("payload", "trailer").withColumnRenamed("filename", "trailer_filename")
      trailerRecord.persist()
      trailerRecord.createOrReplaceTempView("tail_record")

      val trailerPart = spark.sql("""select trailer_filename,case when (INSTR(trailer,'~GE*') != 0) then substr(trailer,INSTR(trailer,'~GE*')+1) else "" end as trailer,case when (INSTR(trailer,'~GE*') != 0) then substr(SUBSTRING_INDEX(substr(trailer,INSTR(trailer,'~GE*')),"*", 2),5) else "" end as records from tail_record""")

      val trailer = trailerPart.select("trailer", "records", "trailer_filename").withColumn("updated_trailer", replace($"trailer", $"records"))

      val join2 = join1.join(trailer, updatedDebatchDf("filename") === trailer("trailer_filename")).withColumn("new_updated_payload", concat($"updated_payload", $"updated_trailer")).select("new_updated_payload", "filename")

      val data = join2.withColumnRenamed("new_updated_payload", "payload").withColumn("fileName", $"filename").withColumn("uuid", generateUUID(lit(AppName)))
        .withColumn("interfaceType", lit(interfaceType))
        .withColumn("createTimestamp", lit(currentTimestamp))
        .withColumn("updateTimestamp", lit(currentTimestamp))

      val data1 = data.select($"uuid", $"filename", $"interfaceType", $"payload", $"createTimestamp", $"updateTimestamp")

      data1.persist()

      val data2 = data1.map {
        case Row(uuid: String, fileName: String, interface: String, payload: String, createTimestamp: String, updateTimestamp: String) => DebatchMessage(uuid, fileName, interface, payload, createTimestamp, updateTimestamp, MetaData(null, null, null))
      }.as[DebatchMessage].toJSON


      /**
        * Pushing Messages to Kafka
        */
      try {
        Logger.log.info("============>  sending Streaming  message to kafka <============")

        if (securityEnabled.equalsIgnoreCase("true")) {
          Utils.writeToSecureTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER, trustStorePath, trustStorePwd, scrWriteUser, scrWritePwd, scrReadUser, scrReadPwd, algorithm, requestTimeOut, retries, requestSize)
        } else {
          Utils.writeToTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER, requestTimeOut, retries, requestSize)
        }
        Logger.log.info("============> sending Streaming  message to kafka completed <============")
      } catch {
        case e: Exception => Logger.log.error("Exception while sending Streaming  message  to kafka " + e.getMessage)
          throw new RuntimeException("Failed to push records to Kafka. Please check if the provided Cluster details are accurate.")
      }


      /**
        * Elastic Search Summary Indexing
        */
      Utils.writeSummaryToES(data1,interfaceType,es_Index)


      val OutputEndTimeMillis = System.currentTimeMillis()
      val OutputDurationMinutes = OutputEndTimeMillis.-(startTime)./(60000)
      val OutputDurationSeconds = OutputEndTimeMillis.-(startTime)./(1000).%(60)
      Logger.log.info(s"Job Execution Time : $OutputDurationMinutes minutes and $OutputDurationSeconds Seconds")
        Logger.log.info("   ************* End of DentalVision Streamer job ***************\n")
      headerRecord.unpersist()
      trailerRecord.unpersist()
      data1.unpersist()
      sc.stop()
      spark.stop()

    } catch {
      case e: Exception => Logger.log.error("Exception at Main DentalVision Streamer " + e.getMessage)
        Logger.log.info(s"exception in main +" + e.printStackTrace())
        throw e
    } finally {
      path.close
    }
  }//main
}

