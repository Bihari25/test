package com.uhg.ihr.idz.utils

import java.time.Instant
import java.util.UUID.randomUUID
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.uhg.ihr.idz.common.Logger
import org.apache.spark.sql.functions.{current_timestamp, date_format, lit}
import org.apache.spark.{SparkContext, sql}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.elasticsearch.spark.sql._

import scala.util.Try
import org.json.JSONObject

object Utils {

  /**
    * Write the contents of a DataSet[String] to a secure topic(stage/prod)
    * @param spark          => an initialized SparkSession instance
    * @param df             => a DataSet[String] containing the messages
    * @param topic          => the topic path to write to
    * @param kafkaServer    => the kafka bootstrap server to connect to
    * @param trustStorePath => trust store path
    * @param trustStorePwd  => trust store password
    * @param scrWriteUser   => scram write user
    * @param scrWritePwd    => scram write pwd
    * @param scrReadUser    => scram Read User
    * @param scrReadPwd     => scram read pwd
    * @param algorithm      => algorithm
    * @param requestTimeOut =>
    * @param retries        =>
    * @param requestSize    =>
    */
  def writeToSecureTopic(spark: SparkSession, df: Dataset[String], topic: String, kafkaServer: String, trustStorePath: String, trustStorePwd: String, scrWriteUser: String, scrWritePwd: String, scrReadUser: String, scrReadPwd: String, algorithm: String, requestTimeOut :String, retries :String, requestSize :String ): Unit = {
    import spark.implicits._

    val jaasTemplate = "org.apache.kafka.common.security.scram.ScramLoginModule required username=\"%s\" password=\"%s\";"
    val readConfig = String.format(jaasTemplate, scrReadUser, scrReadPwd)
    val writeConfig = String.format(jaasTemplate, scrWriteUser, scrWritePwd)

    df
      .map { row =>
        val attempt = Try(new JSONObject(row).toString())
        if (attempt.isFailure) {
          println(s"Failed to parse message: $row")
          ""
        } else {
          attempt.get
        }
      }
      .filter(s => s.nonEmpty)
      .write
      .format("kafka")
      .option("kafka.bootstrap.servers", kafkaServer)
      .option("topic", topic)
      .option("kafka.request.timeout.ms",requestTimeOut)
      .option("Kafka.retries",retries)
      .option("kafka.max.request.size",requestSize)
      .option("ssl.enabled",true)
      .option("kafka.ssl.truststore.location",trustStorePath)
      .option("kafka.ssl.truststore.password",trustStorePwd)
      .option("kafka.ssl.endpoint.identification.algorithm",algorithm)
      .option("ssl.allow.everyone.if.no.acl.found",false)
      .option("kafka.security.protocol","SASL_SSL")
      .option("ssl.truststore.type", "jks")
      .option("kafka.sasl.mechanism", "SCRAM-SHA-256")
      .option("kafka.sasl.jaas.config", readConfig)
      .option("kafka.sasl.jaas.config", writeConfig)
      .save()
  }

  /**
    *  Write the contents of a DataSet[String] to a secure topic(stage/prod)
    *
    * @param spark          => an initialized SparkSession instance
    * @param df             => a DataSet[Sting] containing the JSON messages
    * @param topic          => the topic path to write to
    * @param kafkaServer    => the kafka bootstrap server to connect to
    * @param requestTimeOut =>
    * @param retries        =>
    * @param requestSize    =>
    */
  def writeToTopic(spark: SparkSession, df: Dataset[String], topic: String, kafkaServer: String ,requestTimeOut :String,retries :String ,requestSize :String): Unit = {
    import spark.implicits._

    df.rdd
      .map { row =>
        val attempt = Try(new JSONObject(row).toString)
        if (attempt.isFailure) {
          println(s"Failed to parse message: $row")
          ""
        } else {
          attempt.get
        }
      }
      .filter(s => s.nonEmpty)
      .toDS()
      .write
      .format("kafka")
      .option("kafka.bootstrap.servers", kafkaServer)
      .option("kafka.request.timeout.ms",requestTimeOut)
      .option("Kafka.retries",retries)
      .option("kafka.max.request.size",requestSize)
      .option("topic", topic)
      .save()
  }


  /**
    * Creates a Unique random Id of form "MED_<timestamp>_<uuid>" by pre-pending the passed file type
    *
    * @param sourceType
    * @return
    */
  def generateUUID(sourceType: String): String = {
    val timeStamp = Instant.now.getEpochSecond.toString
    val randomId = randomUUID().toString.replaceAll("-", "_")
    val uuid: String = sourceType + "_" + timeStamp + "_" + randomId
    uuid
  }

  /**
    * Returns the current Timestamp
    * @return
    */
  def getCurrentTimestamp(): String = {
    return LocalDateTime.now.format(DateTimeFormatter.ofPattern("YYYY-MM-dd HH:mm:ss"))
  }

  /**
    * Helper Class to convert empty Strings to Null
    * @param str
    * @return
    */
  def isEmptyThenNull(str:String): String ={
    if(str.isEmpty) null
    else str.trim
  }


  /**
    * Returns the file paths in a directory
    * @param inputPath
    * @param sc
    * @return
    */
   def getFilePaths(inputPath:String, sc:SparkContext):List[org.apache.hadoop.fs.Path]={
    import org.apache.hadoop.fs.Path
    val fs = org.apache.hadoop.fs.FileSystem.get(sc.hadoopConfiguration)
    fs.listStatus(new Path(inputPath)).filter(_.isFile).map(_.getPath).toList
  }


  def writeToSecureTopicWithKey(spark: SparkSession, df:sql.DataFrame, topic: String, kafkaServer: String, trustStorePath: String, trustStorePwd: String, scrWriteUser: String, scrWritePwd: String, scrReadUser: String, scrReadPwd: String, algorithm: String, requestTimeOut :String, retries :String, requestSize :String ): Unit = {
    import spark.implicits._

    val jaasTemplate = "org.apache.kafka.common.security.scram.ScramLoginModule required username=\"%s\" password=\"%s\";"
    val readConfig = String.format(jaasTemplate, scrReadUser, scrReadPwd)
    val writeConfig = String.format(jaasTemplate, scrWriteUser, scrWritePwd)

    df.write
      .format("kafka")
      .option("kafka.bootstrap.servers", kafkaServer)
      .option("topic", topic)
      .option("kafka.request.timeout.ms",requestTimeOut)
      .option("Kafka.retries",retries)
      .option("kafka.max.request.size",requestSize)
      .option("ssl.enabled",true)
      .option("kafka.ssl.truststore.location",trustStorePath)
      .option("kafka.ssl.truststore.password",trustStorePwd)
      .option("kafka.ssl.endpoint.identification.algorithm",algorithm)
      .option("ssl.allow.everyone.if.no.acl.found",false)
      .option("kafka.security.protocol","SASL_SSL")
      .option("ssl.truststore.type", "jks")
      .option("kafka.sasl.mechanism", "SCRAM-SHA-256")
      .option("kafka.sasl.jaas.config", readConfig)
      .option("kafka.sasl.jaas.config", writeConfig)
      .save()
  }

  def writeToTopicWithKey(spark: SparkSession, df:sql.DataFrame, topic: String, kafkaServer: String ,requestTimeOut :String,retries :String ,requestSize :String): Unit = {
    import spark.implicits._

    df
      .write
      .format("kafka")
      .option("kafka.bootstrap.servers", kafkaServer)
      .option("kafka.request.timeout.ms",requestTimeOut)
      .option("Kafka.retries",retries)
      .option("kafka.max.request.size",requestSize)
      .option("topic", topic)
      .save()
  }


  /**
    * Method to push Summary Statistics to ES
    * @param df
    * @param interface
    * @param esIndex
    */
  def writeSummaryToES(df:DataFrame, interface: String, esIndex:String): Unit ={
    val dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
    val filename_count = df.groupBy("fileName").count.withColumnRenamed("count", "noOfRecords")
    val indexedSeq = filename_count.withColumn("timestamp", date_format(current_timestamp, dateFormat)).
      withColumn("interfaceType", lit(interface)).toDF
    try {
      Logger.log.info(s"Writing summary Index to ES starting...")
      indexedSeq.saveToEs(esIndex)
      Logger.log.info(s"Writing summary Index to ES completed.")
    }
    catch {
      case e: Exception => Logger.log.error(s"Exception while pushing to ElasticSearch " + e.getMessage)
        Logger.log.info(e.printStackTrace())
        throw new RuntimeException("Failed to push summary records to Elastic Search. Please check if the provided ES details are accurate and is up and running.")
    }

  }

  case class DebatchMessage(uuid: String, fileName: String, interfaceType: String, payload:String , createTimestamp:String, updateTimestamp:String , metadata: MetaData = null)
  case class MetaData(subscriberId: String,icn:String, mpin: String)

}

