package com.uhg.ihr.idz.streamer

import java.io.{File, FileInputStream}
import java.util.Properties

import com.uhg.ihr.idz.common.CustomFunctions.parseLinePerFixedLengths
import com.uhg.ihr.idz.common.Logger
import com.uhg.ihr.idz.streamer.memberStreamer.ES_INDEX
import com.uhg.ihr.idz.utils.Utils
import com.uhg.ihr.idz.utils.Utils.{DebatchMessage, MetaData}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.elasticsearch.spark.sql._

object ncpdpStreamer {
  var PROPS: Properties = _
  var INPUT_DIR_PATH: String = _
  var INPUT_PROPERTIES_FILE: String = _
  var KAFKA_TOPIC: String = _
  var SOURCE_TYPE: String = _
  var KAFKA_SERVER: String = _
  var INPUT_SRC_DIR: String = _
  var INTERFACE_TYPE: String = _
  var trustStorePath: String = _
  var trustStorePwd: String = _
  var scrWriteUser: String = _
  var scrWritePwd: String = _
  var scrReadUser: String = _
  var scrReadPwd: String = _
  var algorithm: String = _
  var securityEnabled: String = _
  var requestTimeOut:String = _
  var retries:String = _
  var requestSize:String = _




  def main(args: Array[String]): Unit = {

    if (args.length != 2) {
      Logger.log.error(s"Please Pass the valid input parameter \nInputFilePath  \n PropertiesFile ")
      System.exit(1)
    }
    //Input parameters required when running spark submit command
    INPUT_DIR_PATH = args(0)
    INPUT_SRC_DIR = args(1)
    INPUT_PROPERTIES_FILE = args(1)

    Logger.log.info("InputFile Path: => " + INPUT_DIR_PATH)
   Logger.log.info("Input Source Path : => " + INPUT_SRC_DIR)
    Logger.log.info("PropertiesFile : => " + INPUT_PROPERTIES_FILE)
    try {
      //Reading Properties File
      PROPS = new Properties()
      val path = new FileInputStream( INPUT_PROPERTIES_FILE)
      PROPS.load(path)

      //Common properties
      KAFKA_TOPIC = PROPS.getProperty("kafka_topic") //Kafka topic to push data to
      SOURCE_TYPE = PROPS.getProperty("source_type")
      KAFKA_SERVER = PROPS.getProperty("kafka_server")
      INTERFACE_TYPE = PROPS.getProperty("interface_type")
      trustStorePath = PROPS.getProperty("trust_store_path")
      trustStorePwd = PROPS.getProperty("trust_store_pwd")
      scrWriteUser = PROPS.getProperty("scram_write_user")
      scrWritePwd = PROPS.getProperty("scram_write_pwd")
      scrReadUser = PROPS.getProperty("scram_read_user")
      scrReadPwd = PROPS.getProperty("scram_read_pwd")
      algorithm = PROPS.getProperty("algorithm")
      securityEnabled = PROPS.getProperty("securityEnabled")
      retries = PROPS.getProperty("retries")
      requestTimeOut = PROPS.getProperty("requestTimeOut")
      requestSize = PROPS.getProperty("requestSize")


      Logger.log.info("Kafka Topic : => " + KAFKA_TOPIC)
      Logger.log.info("Kafka Server : => " + KAFKA_SERVER)
      Logger.log.info("Interface Name : => " + INTERFACE_TYPE)

      //ToDo: Need to remove /mapr Dependency for NCPDP
      //Get the list of Input files from given INPUT_DIR_PATH
      val FilePath = new File("/mapr" + INPUT_DIR_PATH)
      val ListOfFiles = FilePath.listFiles.map(x => x.getName).filter(x => x.startsWith("mas") && x.endsWith("txt")).toList

      Logger.log.info(s"Number of  file found in input path ==> ${ListOfFiles.size} FILES ")
      if (ListOfFiles.isEmpty) {
        Logger.log.info(s"No file found in input path ==>  ${FilePath}")
        System.exit(1)
      }

      //Export Columns
      val uuid = PROPS.getProperty("messageUUID")
      val filename = PROPS.getProperty("sourceName")
      val interface = PROPS.getProperty("interface")
      val payload = PROPS.getProperty("payload")



      //Elastic Search Configuration info
      val es_Nodes = PROPS.getProperty("es_Nodes")
      Logger.log.info("kafka.bootstrap.servers =>" + es_Nodes)

      val es_Port = PROPS.getProperty("es_Port")
      Logger.log.info("elastic search es_Port =>" + es_Port)

      val es_user = PROPS.getProperty("es_user")
      Logger.log.info("es user Name: => " + es_user)
      val es_pwd = PROPS.getProperty("es_pwd")
      val es_Index = PROPS.getProperty("es_Index")
      Logger.log.info("elastic search es_Index =>" + es_Index)


      //Initializing Spark Context
      val spark = SparkSession.builder()
        .appName("Provider-Streamer ")
        .config("spark.driver.cores", PROPS.getProperty("driver_cores"))
        .config("spark.executor.instances", PROPS.getProperty("executor_instances"))
        .config("spark.executor.memory", PROPS.getProperty("executor_memory"))
        .config("spark.driver.memory", PROPS.getProperty("driver_memory"))
        .config("spark.executor.cores", PROPS.getProperty("executor_cores"))
        .config("spark.default.parallelism", PROPS.getProperty("default_parallelism"))
        .config("spark.sql.shuffle.partitions", PROPS.getProperty("sql_shuffle_partitions"))
        .config("spark.yarn.executor.memoryoverhead", PROPS.getProperty("yarn_executor_memoryoverhead"))
        .config("spark.driver.maxResultSize", PROPS.getProperty("driver_maxResultSize"))
        .config("spark.memory.fraction", PROPS.getProperty("memory_fraction"))
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")

        .config("spark.es.nodes", es_Nodes)
        .config("spark.es.port", es_Port)
        .config("spark.es.net.http.auth.user", es_user)
        .config("spark.es.net.http.auth.pass", es_pwd)
        .config("spark.es.nodes.wan.only", "true")
        .config("spark.es.mapping.id", filename)
        .config("spark.es.write.operation", "upsert")
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .getOrCreate()

      import spark.implicits._
      val sc = spark.sparkContext
      val sqlContext = spark.sqlContext

      /**
        * register an UDF that creates a random ID NCPDP_<timestamp>_<uuid>
        */
      val generateUUID = udf { (srcType: String) => Utils.generateUUID(srcType) }

      //Capturing Start Time in Milliseconds
      val processStartTimeMillis = System.currentTimeMillis()

      // Reading Input file(mas_af)

      val mas_af_file = sc.textFile(INPUT_DIR_PATH + "/mas_af.txt")

      //Assigning the lengths to the schema defined below
      val mas_af_lengths = Seq(3, 2, 35, 55, 55, 30, 2, 9, 10, 5, 10, 10, 15, 30, 30, 50, 30, 30, 50, 30, 30, 50, 30, 30, 50, 30, 30, 50, 6, 8, 8)

      // calls the split function and creates a DataFrame
      val mas_af_SplitData = mas_af_file.map(parseLinePerFixedLengths(_, mas_af_lengths)).toDF.withColumnRenamed("value", "fields")

      //Defining the schema for mas_af File
      val mas_af = StructType(Array(
        StructField("relationship_id", StringType, true),
        StructField("relationship_type", StringType, true),
        StructField("name", StringType, true),
        StructField("address1", StringType, true),
        StructField("address2", StringType, true),
        StructField("city", StringType, true),
        StructField("state", StringType, true),
        StructField("zip_code", StringType, true),
        StructField("phone_number", StringType, true),
        StructField("extension", StringType, true),
        StructField("fax_number", StringType, true),
        StructField("relationship_npi", StringType, true),
        StructField("relationship_fed_tax_id", StringType, true),
        StructField("contact_name", StringType, true),
        StructField("contact_title", StringType, true),
        StructField("email", StringType, true),
        StructField("Contractual_Contact_Name", StringType, true),
        StructField("Contractual_Contact_Title", StringType, true),
        StructField("Contractual_Contact_Email", StringType, true),
        StructField("Operational_Contact_Name", StringType, true),
        StructField("Operational_Contact_Title", StringType, true),
        StructField("Operational_Contact_Email", StringType, true),
        StructField("Technical_Contact_Name", StringType, true),
        StructField("Technical_Contact_Title", StringType, true),
        StructField("Technical_Contact_Email", StringType, true),
        StructField("Audit_Contact_Name", StringType, true),
        StructField("Audit_Contact_Title", StringType, true),
        StructField("Audit_Contact_Email", StringType, true),
        StructField("parent_organization_id", StringType, true),
        StructField("Effection_from_date", StringType, true),
        StructField("delete_date", StringType, true)))

      //Assigning the schema to the SplitData
      val mas_af_answer = mas_af_lengths.indices.foldLeft(mas_af_SplitData) {
        case (result, idx) =>
          result.toDF.withColumn(s"col_$idx", $"fields".getItem(idx))
      }
      //creates a temporary table
      spark.createDataFrame(mas_af_answer.drop("fields").rdd, mas_af).createOrReplaceTempView("mas_af_table")

      // Reading Input file(mas_af)
      val mas_coo_file = sc.textFile(INPUT_DIR_PATH + "/mas_coo.txt")

      //Assigning the lengths of each column of the file
      val mas_coo_lengths = Seq(7, 7, 8, 8)
      // calls the split function and creates a DataFrame
      val mas_coo_SplitData = mas_coo_file.map(parseLinePerFixedLengths(_, mas_coo_lengths)).toDF.withColumnRenamed("value", "fields")
      // Defining the schema for mas_coo file
      val mas_coo = StructType(Array(
        StructField("ncpdp_id", StringType, true),
        StructField("old_ncpdp_provider_id", StringType, true),
        StructField("old_store_close_date", StringType, true),
        StructField("change_of_ownership_effective_date", StringType, true)))
      //Assigning the schema to the SplitData
      val mas_coo_answer = mas_coo_lengths.indices.foldLeft(mas_coo_SplitData) {
        case (result, idx) =>
          result.toDF.withColumn(s"col_$idx", $"fields".getItem(idx))
      }
      //creates a temporary table for mas_coo file
      spark.createDataFrame(mas_coo_answer.drop("fields").rdd, mas_coo).createOrReplaceTempView("mas_coo_table")

      // Reading Input file(mas_erx)
      val mas_erx_file = sc.textFile(INPUT_DIR_PATH + "/mas_erx.txt")

      //Assigning the lengths of each column of the file(mas_erx)
      val mas_erx_lengths = Seq(7, 3, 100, 8, 8)

      // calls the split function and creates a DataFrame
      val mas_erx_SplitData = mas_erx_file.map(parseLinePerFixedLengths(_, mas_erx_lengths)).toDF.withColumnRenamed("value", "fields")

      //Defining the schema for mas_erx File
      val mas_erx = StructType(Array(
        StructField("ncpdp_id", StringType, true),
        StructField("eprescribing_network_identifier", StringType, true),
        StructField("eprescribing_service_level_codes", StringType, true),
        StructField("effective_from_date", StringType, true),
        StructField("effective_through_date", StringType, true)))

      //Assigning the schema to the SplitData
      val mas_erx_answer = mas_erx_lengths.indices.foldLeft(mas_erx_SplitData) {
        case (result, idx) =>
          result.toDF.withColumn(s"col_$idx", $"fields".getItem(idx))
      }

      //creates a temporary table for mas_erx file
      spark.createDataFrame(mas_erx_answer.drop("fields").rdd, mas_erx).createOrReplaceTempView("mas_erx_table")

      // Reading Input file(mas_md)
      val mas_md_file = sc.textFile(INPUT_DIR_PATH + "/mas_md.txt")

      //Assigning the lengths of each column of the file(mas_md)
      val mas_md_lengths = Seq(7, 2, 20, 8)

      // calls the split function and creates a DataFrame
      val mas_md_SplitData = mas_md_file.map(parseLinePerFixedLengths(_, mas_md_lengths)).toDF.withColumnRenamed("value", "fields")

      //Defining the schema for mas_md File
      val mas_md = StructType(Array(
        StructField("ncpdp_id", StringType, true),
        StructField("state_code", StringType, true),
        StructField("medicaid_id", StringType, true),
        StructField("delete_date", StringType, true)))

      //Assigning the schema to the SplitData
      val mas_md_answer = mas_md_lengths.indices.foldLeft(mas_md_SplitData) {
        case (result, idx) =>
          result.toDF.withColumn(s"col_$idx", $"fields".getItem(idx))
      }

      //creates temporary table for mas_md file
      spark.createDataFrame(mas_md_answer.drop("fields").rdd, mas_md).createOrReplaceTempView("mas_md_table")

      // Reading Input file(mas_pr)
      val mas_pr_file = sc.textFile(INPUT_DIR_PATH + "/mas_pr.txt")

      //Assigning the lengths of each column of the file(mas_pr)
      val mas_pr_lengths = Seq(6, 35, 55, 55, 30, 2, 9, 10, 5, 10, 10, 15, 30, 30, 50, 8)

      // calls the split function and creates a DataFrame
      val mas_pr_SplitData = mas_pr_file.map(parseLinePerFixedLengths(_, mas_pr_lengths)).toDF.withColumnRenamed("value", "fields")

      //Defining the schema for mas_pr File
      val mas_pr = StructType(Array(
        StructField("parent_organization_id", StringType, true),
        StructField("parent_organization_name", StringType, true),
        StructField("parent_organization_address_1", StringType, true),
        StructField("parent_organization_address_2", StringType, true),
        StructField("parent_organization_city", StringType, true),
        StructField("parent_organization_state_code", StringType, true),
        StructField("parent_organization_zip_code", StringType, true),
        StructField("parent_organization_phone_number", StringType, true),
        StructField("parent_organization_phone_extension", StringType, true),
        StructField("parent_organization_fax_number", StringType, true),
        StructField("parent_organization_npi", StringType, true),
        StructField("parent_organization_federal_tax_id", StringType, true),
        StructField("contact_name", StringType, true),
        StructField("contact_title", StringType, true),
        StructField("email", StringType, true),
        StructField("delete_date", StringType, true)))

      //Assigning the schema to the SplitData
      val mas_pr_answer = mas_pr_lengths.indices.foldLeft(mas_pr_SplitData) {
        case (result, idx) =>
          result.toDF.withColumn(s"col_$idx", $"fields".getItem(idx))
      }

      //creates temporary table for mas_pr file
      spark.createDataFrame(mas_pr_answer.drop("fields").rdd, mas_pr).createOrReplaceTempView("mas_pr_table")

      // Reading Input file(mas_rr)
      val mas_rr_file = sc.textFile(INPUT_DIR_PATH + "/mas_rr.txt")

      //Assigning the lengths of each column of the file(mas_rr)
      val mas_rr_lengths = Seq(7, 3, 6, 6, 2, 1, 8, 8)

      // calls the split function and creates a DataFrame
      val mas_rr_SplitData = mas_rr_file.map(parseLinePerFixedLengths(_, mas_rr_lengths)).toDF.withColumnRenamed("value", "fields")

      //Defining the schema for mas_rr File
      val mas_rr = StructType(Array(
        StructField("ncpdp_id", StringType, true),
        StructField("relationship_id", StringType, true),
        StructField("payment_center_id", StringType, true),
        StructField("remit_and_reconcilation_id", StringType, true),
        StructField("provider_type", StringType, true),
        StructField("is_primary", StringType, true),
        StructField("effective_from_date", StringType, true),
        StructField("effective_through_date", StringType, true)))

      //Assigning the schema to the SplitData
      val mas_rr_answer = mas_rr_lengths.indices.foldLeft(mas_rr_SplitData) {
        case (result, idx) =>
          result.toDF.withColumn(s"col_$idx", $"fields".getItem(idx))
      }

      //creates temporary table for mas_rr file
      spark.createDataFrame(mas_rr_answer.drop("fields").rdd, mas_rr).createOrReplaceTempView("mas_rr_table")

      // Reading Input file(mas_stl)
      val mas_stl_file = sc.textFile(INPUT_DIR_PATH + "/mas_stl.txt")

      //Assigning the lengths of each column of the file(mas_stl)
      val mas_stl_lengths = Seq(7, 2, 20, 8, 8)

      // calls the split function and creates a DataFrame
      val mas_stl_SplitData = mas_stl_file.map(parseLinePerFixedLengths(_, mas_stl_lengths)).toDF.withColumnRenamed("value", "fields")

      //Defining the schema for mas_stl File
      val mas_stl = StructType(Array(
        StructField("ncpdp_id", StringType, true),
        StructField("license_state_code", StringType, true),
        StructField("state_license_number", StringType, true),
        StructField("state_license_expiry_date", StringType, true),
        StructField("delete_date", StringType, true)))

      //Assigning the schema to the SplitData
      val mas_stl_answer = mas_stl_lengths.indices.foldLeft(mas_stl_SplitData) {
        case (result, idx) =>
          result.toDF.withColumn(s"col_$idx", $"fields".getItem(idx))
      }

      //creates temporary table for mas_stl file
      spark.createDataFrame(mas_stl_answer.drop("fields").rdd, mas_stl).createOrReplaceTempView("mas_stl_table")

      // Reading Input file(mas_svc)
      val mas_svc_file = sc.textFile(INPUT_DIR_PATH + "/mas_svc.txt")

      //Assigning the lengths of each column of the file(mas_svc)
      val mas_svc_lengths = Seq(7, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2)

      // calls the split function and creates a DataFrame
      val mas_svc_SplitData = mas_svc_file.map(parseLinePerFixedLengths(_, mas_svc_lengths)).toDF.withColumnRenamed("value", "fields")

      //Defining the schema for mas_svc File
      val mas_svc = StructType(Array(
        StructField("ncpdp_id", StringType, true),
        StructField("accepts_eprescriptions_indicator", StringType, true),
        StructField("accepts_eprescriptions_code", StringType, true),
        StructField("delivery_service_indicator", StringType, true),
        StructField("delivery_service_code", StringType, true),
        StructField("compounding_service_indicator", StringType, true),
        StructField("compounding_service_code", StringType, true),
        StructField("drive_up_window_indicator", StringType, true),
        StructField("drive_up_window_code", StringType, true),
        StructField("durable_medical_equipment_indicator", StringType, true),
        StructField("durable_medical_equipment_code", StringType, true),
        StructField("walk_in_clinic_indicator", StringType, true),
        StructField("walk_in_clinic_code", StringType, true),
        StructField("emergency_service_indicator_24_hour", StringType, true),
        StructField("emergency_service_code_24_hour", StringType, true),
        StructField("multi_dose_compliance_packaging_indicator", StringType, true),
        StructField("multi_dose_compliance_packaging_code", StringType, true),
        StructField("immunizations_provided_indicator", StringType, true),
        StructField("immunizations_provided_code", StringType, true),
        StructField("handicapped_accessible_indicator", StringType, true),
        StructField("handicapped_accessible_code", StringType, true),
        StructField("status_indicator_340b", StringType, true),
        StructField("status_code_340b", StringType, true),
        StructField("closed_door_facility_indicator", StringType, true),
        StructField("closed_door_facility_status_code", StringType, true)))

      //Assigning the schema to the SplitData
      val mas_svc_answer = mas_svc_lengths.indices.foldLeft(mas_svc_SplitData) {
        case (result, idx) =>
          result.toDF.withColumn(s"col_$idx", $"fields".getItem(idx))
      }

      //creates temporary table for mas_svc file
      spark.createDataFrame(mas_svc_answer.drop("fields").rdd, mas_svc).createOrReplaceTempView("mas_svc_table")

      // Reading Input file(mas_tx)
      val mas_tx_file = sc.textFile(INPUT_DIR_PATH + "/mas_tx.txt")

      //Assigning the lengths of each column of the file(mas_tx)
      val mas_tx_lengths = Seq(7, 10, 2, 8)

      // calls the split function and creates a DataFrame
      val mas_tx_SplitData = mas_tx_file.map(parseLinePerFixedLengths(_, mas_tx_lengths)).toDF.withColumnRenamed("value", "fields")

      //Defining the schema for mas_tx File
      val mas_tx = StructType(Array(
        StructField("ncpdp_id", StringType, true),
        StructField("taxonomy_code", StringType, true),
        StructField("provider_type_code", StringType, true),
        StructField("delete_date", StringType, true)))

      //Assigning the schema to the SplitData
      val mas_tx_answer = mas_tx_lengths.indices.foldLeft(mas_tx_SplitData) {
        case (result, idx) =>
          result.toDF.withColumn(s"col_$idx", $"fields".getItem(idx))
      }

      //creates temporary table for mas_tx file
      spark.createDataFrame(mas_tx_answer.drop("fields").rdd, mas_tx).createOrReplaceTempView("mas_tx_table")

      // Reading Input file(mas)
      val mas_file = sc.textFile(INPUT_DIR_PATH + "/mas.txt")

      //Assigning the lengths of each column of the file(mas)
      val mas_lengths = Seq(7, 60, 60, 60, 10, 55, 55, 30, 2, 9, 10, 5, 10, 50, 50, 5, 4, 4, 1, 35, 4, 2, 2, 2, 2, 2, 8, 8, 55, 55, 30, 2, 9, 20, 20, 1, 30, 10, 5, 50, 2, 2, 2, 2, 10, 10, 12, 8, 15, 15, 2, 2, 8)

      // calls the split function and creates a DataFrame
      val mas_SplitData = mas_file.map(parseLinePerFixedLengths(_, mas_lengths)).toDF.withColumnRenamed("value", "fields")

      //Defining the schema for mas File
      val mas = StructType(Array(
        StructField("ncpdp_id", StringType, true),
        StructField("legal_business_name", StringType, true),
        StructField("name_dba", StringType, true),
        StructField("doctor_name", StringType, true),
        StructField("store_number", StringType, true),
        StructField("physical_location_address_1", StringType, true),
        StructField("physical_location_address_2", StringType, true),
        StructField("physical_location_city", StringType, true),
        StructField("physical_location_state", StringType, true),
        StructField("physical_location_zip", StringType, true),
        StructField("physical_location_phone", StringType, true),
        StructField("physical_location_extention", StringType, true),
        StructField("physical_location_fax", StringType, true),
        StructField("physical_location_email", StringType, true),
        StructField("physical_location_cross_street_directions", StringType, true),
        StructField("physical_location_country", StringType, true),
        StructField("physical_location_MSA", StringType, true),
        StructField("physical_location_PMSA", StringType, true),
        StructField("hour_flag", StringType, true),
        StructField("physical_location_provider_hours", StringType, true),
        StructField("physical_location_voting_district", StringType, true),
        StructField("physical_location_language_code1", StringType, true),
        StructField("physical_location_language_code2", StringType, true),
        StructField("physical_location_language_code3", StringType, true),
        StructField("physical_location_language_code4", StringType, true),
        StructField("physical_location_language_code5", StringType, true),
        StructField("physical_location_store_open_date", StringType, true),
        StructField("physical_location_store_close_date", StringType, true),
        StructField("mailing_address1", StringType, true),
        StructField("mailing_address2", StringType, true),
        StructField("mailing_address_city", StringType, true),
        StructField("mailing_address_state_code", StringType, true),
        StructField("mailing_address_zip_code", StringType, true),
        StructField("last_name", StringType, true),
        StructField("first_name", StringType, true),
        StructField("middle_initial", StringType, true),
        StructField("title", StringType, true),
        StructField("phone_number", StringType, true),
        StructField("extension", StringType, true),
        StructField("email", StringType, true),
        StructField("dispenser_class_code", StringType, true),
        StructField("primary_provider_type_code", StringType, true),
        StructField("secondary_provider_type_code", StringType, true),
        StructField("tertiary_provider_type_code", StringType, true),
        StructField("medicare_provider_supplier_id", StringType, true),
        StructField("npi", StringType, true),
        StructField("dea_registration_id", StringType, true),
        StructField("dea_expiry_date", StringType, true),
        StructField("federal_tax_id", StringType, true),
        StructField("state_tax_id", StringType, true),
        StructField("deactivation_code", StringType, true),
        StructField("reinstatement_code", StringType, true),
        StructField("reinstatement_date", StringType, true)))

      //Assigning the schema to the SplitData
      val mas_answer = mas_lengths.indices.foldLeft(mas_SplitData) {
        case (result, idx) =>
          result.toDF.withColumn(s"col_$idx", $"fields".getItem(idx))
      }

      //creates temporary table for mas file
      spark.createDataFrame(mas_answer.drop("fields").rdd, mas).createOrReplaceTempView("mas_table")

      // SQL query to join all the files
      sqlContext.sql("""select mas.ncpdp_id,mas.legal_business_name,mas.name_dba,mas.store_number,mas.physical_location_address_1,mas.physical_location_address_2,mas.physical_location_city,mas.physical_location_state,mas.physical_location_zip,mas.physical_location_phone,mas.physical_location_fax,mas.physical_location_cross_street_directions,mas.hour_flag,mas.primary_provider_type_code,mas.secondary_provider_type_code,mas.tertiary_provider_type_code,mas.medicare_provider_supplier_id,mas.npi,mas.dea_registration_id,mas.federal_tax_id,mas.state_tax_id,coo.old_ncpdp_provider_id,coo.old_store_close_date,coo.change_of_ownership_effective_date,erx.eprescribing_network_identifier,erx.eprescribing_service_level_codes,md.state_code,md.medicaid_id,stl.license_state_code,stl.state_license_number,svc.accepts_eprescriptions_indicator,svc.accepts_eprescriptions_code,svc.delivery_service_indicator,svc.delivery_service_code,svc.compounding_service_indicator,svc.compounding_service_code,svc.drive_up_window_indicator,svc.drive_up_window_code,svc.durable_medical_equipment_indicator,svc.durable_medical_equipment_code,svc.walk_in_clinic_indicator,svc.walk_in_clinic_code,svc.emergency_service_indicator_24_hour,svc.emergency_service_code_24_hour,svc.multi_dose_compliance_packaging_indicator,svc.multi_dose_compliance_packaging_code,svc.immunizations_provided_indicator,svc.immunizations_provided_code,svc.handicapped_accessible_indicator,svc.handicapped_accessible_code,svc.status_indicator_340b,svc.status_code_340b,svc.closed_door_facility_indicator,svc.closed_door_facility_status_code,tx.taxonomy_code,af.relationship_id,af.relationship_type,pr.parent_organization_id,pr.parent_organization_name,pr.parent_organization_address_1,pr.parent_organization_address_2,pr.parent_organization_city,pr.parent_organization_state_code,pr.parent_organization_zip_code,pr.parent_organization_phone_number,pr.parent_organization_phone_extension,pr.parent_organization_fax_number,pr.parent_organization_npi,pr.parent_organization_federal_tax_id from mas_table mas Left Outer Join mas_coo_table coo on coo.ncpdp_id = mas.ncpdp_id Left Outer Join mas_erx_table erx on erx.ncpdp_id = mas.ncpdp_id Left Outer Join mas_md_table md on md.ncpdp_id = mas.ncpdp_id Left Outer Join mas_stl_table stl on stl.ncpdp_id = mas.ncpdp_id Left Outer Join mas_svc_table svc on svc.ncpdp_id = mas.ncpdp_id Left Outer Join mas_tx_table tx on tx.ncpdp_id = mas.ncpdp_id Left Outer Join mas_rr_table rr on rr.ncpdp_id = mas.ncpdp_id Left Outer Join mas_af_table af on af.relationship_id = rr.relationship_id Left Outer Join mas_pr_table pr on pr.parent_organization_id = af.parent_organization_id""").createOrReplaceTempView("final_table")

      // concatenates multiple records of each Provider ID to a single row and creates a dataframe
      val df = sqlContext.sql("""SELECT ncpdp_id,CONCAT_WS("~",COLLECT_SET(trim(legal_business_name))) AS legal_business_name,CONCAT_WS("~",COLLECT_SET(trim(name_dba))) AS name_dba,CONCAT_WS("~",COLLECT_SET(trim(store_number))) AS store_number,CONCAT_WS("~",COLLECT_SET(trim(physical_location_address_1))) AS physical_location_address_1,CONCAT_WS("~",COLLECT_SET(trim(physical_location_address_2))) AS physical_location_address_2,CONCAT_WS("~",COLLECT_SET(trim(physical_location_city))) AS physical_location_city,CONCAT_WS("~",COLLECT_SET(trim(physical_location_state))) AS physical_location_state,CONCAT_WS("~",COLLECT_SET(trim(physical_location_zip))) AS physical_location_zip,CONCAT_WS("~",COLLECT_SET(trim(physical_location_phone))) AS physical_location_phone,CONCAT_WS("~",COLLECT_SET(trim(physical_location_fax))) AS physical_location_fax,CONCAT_WS("~",COLLECT_SET(trim(physical_location_cross_street_directions))) AS physical_location_cross_street_directions,CONCAT_WS("~",COLLECT_SET(trim(hour_flag))) AS 24_hour_flag,CONCAT_WS("~",COLLECT_SET(trim(primary_provider_type_code))) AS primary_provider_type_code,CONCAT_WS("~",COLLECT_SET(trim(secondary_provider_type_code))) AS secondary_provider_type_code,CONCAT_WS("~",COLLECT_SET(trim(tertiary_provider_type_code))) AS tertiary_provider_type_code,CONCAT_WS("~",COLLECT_SET(trim(medicare_provider_supplier_id))) AS medicare_provider_supplier_id,CONCAT_WS("~",COLLECT_SET(trim(npi))) AS npi,CONCAT_WS("~",COLLECT_SET(trim(dea_registration_id))) AS dea_registration_id,CONCAT_WS("~",COLLECT_SET(trim(federal_tax_id))) AS federal_tax_id,CONCAT_WS("~",COLLECT_SET(trim(state_tax_id))) AS state_tax_id,CONCAT_WS("~",COLLECT_SET(trim(taxonomy_code))) AS taxonomy_code,CONCAT_WS("~",COLLECT_SET(trim(state_code))) AS state_code,CONCAT_WS("~",COLLECT_SET(trim(medicaid_id))) AS medicaid_id,CONCAT_WS("~",COLLECT_SET(trim(license_state_code))) AS license_state_code,CONCAT_WS("~",COLLECT_SET(trim(state_license_number))) AS state_license_number,CONCAT_WS("~",COLLECT_SET(trim(accepts_eprescriptions_indicator))) AS accepts_eprescriptions_indicator,CONCAT_WS("~",COLLECT_SET(trim(accepts_eprescriptions_code))) AS accepts_eprescriptions_code,CONCAT_WS("~",COLLECT_SET(trim(delivery_service_indicator))) AS delivery_service_indicator,CONCAT_WS("~",COLLECT_SET(trim(delivery_service_code))) AS delivery_service_code,CONCAT_WS("~",COLLECT_SET(trim(compounding_service_indicator))) AS compounding_service_indicator,CONCAT_WS("~",COLLECT_SET(trim(compounding_service_code))) AS compounding_service_code,CONCAT_WS("~",COLLECT_SET(trim(drive_up_window_indicator))) AS `drive-up_window_indicator`,CONCAT_WS("~",COLLECT_SET(trim(drive_up_window_code))) AS `drive-up_window_code`,CONCAT_WS("~",COLLECT_SET(trim(durable_medical_equipment_indicator))) AS durable_medical_equipment_indicator,CONCAT_WS("~",COLLECT_SET(trim(durable_medical_equipment_code))) AS durable_medical_equipment_code,CONCAT_WS("~",COLLECT_SET(trim(walk_in_clinic_indicator))) AS `walk-in_clinic_indicator`,CONCAT_WS("~",COLLECT_SET(trim(walk_in_clinic_code))) AS `walk-in_clinic_code`,CONCAT_WS("~",COLLECT_SET(trim(emergency_service_indicator_24_hour))) AS `24-hour_emergency_service_indicator`,CONCAT_WS("~",COLLECT_SET(trim(emergency_service_code_24_hour))) AS `24-hour_emergency_service_code`,CONCAT_WS("~",COLLECT_SET(trim(multi_dose_compliance_packaging_indicator))) AS `multi-dose_compliance_packaging_indicator`,CONCAT_WS("~",COLLECT_SET(trim(multi_dose_compliance_packaging_code))) AS `multi-dose_compliance_packaging_code`,CONCAT_WS("~",COLLECT_SET(trim(immunizations_provided_indicator))) AS immunizations_provided_indicator,CONCAT_WS("~",COLLECT_SET(trim(immunizations_provided_code))) AS immunizations_provided_code,CONCAT_WS("~",COLLECT_SET(trim(handicapped_accessible_indicator))) AS handicapped_accessible_indicator,CONCAT_WS("~",COLLECT_SET(trim(handicapped_accessible_code))) AS handicapped_accessible_code,CONCAT_WS("~",COLLECT_SET(trim(status_indicator_340b))) AS `340b_status_indicator`,CONCAT_WS("~",COLLECT_SET(trim(status_code_340b))) AS `340b_status_code`,CONCAT_WS("~",COLLECT_SET(trim(closed_door_facility_indicator))) AS closed_door_facility_indicator,CONCAT_WS("~",COLLECT_SET(trim(closed_door_facility_status_code))) AS closed_door_facility_status_code,CONCAT_WS("~",COLLECT_SET(trim(parent_organization_id))) AS parent_organization_id,CONCAT_WS("~",COLLECT_SET(trim(parent_organization_name))) AS parent_organization_name,CONCAT_WS("~",COLLECT_SET(trim(parent_organization_address_1))) AS parent_organization_address_1,CONCAT_WS("~",COLLECT_SET(trim(parent_organization_address_2))) AS parent_organization_address_2,CONCAT_WS("~",COLLECT_SET(trim(parent_organization_city))) AS parent_organization_city,CONCAT_WS("~",COLLECT_SET(trim(parent_organization_state_code))) AS parent_organization_state_code,CONCAT_WS("~",COLLECT_SET(trim(parent_organization_zip_code))) AS parent_organization_zip_code,CONCAT_WS("~",COLLECT_SET(trim(parent_organization_phone_number))) AS parent_organization_phone_number,CONCAT_WS("~",COLLECT_SET(trim(parent_organization_phone_extension))) AS parent_organization_phone_extension,CONCAT_WS("~",COLLECT_SET(trim(parent_organization_fax_number))) AS parent_organization_fax_number,CONCAT_WS("~",COLLECT_SET(trim(parent_organization_npi))) AS parent_organization_npi,CONCAT_WS("~",COLLECT_SET(trim(parent_organization_federal_tax_id))) AS parent_organization_federal_tax_id,CONCAT_WS("~",COLLECT_SET(trim(relationship_id))) AS relationship_id,CONCAT_WS("~",COLLECT_SET(trim(relationship_type))) AS relationship_type,CONCAT_WS("~",COLLECT_SET(trim(eprescribing_network_identifier))) AS eprescribing_network_identifier,CONCAT_WS("~",COLLECT_SET(trim(regexp_replace(eprescribing_service_level_codes,"\\|"," ")))) AS eprescribing_service_level_codes,CONCAT_WS("~",COLLECT_SET(trim(old_ncpdp_provider_id))) AS old_ncpdp_provider_id,CONCAT_WS("~",COLLECT_SET(trim(old_store_close_date))) AS old_store_close_date,CONCAT_WS("~",COLLECT_SET(trim(change_of_ownership_effective_date))) AS change_of_ownership_effective_date from final_table group by ncpdp_id""")

      val currentTimestamp = Utils.getCurrentTimestamp()

      //Writing the data to Output File
      val selection = df.columns.map(col)
      val finalDf = df.withColumn("payload", concat_ws("|", selection: _*))
        .withColumn("filename", lit(INPUT_SRC_DIR)) //Replace with source dir
        .withColumn("uuid", generateUUID(lit(SOURCE_TYPE)))
        .withColumn("interfacetype", lit(INTERFACE_TYPE))
        .withColumn("createTimestamp",lit(currentTimestamp))
        .withColumn("updateTimestamp",lit(currentTimestamp))
       // .select($"uuid".as(uuid), $"filename".as(filename), $"interfacetype".as(interface), $"payload".as(payload))



      val data1 = finalDf.select($"uuid".as(uuid)
        , $"filename".as(filename)
        , $"interfacetype".as(interface)
        , $"payload".as(payload)
        , $"createTimestamp"
        , $"updateTimestamp")

      Logger.log.info("***** Selecting required column created  *****")


      data1.persist()

      val data2 = data1.map {
        case Row(uuid: String, fileName: String ,interface:String, payload:String, createTimestamp:String, updateTimestamp:String) => DebatchMessage(uuid,fileName,interface,payload,createTimestamp,updateTimestamp,MetaData(null,null,null))
      }.as[DebatchMessage].toJSON


      /**
        * Pushing Messages to Kafka
        */
      try {
        Logger.log.info("***** sending Streaming  message to kafka *****")
        if(securityEnabled.equalsIgnoreCase("true")) {

          Utils.writeToSecureTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER, trustStorePath, trustStorePwd, scrWriteUser, scrWritePwd, scrReadUser, scrReadPwd, algorithm,requestTimeOut,retries,requestSize)
        }else {
          Utils.writeToTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER,requestTimeOut,retries,requestSize)

        }
        Logger.log.info("***** sending Streaming  message  to kafka  completed *****")
      } catch {
        case e: Exception => Logger.log.error("Exception while sending Streaming  message  to kafka " + e.getMessage)
          Logger.log.error(e.printStackTrace())
          throw new RuntimeException("Failed to push records to Kafka. Please check if the provided Cluster details are accurate.")
      }

      Logger.log.info("Records pushed to Kafka topic: " + data1.count)


      /**
        * Elastic Search Summary Indexing
        */
      Utils.writeSummaryToES(data1,INTERFACE_TYPE,ES_INDEX)

      //Capturing End Time in Milliseconds and calculating the Spark Start to Output File Creation Execution Time in minutes
      val outputEndTimeMillis = System.currentTimeMillis()
      val outputDurationMinutes = (outputEndTimeMillis - processStartTimeMillis) / 60000
      Logger.log.info(s"=======================> Output File Creation Execution Time : $outputDurationMinutes min <=========================")

      Logger.log.info("   ************* END OF NCPDP-STREAMER JOB ***************\n")
      sqlContext.clearCache()

      sc.stop()
      spark.stop()
    } catch {
      case e: Exception => {
        Logger.log.info("NCPDP Streamer job  process failed: " + e.getMessage)
        System.exit(1)
      }
    }
  }
}

