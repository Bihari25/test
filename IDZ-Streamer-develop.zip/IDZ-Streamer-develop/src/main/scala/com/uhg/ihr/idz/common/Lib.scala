package com.uhg.ihr.idz.common

import java.io.File

import org.apache.commons.io.FileUtils
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, FileUtil, Path}

object Lib {

  def ListDirFiles(directoryPath: String): List[String] = {
    var returnList = List[String]()
    val d = new File(directoryPath)
    for (fileList <- d.listFiles()) {
      returnList = fileList.getAbsolutePath :: returnList
    }
    returnList
  }

  // To get list of zip  files given input directory
  def getListOfFiles(dir: String): List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
      d.listFiles.filter(_.isFile).filter(_.getName.toLowerCase().endsWith(".txt")).toList
    } else {
      List[File]()
    }
  } //method

  // Given source and destination, copy the file from source to destination.
  def copyFile(sourceFilePath: String, targetFilePath: String): Unit = {

    try {
      val hadoopConf = new Configuration()

      val source = new Path(sourceFilePath.replace("/mapr", ""))

      val target = new Path(targetFilePath.replace("/mapr", ""))
      val fs: FileSystem = source.getFileSystem(hadoopConf)
      val sourceFiles = fs.listFiles(source, true)

      var count = 0
      if (sourceFiles != null) {
        Logger.log.info(s" Source path $sourceFilePath ")
        Logger.log.info(s" target path $targetFilePath")
        while (sourceFiles.hasNext()) {
          FileUtil.copy(fs, sourceFiles.next().getPath(), fs, target, false, hadoopConf)
          count += 1
        } ///while

        Logger.log.info(s"==============>   Total no of Files copied  = $count <==============================")
        Logger.log.info(s" ==============>  copying the files completed  <==============================")

      } //if

      if (sourceFiles == null) {
        Logger.log.info(s"No Files found  to copied  $sourceFilePath ")
        sys.exit()

      }
    } catch {
      case e@(_: java.io.IOException | _: Exception) =>
        Logger.log.error(s"ERROR :Unable to check whether file at $sourceFilePath exists or note ", e)
        Logger.log.info("error message " + e.getMessage)
        sys.exit()
    }

  }


  def moveFile(sourceFilePath: String, targetFilePath: String): Unit = {

    try {
      val hadoopConf = new Configuration()

      val source = new Path(sourceFilePath.replace("/mapr", ""))

      val target = new Path(targetFilePath.replace("/mapr", ""))
      val fs: FileSystem = source.getFileSystem(hadoopConf)
      val sourceFiles = fs.listFiles(source, true)

      var count = 0
      if (sourceFiles != null) {
        Logger.log.info(s"====>  Source path $sourceFilePath ")
        Logger.log.info(s" =====> target path $targetFilePath")
        while (sourceFiles.hasNext()) {
          FileUtil.copy(fs, sourceFiles.next().getPath(), fs, target, true, hadoopConf)
          count += 1
        } ///while

        Logger.log.info(s"==========>  Total no of Files moved  = $count ")
        Logger.log.info(s" ============>   moving the files completed   <========================")

      } //if

      if (sourceFiles == null) {
        Logger.log.info(s"No Files found  to moved  $sourceFilePath ")
        sys.exit()

      }
    } catch {
      case e@(_: java.io.IOException | _: Exception) =>
        Logger.log.error(s"ERROR :Unable to check whether file at $sourceFilePath exists or note ", e)
        Logger.log.info("error message " + e.getMessage)
        sys.exit()
    }

  }


  def archiveFile(sourceFilePath: String, targetFilePath: String): Unit = {

    try {

      val source = new File("/mapr" + sourceFilePath)
      val destination = new File("/mapr" + targetFilePath)
      if (!destination.exists()) {
        destination.mkdirs()
      }
      if (source.isDirectory && destination.isDirectory) {
        FileUtils.moveToDirectory(source, destination, true)
        Logger.log.info(s" ============>   moving the files completed   <========================")
      }
    } //try
    catch {
      case e@(_: java.io.IOException | _: Exception) =>
        Logger.log.error(s"ERROR :Unable to check whether file at $sourceFilePath exists or note ", e)
        Logger.log.info("error message " + e.getMessage)
        sys.exit()
    }

  }

  //// Given the source path, it will delete all the files inside that path.
  def deleteFile(sourceFilePath: String): Unit = {

    Logger.log.info(s"***** Delete files Started  ***********")
    Logger.log.info(s"***** files path  $sourceFilePath  ***********")

    try {
      val hadoopConf = new Configuration()

      val source = new Path(sourceFilePath.replace("/mapr", ""))

      val fs: FileSystem = source.getFileSystem(hadoopConf)
      val sourceFiles = fs.listFiles(source, true)
      var filecount = 0
      if (sourceFiles != null) {
        Logger.log.info(s"Started deleting the files from $sourceFilePath ")
        while (sourceFiles.hasNext()) {
          FileUtil.fullyDelete(fs, sourceFiles.next().getPath())
          filecount += 1
        }
        Logger.log.info(s"***** Delete files completed   ***********")
        Logger.log.info(s"*****  No Of Files  $filecount  deleted ")

      }
    } catch {
      case e@(_: java.io.IOException | _: Exception) =>
        Logger.log.error(s"Unable to Delete file at $sourceFilePath exists", e)

        throw e
        sys.exit()
    }

  }

}
