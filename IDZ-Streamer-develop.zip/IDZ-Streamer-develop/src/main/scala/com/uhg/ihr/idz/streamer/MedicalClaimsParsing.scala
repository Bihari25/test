 package com.uhg.ihr.idz.streamer

import java.io.{FileInputStream}
import java.util.Properties

import com.uhg.ihr.idz.common.Logger
import com.uhg.ihr.idz.utils.Utils
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
 import org.apache.hadoop.fs.{Path,FileSystem}

 object MedicalClaimsParsing {
   def readX12Parser(spark: SparkSession, path: String, log_file_name: String): Unit = {

     var logFileEntry :List[List[String]] =  List();
     val sc = spark.sparkContext
     val delimit = "~\nISA*"
     sc.hadoopConfiguration.set("textinputformat.record.delimiter", delimit)
     import spark.implicits._


     val fileSystem = FileSystem.get(sc.hadoopConfiguration)
     val tempDirPath = new Path(s"${path}/processed/tempdir")

     val ListOfFiles = Utils.getFilePaths(path,sc).map(x => x.getName).filter(x => x.startsWith("thread") && x.contains("x12")).toBuffer
     Logger.log.info(ListOfFiles)
     try{
       ListOfFiles.foreach { claimFile =>
         Logger.log.info(s"File Processed : ${path}/${claimFile}")
         val medDf = sc.textFile(s"${path}/${claimFile.replace("[", "?").replace("]", "?")}")
           .map(x => "ISA*" ++ x ++ "~")
           .map(r => r.replace("ISA*ISA*", "ISA*"))
           .map(r => r.replace("~\n~", "~"))
           .toDF("delimit_column")

         val filteredDf = medDf.filter(row => ! {
           val message = row.mkString
           val segments = message.split("~\nNM1")
           val prSegment = segments.filter(x => x.startsWith("*PR*"))
           var prInd = true
           if (prSegment.length == 0) {
             prInd = false
           } else {
             prInd = prSegment(0).split("~")(0).split("\\*")(9).replaceAll("~\n", "").contains("95964")
           }
           val k3segment = message.split("~").map(x => x.trim) filter (x => x.startsWith("K3*ICN"))
           var k3Ind = true
           if (k3segment.length == 0) {
             k3Ind = false
           } else {
             k3Ind = k3segment(0).contains("COSM")
           }
           prInd & k3Ind
         })
         val totalCount = medDf.count()
         val filteredCount = filteredDf.count()
         Logger.log.info(s"Total Count: ${totalCount}, Filtered Count: ${filteredCount}")

         //Cleanup the dir
         deleteDir(tempDirPath,fileSystem)

         if( totalCount-filteredCount > 0 ){
           filteredDf.coalesce(1).write.mode(SaveMode.Overwrite).text(s"${path}/processed/tempdir")

           sleep(fileSystem.exists(tempDirPath),0)

           Logger.log.info(s"Num of Partitions")
           Logger.log.info(s"Writing File ${claimFile} to /mapr${path}/processed/tempdir completed.")

           Logger.log.info("Checking if tempdir is created:"+fileSystem.exists(tempDirPath))
           Logger.log.info("List of files in tempdir:"+fileSystem.listStatus(tempDirPath).map(_.getPath.getName))

           val srcFilePath = fileSystem.listStatus(tempDirPath).filter(_.isFile).filter(_.getPath.getName.startsWith("part-")).map(_.getPath)

           Logger.log.info(s"Src File path : ${srcFilePath.toList(0)}")
           val dstFilePath = new Path(s"${path}/processed/${claimFile}")
           Logger.log.info(s"Target File path : ${dstFilePath}")
           try{
             fileSystem.rename(srcFilePath(0),dstFilePath)
           }catch{
             case e: Exception => Logger.log.error(e.printStackTrace())
               throw new Exception("Data Files could not be Moved.")
           }

           logFileEntry = logFileEntry :+ List(claimFile, totalCount.toString, filteredCount.toString, (totalCount - filteredCount).toString)
         }

       }
     }catch {
       case e: Exception => Logger.log.error(e.printStackTrace())
         throw new Exception("Files could not be processed.")
     }

     //Cleanup the dir
     deleteDir(tempDirPath,fileSystem)

     //Creating the Log File
     Logger.log.info(s"Log file Entries: ${logFileEntry}")
     val medLogTempDir = if(!log_file_name.startsWith("/mapr"))
       log_file_name.split("/").dropRight(1).mkString("/")+"/medParsingLogTempDir"
     else
       "/"+log_file_name.split("/").drop(2).dropRight(1).mkString("/")+"/medParsingLogTempDir"


     logFileEntry.map(x=>(x(0),x(1),x(2),x(3))).toDF("FileName","TotalCount","FilteredRecordCount","BadRecordCount")
       .coalesce(1)
       .write.format("com.databricks.spark.csv")
       .mode(SaveMode.Overwrite)
       .option("header","true")
       .option("delimiter",",")
       .save(medLogTempDir)

     sleep(fileSystem.exists(new Path(medLogTempDir)),0)
     val log_file = if(log_file_name.startsWith("/mapr"))
       "/"+log_file_name.split("/").drop(2).mkString("/")
     else
       log_file_name

     val srcFilePath = fileSystem.listStatus(new Path(medLogTempDir)).filter(_.isFile)
       .filter(_.getPath.getName.startsWith("part-")).map(_.getPath)
     Logger.log.info(s"Log TempFile ${srcFilePath(0).getName}")
     Logger.log.info(s"Target Log File ${log_file}")

     val dstFilePath = new Path(log_file)

      try{
        fileSystem.rename(srcFilePath(0),dstFilePath)
      }catch{
        case e: Exception => Logger.log.error(e.printStackTrace())
          throw new Exception("Log Files could not be Moved.")
      }
   }

   def deleteDir(dirPath:Path,fileSystem: FileSystem): Unit ={
     Logger.log.info(s"Deleting ${dirPath.getName}")
     if(fileSystem.exists(dirPath)){
       if(fileSystem.delete(dirPath,true))
         Logger.log.info(s"Deleted ${dirPath.getName} Successfully")
       else {
         Logger.log.error(s"Could not delete the directory ${dirPath.getName}")
         throw new Exception(s"Could not delete the directory ${dirPath.getName}")
       }
     }
   }

   def sleep(tempDirExists:Boolean,counter:Int): Unit ={
     if(!tempDirExists && counter <= 20) {
       Logger.log.info("Sleep for 3 seconds")
       Thread.sleep(3000)
       sleep(tempDirExists,counter+1)
     }
     return
   }

   def main(args: Array[String]): Unit = {

     if (args.length != 3) {
       Logger.log.error(s"Please Pass the valid input parameter \nInputFilePath  \n PropertiesFile ")
       System.exit(1)
     }
     try {
       val propertiesFile = args(1)
       val prop = new Properties()
       val prop_path = new FileInputStream(propertiesFile)

       try {
         prop.load(prop_path)
       } finally {
         prop_path.close
       }

       val conf = new SparkConf().setAppName("memberStreamer")
       conf.set("spark.driver.cores", prop.getProperty("driver_cores"))
       conf.set("spark.executor.instances", prop.getProperty("executor_instances"))
       conf.set("spark.executor.memory", prop.getProperty("executor_memory"))
       conf.set("spark.driver.memory", prop.getProperty("driver_memory"))
       conf.set("spark.executor.cores", prop.getProperty("executor_cores"))
       conf.set("spark.default.parallelism", prop.getProperty("default_parallelism"))
       conf.set("spark.sql.shuffle.partitions", prop.getProperty("sql_shuffle_partitions"))
       conf.set("spark.yarn.executor.memoryoverhead", prop.getProperty("yarn_executor_memoryoverhead"))
       conf.set("spark.driver.maxResultSize", prop.getProperty("driver_maxResultSize"))
       conf.set("spark.memory.fraction", prop.getProperty("memory_fraction"))
       conf.set("spark.debug.maxToStringFields", prop.getProperty("maxToStringFields"))
       conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
       conf.set("spark.kryoserializer.buffer.max", "128m")


       val spark = SparkSession.builder().config(conf).getOrCreate()
       val sc = spark.sparkContext

       val startTimeMillis = System.currentTimeMillis()

       val path = args(0)
       val outputPath = path + "/processed"
       val log_file_name_path = args(2)
       readX12Parser(spark, path, log_file_name_path)
       val fs = FileSystem.get(sc.hadoopConfiguration)
       if(!fs.exists(new Path(outputPath)))
         fs.mkdirs(new Path(outputPath))

       val endTimeMillis = System.currentTimeMillis()
       val totalDurationMinutes = endTimeMillis.-(startTimeMillis)./(60000)
       val totalDurationSeconds = endTimeMillis.-(startTimeMillis)./(1000).%(60)
       Logger.log.info(s"==========> Job Completion Time : $totalDurationMinutes minutes and $totalDurationSeconds seconds <===========")
       sc.stop()
       spark.stop()
     }
     catch {
       case e: Exception => {
         Logger.log.error("Medical claims filtering process failed: " + e.getMessage)
         System.exit(1)
       }
     }
   }
 }
