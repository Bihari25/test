/*@Author Gowtham Kaladandi 26/08/19
 *This Spark Job is used to Stream Medical claim transactional files(x12)
 * and push the data into kafka topic in Json format with each claim transaction as payload.
 */

package com.uhg.ihr.idz.streamer

import java.io.FileInputStream
import java.util.Properties

import com.uhg.ihr.idz.common.Logger
import com.uhg.ihr.idz.utils.Utils
import com.uhg.ihr.idz.utils.Utils.{DebatchMessage, MetaData}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.elasticsearch.spark.sql._

object IcueStreamer {

  var PROPS: Properties = _
  var INPUT_DIR_PATH: String = _
  var INPUT_PROPERTIES_FILE: String = _
  var KAFKA_TOPIC: String = _
  var SOURCE_TYPE: String = _
  var KAFKA_SERVER: String = _
  var INTERFACE_TYPE: String = _
  var ES_NODES: String = _
  var ES_PORT: String = _
  var ES_INDEX: String = _
  var TRAN_KAFKA_TOPIC: String = _
  var TRAN_KAFKA_SERVER: String = _
  // var INPUT_PARTITION_DATE: String = _
  var SOURCE_TO_PROCESS: String = _
  var trustStorePath: String = _
  var trustStorePwd: String = _
  var scrWriteUser: String = _
  var scrWritePwd: String = _
  var scrReadUser: String = _
  var scrReadPwd: String = _
  var algorithm: String = _
  var securityEnabled: String = _
  var requestTimeOut: String = _
  var retries: String = _
  var requestSize: String = _


  def main(args: Array[String]): Unit = {
    if (args.length != 3) {
      Logger.log.info(s"Please Pass the valid input parameter \nInputFilePath  \n PropertiesFile \nSourceToProcess")
      System.exit(1)
    }

    //Arguments
    INPUT_DIR_PATH = args(0)
    INPUT_PROPERTIES_FILE = args(1)
    SOURCE_TO_PROCESS = args(2)

    Logger.log.info("InputFile Path: => " + INPUT_DIR_PATH)
    Logger.log.info("PropertiesFile : => " + INPUT_PROPERTIES_FILE)

    val processStartTimeMillis = System.currentTimeMillis()
    try {
      //Reading the properties file
      PROPS = new Properties()
      val path = new FileInputStream(INPUT_PROPERTIES_FILE)
      try {
        PROPS.load(path)
      } finally {
        path.close
      }

      //application properties
      KAFKA_TOPIC = PROPS.getProperty("kafka_topic")
      SOURCE_TYPE = PROPS.getProperty("source_type")
      KAFKA_SERVER = PROPS.getProperty("kafka_server")
      ES_NODES = PROPS.getProperty("es_Nodes")
      ES_PORT = PROPS.getProperty("es_Port")
      ES_INDEX = PROPS.getProperty("es_Index")
      trustStorePath = PROPS.getProperty("trust_store_path")
      trustStorePwd = PROPS.getProperty("trust_store_pwd")
      scrWriteUser = PROPS.getProperty("scram_write_user")
      scrWritePwd = PROPS.getProperty("scram_write_pwd")
      scrReadUser = PROPS.getProperty("scram_read_user")
      scrReadPwd = PROPS.getProperty("scram_read_pwd")
      algorithm = PROPS.getProperty("algorithm")
      securityEnabled = PROPS.getProperty("securityEnabled")
      retries = PROPS.getProperty("retries")
      requestTimeOut = PROPS.getProperty("requestTimeOut")
      requestSize = PROPS.getProperty("requestSize")

      var sourceSchema = " "

      if (SOURCE_TO_PROCESS == "MANUAL") {
        sourceSchema = PROPS.getProperty("manual_schema")
        INTERFACE_TYPE = PROPS.getProperty("interface_manual")
      } else if (SOURCE_TO_PROCESS == "IMPACTPRO") {
        sourceSchema = PROPS.getProperty("impactpro_schema")
        INTERFACE_TYPE = PROPS.getProperty("interface_impact")
      } else if (SOURCE_TO_PROCESS == "MAGELLAN") {
        sourceSchema = PROPS.getProperty("magellan_schema")
        INTERFACE_TYPE = PROPS.getProperty("interface_magellan")
      } else if (SOURCE_TO_PROCESS == "CONDITIONS") {
        sourceSchema = PROPS.getProperty("conditions_schema")
        INTERFACE_TYPE = PROPS.getProperty("interface_conditions")
      } else {
        Logger.log.info("Please pass the required argument source to process")
        System.exit(1)
      }

      Logger.log.info("kafka transction topic Name =>" + TRAN_KAFKA_TOPIC)
      Logger.log.info("kafka transction server Name =>" + TRAN_KAFKA_SERVER)
      Logger.log.info("Elastic Search Nodes : => " + ES_NODES)
      Logger.log.info("Elastic Search Port : => " + ES_PORT)
      Logger.log.info("Elastic Search Index : => " + ES_INDEX)
      Logger.log.info("Kafka Topic : => " + KAFKA_TOPIC)
      Logger.log.info("Kafka Server : => " + KAFKA_SERVER)
      Logger.log.info("Interface Name : => " + INTERFACE_TYPE)

      //Export Columns
      val uuid = PROPS.getProperty("messageUUID")
      //val partitionDate = PROPS.getProperty("partiionDate")
      val fileName = PROPS.getProperty("sourceName")
      val payload = PROPS.getProperty("payload")
      val es_user = PROPS.getProperty("es_user")
      Logger.log.info("es user Name: => " + es_user)
      val es_pwd = PROPS.getProperty("es_pwd")

      //pulling the required source type
      val spark = SparkSession.builder()
        .appName("ICUE-B50-Streaming")
        .config("spark.driver.cores", PROPS.getProperty("driver_cores"))
        .config("spark.executor.instances", PROPS.getProperty("executor_instances"))
        .config("spark.executor.memory", PROPS.getProperty("executor_memory"))
        .config("spark.driver.memory", PROPS.getProperty("driver_memory"))
        .config("spark.executor.cores", PROPS.getProperty("executor_cores"))
        .config("spark.default.parallelism", PROPS.getProperty("default_parallelism"))
        .config("spark.sql.shuffle.partitions", PROPS.getProperty("sql_shuffle_partitions"))
        .config("spark.yarn.executor.memoryoverhead", PROPS.getProperty("yarn_executor_memoryoverhead"))
        .config("spark.driver.maxResultSize", PROPS.getProperty("driver_maxResultSize"))
        .config("spark.memory.fraction", PROPS.getProperty("memory_fraction"))
        .config("spark.es.nodes", ES_NODES)
        .config("spark.es.port", ES_PORT)
        .config("spark.es.net.http.auth.user", es_user)
        .config("spark.es.net.http.auth.pass", es_pwd)
        .config("spark.es.nodes.wan.only", "true")
        .config("spark.es.mapping.id", fileName)
        .config("spark.es.write.operation", "upsert")
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .getOrCreate()

      import spark.implicits._
      val sc = spark.sparkContext

      /**
        * Exit if the input Directory is Empty.
        */
      if(Utils.getFilePaths(INPUT_DIR_PATH,sc).length == 0){
        Logger.log.info(s"Source ${INPUT_DIR_PATH} is Empty or doesn't exist.")
        Logger.log.error("==> ==> ==>  Exiting the Job  <== <== <==")
        System.exit(1)
      }

      //register an UDF that creates a random ID MED_<timestamp>_<uuid>
      val generateUUID = udf { (srcType: String) => Utils.generateUUID(srcType) }

      //Reading the input claim File
      Logger.log.info("Started Reading Input Files")
      val inputPath = s"$INPUT_DIR_PATH"
      //s"/date=$INPUT_PARTITION_DATE"
      val interface = PROPS.getProperty("interface")
      val fields = sourceSchema.split("\\|").map(fieldName => StructField(fieldName, StringType, nullable = true))
      val schema = StructType(fields)
      val icueDebatch_df = spark.read
        .option("header", false)
        .option("delimiter", "|")
        .schema(schema).csv(inputPath).na.fill("").filter($"FST_NM" =!= "FST_NM")

      val currentTimestamp = Utils.getCurrentTimestamp()

      val icueDebatchPayload = icueDebatch_df.select(concat_ws("|", icueDebatch_df.columns.map(c => col(c)): _*).as("payload"))
        .withColumn("uuid", generateUUID(lit(SOURCE_TYPE)))
        .withColumn("interfacename", lit(INTERFACE_TYPE))
        .withColumn("filename", input_file_name())
        .withColumn("createTimestamp", lit(currentTimestamp))
        .withColumn("updateTimestamp", lit(currentTimestamp))

      Logger.log.info("Completed Reading Input Files")

      val data1 = icueDebatchPayload.select($"uuid".as(uuid)
        , $"filename".as(fileName)
        , $"interfacename".as(interface)
        , $"payload".as(payload)
        , $"createTimestamp"
        , $"updateTimestamp")
      Logger.log.info("***** Selecting required column created  *****")

      data1.persist()

      val data2 = data1.map {
        case Row(uuid: String, fileName: String, interface: String, payload: String, createTimestamp: String, updateTimestamp: String) => DebatchMessage(uuid, fileName, interface, payload, createTimestamp, updateTimestamp, MetaData(null, null, null))
      }.as[DebatchMessage].toJSON

      /**
        * Pushing Messages to Kafka
        */
      try {
        Logger.log.info("***** sending Streaming  message to kafka *****")
        if (securityEnabled.equalsIgnoreCase("true")) {
          Utils.writeToSecureTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER, trustStorePath, trustStorePwd, scrWriteUser, scrWritePwd, scrReadUser, scrReadPwd, algorithm, requestTimeOut, retries, requestSize)
        } else {
          Utils.writeToTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER, requestTimeOut, retries, requestSize)
        }
        Logger.log.info("***** sending Streaming  message to kafka completed *****")
      } catch {
        case e: Exception => Logger.log.error("Exception while sending Streaming  message to kafka " + e.getMessage)
          Logger.log.error(e.printStackTrace())
          throw new RuntimeException("Failed to push records to Kafka. Please check if the provided Cluster details are accurate.")
      }

      /**
        * Elastic Search Summary Indexing
        */
      Utils.writeSummaryToES(data1,INTERFACE_TYPE,ES_INDEX)

      val OutputEndTimeMillis = System.currentTimeMillis()
      val OutputDurationMinutes = OutputEndTimeMillis.-(processStartTimeMillis)./(60000)
      val OutputDurationSeconds = OutputEndTimeMillis.-(processStartTimeMillis)./(1000).%(60)
      Logger.log.info(s"Job Execution Time : $OutputDurationMinutes minutes and $OutputDurationSeconds Seconds")
      Logger.log.info("   ************* END OF ICUE-Streamer JOB ***************\n")
      data1.unpersist()
      spark.stop()
      Logger.log.info("************* Completion of Spark job ***************\n")
    } catch {
      case e: Exception => {
        Logger.log.info("ICUE Streamer process failed: " + e.getMessage)
        System.exit(1)
      }
    }
  }

}
