package com.uhg.ihr.idz.streamer

  import java.util.{Calendar, Properties}
  import java.io.FileInputStream

  import com.uhg.ihr.idz.common.{Lib, Logger}
  import com.uhg.ihr.idz.schema.ClinicianSchema
  import com.uhg.ihr.idz.utils.Utils
  import com.uhg.ihr.idz.utils.Utils.{DebatchMessage, MetaData}
  import org.apache.spark.sql.functions._
  import org.apache.spark.sql.{Row, SparkSession}
  import org.apache.spark.{SparkConf, SparkContext}


  object ClinicianRosterStreamer {
    def main(args: Array[String]): Unit = {

      if (args.length != 2) {
        Logger.log.error("please pass the valid input parameter (inputfilepath properties) file path \n")
        Logger.log.error("Required input file path not found\n")
        Logger.log.error("===========>  exiting program <===========\n")
        System.exit(1)
      }

      val inputFilePath = args(0)
      val propertiesFile = args(1)

      Logger.log.info("InputFile Path: => " + inputFilePath)
      Logger.log.info("propertiesFile: => " + propertiesFile)
      Logger.log.info("Reading the properties File")

      try {
        val startTime = System.currentTimeMillis()
        val prop = new Properties()
        val path = new FileInputStream(propertiesFile)

        try {
          prop.load(path)
        } finally {
          path.close
        }


        val AppName = prop.getProperty("source_type")
        Logger.log.info("source_type =>" + AppName)

        val UUID = prop.getProperty("messageUUID")
        Logger.log.info("uuid =>" + UUID)

        val fileName = prop.getProperty("sourceName")
        Logger.log.info("fileName =>" + fileName)

        val Payload = prop.getProperty("payload")
        Logger.log.info("Payload =>" + Payload)

        val interfaceType = prop.getProperty("interface")
        Logger.log.info("interfaceType =>" + interfaceType)
        val interfaceName = prop.getProperty("interface_type")
        Logger.log.info("interfaceType =>" + interfaceName)

        val topic = prop.getProperty("kafka_topic")
        Logger.log.info("topic Name =>" + topic)

        val server = prop.getProperty("kafka_server")
        Logger.log.info("kafka.bootstrap.servers =>" + server)

        val trustStorePath = prop.getProperty("trust_store_path")
        Logger.log.info("kafka trust store path  =>" + trustStorePath)


        val trustStorePwd = prop.getProperty("trust_store_pwd")

        val scrWriteUser = prop.getProperty("scram_write_user")
        Logger.log.info("kafka scr write user   =>" + server)

        val scrWritePwd = prop.getProperty("scram_write_pwd")

        val scrReadUser = prop.getProperty("scram_read_user")
        Logger.log.info("kafka scr write user   =>" + server)

        val scrReadPwd = prop.getProperty("scram_read_pwd")

        val algorithm = prop.getProperty("algorithm")

        val securityEnabled = prop.getProperty("securityEnabled")

        val retries = prop.getProperty("retries")

        val requestTimeOut = prop.getProperty("requestTimeOut")

        val requestSize = prop.getProperty("requestSize")

        val es_Nodes = prop.getProperty("es_Nodes")
        Logger.log.info("ES nodes =>" + es_Nodes)

        val es_Port = prop.getProperty("es_Port")
        Logger.log.info("ES port =>" + es_Port)

        val es_Index = prop.getProperty("es_Index")
        Logger.log.info("ES index =>" + es_Index)

        val es_user = prop.getProperty("es_user")
        Logger.log.info("ES user =>" + es_user)

        val es_pwd = prop.getProperty("es_pwd")


        val conf = new SparkConf().setAppName("ClinicianRosterStreamer")
        conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        conf.set("spark.driver.cores", prop.getProperty("driver_cores"))
        conf.set("spark.executor.instances", prop.getProperty("executor_instances"))
        conf.set("spark.executor.memory", prop.getProperty("executor_memory"))
        conf.set("spark.driver.memory", prop.getProperty("driver_memory"))
        conf.set("spark.executor.cores", prop.getProperty("executor_cores"))
        conf.set("spark.default.parallelism", prop.getProperty("default_parallelism"))
        conf.set("spark.sql.shuffle.partitions", prop.getProperty("sql_shuffle_partitions"))
        conf.set("spark.yarn.executor.memoryoverhead", prop.getProperty("yarn_executor_memoryoverhead"))
        conf.set("spark.driver.maxResultSize", prop.getProperty("driver_maxResultSize"))
        conf.set("spark.memory.fraction", prop.getProperty("memory_fraction"))
        conf.set("spark.debug.maxToStringFields", prop.getProperty("maxToStringFields"))
        conf.set("spark.es.nodes", es_Nodes)
        conf.set("spark.es.port", es_Port)
        conf.set("spark.es.net.http.auth.user", es_user)
        conf.set("spark.es.net.http.auth.pass", es_pwd)
        conf.set("spark.es.nodes.wan.only", "true")
        conf.set("spark.es.mapping.id", fileName)
        conf.set("spark.es.write.operation", "upsert")
        conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")

        val spark = SparkSession.builder().config(conf).getOrCreate()
        val sc = spark.sparkContext
        import spark.implicits._

        /**
          * Exit if the input Directory is Empty.
          */
        if (Utils.getFilePaths(inputFilePath, sc).length == 0) {
          Logger.log.info(s"Source ${inputFilePath} is Empty or doesn't exist.")
          Logger.log.error("==> ==> ==>  Exiting the Job  <== <== <==")
          System.exit(1)
        }



        /**
          * register an UDF that creates a random ID MED_<timestamp>_<uuid>
          */
        val generateUUID = udf { (srcType: String) => Utils.generateUUID(srcType) }


        //reading file
        val ClnFile = sc.textFile(inputFilePath)

        val ClnFileData = ClnFile.map(x => x.split("\\,", -1)).map(a => Row.fromSeq(a))

        val ClnRecords = spark.createDataFrame(ClnFileData, ClinicianSchema.ClinicianSchema).withColumn("JOB_TITLE",when($"JOB_TITLE".isNull or $"JOB_TITLE" === "", "").otherwise(concat(lit("UHC "),$"JOB_TITLE"))).filter($"ID".notEqual("ID"))

        val currentTimestamp = Utils.getCurrentTimestamp()
        val selection = ClnRecords.columns.map(col)

        val inputColumn = ClnRecords
          .withColumn("payload", concat_ws("|", selection: _*))
          .withColumn("payload",concat($"payload",lit("|"),lit("UHG")))
          .withColumn("filename", input_file_name())
          .withColumn("uuid", generateUUID(lit(AppName)))
          .withColumn("interfaceType", lit(interfaceName))
          .withColumn("createTimestamp", lit(currentTimestamp))
          .withColumn("updateTimestamp", lit(currentTimestamp))


        val data1 = inputColumn.select($"uuid".as(UUID)
          , $"filename".as(fileName)
          , $"interfaceType".as(interfaceType)
          , $"payload".as(Payload)
          , $"createTimestamp"
          , $"updateTimestamp")

        data1.persist()

        val data2 = data1.map {
          case Row(uuid: String, fileName: String ,interface:String, payload:String, createTimestamp:String, updateTimestamp:String) => DebatchMessage(uuid,fileName,interface,payload,createTimestamp,updateTimestamp,MetaData(null,null,null))
        }.as[DebatchMessage].toJSON


        /**
          * Pushing Messages to Kafka
          */
        try {
          Logger.log.info("***** sending Streaming  message to kafka *****")
          if(securityEnabled.equalsIgnoreCase("true")) {

            Utils.writeToSecureTopic(spark, data2, topic, server, trustStorePath, trustStorePwd, scrWriteUser, scrWritePwd, scrReadUser, scrReadPwd, algorithm,requestTimeOut,retries,requestSize)
          }else {
            Utils.writeToTopic(spark, data2, topic, server,requestTimeOut,retries,requestSize)

          }
          Logger.log.info("***** sending Streaming  message  to kafka  completed *****")
        } catch {
          case e: Exception => Logger.log.error("Exception while sending Streaming  message  to kafka " + e.getMessage)
            Logger.log.error(e.printStackTrace())
            throw new RuntimeException("Failed to push records to Kafka. Please check if the provided Cluster details are accurate.")
        }

        /**
          * Elastic Search Summary Indexing
          */
        Utils.writeSummaryToES(data1,interfaceName,es_Index)


        val OutputEndTimeMillis = System.currentTimeMillis()
        val OutputDurationMinutes = OutputEndTimeMillis.-(startTime)./(60000)
        val OutputDurationSeconds = OutputEndTimeMillis.-(startTime)./(1000).%(60)
        Logger.log.info(s"Job Execution Time : $OutputDurationMinutes minutes and $OutputDurationSeconds Seconds")
        Logger.log.info("   ************* END OF Clinician Roster Streamer job ***************\n")
        data1.unpersist()
        sc.stop()
        spark.stop()

      }
    }
  }