package com.uhg.ihr.idz.streamer

import java.io.{File, FileInputStream}
import java.util.Properties

import com.uhg.ihr.idz.common.Logger
import com.uhg.ihr.idz.utils.Utils
import com.uhg.ihr.idz.utils.Utils.{DebatchMessage, MetaData}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.{SparkConf, SparkContext}
import org.elasticsearch.spark.sql._

object MedRxOldPathStreamer {

  def main(args: Array[String]): Unit = {

    if (args.length != 2) {
      Logger.log.info(s"Please Pass the valid input parameters (inputPath,propertiesFile,outputPath) ")
      Logger.log.error("  ==> ==> ==>  Exiting the job  <== <== <== ")
      sys.exit()
    }
    val startTime = System.currentTimeMillis()
    val inputPath = args(0)
    val propertiesFile = args(1)
    Logger.log.error("Input File Path  ==> " + inputPath)
    Logger.log.error("propertiesFile File Path  ==> " + propertiesFile)

    try {
      val FilePath = new File("/mapr" + inputPath)
      val ListOfFiles = FilePath.listFiles.map(x => x.getName)
      Logger.log.info("Number of  file found in input path ==>  " + ListOfFiles.size + " FILES ")
      if (ListOfFiles.isEmpty) {
        Logger.log.info("No file found in input path ==>  " + FilePath)
        Logger.log.error("  ==> ==> ==>  Exiting the job  <== <== <== ")
        sys.exit()
      }
      val prop = new Properties()
      val path = new FileInputStream( propertiesFile)
      try {
        prop.load(path)
      } finally {
        path.close()
      }

      if (prop.isEmpty) {
        Logger.log.error(s"Please pass valid path for  propertiesFile  ==>  $path  ")
        Logger.log.error("  ==> ==> ==>  Exiting the job  <== <== <== ")
        sys.exit(1)
      }

      val AppName = prop.getProperty("source_type").toString
      Logger.log.info("AppName =>" + AppName)

      val UUID = prop.getProperty("messageUUID").toString
      Logger.log.info("uuid =>" + UUID)

      val fileName = prop.getProperty("sourceName").toString
      Logger.log.info("fileName =>" + fileName)

      val Payload = prop.getProperty("payload").toString
      Logger.log.info("Payload =>" + Payload)

      val interfaceType = prop.getProperty("interface").toString
      Logger.log.info("interfaceType =>" + interfaceType)

      val interfaceName = prop.getProperty("interface_type").toString
      Logger.log.info("interfaceType =>" + interfaceName)

      val topic = prop.getProperty("kafka_topic").toString
      Logger.log.info("kafka topic Name =>" + topic)

      val server = prop.getProperty("kafka_server").toString
      Logger.log.info("kafka server name =>" + server)

      val trustStorePath = prop.getProperty("trust_store_path").toString
      Logger.log.info("kafka trust store path  =>" + trustStorePath)


      val trustStorePwd = prop.getProperty("trust_store_pwd").toString

      val scrWriteUser = prop.getProperty("scram_write_user").toString
      Logger.log.info("kafka scr write user   =>" + server)

      val scrWritePwd = prop.getProperty("scram_write_pwd").toString

      val scrReadUser = prop.getProperty("scram_read_user").toString
      Logger.log.info("kafka scr write user   =>" + server)

      val scrReadPwd = prop.getProperty("scram_read_pwd").toString

      val algorithm = prop.getProperty("algorithm").toString

      val securityEnabled = prop.getProperty("securityEnabled").toString

      val retries = prop.getProperty("retries").toString
      val requestTimeOut = prop.getProperty("requestTimeOut").toString
      val requestSize = prop.getProperty("requestSize").toString


      val tranTopic = prop.getProperty("kafka_log_topic").toString
      Logger.log.info("Transaction topic Name =>" + tranTopic)

      val tranServer = prop.getProperty("kafka_log_server").toString
      Logger.log.info("Transaction log Server name =>" + tranServer)

      //Elastic Search conf info
      val es_Nodes = prop.getProperty("es_Nodes").toString
      Logger.log.info("Elastic search node  =>" + es_Nodes)

      val es_Port = prop.getProperty("es_Port").toString
      Logger.log.info("Elastic search port =>" + es_Port)

      val es_Index = prop.getProperty("es_Index").toString
      Logger.log.info("elastic search index tale name =>" + es_Index)

      val es_user = prop.getProperty("es_user").toString
      Logger.log.info("es user Name: => " + es_user)
      val es_pwd = prop.getProperty("es_pwd").toString
      Logger.log.info("es password => " + es_pwd)


      val conf = new SparkConf().setAppName("Old Path Streamer  Job")
      conf.set("spark.driver.cores", prop.getProperty("driver_cores"))
      conf.set("spark.executor.instances", prop.getProperty("executor_instances"))
      conf.set("spark.executor.memory", prop.getProperty("executor_memory"))
      conf.set("spark.driver.memory", prop.getProperty("driver_memory"))
      conf.set("spark.executor.cores", prop.getProperty("executor_cores"))
      conf.set("spark.default.parallelism", prop.getProperty("default_parallelism"))
      conf.set("spark.sql.shuffle.partitions", prop.getProperty("sql_shuffle_partitions"))
      conf.set("spark.yarn.executor.memoryoverhead", prop.getProperty("yarn_executor_memoryoverhead"))
      conf.set("spark.driver.maxResultSize", prop.getProperty("driver_maxResultSize"))
      conf.set("spark.memory.fraction", prop.getProperty("memory_fraction"))
      conf.set("spark.debug.maxToStringFields", prop.getProperty("maxToStringFields"))

      //Elastic search  configuration details
      conf.set("spark.es.nodes", es_Nodes)
      conf.set("spark.es.port", es_Port)
      conf.set("spark.es.net.http.auth.user", es_user)
      conf.set("spark.es.net.http.auth.pass", es_pwd)
      conf.set("spark.es.nodes.wan.only", "true")
      conf.set("spark.es.mapping.id", fileName)
      conf.set("spark.es.write.operation", "upsert")
      conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")

      val sc = new SparkContext(conf)
      val sqlContext = new org.apache.spark.sql.SQLContext(sc)
      val spark = SparkSession.builder().getOrCreate()
      import org.apache.spark.sql.functions._
      import sqlContext.implicits._
      Logger.log.info("***** Configuration details *****" + conf.toDebugString)
      Logger.log.info("********* creating uuid ********")
      /**
        * register an UDF that creates a random ID MED_<timestamp>_<uuid>
        */
      val generateUUID = udf { (srcType: String) => Utils.generateUUID(srcType) }

      Logger.log.info("*********** uuid created  **************")
      Logger.log.info("*********** Reading input file   **************")
      //reading input file one by one
       val inputFile = sc.textFile(inputPath)
      val payloadDF=inputFile.toDF("Payload")

     // val inputFile = spark.read.option("header", "false").option("inferSchema", "false").option("delimiter", "|").csv(s"$inputPath")

      //val payloadDF = inputFile.na.fill("").toDF("Payload")

      Logger.log.info("*********** Reading input file completed  **************")
      val df2 = payloadDF.withColumn("uuid", generateUUID(lit(interfaceName))).withColumn("filename", input_file_name()).withColumn("interfaceType", lit(interfaceName))
      val data1 = df2.select($"uuid".as(UUID), $"filename".as(fileName), $"interfaceType".as(interfaceType), $"payload".as(Payload))
      data1.persist()

      val data2 = data1.map {
        case Row(uuid: String, fileName: String ,interface:String, payload:String, createTimestamp:String, updateTimestamp:String) => DebatchMessage(uuid,fileName,interface,payload,createTimestamp,updateTimestamp,MetaData(null,null,null))
      }.as[DebatchMessage].toJSON

      Logger.log.info("***** Selecting required column created  *****")

      try {
        Logger.log.info("***** sending Streaming  message to kafka *****")
      // Utils.writeToTopic(spark, data1, topic, server)
        if(securityEnabled.equalsIgnoreCase("true")){
          Utils.writeToSecureTopic(spark, data2, topic, server,trustStorePath,trustStorePwd,scrWriteUser,scrWritePwd,scrReadUser,scrReadPwd,algorithm,requestTimeOut,retries,requestSize)
        } else {
          Utils.writeToTopic(spark, data2, topic, server,requestTimeOut,retries,requestSize)

        }
        Logger.log.info("***** sending Streaming  message  to kafka  completed *****")
      } catch {
        case e: Exception => Logger.log.error("Exception while sending Streaming  message  to kafka " :+ e.getMessage)
     //    Utils.writeToTopic(spark, data1, topic, server)
          if(securityEnabled.equalsIgnoreCase("true")){
            Utils.writeToSecureTopic(spark, data2, topic, server,trustStorePath,trustStorePwd,scrWriteUser,scrWritePwd,scrReadUser,scrReadPwd,algorithm,requestTimeOut,retries,requestSize)
          } else {
            Utils.writeToTopic(spark, data2, topic, server,requestTimeOut,retries,requestSize)

          }
      }

      //Transaction indexing configuration

      val streamerStatusColName = prop.getProperty("streamerStatusColName").toString
      Logger.log.info("streamer Status ColumnName =>" + streamerStatusColName)

      val timeStampColName = prop.getProperty("timeStampColName").toString
      Logger.log.info("time Stamp ColumnName =>" + timeStampColName)

      val appNameColName = prop.getProperty("appNameColName").toString
      Logger.log.info("AppName Column Name =>" + appNameColName)

      val appVersionColName = prop.getProperty("appVersionColName").toString
      Logger.log.info("App Version Column Name =>" + appVersionColName)

      val messageColName = prop.getProperty("messageColName").toString
      Logger.log.info("message column Name  =>" + messageColName)

      val applicationName = prop.getProperty("applicationName").toString
      Logger.log.info("application name =>" + applicationName)

      val applicationVersion = prop.getProperty("applicationVersion").toString
      Logger.log.info("application version =>" + applicationVersion)


      val dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
      val tran_index = data1.withColumn("streamer-status", lit("COMPLETE")).withColumn("timestamp", date_format(current_timestamp, dateFormat)).withColumn("appname", lit(applicationName)).withColumn("appversion", lit(applicationVersion))


      Logger.log.info("selecting transction indexing column  =>")
      val tranIndexData = tran_index.select(
        col("timestamp").as(timeStampColName),
        concat(lit("IDZIndexingMessage "), lit("[ "),
          lit("uuid: "), col(UUID), lit(","),
          lit("filename: "), col(fileName), lit(","),
          lit("interfacetype: "), col(interfaceType), lit(","),
          lit(streamerStatusColName + ": "), col("streamer-status"),
          lit(" ]"))
          .as(messageColName),
        col("appname").as(appNameColName),
        col("appversion").as(appVersionColName)).toJSON

      Logger.log.info("selecting transction indexing column complete  =>")

      try {
        Logger.log.info("=========> sending transaction Elastic  Streaming  message to kafka <==============")
        if(securityEnabled.equalsIgnoreCase("true")){
          Utils.writeToSecureTopic(spark, tranIndexData, tranTopic, tranServer,trustStorePath,trustStorePwd,scrWriteUser,scrWritePwd,scrReadUser,scrReadPwd,algorithm,requestTimeOut,retries,requestSize)
        } else {
          Utils.writeToTopic(spark, tranIndexData, tranTopic, tranServer,requestTimeOut,retries,requestSize)

        }
       // Utils.writeToTopic(spark, tranIndexData, tranTopic, tranServer)
        Logger.log.info("===========> sending transaction Elastic  Streaming  message to kafka competed <============")
      } catch {
        case e: Exception => Logger.log.error("Exception while sending transaction Elastic  Streaming  message to kafka" + e.getMessage)
       //   Utils.writeToTopic(spark, tranIndexData, tranTopic, tranServer)
          if(securityEnabled.equalsIgnoreCase("true")){
            Utils.writeToSecureTopic(spark, tranIndexData, tranTopic, tranServer,trustStorePath,trustStorePwd,scrWriteUser,scrWritePwd,scrReadUser,scrReadPwd,algorithm,requestTimeOut,retries,requestSize)
          } else {
            Utils.writeToTopic(spark, tranIndexData, tranTopic, tranServer,requestTimeOut,retries,requestSize)

          }
      }
      //**************TRAN ELASTIC SEARCH  COMPLETE*************************
      //**************ELASTIC SEARCH SUMMERY*************************
      /*
      writing summary level data to Elastic search
       */

      val filename_count = data1.groupBy(fileName).count.withColumnRenamed("count", "noOfRecords")
      val indexedSeq = filename_count.withColumn("timestamp", date_format(current_timestamp, dateFormat)).withColumn("interfaceType", lit(interfaceName).as(interfaceType)).toDF

      try {
        Logger.log.info("  ==> ==> ==>  writing summary    data to ES  starting <== <== <== ")
        indexedSeq.saveToEs(es_Index)
        Logger.log.info("  ==> ==> ==>  writing summary   data to ES  completed <== <== <== ")
      }
      catch {
        case e: Exception => Logger.log.error("Exception at Main oldStreamer   Object" + e.getMessage)
          Logger.log.info("  ==> ==> ==>  writing summary data to ES  starting <== <== <== ")
          indexedSeq.saveToEs(es_Index)
          Logger.log.info("  ==> ==> ==>  writing summary  data to ES  completed <== <== <== ")
      } //catch


      val OutputEndTimeMillis = System.currentTimeMillis()
      val OutputDurationMinutes = OutputEndTimeMillis.-(startTime)./(60000)
      val OutputDurationSeconds = OutputEndTimeMillis.-(startTime)./(1000).%(60)
      Logger.log.info(s"Job Execution Time : $OutputDurationMinutes minutes and $OutputDurationSeconds Seconds")
      Logger.log.info("   ************* END OF MED-RX-OLD PATH STREAMER JOB ***************\n")
      data1.unpersist()
      sc.stop()
      spark.stop()

    } catch {
      case e: Exception => Logger.log.error("Exception at Main pharmacyDebatch  Object" + e.getMessage)
        Logger.log.info(s"exception in main +" + e.printStackTrace())
        throw e
    } //catch
  } //main
} //object
