package com.uhg.ihr.idz.java;


import com.fasterxml.jackson.databind.ObjectMapper;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class IDZKafkaUtil {
    private static Logger LOGGER = LoggerFactory.getLogger(IDZKafkaUtil.class);

    Producer<String, String> producer = null;

    public IDZKafkaUtil(Properties props) {
        try {
            props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
            props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
            producer = new KafkaProducer(props);
        } catch (Exception e) {
            LOGGER.error("Exception occured while initializing KafkaTemplate {}", e.getMessage());
        }
    }

    public boolean sendDummyMessagesToKafka(String topic, long lagForDummyMessage) {

        try {
            IDZDebatchedMessage debatch = new IDZDebatchedMessage();
            debatch.setUuid("DUMMY-" + UUID.randomUUID().toString());
            debatch.setInterfaceType("DUMMY");
            debatch.setFileName("DUMMY-File");
            debatch.setPayload("DUMMY-Payload");

            Instant instant = Instant.now().plus(lagForDummyMessage, ChronoUnit.MINUTES);
            Long timestamp = instant.toEpochMilli();

            ObjectMapper objectMapper = new ObjectMapper();
            String message = objectMapper.valueToTree(debatch).toString();

            List<PartitionInfo> partitionInfos = producer.partitionsFor(topic);
            LOGGER.info("number of paritions for the topic {} is {}", topic, partitionInfos.size());
            for (PartitionInfo partitionInfo : partitionInfos) {
                int paritionNo = partitionInfo.partition();
                ProducerRecord record = new ProducerRecord(topic, paritionNo,timestamp, debatch.getUuid() + paritionNo, message);
                LOGGER.info("ProducerRecord with dummy message {}", record);
                producer.send(record);
            }
            producer.close();
        } catch (Exception e) {
            LOGGER.error("Exception occured while publishing dummy messages to topic {}", e.getMessage());
            return false;
        }
        return true;
    }
}
