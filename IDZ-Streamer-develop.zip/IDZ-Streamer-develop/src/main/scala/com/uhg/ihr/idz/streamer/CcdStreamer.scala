package com.uhg.ihr.idz.streamer

import java.io.{File, FileInputStream}
import java.util.Properties

import com.uhg.ihr.idz.common.Logger
import com.uhg.ihr.idz.utils.Utils
import com.uhg.ihr.idz.utils.Utils.{DebatchMessage, MetaData}
import org.apache.spark.SparkConf
import org.apache.spark.sql.functions.{concat, lit, _}
import org.apache.spark.sql.{Row, SparkSession}
import org.elasticsearch.spark.sql._

object CcdStreamer {

  var SOURCE_TYPE :String = _
  var KAFKA_SERVER :String = _
  var KAFKA_TOPIC :String = _
  var ES_NODES :String = _
  var ES_PORT :String = _
  var ES_INDEX :String = _
  var ES_USER :String = _
  var ES_PWD :String = _
  var TRAN_KAFKA_TOPIC: String = _
  var TRAN_KAFKA_SERVER: String = _
  var trustStorePath: String = _
  var trustStorePwd: String = _
  var scrWriteUser: String = _
  var scrWritePwd: String = _
  var scrReadUser: String = _
  var scrReadPwd: String = _
  var algorithm: String = _
  var securityEnabled: String = _
  var requestTimeOut:String = _
  var retries:String = _
  var requestSize:String = _



  def main(args: Array[String]): Unit = {

    if (args.length != 2) {
      Logger.log.info(s"Please Pass the valid input parameter:\ninputFilePath  \npropertiesFile ")
      System.exit(1)
    }

    //Arguments
    val inputFilePath = args(0)
    val propertiesFile = args(1)



    Logger.log.info("InputFile Path: => " + inputFilePath)
    Logger.log.info("propertiesFile: => " + propertiesFile)

    Logger.log.info("Reading the properties File")
    val processstart = System.currentTimeMillis()
    try {

      val prop = new Properties()
      val path: FileInputStream = new FileInputStream(propertiesFile)

      try {
        prop.load(path)
      } finally {
        path.close
      }

      /**
        *register an UDF that creates a random ID LBS_<timestamp>_<uuid>
        */
      val generateUUID = udf{(srcType:String)=>Utils.generateUUID(srcType)}

      val currentTimestamp = Utils.getCurrentTimestamp()

      SOURCE_TYPE = prop.getProperty("source_type")
      KAFKA_SERVER = prop.getProperty("kafka_server")
      KAFKA_TOPIC = prop.getProperty("kafka_topic")
      ES_NODES = prop.getProperty("es_Nodes")
      ES_PORT = prop.getProperty("es_Port")
      ES_INDEX = prop.getProperty("es_Index")
      ES_USER = prop.getProperty("es_user")
      ES_PWD = prop.getProperty("es_pwd")
      trustStorePath = prop.getProperty("trust_store_path")
      trustStorePwd = prop.getProperty("trust_store_pwd")
      scrWriteUser = prop.getProperty("scram_write_user")
      scrWritePwd = prop.getProperty("scram_write_pwd")
      scrReadUser = prop.getProperty("scram_read_user")
      scrReadPwd = prop.getProperty("scram_read_pwd")
      algorithm = prop.getProperty("algorithm")
      securityEnabled = prop.getProperty("securityEnabled")
      retries = prop.getProperty("retries")
      requestTimeOut = prop.getProperty("requestTimeOut")
      requestSize = prop.getProperty("requestSize")


      Logger.log.info("Elastic Search Nodes : => " + ES_NODES)
      Logger.log.info("Elastic Search Port : => " + ES_PORT)
      Logger.log.info("Elastic Search Index : => " + ES_INDEX)
      Logger.log.info("topic Name =>" + KAFKA_TOPIC)
      Logger.log.info(" server Name =>" +KAFKA_SERVER)
      Logger.log.info("kafka transction topic Name =>" + TRAN_KAFKA_TOPIC)
      Logger.log.info("kafka transction server Name =>" + TRAN_KAFKA_SERVER)


      val uuid = prop.getProperty("messageUUID")
      Logger.log.info("messageUUID: => " + uuid)
      val filename = prop.getProperty("sourceName")
      Logger.log.info("sourceName: => " + filename)

      val interface = prop.getProperty("interface")
      Logger.log.info("interface: => " + interface)
      val payload = prop.getProperty("payload")


      val interfaceType = prop.getProperty("interface_type")
      Logger.log.info("payload: => " + interfaceType)

      val sourceType = prop.getProperty("sourceType")
      Logger.log.info("Source that is Passed is " + sourceType)



      // passing the spark configurations
      val conf = new SparkConf ().setAppName ("ccdStreamer")
      conf.set("spark.driver.cores", prop.getProperty("driver_cores"))
      conf.set("spark.executor.instances", prop.getProperty("executor_instances"))
      conf.set("spark.executor.memory", prop.getProperty("executor_memory"))
      conf.set("spark.driver.memory", prop.getProperty("driver_memory"))
      conf.set("spark.executor.cores", prop.getProperty("executor_cores"))
      conf.set("spark.default.parallelism", prop.getProperty("default_parallelism"))
      conf.set("spark.sql.shuffle.partitions", prop.getProperty("sql_shuffle_partitions"))
      conf.set("spark.yarn.executor.memoryoverhead", prop.getProperty("yarn_executor_memoryoverhead"))
      conf.set("spark.driver.maxResultSize", prop.getProperty("driver_maxResultSize"))
      conf.set("spark.memory.fraction", prop.getProperty("memory_fraction"))
      conf.set("spark.debug.maxToStringFields", prop.getProperty("maxToStringFields"))
      conf.set ( "spark.serializer", "org.apache.spark.serializer.KryoSerializer" )
      conf.set("spark.es.nodes", ES_NODES)
      conf.set("spark.es.port", ES_PORT)
      //use in pro
      conf.set("spark.es.net.http.auth.user", ES_USER)
      conf.set("spark.es.net.http.auth.pass", ES_PWD)
      conf.set("spark.es.nodes.wan.only", "true")
      conf.set("spark.es.mapping.id", filename)
      conf.set("spark.es.write.operation", "upsert")


      // Creating the spark context & session
      val spark = SparkSession.builder().config(conf).getOrCreate()
      val sc = spark.sparkContext
      import spark.implicits._

      /**
        * Exit if the input Directory is Empty.
        */
      if(Utils.getFilePaths(inputFilePath,sc).length == 0){
        Logger.log.info(s"Source ${inputFilePath} is Empty or doesn't exist.")
        Logger.log.error("==> ==> ==>  Exiting the Job  <== <== <==")
        System.exit(1)
      }

      val ListOfFiles: List[String] = Utils.getFilePaths(inputFilePath,sc).map(x => "/mapr/"+x.toString.split("/").drop(3).mkString("/"))
      val xmlsRDD = ListOfFiles.toDF("filename").repartition(15).withColumn("payload", lit("")).withColumn( "uuid", generateUUID(lit(SOURCE_TYPE))).withColumn("interfacename",lit(interfaceType)).withColumn("createTimestamp",lit(currentTimestamp)).withColumn("updateTimestamp",lit(currentTimestamp))


      val data1 = xmlsRDD.select($"uuid".as(uuid), $"filename".as(filename), $"interfacename".as(interface), $"payload".as(payload), $"createTimestamp", $"updateTimestamp")
      data1.persist()

      val data2 = data1.map {
        case Row(uuid: String, fileName: String ,interface:String, payload:String, createTimestamp:String, updateTimestamp:String) => DebatchMessage(uuid,fileName,interface,payload,createTimestamp,updateTimestamp, MetaData(null,null,null))
      }.as[DebatchMessage].toJSON


      /**
        * Pushing Messages to Kafka
        */
      try {
        Logger.log.info("============>  sending Streaming  message to kafka <============")
        if(securityEnabled.equalsIgnoreCase("true")) {
          Utils.writeToSecureTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER, trustStorePath, trustStorePwd, scrWriteUser, scrWritePwd, scrReadUser, scrReadPwd, algorithm,requestTimeOut,retries,requestSize)
        }else {
          Utils.writeToTopic(spark, data2, KAFKA_TOPIC, KAFKA_SERVER,requestTimeOut,retries,requestSize)
        }
        Logger.log.info("============> sending Streaming  message to kafka completed <============")
      } catch {
        case e: Exception => Logger.log.error("Exception while sending Streaming  message to kafka " :+ e.getMessage)
          throw new RuntimeException("Failed to push records to Kafka. Please check if the provided Cluster details are accurate.")
      }


      /**
        * Elastic Search Summary Indexing
        */
      Utils.writeSummaryToES(data1,interfaceType,ES_INDEX)

      val OutputEndTimeMillis = System.currentTimeMillis()
      val OutputDurationMinutes = OutputEndTimeMillis.-(processstart)./(60000)
      val OutputDurationSeconds = OutputEndTimeMillis.-(processstart)./(1000).%(60)
      Logger.log.info(s"Job Execution Time : $OutputDurationMinutes minutes and $OutputDurationSeconds Seconds")
      Logger.log.info("=================== END OF CCD-Streamer JOB =============================\n")


      data1.unpersist()
      sc.stop()
      spark.stop()

      Logger.log.info("==================== Completion of Spark job ==============================\n")
    } catch {

      case e: Exception => {
        Logger.log.info("CCD Streamer process failed: " + e.getMessage)
        System.exit(1)
      }
    }
  }

}
